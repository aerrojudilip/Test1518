package com.example.ldapauth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LdapAuthApplication {
    public static void main(String[] args) {
        SpringApplication.run(LdapAuthApplication.class, args);
    }
}
