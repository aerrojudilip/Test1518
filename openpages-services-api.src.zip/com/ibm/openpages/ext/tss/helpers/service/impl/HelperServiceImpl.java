/*   1:    */ package com.ibm.openpages.ext.tss.helpers.service.impl;
/*   2:    */ 
/*   3:    */ import com.ibm.openpages.ext.tss.helpers.bean.IDXHeaderInfo;
/*   4:    */ import com.ibm.openpages.ext.tss.helpers.bean.IDXHeaderMenuItemInfo;
/*   5:    */ import com.ibm.openpages.ext.tss.helpers.bean.IDXHeaderUserInfo;
/*   6:    */ import com.ibm.openpages.ext.tss.helpers.service.IHelperService;
/*   7:    */ import com.ibm.openpages.ext.tss.service.IApplicationUtil;
/*   8:    */ import com.ibm.openpages.ext.tss.service.ILoggerUtil;
/*   9:    */ import com.ibm.openpages.ext.tss.service.IUserUtil;
/*  10:    */ import com.ibm.openpages.ext.tss.service.util.CommonUtil;
/*  11:    */ import java.util.ArrayList;
/*  12:    */ import java.util.List;
/*  13:    */ import javax.annotation.PostConstruct;
/*  14:    */ import org.apache.commons.logging.Log;
/*  15:    */ import org.springframework.beans.factory.annotation.Autowired;
/*  16:    */ import org.springframework.stereotype.Service;
/*  17:    */ 
/*  18:    */ @Service("commonHelperService")
/*  19:    */ public class HelperServiceImpl
/*  20:    */   implements IHelperService
/*  21:    */ {
/*  22:    */   private Log logger;
/*  23:    */   @Autowired
/*  24:    */   IUserUtil userUtil;
/*  25:    */   @Autowired
/*  26:    */   ILoggerUtil loggerUtil;
/*  27:    */   @Autowired
/*  28:    */   IApplicationUtil applicationUtil;
/*  29:    */   
/*  30:    */   @PostConstruct
/*  31:    */   public void initController()
/*  32:    */   {
/*  33: 45 */     this.logger = this.loggerUtil.getExtLogger();
/*  34:    */   }
/*  35:    */   
/*  36:    */   public IDXHeaderInfo getHelperAppHeaderInfo(String helperAppRootSetting)
/*  37:    */     throws Exception
/*  38:    */   {
/*  39: 56 */     this.logger.error("getHelperAppHeaderInfo() START");
/*  40:    */     
/*  41:    */ 
/*  42: 59 */     int menuItemCount = 1;
/*  43: 60 */     String menuItemsSetting = "";
/*  44: 61 */     String headerInfoSetting = "";
/*  45:    */     
/*  46: 63 */     IDXHeaderInfo idxHeaderInfo = null;
/*  47: 64 */     IDXHeaderUserInfo idxMenuItemUserInfo = null;
/*  48: 65 */     IDXHeaderMenuItemInfo idxMentuItemInfo = null;
/*  49: 66 */     List<IDXHeaderMenuItemInfo> idxMentuItemInfoList = null;
/*  50: 69 */     if (CommonUtil.isNotNullOrEmpty(helperAppRootSetting))
/*  51:    */     {
/*  52: 72 */       headerInfoSetting = helperAppRootSetting + "/Header Info";
/*  53: 73 */       menuItemsSetting = headerInfoSetting + "/Menu Items/Menu Item ";
/*  54: 74 */       idxHeaderInfo = new IDXHeaderInfo();
/*  55: 75 */       idxMenuItemUserInfo = new IDXHeaderUserInfo();
/*  56:    */       
/*  57:    */ 
/*  58: 78 */       idxMenuItemUserInfo.setDisplayName(this.userUtil.getLoggedInUserName());
/*  59:    */       
/*  60:    */ 
/*  61: 81 */       this.logger.info("Header Info Registry Setting: " + headerInfoSetting);
/*  62: 82 */       this.logger.info("Header Info Registry Setting: " + this.applicationUtil.getRegistrySetting(new StringBuilder().append(headerInfoSetting).append("/App Title").toString(), ""));
/*  63:    */       
/*  64: 84 */       idxHeaderInfo.setUserInfo(CommonUtil.isEqualIgnoreCase("true", this.applicationUtil.getRegistrySetting(headerInfoSetting + "/Display User Info", "")));
/*  65: 85 */       idxHeaderInfo.setBannerTitle(this.applicationUtil.getRegistrySetting(headerInfoSetting + "/App Title", ""));
/*  66: 86 */       idxHeaderInfo.setDisplayName(this.applicationUtil.getRegistrySetting(headerInfoSetting + "/Display Name", ""));
/*  67: 87 */       idxHeaderInfo.setPrimaryBannerType(this.applicationUtil.getRegistrySetting(headerInfoSetting + "/Banner Type", ""));
/*  68: 88 */       idxHeaderInfo.setToolTip(CommonUtil.isEqualIgnoreCase("true", this.applicationUtil.getRegistrySetting(headerInfoSetting + "/Show Tool Tip", "")));
/*  69:    */       
/*  70:    */ 
/*  71: 91 */       idxHeaderInfo.setHeaderUserInfo(idxMenuItemUserInfo);
/*  72: 94 */       if (!CommonUtil.isEqualIgnoreCase("No Setting Found", this.applicationUtil.getRegistrySetting(menuItemsSetting + menuItemCount + "/Menu Item Id", "No Setting Found")))
/*  73:    */       {
/*  74: 96 */         idxMentuItemInfoList = new ArrayList();
/*  75: 99 */         while (!CommonUtil.isEqualIgnoreCase("No Setting Found", this.applicationUtil.getRegistrySetting(menuItemsSetting + menuItemCount + "/Menu Item Id", "No Setting Found")))
/*  76:    */         {
/*  77:101 */           idxMentuItemInfo = new IDXHeaderMenuItemInfo();
/*  78:    */           
/*  79:103 */           idxMentuItemInfo.setId(this.applicationUtil.getRegistrySetting(menuItemsSetting + menuItemCount + "/Menu Item Id", ""));
/*  80:104 */           idxMentuItemInfo.setMenuItemLabel(this.applicationUtil.getRegistrySetting(menuItemsSetting + menuItemCount + "/Menu Item Label", ""));
/*  81:105 */           idxMentuItemInfo.setCloseButtonLabel(this.applicationUtil.getRegistrySetting(menuItemsSetting + menuItemCount + "/Close Button Label", ""));
/*  82:106 */           idxMentuItemInfo.setContent(this.applicationUtil.getRegistrySetting(menuItemsSetting + menuItemCount + "/Content", ""));
/*  83:107 */           idxMentuItemInfo.setTitle(this.applicationUtil.getRegistrySetting(menuItemsSetting + menuItemCount + "/Title", ""));
/*  84:108 */           idxMentuItemInfo.setInstruction(this.applicationUtil.getRegistrySetting(menuItemsSetting + menuItemCount + "/Instructions", ""));
/*  85:109 */           idxMentuItemInfo.setDraggable(CommonUtil.isEqualIgnoreCase("true", this.applicationUtil.getRegistrySetting(menuItemsSetting + menuItemCount + "/Draggable", "")));
/*  86:    */           
/*  87:111 */           idxMentuItemInfoList.add(idxMentuItemInfo);
/*  88:112 */           menuItemCount++;
/*  89:    */         }
/*  90:115 */         idxHeaderInfo.setMenuItemsInfo(idxMentuItemInfoList);
/*  91:    */       }
/*  92:    */     }
/*  93:119 */     this.logger.error("Header Information: " + idxHeaderInfo);
/*  94:120 */     this.logger.error("getHelperAppHeaderInfo() END");
/*  95:121 */     return idxHeaderInfo;
/*  96:    */   }
/*  97:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.helpers.service.impl.HelperServiceImpl
 * JD-Core Version:    0.7.0.1
 */