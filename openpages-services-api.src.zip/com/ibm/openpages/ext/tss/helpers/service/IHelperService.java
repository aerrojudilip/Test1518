package com.ibm.openpages.ext.tss.helpers.service;

import com.ibm.openpages.ext.tss.helpers.bean.IDXHeaderInfo;

public abstract interface IHelperService
{
  public abstract IDXHeaderInfo getHelperAppHeaderInfo(String paramString)
    throws Exception;
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.helpers.service.IHelperService
 * JD-Core Version:    0.7.0.1
 */