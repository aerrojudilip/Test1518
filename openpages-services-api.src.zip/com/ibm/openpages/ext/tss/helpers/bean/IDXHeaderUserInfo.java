/*  1:   */ package com.ibm.openpages.ext.tss.helpers.bean;
/*  2:   */ 
/*  3:   */ import java.io.Serializable;
/*  4:   */ 
/*  5:   */ public class IDXHeaderUserInfo
/*  6:   */   implements Serializable
/*  7:   */ {
/*  8:   */   private static final long serialVersionUID = -1215709798334839216L;
/*  9:   */   private String displayName;
/* 10:   */   private String displayImage;
/* 11:   */   
/* 12:   */   public String getDisplayName()
/* 13:   */   {
/* 14:36 */     return this.displayName;
/* 15:   */   }
/* 16:   */   
/* 17:   */   public void setDisplayName(String displayName)
/* 18:   */   {
/* 19:42 */     this.displayName = displayName;
/* 20:   */   }
/* 21:   */   
/* 22:   */   public String getDisplayImage()
/* 23:   */   {
/* 24:48 */     return this.displayImage;
/* 25:   */   }
/* 26:   */   
/* 27:   */   public void setDisplayImage(String displayImage)
/* 28:   */   {
/* 29:54 */     this.displayImage = displayImage;
/* 30:   */   }
/* 31:   */   
/* 32:   */   public String toString()
/* 33:   */   {
/* 34:60 */     StringBuilder sb = new StringBuilder();
/* 35:   */     
/* 36:62 */     sb.append("\n Display Name : " + this.displayName);
/* 37:63 */     sb.append("\n Display Image : " + this.displayImage);
/* 38:64 */     sb.append("\n");
/* 39:   */     
/* 40:66 */     return sb.toString();
/* 41:   */   }
/* 42:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.helpers.bean.IDXHeaderUserInfo
 * JD-Core Version:    0.7.0.1
 */