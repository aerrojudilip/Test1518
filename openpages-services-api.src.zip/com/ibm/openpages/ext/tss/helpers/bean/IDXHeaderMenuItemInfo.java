/*   1:    */ package com.ibm.openpages.ext.tss.helpers.bean;
/*   2:    */ 
/*   3:    */ import java.io.Serializable;
/*   4:    */ 
/*   5:    */ public class IDXHeaderMenuItemInfo
/*   6:    */   implements Serializable
/*   7:    */ {
/*   8:    */   private static final long serialVersionUID = 8214812314787078988L;
/*   9:    */   private boolean draggable;
/*  10:    */   private String id;
/*  11:    */   private String title;
/*  12:    */   private String content;
/*  13:    */   private String instruction;
/*  14:    */   private String closeButtonLabel;
/*  15:    */   private String menuItemLabel;
/*  16:    */   
/*  17:    */   public boolean isDraggable()
/*  18:    */   {
/*  19: 45 */     return this.draggable;
/*  20:    */   }
/*  21:    */   
/*  22:    */   public void setDraggable(boolean draggable)
/*  23:    */   {
/*  24: 51 */     this.draggable = draggable;
/*  25:    */   }
/*  26:    */   
/*  27:    */   public String getId()
/*  28:    */   {
/*  29: 57 */     return this.id;
/*  30:    */   }
/*  31:    */   
/*  32:    */   public void setId(String id)
/*  33:    */   {
/*  34: 63 */     this.id = id;
/*  35:    */   }
/*  36:    */   
/*  37:    */   public String getTitle()
/*  38:    */   {
/*  39: 69 */     return this.title;
/*  40:    */   }
/*  41:    */   
/*  42:    */   public void setTitle(String title)
/*  43:    */   {
/*  44: 75 */     this.title = title;
/*  45:    */   }
/*  46:    */   
/*  47:    */   public String getContent()
/*  48:    */   {
/*  49: 81 */     return this.content;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public void setContent(String content)
/*  53:    */   {
/*  54: 87 */     this.content = content;
/*  55:    */   }
/*  56:    */   
/*  57:    */   public String getInstruction()
/*  58:    */   {
/*  59: 93 */     return this.instruction;
/*  60:    */   }
/*  61:    */   
/*  62:    */   public void setInstruction(String instruction)
/*  63:    */   {
/*  64: 99 */     this.instruction = instruction;
/*  65:    */   }
/*  66:    */   
/*  67:    */   public String getCloseButtonLabel()
/*  68:    */   {
/*  69:105 */     return this.closeButtonLabel;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public void setCloseButtonLabel(String closeButtonLabel)
/*  73:    */   {
/*  74:111 */     this.closeButtonLabel = closeButtonLabel;
/*  75:    */   }
/*  76:    */   
/*  77:    */   public String getMenuItemLabel()
/*  78:    */   {
/*  79:114 */     return this.menuItemLabel;
/*  80:    */   }
/*  81:    */   
/*  82:    */   public void setMenuItemLabel(String menuItemLabel)
/*  83:    */   {
/*  84:117 */     this.menuItemLabel = menuItemLabel;
/*  85:    */   }
/*  86:    */   
/*  87:    */   public String toString()
/*  88:    */   {
/*  89:123 */     StringBuilder sb = new StringBuilder();
/*  90:    */     
/*  91:125 */     sb.append("\n Menu Item Label : " + this.menuItemLabel);
/*  92:126 */     sb.append("\n Is Draggable : " + this.id);
/*  93:127 */     sb.append("\n Menu Item Name : " + this.title);
/*  94:128 */     sb.append("\n Menu Item Content : " + this.content);
/*  95:    */     
/*  96:130 */     sb.append("\n Close Button Lable : " + this.instruction);
/*  97:131 */     sb.append("\n Menu Item Instructions : " + this.draggable);
/*  98:132 */     sb.append("\n Close Button Lable : " + this.closeButtonLabel);
/*  99:133 */     sb.append("\n");
/* 100:    */     
/* 101:135 */     return sb.toString();
/* 102:    */   }
/* 103:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.helpers.bean.IDXHeaderMenuItemInfo
 * JD-Core Version:    0.7.0.1
 */