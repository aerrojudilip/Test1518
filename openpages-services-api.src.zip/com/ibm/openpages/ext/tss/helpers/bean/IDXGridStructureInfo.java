/*  1:   */ package com.ibm.openpages.ext.tss.helpers.bean;
/*  2:   */ 
/*  3:   */ import java.io.Serializable;
/*  4:   */ 
/*  5:   */ public class IDXGridStructureInfo
/*  6:   */   implements Serializable
/*  7:   */ {
/*  8:   */   private static final long serialVersionUID = 7117477219012059392L;
/*  9:   */   private String id;
/* 10:   */   private String field;
/* 11:   */   private String name;
/* 12:   */   
/* 13:   */   public String getId()
/* 14:   */   {
/* 15:39 */     return this.id;
/* 16:   */   }
/* 17:   */   
/* 18:   */   public void setId(String id)
/* 19:   */   {
/* 20:45 */     this.id = id;
/* 21:   */   }
/* 22:   */   
/* 23:   */   public String getField()
/* 24:   */   {
/* 25:51 */     return this.field;
/* 26:   */   }
/* 27:   */   
/* 28:   */   public void setField(String field)
/* 29:   */   {
/* 30:57 */     this.field = field;
/* 31:   */   }
/* 32:   */   
/* 33:   */   public String getName()
/* 34:   */   {
/* 35:63 */     return this.name;
/* 36:   */   }
/* 37:   */   
/* 38:   */   public void setName(String name)
/* 39:   */   {
/* 40:69 */     this.name = name;
/* 41:   */   }
/* 42:   */   
/* 43:   */   public String toString()
/* 44:   */   {
/* 45:75 */     StringBuilder sb = new StringBuilder();
/* 46:   */     
/* 47:77 */     sb.append("\n Id : " + this.id);
/* 48:78 */     sb.append("\n Field : " + this.field);
/* 49:79 */     sb.append("\n Name : " + this.name);
/* 50:80 */     sb.append("\n");
/* 51:   */     
/* 52:82 */     return sb.toString();
/* 53:   */   }
/* 54:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.helpers.bean.IDXGridStructureInfo
 * JD-Core Version:    0.7.0.1
 */