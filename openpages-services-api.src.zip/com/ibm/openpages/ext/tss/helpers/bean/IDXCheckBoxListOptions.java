/*  1:   */ package com.ibm.openpages.ext.tss.helpers.bean;
/*  2:   */ 
/*  3:   */ import java.io.Serializable;
/*  4:   */ 
/*  5:   */ public class IDXCheckBoxListOptions
/*  6:   */   implements Serializable
/*  7:   */ {
/*  8:   */   private static final long serialVersionUID = 4543997132427779427L;
/*  9:   */   private String optionName;
/* 10:   */   private String optionValue;
/* 11:   */   
/* 12:   */   public String getOptionName()
/* 13:   */   {
/* 14:19 */     return this.optionName;
/* 15:   */   }
/* 16:   */   
/* 17:   */   public void setOptionName(String optionName)
/* 18:   */   {
/* 19:25 */     this.optionName = optionName;
/* 20:   */   }
/* 21:   */   
/* 22:   */   public String getOptionValue()
/* 23:   */   {
/* 24:31 */     return this.optionValue;
/* 25:   */   }
/* 26:   */   
/* 27:   */   public void setOptionValue(String optionValue)
/* 28:   */   {
/* 29:37 */     this.optionValue = optionValue;
/* 30:   */   }
/* 31:   */   
/* 32:   */   public String toString()
/* 33:   */   {
/* 34:43 */     StringBuilder sb = new StringBuilder();
/* 35:   */     
/* 36:45 */     sb.append("\n Option Name : " + this.optionName);
/* 37:46 */     sb.append("\n Option Value : " + this.optionValue);
/* 38:47 */     sb.append("\n");
/* 39:   */     
/* 40:49 */     return sb.toString();
/* 41:   */   }
/* 42:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.helpers.bean.IDXCheckBoxListOptions
 * JD-Core Version:    0.7.0.1
 */