/*  1:   */ package com.ibm.openpages.ext.tss.helpers.bean;
/*  2:   */ 
/*  3:   */ import java.io.Serializable;
/*  4:   */ import java.util.List;
/*  5:   */ 
/*  6:   */ public class IDXCheckBoxList
/*  7:   */   implements Serializable
/*  8:   */ {
/*  9:   */   private static final long serialVersionUID = -638936195175436580L;
/* 10:   */   private String id;
/* 11:   */   private String labelAlignment;
/* 12:   */   private String groupAlignment;
/* 13:   */   List<IDXCheckBoxListOptions> checkBoxOptions;
/* 14:   */   
/* 15:   */   public String getId()
/* 16:   */   {
/* 17:21 */     return this.id;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public void setId(String id)
/* 21:   */   {
/* 22:27 */     this.id = id;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public String getLabelAlignment()
/* 26:   */   {
/* 27:33 */     return this.labelAlignment;
/* 28:   */   }
/* 29:   */   
/* 30:   */   public void setLabelAlignment(String labelAlignment)
/* 31:   */   {
/* 32:39 */     this.labelAlignment = labelAlignment;
/* 33:   */   }
/* 34:   */   
/* 35:   */   public String getGroupAlignment()
/* 36:   */   {
/* 37:45 */     return this.groupAlignment;
/* 38:   */   }
/* 39:   */   
/* 40:   */   public void setGroupAlignment(String groupAlignment)
/* 41:   */   {
/* 42:51 */     this.groupAlignment = groupAlignment;
/* 43:   */   }
/* 44:   */   
/* 45:   */   public List<IDXCheckBoxListOptions> getCheckBoxOptions()
/* 46:   */   {
/* 47:57 */     return this.checkBoxOptions;
/* 48:   */   }
/* 49:   */   
/* 50:   */   public void setCheckBoxOptions(List<IDXCheckBoxListOptions> checkBoxOptions)
/* 51:   */   {
/* 52:63 */     this.checkBoxOptions = checkBoxOptions;
/* 53:   */   }
/* 54:   */   
/* 55:   */   public String toString()
/* 56:   */   {
/* 57:69 */     StringBuilder sb = new StringBuilder();
/* 58:   */     
/* 59:71 */     sb.append("\n Id : " + this.id);
/* 60:72 */     sb.append("\n Label Alignment : " + this.labelAlignment);
/* 61:73 */     sb.append("\n Group Alignment : " + this.groupAlignment);
/* 62:74 */     sb.append("\n Check Box Options : " + this.checkBoxOptions);
/* 63:75 */     sb.append("\n");
/* 64:   */     
/* 65:77 */     return sb.toString();
/* 66:   */   }
/* 67:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.helpers.bean.IDXCheckBoxList
 * JD-Core Version:    0.7.0.1
 */