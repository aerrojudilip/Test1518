/*   1:    */ package com.ibm.openpages.ext.tss.helpers.bean;
/*   2:    */ 
/*   3:    */ import java.io.Serializable;
/*   4:    */ 
/*   5:    */ public class HelperAppResultsInfo
/*   6:    */   implements Serializable
/*   7:    */ {
/*   8:    */   private static final long serialVersionUID = -2689992357990047386L;
/*   9:    */   private boolean isWarning;
/*  10:    */   private boolean isException;
/*  11:    */   private String id;
/*  12:    */   private String resultsHeader;
/*  13:    */   private String resultsContent;
/*  14:    */   private String errorMessage;
/*  15:    */   private String errorStackTrace;
/*  16:    */   
/*  17:    */   public boolean isWarning()
/*  18:    */   {
/*  19: 45 */     return this.isWarning;
/*  20:    */   }
/*  21:    */   
/*  22:    */   public void setWarning(boolean isWarning)
/*  23:    */   {
/*  24: 51 */     this.isWarning = isWarning;
/*  25:    */   }
/*  26:    */   
/*  27:    */   public boolean isException()
/*  28:    */   {
/*  29: 57 */     return this.isException;
/*  30:    */   }
/*  31:    */   
/*  32:    */   public void setException(boolean isException)
/*  33:    */   {
/*  34: 63 */     this.isException = isException;
/*  35:    */   }
/*  36:    */   
/*  37:    */   public String getId()
/*  38:    */   {
/*  39: 69 */     return this.id;
/*  40:    */   }
/*  41:    */   
/*  42:    */   public void setId(String id)
/*  43:    */   {
/*  44: 75 */     this.id = id;
/*  45:    */   }
/*  46:    */   
/*  47:    */   public String getResultsHeader()
/*  48:    */   {
/*  49: 81 */     return this.resultsHeader;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public void setResultsHeader(String resultsHeader)
/*  53:    */   {
/*  54: 87 */     this.resultsHeader = resultsHeader;
/*  55:    */   }
/*  56:    */   
/*  57:    */   public String getResultsContent()
/*  58:    */   {
/*  59: 93 */     return this.resultsContent;
/*  60:    */   }
/*  61:    */   
/*  62:    */   public void setResultsContent(String resultsContent)
/*  63:    */   {
/*  64: 99 */     this.resultsContent = resultsContent;
/*  65:    */   }
/*  66:    */   
/*  67:    */   public String getErrorMessage()
/*  68:    */   {
/*  69:105 */     return this.errorMessage;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public void setErrorMessage(String errorMessage)
/*  73:    */   {
/*  74:111 */     this.errorMessage = errorMessage;
/*  75:    */   }
/*  76:    */   
/*  77:    */   public String getErrorStackTrace()
/*  78:    */   {
/*  79:117 */     return this.errorStackTrace;
/*  80:    */   }
/*  81:    */   
/*  82:    */   public void setErrorStackTrace(String errorStackTrace)
/*  83:    */   {
/*  84:123 */     this.errorStackTrace = errorStackTrace;
/*  85:    */   }
/*  86:    */   
/*  87:    */   public String toString()
/*  88:    */   {
/*  89:129 */     StringBuilder sb = new StringBuilder();
/*  90:    */     
/*  91:131 */     sb.append("\n Id: " + this.id);
/*  92:132 */     sb.append("\n Is Warning: " + this.isWarning);
/*  93:133 */     sb.append("\n Is Exception: " + this.isException);
/*  94:134 */     sb.append("\n Results Header: " + this.resultsHeader);
/*  95:135 */     sb.append("\n Results Content: " + this.resultsContent);
/*  96:136 */     sb.append("\n Error Message: " + this.errorMessage);
/*  97:137 */     sb.append("\n Error Stack Trace: " + this.errorStackTrace);
/*  98:    */     
/*  99:139 */     return sb.toString();
/* 100:    */   }
/* 101:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.helpers.bean.HelperAppResultsInfo
 * JD-Core Version:    0.7.0.1
 */