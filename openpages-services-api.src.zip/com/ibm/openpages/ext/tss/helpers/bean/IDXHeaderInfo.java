/*   1:    */ package com.ibm.openpages.ext.tss.helpers.bean;
/*   2:    */ 
/*   3:    */ import java.io.Serializable;
/*   4:    */ import java.util.List;
/*   5:    */ 
/*   6:    */ public class IDXHeaderInfo
/*   7:    */   implements Serializable
/*   8:    */ {
/*   9:    */   private static final long serialVersionUID = 7192782048546317524L;
/*  10:    */   private boolean isToolTip;
/*  11:    */   private boolean isUserInfo;
/*  12:    */   private boolean isDraggable;
/*  13:    */   private String id;
/*  14:    */   private String bannerTitle;
/*  15:    */   private String tooltipInfo;
/*  16:    */   private String displayName;
/*  17:    */   private String tooltipTitle;
/*  18:    */   private String instructions;
/*  19:    */   private String closeButtonLabel;
/*  20:    */   private String primaryBannerType;
/*  21:    */   private IDXHeaderUserInfo headerUserInfo;
/*  22:    */   private List<IDXHeaderMenuItemInfo> menuItemsInfo;
/*  23:    */   
/*  24:    */   public boolean isToolTip()
/*  25:    */   {
/*  26: 52 */     return this.isToolTip;
/*  27:    */   }
/*  28:    */   
/*  29:    */   public void setToolTip(boolean isToolTip)
/*  30:    */   {
/*  31: 58 */     this.isToolTip = isToolTip;
/*  32:    */   }
/*  33:    */   
/*  34:    */   public boolean isUserInfo()
/*  35:    */   {
/*  36: 64 */     return this.isUserInfo;
/*  37:    */   }
/*  38:    */   
/*  39:    */   public void setUserInfo(boolean isUserInfo)
/*  40:    */   {
/*  41: 70 */     this.isUserInfo = isUserInfo;
/*  42:    */   }
/*  43:    */   
/*  44:    */   public boolean isDraggable()
/*  45:    */   {
/*  46: 76 */     return this.isDraggable;
/*  47:    */   }
/*  48:    */   
/*  49:    */   public void setDraggable(boolean isDraggable)
/*  50:    */   {
/*  51: 82 */     this.isDraggable = isDraggable;
/*  52:    */   }
/*  53:    */   
/*  54:    */   public String getId()
/*  55:    */   {
/*  56: 88 */     return this.id;
/*  57:    */   }
/*  58:    */   
/*  59:    */   public void setId(String id)
/*  60:    */   {
/*  61: 94 */     this.id = id;
/*  62:    */   }
/*  63:    */   
/*  64:    */   public String getBannerTitle()
/*  65:    */   {
/*  66:100 */     return this.bannerTitle;
/*  67:    */   }
/*  68:    */   
/*  69:    */   public void setBannerTitle(String bannerTitle)
/*  70:    */   {
/*  71:106 */     this.bannerTitle = bannerTitle;
/*  72:    */   }
/*  73:    */   
/*  74:    */   public String getTooltipInfo()
/*  75:    */   {
/*  76:112 */     return this.tooltipInfo;
/*  77:    */   }
/*  78:    */   
/*  79:    */   public void setTooltipInfo(String tooltipInfo)
/*  80:    */   {
/*  81:118 */     this.tooltipInfo = tooltipInfo;
/*  82:    */   }
/*  83:    */   
/*  84:    */   public String getDisplayName()
/*  85:    */   {
/*  86:124 */     return this.displayName;
/*  87:    */   }
/*  88:    */   
/*  89:    */   public void setDisplayName(String displayName)
/*  90:    */   {
/*  91:130 */     this.displayName = displayName;
/*  92:    */   }
/*  93:    */   
/*  94:    */   public String getTooltipTitle()
/*  95:    */   {
/*  96:136 */     return this.tooltipTitle;
/*  97:    */   }
/*  98:    */   
/*  99:    */   public void setTooltipTitle(String tooltipTitle)
/* 100:    */   {
/* 101:142 */     this.tooltipTitle = tooltipTitle;
/* 102:    */   }
/* 103:    */   
/* 104:    */   public String getInstructions()
/* 105:    */   {
/* 106:148 */     return this.instructions;
/* 107:    */   }
/* 108:    */   
/* 109:    */   public void setInstructions(String instructions)
/* 110:    */   {
/* 111:154 */     this.instructions = instructions;
/* 112:    */   }
/* 113:    */   
/* 114:    */   public String getCloseButtonLabel()
/* 115:    */   {
/* 116:160 */     return this.closeButtonLabel;
/* 117:    */   }
/* 118:    */   
/* 119:    */   public void setCloseButtonLabel(String closeButtonLabel)
/* 120:    */   {
/* 121:166 */     this.closeButtonLabel = closeButtonLabel;
/* 122:    */   }
/* 123:    */   
/* 124:    */   public String getPrimaryBannerType()
/* 125:    */   {
/* 126:172 */     return this.primaryBannerType;
/* 127:    */   }
/* 128:    */   
/* 129:    */   public void setPrimaryBannerType(String primaryBannerType)
/* 130:    */   {
/* 131:178 */     this.primaryBannerType = primaryBannerType;
/* 132:    */   }
/* 133:    */   
/* 134:    */   public IDXHeaderUserInfo getHeaderUserInfo()
/* 135:    */   {
/* 136:184 */     return this.headerUserInfo;
/* 137:    */   }
/* 138:    */   
/* 139:    */   public void setHeaderUserInfo(IDXHeaderUserInfo headerUserInfo)
/* 140:    */   {
/* 141:190 */     this.headerUserInfo = headerUserInfo;
/* 142:    */   }
/* 143:    */   
/* 144:    */   public List<IDXHeaderMenuItemInfo> getMenuItemsInfo()
/* 145:    */   {
/* 146:196 */     return this.menuItemsInfo;
/* 147:    */   }
/* 148:    */   
/* 149:    */   public void setMenuItemsInfo(List<IDXHeaderMenuItemInfo> menuItemsInfo)
/* 150:    */   {
/* 151:202 */     this.menuItemsInfo = menuItemsInfo;
/* 152:    */   }
/* 153:    */   
/* 154:    */   public String toString()
/* 155:    */   {
/* 156:210 */     StringBuilder sb = new StringBuilder();
/* 157:    */     
/* 158:212 */     sb.append("\n Is Tool Tip : " + this.isToolTip);
/* 159:213 */     sb.append("\n Is User Info : " + this.isUserInfo);
/* 160:214 */     sb.append("\n Is Draggable : " + this.isDraggable);
/* 161:    */     
/* 162:216 */     sb.append("\n Id : " + this.id);
/* 163:217 */     sb.append("\n Banner Title : " + this.bannerTitle);
/* 164:218 */     sb.append("\n Tool Tip Info : " + this.tooltipInfo);
/* 165:219 */     sb.append("\n Display Name : " + this.displayName);
/* 166:220 */     sb.append("\n Instructions : " + this.instructions);
/* 167:221 */     sb.append("\n Tool Tip Title : " + this.tooltipTitle);
/* 168:222 */     sb.append("\n Close Button Label : " + this.closeButtonLabel);
/* 169:223 */     sb.append("\n Primary Banner Type : " + this.primaryBannerType);
/* 170:224 */     sb.append("\n Header User Info : " + this.headerUserInfo);
/* 171:225 */     sb.append("\n Menu Items: " + this.menuItemsInfo);
/* 172:226 */     sb.append("\n");
/* 173:    */     
/* 174:228 */     return sb.toString();
/* 175:    */   }
/* 176:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.helpers.bean.IDXHeaderInfo
 * JD-Core Version:    0.7.0.1
 */