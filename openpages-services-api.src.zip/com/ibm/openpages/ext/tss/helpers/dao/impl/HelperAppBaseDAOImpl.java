/*   1:    */ package com.ibm.openpages.ext.tss.helpers.dao.impl;
/*   2:    */ 
/*   3:    */ import com.ibm.openpages.ext.tss.helpers.dao.IHelperAppBaseDAO;
/*   4:    */ import com.ibm.openpages.ext.tss.service.ILoggerUtil;
/*   5:    */ import com.ibm.openpages.ext.tss.service.util.CommonUtil;
/*   6:    */ import java.sql.CallableStatement;
/*   7:    */ import java.sql.Connection;
/*   8:    */ import java.sql.ResultSet;
/*   9:    */ import java.sql.Statement;
/*  10:    */ import javax.annotation.PostConstruct;
/*  11:    */ import javax.sql.DataSource;
/*  12:    */ import org.apache.commons.logging.Log;
/*  13:    */ import org.springframework.beans.factory.annotation.Autowired;
/*  14:    */ import org.springframework.stereotype.Service;
/*  15:    */ 
/*  16:    */ @Service("helperAppBaseDAO")
/*  17:    */ public class HelperAppBaseDAOImpl
/*  18:    */   implements IHelperAppBaseDAO
/*  19:    */ {
/*  20:    */   public Log logger;
/*  21:    */   @Autowired
/*  22:    */   ILoggerUtil loggerUtil;
/*  23:    */   @Autowired
/*  24:    */   DataSource dataAccessConfig;
/*  25:    */   
/*  26:    */   @PostConstruct
/*  27:    */   public void intDAO()
/*  28:    */   {
/*  29: 39 */     this.logger = this.loggerUtil.getExtLogger();
/*  30:    */   }
/*  31:    */   
/*  32:    */   public Connection getConnection()
/*  33:    */     throws Exception
/*  34:    */   {
/*  35: 53 */     return this.dataAccessConfig.getConnection();
/*  36:    */   }
/*  37:    */   
/*  38:    */   public void closeConnection(Connection connection)
/*  39:    */     throws Exception
/*  40:    */   {
/*  41: 66 */     this.logger.info("closeConnection() START");
/*  42:    */     try
/*  43:    */     {
/*  44: 70 */       this.logger.info("Is connection not null? " + CommonUtil.isObjectNotNull(connection));
/*  45: 71 */       if (CommonUtil.isObjectNotNull(connection))
/*  46:    */       {
/*  47: 73 */         this.logger.info("Closing Connection...");
/*  48: 74 */         connection.close();
/*  49:    */       }
/*  50:    */     }
/*  51:    */     catch (Exception ex)
/*  52:    */     {
/*  53: 79 */       this.logger.error("Error closing connection: " + CommonUtil.getStackTrace(ex));
/*  54:    */     }
/*  55:    */     finally
/*  56:    */     {
/*  57: 83 */       connection = null;
/*  58:    */     }
/*  59: 86 */     this.logger.info("closeConnection() END");
/*  60:    */   }
/*  61:    */   
/*  62:    */   public void clearCallableStatement(CallableStatement stmt)
/*  63:    */     throws Exception
/*  64:    */   {
/*  65: 97 */     this.logger.info("clearCallableStatement() START");
/*  66: 99 */     if (CommonUtil.isObjectNotNull(stmt)) {
/*  67:    */       try
/*  68:    */       {
/*  69:103 */         stmt.close();
/*  70:    */       }
/*  71:    */       catch (Exception ex)
/*  72:    */       {
/*  73:107 */         this.logger.error("Error closing statement: " + CommonUtil.getStackTrace(ex));
/*  74:    */       }
/*  75:    */       finally
/*  76:    */       {
/*  77:110 */         stmt = null;
/*  78:    */       }
/*  79:    */     }
/*  80:114 */     this.logger.info("clearCallableStatement() END");
/*  81:    */   }
/*  82:    */   
/*  83:    */   public void clearStatement(Statement stmt)
/*  84:    */     throws Exception
/*  85:    */   {
/*  86:125 */     this.logger.info("clearStatement() START");
/*  87:127 */     if (CommonUtil.isObjectNotNull(stmt)) {
/*  88:    */       try
/*  89:    */       {
/*  90:131 */         stmt.close();
/*  91:    */       }
/*  92:    */       catch (Exception ex)
/*  93:    */       {
/*  94:135 */         this.logger.error("Error closing statement: " + CommonUtil.getStackTrace(ex));
/*  95:    */       }
/*  96:    */       finally
/*  97:    */       {
/*  98:138 */         stmt = null;
/*  99:    */       }
/* 100:    */     }
/* 101:142 */     this.logger.info("clearStatement() END");
/* 102:    */   }
/* 103:    */   
/* 104:    */   public void clearResultSet(ResultSet resultSet)
/* 105:    */     throws Exception
/* 106:    */   {
/* 107:153 */     this.logger.info("clearResultSet() START");
/* 108:155 */     if (CommonUtil.isObjectNotNull(resultSet)) {
/* 109:    */       try
/* 110:    */       {
/* 111:159 */         resultSet.close();
/* 112:    */       }
/* 113:    */       catch (Exception ex)
/* 114:    */       {
/* 115:163 */         this.logger.error("Error closing Result Set: " + CommonUtil.getStackTrace(ex));
/* 116:    */       }
/* 117:    */       finally
/* 118:    */       {
/* 119:166 */         resultSet = null;
/* 120:    */       }
/* 121:    */     }
/* 122:170 */     this.logger.info("clearResultSet() END");
/* 123:    */   }
/* 124:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.helpers.dao.impl.HelperAppBaseDAOImpl
 * JD-Core Version:    0.7.0.1
 */