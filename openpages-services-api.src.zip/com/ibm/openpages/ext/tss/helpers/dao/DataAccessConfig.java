/*  1:   */ package com.ibm.openpages.ext.tss.helpers.dao;
/*  2:   */ 
/*  3:   */ import com.ibm.openpages.ext.tss.service.util.CommonUtil;
/*  4:   */ import com.openpages.apps.common.util.AppEnv;
/*  5:   */ import com.openpages.tool.encrypt.CryptUtil;
/*  6:   */ import java.io.IOException;
/*  7:   */ import java.io.PrintStream;
/*  8:   */ import javax.sql.DataSource;
/*  9:   */ import org.apache.commons.dbcp.BasicDataSource;
/* 10:   */ import org.springframework.context.annotation.Bean;
/* 11:   */ import org.springframework.context.annotation.ComponentScan;
/* 12:   */ import org.springframework.context.annotation.Configuration;
/* 13:   */ import org.springframework.transaction.annotation.EnableTransactionManagement;
/* 14:   */ 
/* 15:   */ @Configuration
/* 16:   */ @EnableTransactionManagement
/* 17:   */ @ComponentScan
/* 18:   */ public class DataAccessConfig
/* 19:   */ {
/* 20:   */   @Bean
/* 21:   */   public DataSource dataSource()
/* 22:   */     throws Exception
/* 23:   */   {
/* 24:27 */     BasicDataSource ds = null;
/* 25:   */     try
/* 26:   */     {
/* 27:31 */       String dburl = AppEnv.getProperty("database.URL");
/* 28:32 */       String username = AppEnv.getProperty("database.USERID");
/* 29:33 */       String password = AppEnv.getProperty("database.PASSWORD");
/* 30:34 */       String pwd = CryptUtil.decrypt(password);
/* 31:   */       
/* 32:36 */       System.out.println("DataAccessConfig DB URL: " + dburl);
/* 33:37 */       System.out.println("DataAccessConfig Username: " + username);
/* 34:38 */       System.out.println("DataAccessConfig Password: " + pwd);
/* 35:39 */       System.out.println("DataAccessConfig Driver Class Name: " + AppEnv.getProperty("database.DRIVER"));
/* 36:   */       
/* 37:41 */       ds = new BasicDataSource();
/* 38:42 */       ds.setDriverClassName(AppEnv.getProperty("database.DRIVER"));
/* 39:43 */       ds.setUrl(dburl);
/* 40:44 */       ds.setUsername(username);
/* 41:45 */       ds.setPassword(pwd);
/* 42:   */     }
/* 43:   */     catch (IOException ioex)
/* 44:   */     {
/* 45:49 */       System.out.println("DataAccessConfig Exception reading properties from aurora.properties: " + CommonUtil.getStackTrace(ioex));
/* 46:50 */       throw ioex;
/* 47:   */     }
/* 48:   */     catch (Exception ex)
/* 49:   */     {
/* 50:54 */       System.out.println("DataAccessConfig Exception!!!!!: " + CommonUtil.getStackTrace(ex));
/* 51:55 */       throw ex;
/* 52:   */     }
/* 53:59 */     return ds;
/* 54:   */   }
/* 55:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.helpers.dao.DataAccessConfig
 * JD-Core Version:    0.7.0.1
 */