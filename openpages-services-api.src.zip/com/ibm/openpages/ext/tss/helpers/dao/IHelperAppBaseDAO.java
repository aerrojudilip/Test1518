package com.ibm.openpages.ext.tss.helpers.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public abstract interface IHelperAppBaseDAO
{
  public abstract Connection getConnection()
    throws Exception;
  
  public abstract void closeConnection(Connection paramConnection)
    throws Exception;
  
  public abstract void clearCallableStatement(CallableStatement paramCallableStatement)
    throws Exception;
  
  public abstract void clearStatement(Statement paramStatement)
    throws Exception;
  
  public abstract void clearResultSet(ResultSet paramResultSet)
    throws Exception;
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.helpers.dao.IHelperAppBaseDAO
 * JD-Core Version:    0.7.0.1
 */