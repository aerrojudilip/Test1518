/*  1:   */ package com.ibm.openpages.ext.tss.helpers.dao.impl;
/*  2:   */ 
/*  3:   */ import com.ibm.openpages.ext.tss.service.ILoggerUtil;
/*  4:   */ import com.ibm.openpages.ext.tss.service.util.CommonUtil;
/*  5:   */ import java.sql.Connection;
/*  6:   */ import javax.sql.DataSource;
/*  7:   */ import org.apache.commons.logging.Log;
/*  8:   */ import org.springframework.beans.factory.annotation.Autowired;
/*  9:   */ 
/* 10:   */ public class BaseDAOImpl
/* 11:   */ {
/* 12:   */   public Log logger;
/* 13:   */   public Connection connection;
/* 14:   */   @Autowired
/* 15:   */   ILoggerUtil loggerUtil;
/* 16:   */   @Autowired
/* 17:   */   DataSource dataAccessConfig;
/* 18:   */   
/* 19:   */   public void initLogger()
/* 20:   */   {
/* 21:31 */     this.logger = this.loggerUtil.getExtLogger();
/* 22:   */   }
/* 23:   */   
/* 24:   */   public Connection getConnection()
/* 25:   */     throws Exception
/* 26:   */   {
/* 27:38 */     if (CommonUtil.isObjectNotNull(this.connection)) {
/* 28:39 */       return this.connection;
/* 29:   */     }
/* 30:41 */     return this.dataAccessConfig.getConnection();
/* 31:   */   }
/* 32:   */   
/* 33:   */   public void closeConnection()
/* 34:   */   {
/* 35:51 */     this.logger.debug("closeConnection() START");
/* 36:   */     try
/* 37:   */     {
/* 38:55 */       this.logger.debug("Is connection not null? " + CommonUtil.isObjectNotNull(this.connection));
/* 39:56 */       if (CommonUtil.isObjectNotNull(this.connection))
/* 40:   */       {
/* 41:58 */         this.logger.info("Closing Connection...");
/* 42:59 */         this.connection.close();
/* 43:   */       }
/* 44:   */     }
/* 45:   */     catch (Exception ex)
/* 46:   */     {
/* 47:64 */       this.logger.error("Error closing connection: " + CommonUtil.getStackTrace(ex));
/* 48:   */     }
/* 49:   */     finally
/* 50:   */     {
/* 51:68 */       this.connection = null;
/* 52:   */     }
/* 53:71 */     this.logger.debug("closeConnection() END");
/* 54:   */   }
/* 55:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.helpers.dao.impl.BaseDAOImpl
 * JD-Core Version:    0.7.0.1
 */