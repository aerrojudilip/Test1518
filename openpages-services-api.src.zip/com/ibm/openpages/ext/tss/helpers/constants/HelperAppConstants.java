package com.ibm.openpages.ext.tss.helpers.constants;

public class HelperAppConstants
{
  public static final String HELPER_APP_TITLE = "/App Title";
  public static final String HELPER_BANNER_TYPE = "/Banner Type";
  public static final String IS_SHOW_TOOL_TIP = "/Show Tool Tip";
  public static final String HELPER_DISPLAY_NAME = "/Display Name";
  public static final String IS_DISPLAY_USER_INFO = "/Display User Info";
  public static final String MENU_ITEM_TITLE = "/Title";
  public static final String MENU_ITEM_CONTENT = "/Content";
  public static final String HELPER_MENU_ITEM_ID = "/Menu Item Id";
  public static final String IS_MENU_ITEM_DRAGGABLE = "/Draggable";
  public static final String MENU_ITEM_INSTRUCTIONS = "/Instructions";
  public static final String HELPER_MENU_ITEM_LABEL = "/Menu Item Label";
  public static final String MENU_ITEM_CLOSE_BUTTON_LABEL = "/Close Button Label";
  public static final String HEADER_INFO_SETTINGS_PATH = "/Header Info";
  public static final String MENU_ITEMS_SETTINGS_PATH = "/Menu Items/Menu Item ";
  public static final String HELPERAPP_CONFIG_INSTANCE_EXCEPTION = "Expecting instance of HelperAppConfig";
  public static final String SYSTEM_RESOURCEID_FIELD = "System Fields:Resource ID";
  public static final String MIME_TYPE_JSON = "application/json";
  public static final String OPERATION_NOT_ALLOWED = "This operation is not allowed.";
  public static final String UNABLE_TO_SAVE = "Unable to save configuration due to FATAL issues.";
  public static final String BODY_CONTENT_ONLY = "bodyContentOnly";
  public static final String HAS_SYNTAX_ERROR = "hasSyntaxError";
  public static final String HAS_CONFIG_ERROR = "hasConfigError";
  public static final String ERROR_DETAILS = "errorDetails";
  public static final String DECK_CONGFIG_ISSUES = "deckConfigIssues";
  public static final String VALIDATION_RESULTS = "validationResults";
  public static final String COLUMN_NAMES = "columnNames";
  public static final String ORIGINAL_RESOURCE_ID = "OriginalResourceId";
  public static final String RESULTS_SUCESSFUL = "SUCCESSFUL";
  public static final String RESULTS_NOT_SUCCESSFUL = "NOT SUCCESSFUL";
  public static final String COPY_OPERATION_SUCESSFUL = "Copy was Successful";
  public static final String IDENTIFIER = "id";
  public static final String LIST_OF_FIELDS = "listOfFields";
  public static final String GRID_VALUES = "gridValues";
  public static final String BLANK = "";
  public static final String SPACE = " ";
  public static final String COMMA = ",";
  public static final String SEPARATOR = "_SEPARATOR_";
  public static final String SEMICOLON = ";";
  public static final String PIPESPLITER = "\\|";
  public static final String TILDAPLACEHOLDER = "~";
  public static final String PARAM_HELPERTYPE = "helperType";
  public static final String OBJECT_NOT_FOUND_EXCEPTION = "com.exception.profile.object.type.not.found";
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.helpers.constants.HelperAppConstants
 * JD-Core Version:    0.7.0.1
 */