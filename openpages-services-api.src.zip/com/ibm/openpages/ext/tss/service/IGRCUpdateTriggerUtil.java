package com.ibm.openpages.ext.tss.service;

import com.ibm.openpages.ext.tss.service.beans.IGRCObjectUpdateInformation;

public abstract interface IGRCUpdateTriggerUtil
{
  public abstract void initService();
  
  public abstract boolean updateObject(IGRCObjectUpdateInformation paramIGRCObjectUpdateInformation);
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.IGRCUpdateTriggerUtil
 * JD-Core Version:    0.7.0.1
 */