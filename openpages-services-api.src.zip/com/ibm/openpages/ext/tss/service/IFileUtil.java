package com.ibm.openpages.ext.tss.service;

public abstract interface IFileUtil
{
  public abstract String copyFile(String paramString1, String paramString2)
    throws Exception;
  
  public abstract String copyFile(String paramString1, String paramString2, String paramString3)
    throws Exception;
  
  public abstract void deleteFile(String paramString)
    throws Exception;
  
  public abstract String getFileNameWithoutExtension(String paramString);
  
  public abstract String getFileNameWithExtension(String paramString);
  
  public abstract String getFileExtension(String paramString);
  
  public abstract String getMimeType(String paramString);
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.IFileUtil
 * JD-Core Version:    0.7.0.1
 */