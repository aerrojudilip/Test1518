package com.ibm.openpages.ext.tss.service;

import com.ibm.openpages.api.resource.IDateField;
import com.ibm.openpages.api.resource.IField;
import com.ibm.openpages.api.resource.IGRCObject;
import java.util.Date;

public abstract interface IDateFieldUtil
{
  public abstract void initService();
  
  public abstract IDateField getDateField(IField paramIField)
    throws Exception;
  
  public abstract IDateField getDateField(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract boolean isDateFieldNull(IField paramIField)
    throws Exception;
  
  public abstract boolean isDateFieldNull(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract boolean isDateFieldNotNull(IField paramIField)
    throws Exception;
  
  public abstract boolean isDateFieldNotNull(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract boolean isDateFieldValueNull(IField paramIField)
    throws Exception;
  
  public abstract boolean isDateFieldValueNull(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract boolean isDateFieldValueNotNull(IField paramIField)
    throws Exception;
  
  public abstract boolean isDateFieldValueNotNull(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract String getDateFieldValueInSpecificFormat(IField paramIField, String paramString)
    throws Exception;
  
  public abstract String getDateFieldValueAsString(IField paramIField)
    throws Exception;
  
  public abstract String getDateFieldValueInSpecificFormat(IGRCObject paramIGRCObject, String paramString1, String paramString2)
    throws Exception;
  
  public abstract String getDateFieldValueAsString(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract Date getDateFieldValue(IField paramIField)
    throws Exception;
  
  public abstract Date getDateFieldValue(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract void setDateField(IGRCObject paramIGRCObject, String paramString1, String paramString2)
    throws Exception;
  
  public abstract void setDateField(IDateField paramIDateField, String paramString)
    throws Exception;
  
  public abstract void setDateField(IDateField paramIDateField, Date paramDate)
    throws Exception;
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.IDateFieldUtil
 * JD-Core Version:    0.7.0.1
 */