package com.ibm.openpages.ext.tss.service;

import com.ibm.openpages.api.metadata.IEnumValue;
import com.ibm.openpages.api.metadata.IFieldDefinition;
import com.ibm.openpages.api.resource.IField;
import com.ibm.openpages.api.resource.IGRCObject;
import com.ibm.openpages.api.resource.IMultiEnumField;
import com.ibm.openpages.ext.tss.service.constants.CheckFor;
import java.util.List;

public abstract interface IMultiEnumFieldUtil
{
  public abstract void initService();
  
  public abstract IMultiEnumField getEnumField(IField paramIField)
    throws Exception;
  
  public abstract IMultiEnumField getEnumField(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract boolean isEnumFieldNull(IField paramIField)
    throws Exception;
  
  public abstract boolean isEnumFieldNull(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract boolean isEnumFieldNotNull(IField paramIField)
    throws Exception;
  
  public abstract boolean isEnumFieldNotNull(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract boolean isEnumFieldValueNull(IField paramIField)
    throws Exception;
  
  public abstract boolean isEnumFieldValueNull(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract boolean isEnumFieldValueNotNull(IField paramIField)
    throws Exception;
  
  public abstract boolean isEnumFieldValueNotNull(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract List<IEnumValue> getEnumFieldValues(IField paramIField)
    throws Exception;
  
  public abstract List<IEnumValue> getEnumFieldValues(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract List<String> getEnumFieldSelectedValue(IField paramIField)
    throws Exception;
  
  public abstract List<String> getEnumFieldSelectedValue(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract List<String> getAllValuesInEnumFieldAsList(IFieldDefinition paramIFieldDefinition)
    throws Exception;
  
  public abstract List<String> getActiveValuesInEnumFieldAsList(IFieldDefinition paramIFieldDefinition)
    throws Exception;
  
  public abstract List<String> getHiddenValuesInEnumFieldAsList(IFieldDefinition paramIFieldDefinition)
    throws Exception;
  
  public abstract List<String> getAllValuesInEnumFieldAsList(IField paramIField)
    throws Exception;
  
  public abstract List<String> getAllValuesInEnumFieldAsList(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract List<String> getActiveValuesInEnumFieldAsList(IField paramIField)
    throws Exception;
  
  public abstract List<String> getActiveValuesInEnumFieldAsList(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract List<String> getHiddenValuesInEnumFieldAsList(IField paramIField)
    throws Exception;
  
  public abstract List<String> getHiddenValuesInEnumFieldAsList(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract boolean isEnumFieldValueMatchExpectedValue(IField paramIField, String paramString, CheckFor paramCheckFor)
    throws Exception;
  
  public abstract boolean isEnumFieldValueMatchExpectedValue(IGRCObject paramIGRCObject, String paramString1, String paramString2, CheckFor paramCheckFor)
    throws Exception;
  
  public abstract void setEnumFieldValue(IField paramIField, String paramString)
    throws Exception;
  
  public abstract void setEnumFieldValue(IGRCObject paramIGRCObject, String paramString1, String paramString2)
    throws Exception;
  
  public abstract void setEnumFieldValue(IField paramIField, List<IEnumValue> paramList)
    throws Exception;
  
  public abstract void setEnumFieldValue(IGRCObject paramIGRCObject, String paramString, List<IEnumValue> paramList)
    throws Exception;
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.IMultiEnumFieldUtil
 * JD-Core Version:    0.7.0.1
 */