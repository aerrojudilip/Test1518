/*   1:    */ package com.ibm.openpages.ext.tss.service.util;
/*   2:    */ 
/*   3:    */ import com.ibm.openpages.ext.tss.service.constants.CommonConstants;
/*   4:    */ import com.openpages.aurora.util.FileIOUtil;
/*   5:    */ import java.io.File;
/*   6:    */ import java.util.Map;
/*   7:    */ 
/*   8:    */ public class FileUtil
/*   9:    */ {
/*  10:    */   public static String copyFile(String newFileNamePrefix, String absoluteSourceFileName)
/*  11:    */     throws Exception
/*  12:    */   {
/*  13: 40 */     String fileName = "";
/*  14: 41 */     String fileDirectoryPath = "";
/*  15:    */     
/*  16:    */ 
/*  17: 44 */     fileName = absoluteSourceFileName.substring(absoluteSourceFileName.lastIndexOf("\\") + 1);
/*  18: 45 */     fileDirectoryPath = absoluteSourceFileName.substring(0, absoluteSourceFileName.lastIndexOf("\\") + 1);
/*  19:    */     
/*  20: 47 */     return copyFile(newFileNamePrefix, fileDirectoryPath, fileName);
/*  21:    */   }
/*  22:    */   
/*  23:    */   public static String copyFile(String prefix, String sourceFilePath, String sourceFileName)
/*  24:    */     throws Exception
/*  25:    */   {
/*  26: 66 */     File destFile = null;
/*  27: 67 */     File sourceFile = null;
/*  28: 68 */     FileIOUtil fileIOUtil = null;
/*  29:    */     
/*  30:    */ 
/*  31: 71 */     fileIOUtil = new FileIOUtil();
/*  32: 72 */     sourceFile = new File(sourceFilePath + sourceFileName);
/*  33: 73 */     destFile = new File(sourceFilePath + prefix + sourceFileName);
/*  34:    */     
/*  35: 75 */     fileIOUtil.copyFile(sourceFile, destFile, true);
/*  36: 76 */     return destFile.getAbsolutePath();
/*  37:    */   }
/*  38:    */   
/*  39:    */   public static void deleteFile(String filePath)
/*  40:    */     throws Exception
/*  41:    */   {
/*  42: 90 */     File file = null;
/*  43: 91 */     FileIOUtil fileIOUtil = null;
/*  44:    */     
/*  45:    */ 
/*  46: 94 */     fileIOUtil = new FileIOUtil();
/*  47: 95 */     file = new File(filePath);
/*  48: 96 */     fileIOUtil.deleteFile(file);
/*  49:    */   }
/*  50:    */   
/*  51:    */   public static String getFileNameWithoutExtension(String filePath)
/*  52:    */   {
/*  53:115 */     int index = 0;
/*  54:116 */     String fileName = "";
/*  55:119 */     if (CommonUtil.isNotNullOrEmpty(filePath))
/*  56:    */     {
/*  57:121 */       index = filePath.lastIndexOf("/");
/*  58:122 */       if (index > 0)
/*  59:    */       {
/*  60:124 */         fileName = filePath.substring(index + 1, filePath.length());
/*  61:125 */         index = fileName.lastIndexOf(".");
/*  62:126 */         if (index > 0) {
/*  63:128 */           fileName = fileName.substring(0, index);
/*  64:    */         }
/*  65:    */       }
/*  66:    */       else
/*  67:    */       {
/*  68:132 */         index = filePath.lastIndexOf("//");
/*  69:133 */         if (index > 0)
/*  70:    */         {
/*  71:135 */           fileName = filePath.substring(index + 1, filePath.length());
/*  72:136 */           index = fileName.lastIndexOf(".");
/*  73:137 */           if (index > 0) {
/*  74:139 */             fileName = fileName.substring(0, index);
/*  75:    */           }
/*  76:    */         }
/*  77:    */         else
/*  78:    */         {
/*  79:143 */           index = filePath.lastIndexOf("\\");
/*  80:145 */           if (index > 0)
/*  81:    */           {
/*  82:147 */             fileName = filePath.substring(index + 1, filePath.length());
/*  83:148 */             index = fileName.lastIndexOf(".");
/*  84:149 */             if (index > 0) {
/*  85:151 */               fileName = fileName.substring(0, index);
/*  86:    */             }
/*  87:    */           }
/*  88:    */         }
/*  89:    */       }
/*  90:    */     }
/*  91:160 */     return fileName;
/*  92:    */   }
/*  93:    */   
/*  94:    */   public static String getFileNameWithExtension(String filePath)
/*  95:    */   {
/*  96:175 */     int index = 0;
/*  97:176 */     String fileName = "";
/*  98:179 */     if (CommonUtil.isNotNullOrEmpty(filePath))
/*  99:    */     {
/* 100:181 */       index = filePath.lastIndexOf("/");
/* 101:182 */       if (index > 0)
/* 102:    */       {
/* 103:184 */         fileName = filePath.substring(index + 1, filePath.length());
/* 104:    */       }
/* 105:    */       else
/* 106:    */       {
/* 107:187 */         index = filePath.lastIndexOf("//");
/* 108:188 */         if (index > 0)
/* 109:    */         {
/* 110:190 */           fileName = filePath.substring(index + 1, filePath.length());
/* 111:    */         }
/* 112:    */         else
/* 113:    */         {
/* 114:193 */           index = filePath.lastIndexOf("\\");
/* 115:195 */           if (index > 0) {
/* 116:197 */             fileName = filePath.substring(index + 1, filePath.length());
/* 117:    */           }
/* 118:    */         }
/* 119:    */       }
/* 120:    */     }
/* 121:204 */     return fileName;
/* 122:    */   }
/* 123:    */   
/* 124:    */   public static String getFileExtension(String filename)
/* 125:    */   {
/* 126:219 */     int index = 0;
/* 127:220 */     String extension = "";
/* 128:223 */     if (CommonUtil.isNotNullOrEmpty(filename))
/* 129:    */     {
/* 130:225 */       index = filename.lastIndexOf(".");
/* 131:226 */       if (index > 0) {
/* 132:228 */         extension = filename.substring(index + 1, filename.length());
/* 133:    */       }
/* 134:    */     }
/* 135:232 */     return extension;
/* 136:    */   }
/* 137:    */   
/* 138:    */   public static String getMimeType(String fileNameOrPath)
/* 139:    */   {
/* 140:244 */     return (CommonUtil.isNotNullOrEmpty(fileNameOrPath)) && (CommonUtil.isNotNullOrEmpty(getFileExtension(fileNameOrPath))) ? (String)CommonConstants.FILE_EXTENSION_TO_FILE_MIME_TYPES_MAP.get(getFileExtension(fileNameOrPath)) : "";
/* 141:    */   }
/* 142:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.util.FileUtil
 * JD-Core Version:    0.7.0.1
 */