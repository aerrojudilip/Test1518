/*   1:    */ package com.ibm.openpages.ext.tss.service.util;
/*   2:    */ 
/*   3:    */ import com.openpages.apps.common.i18n.I18NClient;
/*   4:    */ import com.openpages.aurora.common.Environment;
/*   5:    */ import com.openpages.aurora.common.logging.LoggerFactory;
/*   6:    */ import java.io.File;
/*   7:    */ import javax.servlet.http.HttpServletRequest;
/*   8:    */ import org.apache.commons.logging.Log;
/*   9:    */ import org.apache.log4j.Level;
/*  10:    */ import org.apache.log4j.Logger;
/*  11:    */ import org.apache.log4j.PatternLayout;
/*  12:    */ import org.apache.log4j.RollingFileAppender;
/*  13:    */ 
/*  14:    */ public class LoggerUtil
/*  15:    */ {
/*  16:    */   private static final String CLASS_NAME = "LoggerUtil";
/*  17:    */   private static final String DEBUG_LEVEL_REGISTRY_ENTRY = "/OpenPages/Custom Deliverables/Logging/Enabled";
/*  18: 35 */   private static final String FILE_SEPARATOR = System.getProperty("file.separator");
/*  19:    */   private static final int MAX_LOG_BACKUP_FILES = 200;
/*  20:    */   private static final String MAX_LOG_FILE_SIZE = "128KB";
/*  21:    */   private static final int LOG_IO_BUFFER_SIZE_BYTES = 1024;
/*  22: 39 */   private static final String OPENPAGES_HOME = Environment.getOpenpagesHomeDir();
/*  23: 40 */   private static final String LOG_DIR = OPENPAGES_HOME + FILE_SEPARATOR + "aurora" + FILE_SEPARATOR + "logs" + FILE_SEPARATOR + "ext";
/*  24:    */   private static final boolean APPEND = true;
/*  25:    */   private static final String PATTERN = "%-5p[%d](%F:%L)%n%m%n%n";
/*  26:    */   private static final String LOG_FILENAME = "services.log";
/*  27:    */   private static Logger extLogger;
/*  28:    */   
/*  29:    */   public static Logger getEXTLogger()
/*  30:    */     throws Exception
/*  31:    */   {
/*  32: 54 */     String file = "";
/*  33: 55 */     String debugLevel = "";
/*  34: 56 */     File logDir = null;
/*  35: 57 */     File logFile = null;
/*  36: 58 */     Level level = null;
/*  37: 59 */     PatternLayout layout = null;
/*  38: 60 */     RollingFileAppender rollingFileAppender = null;
/*  39:    */     
/*  40:    */ 
/*  41:    */ 
/*  42:    */ 
/*  43:    */ 
/*  44: 66 */     debugLevel = "true";
/*  45: 67 */     level = Level.ALL;
/*  46:    */     try
/*  47:    */     {
/*  48: 72 */       if (CommonUtil.isObjectNull(extLogger))
/*  49:    */       {
/*  50: 73 */         LoggerFactory.getLogger().error("services.log logger is null - trying to init it...");
/*  51: 74 */         extLogger = Logger.getLogger("services.log");
/*  52:    */         
/*  53:    */ 
/*  54:    */ 
/*  55:    */ 
/*  56:    */ 
/*  57: 80 */         logDir = new File(LOG_DIR);
/*  58: 81 */         logDir.mkdirs();
/*  59: 82 */         logFile = new File(logDir, String.format("%s%s", new Object[] { FILE_SEPARATOR, "services.log" }));
/*  60: 83 */         file = logFile.getCanonicalPath();
/*  61:    */         
/*  62:    */ 
/*  63: 86 */         layout = new PatternLayout("%-5p[%d](%F:%L)%n%m%n%n");
/*  64: 87 */         rollingFileAppender = new RollingFileAppender(layout, file, true);
/*  65:    */         
/*  66:    */ 
/*  67:    */ 
/*  68:    */ 
/*  69:    */ 
/*  70:    */ 
/*  71:    */ 
/*  72:    */ 
/*  73:    */ 
/*  74:    */ 
/*  75:    */ 
/*  76:    */ 
/*  77:    */ 
/*  78:    */ 
/*  79:    */ 
/*  80:    */ 
/*  81:    */ 
/*  82:    */ 
/*  83:106 */         extLogger.addAppender(rollingFileAppender);
/*  84:    */       }
/*  85:    */     }
/*  86:    */     catch (Exception e)
/*  87:    */     {
/*  88:111 */       LoggerFactory.getLogger().info("could not init custom logger - " + e.getMessage());
/*  89:    */     }
/*  90:    */     finally
/*  91:    */     {
/*  92:114 */       LoggerFactory.getLogger().info("Init custom logger Successfully - see " + file);
/*  93:    */     }
/*  94:119 */     extLogger.setLevel(level);
/*  95:120 */     return extLogger;
/*  96:    */   }
/*  97:    */   
/*  98:    */   public static void debugEXTLog(String className, String methodName, String name, Object message)
/*  99:    */   {
/* 100:135 */     String logMessage = "";
/* 101:    */     try
/* 102:    */     {
/* 103:139 */       logMessage = CommonUtil.isObjectNotNull(message) ? message.toString() : "Null";
/* 104:140 */       getEXTLogger().debug("[ " + className + " ] [ " + methodName + " ] [ " + name + "] : " + logMessage);
/* 105:    */     }
/* 106:    */     catch (Exception ex)
/* 107:    */     {
/* 108:143 */       debug("LoggerUtil", "debugEXTLog()", " Error while Logging EXT debug", CommonUtil.getStackTrace(ex));
/* 109:    */     }
/* 110:    */   }
/* 111:    */   
/* 112:    */   public static void errorEXTLog(String className, String methodName, String name, Object message)
/* 113:    */   {
/* 114:160 */     String logMessage = "";
/* 115:    */     try
/* 116:    */     {
/* 117:164 */       logMessage = CommonUtil.isObjectNotNull(message) ? message.toString() : "Null";
/* 118:165 */       getEXTLogger().error("[ " + className + " ] [ " + methodName + " ] [ " + name + "] : " + logMessage);
/* 119:    */     }
/* 120:    */     catch (Exception ex)
/* 121:    */     {
/* 122:168 */       error("LoggerUtil", "errorEXTLog()", " Error while Logging EXT Error", CommonUtil.getStackTrace(ex));
/* 123:    */     }
/* 124:    */   }
/* 125:    */   
/* 126:    */   public static void infoEXTLog(String className, String methodName, String name, Object message)
/* 127:    */   {
/* 128:186 */     String logMessage = "";
/* 129:    */     try
/* 130:    */     {
/* 131:190 */       logMessage = CommonUtil.isObjectNotNull(message) ? message.toString() : "Null";
/* 132:191 */       getEXTLogger().info("[ " + className + " ] [ " + methodName + " ] [ " + name + "] : " + logMessage);
/* 133:    */     }
/* 134:    */     catch (Exception ex)
/* 135:    */     {
/* 136:194 */       error("LoggerUtil", "infoEXTLog()", " Error while Logging EXT Info", CommonUtil.getStackTrace(ex));
/* 137:    */     }
/* 138:    */   }
/* 139:    */   
/* 140:    */   public static void fatalEXTLog(String className, String methodName, String name, Object message)
/* 141:    */   {
/* 142:211 */     String logMessage = "";
/* 143:    */     try
/* 144:    */     {
/* 145:215 */       logMessage = CommonUtil.isObjectNotNull(message) ? message.toString() : "Null";
/* 146:216 */       getEXTLogger().fatal("[ " + className + " ] [ " + methodName + " ] [ " + name + "] : " + logMessage);
/* 147:    */     }
/* 148:    */     catch (Exception ex)
/* 149:    */     {
/* 150:219 */       error("LoggerUtil", "fatalEXTLog()", " Error while Logging EXT Fatal", CommonUtil.getStackTrace(ex));
/* 151:    */     }
/* 152:    */   }
/* 153:    */   
/* 154:    */   public static void debug(String className, String methodName, String name, Object message)
/* 155:    */   {
/* 156:235 */     String logMessage = "";
/* 157:    */     
/* 158:237 */     logMessage = CommonUtil.isObjectNotNull(message) ? message.toString() : "Null";
/* 159:238 */     LoggerFactory.getLogger().debug("[ " + className + " ] [ " + methodName + " ] [ " + name + "] : " + logMessage);
/* 160:    */   }
/* 161:    */   
/* 162:    */   public static void error(String className, String methodName, String name, Object message)
/* 163:    */   {
/* 164:254 */     String logMessage = "";
/* 165:    */     
/* 166:256 */     logMessage = CommonUtil.isObjectNotNull(message) ? message.toString() : "Null";
/* 167:257 */     LoggerFactory.getLogger().error("[ " + className + " ] [ " + methodName + " ] [ " + name + "] : " + logMessage);
/* 168:    */   }
/* 169:    */   
/* 170:    */   public static void info(String className, String methodName, String name, Object message)
/* 171:    */   {
/* 172:274 */     String logMessage = "";
/* 173:    */     
/* 174:276 */     logMessage = CommonUtil.isObjectNotNull(message) ? message.toString() : "Null";
/* 175:277 */     LoggerFactory.getLogger().info("[ " + className + " ] [ " + methodName + " ] [ " + name + "] : " + logMessage);
/* 176:    */   }
/* 177:    */   
/* 178:    */   public static void fatal(String className, String methodName, String name, Object message)
/* 179:    */   {
/* 180:293 */     String logMessage = "";
/* 181:    */     
/* 182:295 */     logMessage = CommonUtil.isObjectNotNull(message) ? message.toString() : "Null";
/* 183:296 */     LoggerFactory.getLogger().fatal("[ " + className + " ] [ " + methodName + " ] [ " + name + "] : " + logMessage);
/* 184:    */   }
/* 185:    */   
/* 186:    */   public static void logMessageFromAppString(HttpServletRequest request, String appStringKey)
/* 187:    */   {
/* 188:311 */     String logMessage = "";
/* 189:    */     try
/* 190:    */     {
/* 191:316 */       logMessage = I18NClient.getApplicationText(appStringKey, request);
/* 192:317 */       LoggerFactory.getLogger().info(logMessage);
/* 193:    */     }
/* 194:    */     catch (Exception ex)
/* 195:    */     {
/* 196:321 */       LoggerFactory.getLogger().error(ex);
/* 197:    */     }
/* 198:    */   }
/* 199:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.util.LoggerUtil
 * JD-Core Version:    0.7.0.1
 */