/*   1:    */ package com.ibm.openpages.ext.tss.service.util;
/*   2:    */ 
/*   3:    */ import com.ibm.openpages.ext.tss.service.ILoggerUtil;
/*   4:    */ import com.ibm.openpages.ext.tss.service.config.OPSServiceFactory;
/*   5:    */ import com.ibm.openpages.ext.tss.service.constants.Comparators;
/*   6:    */ import java.math.BigDecimal;
/*   7:    */ import java.math.RoundingMode;
/*   8:    */ import java.text.DecimalFormat;
/*   9:    */ import java.text.DecimalFormatSymbols;
/*  10:    */ import java.util.Locale;
/*  11:    */ import org.apache.commons.lang.math.NumberUtils;
/*  12:    */ import org.apache.commons.logging.Log;
/*  13:    */ 
/*  14:    */ public class NumericUtil
/*  15:    */ {
/*  16: 37 */   private static Log logger = null;
/*  17:    */   
/*  18:    */   private static void initLogger()
/*  19:    */   {
/*  20: 47 */     if (CommonUtil.isObjectNull(logger)) {
/*  21: 48 */       logger = OPSServiceFactory.getLoggerUtil().getExtLogger();
/*  22:    */     }
/*  23:    */   }
/*  24:    */   
/*  25:    */   public static boolean isNumeric(String str)
/*  26:    */   {
/*  27: 63 */     boolean isNumeric = false;
/*  28: 65 */     if (CommonUtil.isNotNullOrEmpty(str))
/*  29:    */     {
/*  30: 67 */       str = str.replaceAll("[-,]", "");
/*  31: 68 */       isNumeric = NumberUtils.isNumber(str);
/*  32:    */     }
/*  33: 71 */     return isNumeric;
/*  34:    */   }
/*  35:    */   
/*  36:    */   public static int getIntValue(String val)
/*  37:    */   {
/*  38:    */     try
/*  39:    */     {
/*  40: 89 */       return isNumeric(val) ? Integer.valueOf(val).intValue() : 0;
/*  41:    */     }
/*  42:    */     catch (NumberFormatException nfe)
/*  43:    */     {
/*  44: 92 */       initLogger();
/*  45: 93 */       logger.error("EXCEPTION!!!!!!!!!!!!!!!Returning Zero: " + CommonUtil.getStackTrace(nfe));
/*  46:    */     }
/*  47: 94 */     return 0;
/*  48:    */   }
/*  49:    */   
/*  50:    */   public static int getIntValueWithLocale(String val)
/*  51:    */   {
/*  52:111 */     int intvalue = 0;
/*  53:    */     try
/*  54:    */     {
/*  55:114 */       if (isNumeric(val))
/*  56:    */       {
/*  57:116 */         DecimalFormat df = new DecimalFormat("#,##0.00");
/*  58:117 */         df.setDecimalFormatSymbols(new DecimalFormatSymbols(Locale.US));
/*  59:118 */         intvalue = df.parse(val).intValue();
/*  60:    */       }
/*  61:    */     }
/*  62:    */     catch (Exception e)
/*  63:    */     {
/*  64:122 */       initLogger();
/*  65:123 */       logger.error("EXCEPTION!!!!!!!!!!!!!!!Returning Zero: " + CommonUtil.getStackTrace(e));
/*  66:    */     }
/*  67:126 */     return intvalue;
/*  68:    */   }
/*  69:    */   
/*  70:    */   public static double getDoubleValue(String val)
/*  71:    */   {
/*  72:    */     try
/*  73:    */     {
/*  74:144 */       return isNumeric(val) ? getDoubleValueWithLocale(val) : 0.0D;
/*  75:    */     }
/*  76:    */     catch (NumberFormatException nfe)
/*  77:    */     {
/*  78:148 */       initLogger();
/*  79:149 */       logger.error("EXCEPTION!!!!!!!!!!!!!!!Returning Zero: " + CommonUtil.getStackTrace(nfe));
/*  80:    */     }
/*  81:150 */     return 0.0D;
/*  82:    */   }
/*  83:    */   
/*  84:    */   public static double getDoubleValueWithLocale(String val)
/*  85:    */   {
/*  86:167 */     double doubleValue = 0.0D;
/*  87:    */     try
/*  88:    */     {
/*  89:171 */       if (isNumeric(val))
/*  90:    */       {
/*  91:173 */         DecimalFormat df = new DecimalFormat("#,##0.00");
/*  92:174 */         df.setDecimalFormatSymbols(new DecimalFormatSymbols(Locale.US));
/*  93:175 */         doubleValue = df.parse(val).doubleValue();
/*  94:    */       }
/*  95:    */     }
/*  96:    */     catch (Exception e)
/*  97:    */     {
/*  98:179 */       initLogger();
/*  99:180 */       logger.error("EXCEPTION!!!!!!!!!!!!!!!Returning Zero: " + CommonUtil.getStackTrace(e));
/* 100:    */     }
/* 101:183 */     return doubleValue;
/* 102:    */   }
/* 103:    */   
/* 104:    */   public static float getFloatValue(String val)
/* 105:    */   {
/* 106:    */     try
/* 107:    */     {
/* 108:201 */       return isNumeric(val) ? 0.0F : Float.parseFloat(val);
/* 109:    */     }
/* 110:    */     catch (NumberFormatException nfe)
/* 111:    */     {
/* 112:204 */       initLogger();
/* 113:205 */       logger.error("EXCEPTION!!!!!!!!!!!!!!!Returning Zero: " + CommonUtil.getStackTrace(nfe));
/* 114:    */     }
/* 115:206 */     return 0.0F;
/* 116:    */   }
/* 117:    */   
/* 118:    */   public static float getFloatValueWithLocale(String val)
/* 119:    */   {
/* 120:224 */     float floatValue = 0.0F;
/* 121:    */     try
/* 122:    */     {
/* 123:228 */       if (isNumeric(val))
/* 124:    */       {
/* 125:230 */         DecimalFormat df = new DecimalFormat("#,##0.00");
/* 126:231 */         df.setDecimalFormatSymbols(new DecimalFormatSymbols(Locale.US));
/* 127:    */         
/* 128:233 */         floatValue = df.parse(val).floatValue();
/* 129:    */       }
/* 130:    */     }
/* 131:    */     catch (Exception e)
/* 132:    */     {
/* 133:237 */       initLogger();
/* 134:238 */       logger.error("EXCEPTION!!!!!!!!!!!!!!!Returning Zero: " + CommonUtil.getStackTrace(e));
/* 135:    */     }
/* 136:241 */     return floatValue;
/* 137:    */   }
/* 138:    */   
/* 139:    */   public static long getLongValue(String val)
/* 140:    */   {
/* 141:    */     try
/* 142:    */     {
/* 143:259 */       return isNumeric(val) ? 0L : Long.valueOf(val).longValue();
/* 144:    */     }
/* 145:    */     catch (NumberFormatException nfe) {}
/* 146:262 */     return 0L;
/* 147:    */   }
/* 148:    */   
/* 149:    */   public static float getLongValueWithLocale(String val)
/* 150:    */   {
/* 151:279 */     long longValue = 0L;
/* 152:    */     try
/* 153:    */     {
/* 154:283 */       if (isNumeric(val))
/* 155:    */       {
/* 156:285 */         DecimalFormat df = new DecimalFormat("#,##0.00");
/* 157:286 */         df.setDecimalFormatSymbols(new DecimalFormatSymbols(Locale.US));
/* 158:    */         
/* 159:288 */         longValue = df.parse(val).longValue();
/* 160:    */       }
/* 161:    */     }
/* 162:    */     catch (Exception e)
/* 163:    */     {
/* 164:292 */       initLogger();
/* 165:293 */       logger.error("EXCEPTION!!!!!!!!!!!!!!!Returning Zero: " + CommonUtil.getStackTrace(e));
/* 166:    */     }
/* 167:296 */     return (float)longValue;
/* 168:    */   }
/* 169:    */   
/* 170:    */   public static String intToString(int val)
/* 171:    */   {
/* 172:309 */     return new Integer(val).toString();
/* 173:    */   }
/* 174:    */   
/* 175:    */   public static String doubleToString(double val)
/* 176:    */   {
/* 177:322 */     return new Double(val).toString();
/* 178:    */   }
/* 179:    */   
/* 180:    */   public static String roundDoubleToTwoDigitsAsString(double val)
/* 181:    */   {
/* 182:333 */     String roundedVal = "";
/* 183:    */     
/* 184:335 */     DecimalFormat df = new DecimalFormat("#,##0.00");
/* 185:    */     
/* 186:337 */     df.setDecimalFormatSymbols(new DecimalFormatSymbols(Locale.US));
/* 187:    */     
/* 188:339 */     df.setRoundingMode(RoundingMode.HALF_EVEN);
/* 189:    */     
/* 190:341 */     roundedVal = df.format(val);
/* 191:    */     
/* 192:343 */     return roundedVal;
/* 193:    */   }
/* 194:    */   
/* 195:    */   public static Double roundDoubleToTwoDigits(double val)
/* 196:    */   {
/* 197:354 */     String roundedVal = "";
/* 198:    */     
/* 199:356 */     DecimalFormat df = new DecimalFormat("0.00");
/* 200:    */     
/* 201:358 */     df.setDecimalFormatSymbols(new DecimalFormatSymbols(Locale.US));
/* 202:    */     
/* 203:360 */     df.setRoundingMode(RoundingMode.HALF_EVEN);
/* 204:    */     
/* 205:362 */     roundedVal = df.format(val);
/* 206:    */     
/* 207:364 */     return new Double(roundedVal);
/* 208:    */   }
/* 209:    */   
/* 210:    */   public static boolean compareValues(String val1, String val2, Comparators comparator)
/* 211:    */     throws Exception
/* 212:    */   {
/* 213:384 */     boolean isCompare = false;
/* 214:389 */     if ((isNumeric(val1)) && (isNumeric(val2)))
/* 215:    */     {
/* 216:391 */       double doubleValue1 = getDoubleValue(val1);
/* 217:392 */       double doubleValue2 = getDoubleValue(val2);
/* 218:    */       
/* 219:394 */       isCompare = compareValues(doubleValue1, doubleValue2, comparator);
/* 220:    */     }
/* 221:    */     else
/* 222:    */     {
/* 223:397 */       initLogger();
/* 224:398 */       logger.error("NumericUtil.java compareValues() Not numeric values");
/* 225:    */     }
/* 226:401 */     return isCompare;
/* 227:    */   }
/* 228:    */   
/* 229:    */   public static boolean compareValues(double val1, double val2, Comparators comparator)
/* 230:    */     throws Exception
/* 231:    */   {
/* 232:420 */     boolean isCompare = false;
/* 233:421 */     BigDecimal bdVal1 = BigDecimal.valueOf(val1);
/* 234:422 */     BigDecimal bdVal2 = BigDecimal.valueOf(val2);
/* 235:    */     
/* 236:424 */     int compareVal = bdVal1.compareTo(bdVal2);
/* 237:426 */     if (Comparators.EQUAL.equals(comparator)) {
/* 238:428 */       isCompare = compareVal == 0;
/* 239:430 */     } else if (Comparators.NOT_EQUAL.equals(comparator)) {
/* 240:431 */       isCompare = compareVal != 0;
/* 241:433 */     } else if (Comparators.GREATER_THAN.equals(comparator)) {
/* 242:434 */       isCompare = compareVal > 0;
/* 243:436 */     } else if (Comparators.GREATER_THAN_OR_EQUAL.equals(comparator)) {
/* 244:437 */       isCompare = compareVal >= 0;
/* 245:439 */     } else if (Comparators.LESSER_THAN.equals(comparator)) {
/* 246:440 */       isCompare = compareVal < 0;
/* 247:442 */     } else if (Comparators.LESSER_THAN_OR_EQUAL.equals(comparator)) {
/* 248:443 */       isCompare = compareVal <= 0;
/* 249:    */     }
/* 250:446 */     return isCompare;
/* 251:    */   }
/* 252:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.util.NumericUtil
 * JD-Core Version:    0.7.0.1
 */