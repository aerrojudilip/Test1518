/*    1:     */ package com.ibm.openpages.ext.tss.service.util;
/*    2:     */ 
/*    3:     */ import com.ibm.openpages.ext.tss.service.ILoggerUtil;
/*    4:     */ import com.ibm.openpages.ext.tss.service.config.OPSServiceFactory;
/*    5:     */ import com.ibm.openpages.ext.tss.service.constants.ArithmeticOperations;
/*    6:     */ import com.ibm.openpages.ext.tss.service.constants.CheckFor;
/*    7:     */ import com.ibm.openpages.ext.tss.service.constants.Comparators;
/*    8:     */ import com.ibm.openpages.ext.tss.service.constants.StringOrder;
/*    9:     */ import com.openpages.tool.encrypt.CryptUtil;
/*   10:     */ import java.io.PrintStream;
/*   11:     */ import java.io.PrintWriter;
/*   12:     */ import java.io.StringWriter;
/*   13:     */ import java.io.Writer;
/*   14:     */ import java.util.ArrayList;
/*   15:     */ import java.util.HashMap;
/*   16:     */ import java.util.HashSet;
/*   17:     */ import java.util.List;
/*   18:     */ import java.util.Map;
/*   19:     */ import java.util.Set;
/*   20:     */ import java.util.UUID;
/*   21:     */ import org.apache.commons.logging.Log;
/*   22:     */ 
/*   23:     */ public final class CommonUtil
/*   24:     */ {
/*   25:  47 */   private static Log logger = null;
/*   26:     */   
/*   27:     */   private static void initLogger()
/*   28:     */   {
/*   29:     */     try
/*   30:     */     {
/*   31:  59 */       logger = OPSServiceFactory.getLoggerUtil().getExtLogger();
/*   32:     */     }
/*   33:     */     catch (Exception ex)
/*   34:     */     {
/*   35:  63 */       System.out.println("Exception creating logger");
/*   36:     */     }
/*   37:     */   }
/*   38:     */   
/*   39:     */   public static boolean isNullOrEmpty(String str)
/*   40:     */   {
/*   41:  77 */     return (str == null) || (str.trim().equals(""));
/*   42:     */   }
/*   43:     */   
/*   44:     */   public static boolean isNotNullOrEmpty(String str)
/*   45:     */   {
/*   46:  91 */     return !isNullOrEmpty(str);
/*   47:     */   }
/*   48:     */   
/*   49:     */   public static boolean isListNullOrEmpty(List<?> list)
/*   50:     */   {
/*   51: 104 */     return (list == null) || (list.size() == 0);
/*   52:     */   }
/*   53:     */   
/*   54:     */   public static boolean isListNotNullOrEmpty(List<?> list)
/*   55:     */   {
/*   56: 117 */     return !isListNullOrEmpty(list);
/*   57:     */   }
/*   58:     */   
/*   59:     */   public static boolean isSetNullOrEmpty(Set<?> set)
/*   60:     */   {
/*   61: 130 */     return (set == null) || (set.size() == 0);
/*   62:     */   }
/*   63:     */   
/*   64:     */   public static boolean isSetNotNullOrEmpty(Set<?> set)
/*   65:     */   {
/*   66: 143 */     return !isSetNullOrEmpty(set);
/*   67:     */   }
/*   68:     */   
/*   69:     */   public static boolean isMaptNullOrEmpty(Map<?, ?> map)
/*   70:     */   {
/*   71: 156 */     return (isObjectNull(map)) || (map.isEmpty());
/*   72:     */   }
/*   73:     */   
/*   74:     */   public static boolean isMapNotNullOrEmpty(Map<?, ?> map)
/*   75:     */   {
/*   76: 169 */     return !isMaptNullOrEmpty(map);
/*   77:     */   }
/*   78:     */   
/*   79:     */   public static boolean isListsOfTheSameSize(List<?> list1, List<?> list2)
/*   80:     */   {
/*   81: 186 */     return (isListNotNullOrEmpty(list1)) && (isListNotNullOrEmpty(list2)) && (list1.size() == list2.size());
/*   82:     */   }
/*   83:     */   
/*   84:     */   public static boolean isListsNotOfTheSameSize(List<?> list1, List<?> list2)
/*   85:     */   {
/*   86: 203 */     return !isListsOfTheSameSize(list1, list2);
/*   87:     */   }
/*   88:     */   
/*   89:     */   public static boolean isListsOfTheSameSize(List<List<?>> listsInformation)
/*   90:     */   {
/*   91: 219 */     boolean isListsOfSameSize = false;
/*   92: 220 */     List<?> firstList = null;
/*   93: 222 */     if ((isListNotNullOrEmpty(listsInformation)) && (isObjectNotNull(listsInformation.get(0))))
/*   94:     */     {
/*   95: 224 */       firstList = (List)listsInformation.get(0);
/*   96: 226 */       for (List<?> list : listsInformation)
/*   97:     */       {
/*   98: 228 */         isListsOfSameSize = (isObjectNotNull(list)) && (firstList.size() == list.size());
/*   99: 230 */         if (!isListsOfSameSize) {
/*  100:     */           break;
/*  101:     */         }
/*  102:     */       }
/*  103:     */     }
/*  104: 235 */     return isListsOfSameSize;
/*  105:     */   }
/*  106:     */   
/*  107:     */   public static boolean isListsNotOfTheSameSize(List<List<?>> listsInformation)
/*  108:     */   {
/*  109: 251 */     return !isListsOfTheSameSize(listsInformation);
/*  110:     */   }
/*  111:     */   
/*  112:     */   public static String trimString(String str)
/*  113:     */   {
/*  114: 265 */     return isNullOrEmpty(str) ? "" : str.trim();
/*  115:     */   }
/*  116:     */   
/*  117:     */   public static boolean parseBoolean(String str)
/*  118:     */   {
/*  119: 280 */     return isNullOrEmpty(str) ? false : isEqualIgnoreCase("true", str);
/*  120:     */   }
/*  121:     */   
/*  122:     */   public static String toString(Object obj)
/*  123:     */   {
/*  124: 294 */     return isObjectNull(obj) ? "" : obj.toString();
/*  125:     */   }
/*  126:     */   
/*  127:     */   public static boolean isEqual(String str1, String str2)
/*  128:     */   {
/*  129: 310 */     return (isNullOrEmpty(str1)) && (isNullOrEmpty(str2)) ? false : trimString(str1).equals(trimString(str2));
/*  130:     */   }
/*  131:     */   
/*  132:     */   public static boolean isNotEqual(String str1, String str2)
/*  133:     */   {
/*  134: 327 */     return !isEqual(str1, str2);
/*  135:     */   }
/*  136:     */   
/*  137:     */   public static boolean isEqualIgnoreCase(String str1, String str2)
/*  138:     */   {
/*  139: 343 */     return (isNullOrEmpty(str1)) && (isNullOrEmpty(str2)) ? false : trimString(str1).equalsIgnoreCase(trimString(str2));
/*  140:     */   }
/*  141:     */   
/*  142:     */   public static boolean isNotEqualIgnoreCase(String str1, String str2)
/*  143:     */   {
/*  144: 360 */     return !isEqualIgnoreCase(str1, str2);
/*  145:     */   }
/*  146:     */   
/*  147:     */   public static boolean containsOrEqual(String str1, String str2)
/*  148:     */   {
/*  149: 378 */     return (!isNullOrEmpty(str1)) && (!isNullOrEmpty(str2));
/*  150:     */   }
/*  151:     */   
/*  152:     */   public static boolean isObjectNull(Object obj)
/*  153:     */   {
/*  154: 393 */     return obj == null;
/*  155:     */   }
/*  156:     */   
/*  157:     */   public static boolean isObjectNotNull(Object obj)
/*  158:     */   {
/*  159: 407 */     return obj != null;
/*  160:     */   }
/*  161:     */   
/*  162:     */   public static String generateUniqueId()
/*  163:     */   {
/*  164: 419 */     return UUID.randomUUID().toString();
/*  165:     */   }
/*  166:     */   
/*  167:     */   public static List<Integer> addValueToListIfNotPresent(List<Integer> list1, List<Integer> list2)
/*  168:     */   {
/*  169: 437 */     Set<Integer> nonDuplicateSet = null;
/*  170: 440 */     if (isObjectNotNull(list2))
/*  171:     */     {
/*  172: 442 */       nonDuplicateSet = new HashSet(list2);
/*  173: 444 */       if (isObjectNotNull(list1)) {
/*  174: 446 */         nonDuplicateSet.addAll(list1);
/*  175:     */       }
/*  176:     */     }
/*  177: 449 */     return isObjectNull(nonDuplicateSet) ? new ArrayList() : new ArrayList(nonDuplicateSet);
/*  178:     */   }
/*  179:     */   
/*  180:     */   public static String getStackTrace(Throwable throwable)
/*  181:     */   {
/*  182: 462 */     initLogger();
/*  183:     */     
/*  184:     */ 
/*  185: 465 */     Writer writer = new StringWriter();
/*  186:     */     try
/*  187:     */     {
/*  188: 470 */       PrintWriter printWriter = new PrintWriter(writer);
/*  189: 471 */       throwable.printStackTrace(printWriter);
/*  190:     */     }
/*  191:     */     catch (Exception ex)
/*  192:     */     {
/*  193: 474 */       if (isObjectNotNull(logger))
/*  194:     */       {
/*  195: 476 */         logger.error("Exception: " + ex.getMessage());
/*  196: 477 */         logger.error("Exception Stacktrace: " + ex.getStackTrace());
/*  197:     */       }
/*  198:     */       else
/*  199:     */       {
/*  200: 480 */         System.out.println("Exception: " + ex.getMessage());
/*  201: 481 */         System.out.println("Exception Stacktrace: " + ex.getStackTrace());
/*  202:     */       }
/*  203:     */     }
/*  204: 485 */     return writer.toString();
/*  205:     */   }
/*  206:     */   
/*  207:     */   public static List<String> parseDelimitedValues(String value, String delimiter)
/*  208:     */   {
/*  209: 504 */     String[] valueArray = null;
/*  210: 505 */     List<String> valuesList = null;
/*  211:     */     
/*  212:     */ 
/*  213: 508 */     valuesList = new ArrayList();
/*  214: 510 */     if (!isNullOrEmpty(value))
/*  215:     */     {
/*  216: 512 */       valueArray = value.split(delimiter);
/*  217: 514 */       if (valueArray.length > 0) {
/*  218: 515 */         for (int i = 0; i < valueArray.length; i++) {
/*  219: 517 */           valuesList.add(isNullOrEmpty(valueArray[i]) ? "" : valueArray[i].trim());
/*  220:     */         }
/*  221:     */       }
/*  222:     */     }
/*  223: 522 */     return valuesList;
/*  224:     */   }
/*  225:     */   
/*  226:     */   public static List<String> parseCommaDelimitedValues(String value)
/*  227:     */   {
/*  228: 538 */     return parseDelimitedValues(value, ",");
/*  229:     */   }
/*  230:     */   
/*  231:     */   public static List<String> parsePipeDelimitedValues(String value)
/*  232:     */   {
/*  233: 554 */     return parseDelimitedValues(value, "\\|");
/*  234:     */   }
/*  235:     */   
/*  236:     */   public static String unParseCommaDelimitedValues(List<String> list)
/*  237:     */   {
/*  238: 570 */     return unParseWithDelimitedValue(list, ",");
/*  239:     */   }
/*  240:     */   
/*  241:     */   public static String unParseWithDelimitedValue(List<String> list, String delimiter)
/*  242:     */   {
/*  243: 588 */     StringBuilder unParsedValue = null;
/*  244:     */     
/*  245: 590 */     unParsedValue = new StringBuilder();
/*  246: 591 */     if (isListNotNullOrEmpty(list)) {
/*  247: 593 */       for (String val : list)
/*  248:     */       {
/*  249: 594 */         unParsedValue.append(val);
/*  250: 595 */         unParsedValue.append(delimiter);
/*  251:     */       }
/*  252:     */     }
/*  253: 599 */     return unParsedValue.toString();
/*  254:     */   }
/*  255:     */   
/*  256:     */   public static Map<String, String> parseDelimitedValuesAsMap(String value, String firstDelimiter, String secondDelimiter)
/*  257:     */   {
/*  258: 623 */     String[] valueArray = null;
/*  259: 624 */     String[] secondValueArray = null;
/*  260: 625 */     Map<String, String> valuesMap = null;
/*  261:     */     
/*  262:     */ 
/*  263: 628 */     valuesMap = new HashMap();
/*  264: 630 */     if (!isNullOrEmpty(value))
/*  265:     */     {
/*  266: 632 */       valueArray = value.split(firstDelimiter);
/*  267: 634 */       if (valueArray.length > 0) {
/*  268: 635 */         for (int i = 0; i < valueArray.length; i++) {
/*  269: 637 */           if (isNotNullOrEmpty(valueArray[i]))
/*  270:     */           {
/*  271: 639 */             secondValueArray = valueArray[i].trim().split(secondDelimiter);
/*  272: 640 */             valuesMap.put(isNullOrEmpty(secondValueArray[0]) ? "" : secondValueArray[0].trim(), isNullOrEmpty(secondValueArray[1]) ? "" : secondValueArray[1].trim());
/*  273:     */           }
/*  274:     */         }
/*  275:     */       }
/*  276:     */     }
/*  277: 650 */     return valuesMap;
/*  278:     */   }
/*  279:     */   
/*  280:     */   public static String decryptString(String encryptedVal)
/*  281:     */     throws Exception
/*  282:     */   {
/*  283: 666 */     return CryptUtil.decrypt(encryptedVal);
/*  284:     */   }
/*  285:     */   
/*  286:     */   public static String toStringWithLineBreak(List<String> messages)
/*  287:     */   {
/*  288: 683 */     StringBuilder sb = new StringBuilder();
/*  289: 686 */     for (String msg : messages)
/*  290:     */     {
/*  291: 688 */       sb.append("\n");
/*  292: 689 */       sb.append(msg);
/*  293:     */     }
/*  294: 692 */     return sb.toString();
/*  295:     */   }
/*  296:     */   
/*  297:     */   public static CheckFor getCheckFor(String checkForStr)
/*  298:     */     throws Exception
/*  299:     */   {
/*  300: 708 */     CheckFor checkFor = null;
/*  301:     */     try
/*  302:     */     {
/*  303: 712 */       checkFor = CheckFor.valueOf(checkForStr);
/*  304:     */     }
/*  305:     */     catch (Exception ex)
/*  306:     */     {
/*  307: 715 */       logger.error("EXCEPTION!!!!!!!! " + getStackTrace(ex));
/*  308:     */     }
/*  309: 718 */     return checkFor;
/*  310:     */   }
/*  311:     */   
/*  312:     */   public static List<Comparators> getListOfComparators(String comparatorStr)
/*  313:     */     throws Exception
/*  314:     */   {
/*  315: 734 */     List<String> arithOperationsStrings = null;
/*  316: 735 */     List<Comparators> comparatorsList = null;
/*  317:     */     try
/*  318:     */     {
/*  319: 739 */       arithOperationsStrings = parseCommaDelimitedValues(comparatorStr);
/*  320: 741 */       if (isListNotNullOrEmpty(arithOperationsStrings))
/*  321:     */       {
/*  322: 743 */         comparatorsList = new ArrayList();
/*  323: 745 */         for (String comparatorsString : arithOperationsStrings) {
/*  324: 747 */           if (isObjectNotNull(getComparator(comparatorsString))) {
/*  325: 748 */             comparatorsList.add(getComparator(comparatorsString));
/*  326:     */           }
/*  327:     */         }
/*  328:     */       }
/*  329:     */     }
/*  330:     */     catch (Exception ex)
/*  331:     */     {
/*  332: 753 */       logger.error("EXCEPTION!!!!!!!! " + getStackTrace(ex));
/*  333:     */     }
/*  334: 756 */     return comparatorsList;
/*  335:     */   }
/*  336:     */   
/*  337:     */   public static Comparators getComparator(String comparatorStr)
/*  338:     */     throws Exception
/*  339:     */   {
/*  340: 772 */     Comparators comparator = null;
/*  341:     */     try
/*  342:     */     {
/*  343: 776 */       comparator = Comparators.valueOf(comparatorStr);
/*  344:     */     }
/*  345:     */     catch (Exception ex)
/*  346:     */     {
/*  347: 779 */       logger.error("EXCEPTION!!!!!!!! " + getStackTrace(ex));
/*  348:     */     }
/*  349: 782 */     return comparator;
/*  350:     */   }
/*  351:     */   
/*  352:     */   public static List<ArithmeticOperations> getListOfArithmeticOperation(String arithOperStr)
/*  353:     */     throws Exception
/*  354:     */   {
/*  355: 798 */     List<String> arithOperationsStrings = null;
/*  356: 799 */     List<ArithmeticOperations> arithOperationList = null;
/*  357:     */     try
/*  358:     */     {
/*  359: 803 */       arithOperationsStrings = parseCommaDelimitedValues(arithOperStr);
/*  360: 805 */       if (isListNotNullOrEmpty(arithOperationsStrings))
/*  361:     */       {
/*  362: 807 */         arithOperationList = new ArrayList();
/*  363: 809 */         for (String arithOperationsString : arithOperationsStrings) {
/*  364: 811 */           if (isObjectNotNull(getArithmeticOperation(arithOperationsString))) {
/*  365: 812 */             arithOperationList.add(getArithmeticOperation(arithOperationsString));
/*  366:     */           }
/*  367:     */         }
/*  368:     */       }
/*  369:     */     }
/*  370:     */     catch (Exception ex)
/*  371:     */     {
/*  372: 817 */       logger.error("EXCEPTION!!!!!!!! " + getStackTrace(ex));
/*  373:     */     }
/*  374: 820 */     return arithOperationList;
/*  375:     */   }
/*  376:     */   
/*  377:     */   public static ArithmeticOperations getArithmeticOperation(String arithOperStr)
/*  378:     */     throws Exception
/*  379:     */   {
/*  380: 836 */     ArithmeticOperations arithOperation = null;
/*  381:     */     try
/*  382:     */     {
/*  383: 840 */       arithOperation = ArithmeticOperations.valueOf(arithOperStr);
/*  384:     */     }
/*  385:     */     catch (Exception ex)
/*  386:     */     {
/*  387: 843 */       logger.error("EXCEPTION!!!!!!!! " + getStackTrace(ex));
/*  388:     */     }
/*  389: 846 */     return arithOperation;
/*  390:     */   }
/*  391:     */   
/*  392:     */   public static StringOrder getStringOrder(String stringOrderStr)
/*  393:     */     throws Exception
/*  394:     */   {
/*  395: 862 */     StringOrder stringOrder = null;
/*  396:     */     try
/*  397:     */     {
/*  398: 866 */       stringOrder = StringOrder.valueOf(stringOrderStr);
/*  399:     */     }
/*  400:     */     catch (Exception ex)
/*  401:     */     {
/*  402: 869 */       logger.error("EXCEPTION!!!!!!!! " + getStackTrace(ex));
/*  403:     */     }
/*  404: 872 */     return stringOrder;
/*  405:     */   }
/*  406:     */   
/*  407:     */   public static boolean isSelectedValuesMatchActualValues(List<String> actualValues, List<String> expectedValues, CheckFor checkFor)
/*  408:     */     throws Exception
/*  409:     */   {
/*  410: 893 */     boolean isApplicable = false;
/*  411: 894 */     boolean returnValForAll = true;
/*  412: 895 */     boolean returnValForAny = false;
/*  413:     */     
/*  414:     */ 
/*  415:     */ 
/*  416: 899 */     logger.debug("Actual Values: " + actualValues.toString());
/*  417: 900 */     logger.debug("Selected Values: " + expectedValues.toString());
/*  418: 901 */     logger.debug("Check For" + checkFor.toString());
/*  419:     */     try
/*  420:     */     {
/*  421: 905 */       for (String actualValue : actualValues)
/*  422:     */       {
/*  423: 907 */         boolean flag = false;
/*  424: 908 */         for (String selectedValue : expectedValues) {
/*  425: 910 */           if (isEqualIgnoreCase(actualValue, selectedValue))
/*  426:     */           {
/*  427: 913 */             if (CheckFor.CHECK_ANY.equals(checkFor))
/*  428:     */             {
/*  429: 914 */               returnValForAny = true;
/*  430: 915 */               break;
/*  431:     */             }
/*  432: 916 */             if (CheckFor.CHECK_ALL.equals(checkFor)) {
/*  433: 917 */               flag = true;
/*  434:     */             }
/*  435:     */           }
/*  436:     */         }
/*  437: 922 */         if ((CheckFor.CHECK_ALL.equals(checkFor)) && (!flag))
/*  438:     */         {
/*  439: 923 */           returnValForAll = false;
/*  440: 924 */           break;
/*  441:     */         }
/*  442:     */       }
/*  443:     */     }
/*  444:     */     catch (Exception e)
/*  445:     */     {
/*  446: 928 */       logger.error("EXCEPTION!!!!!!!!!!!!!!! detectPropertyChangeToAGivenValue: " + getStackTrace(e));
/*  447: 929 */       isApplicable = false;
/*  448:     */     }
/*  449: 932 */     if (CheckFor.CHECK_ALL.equals(checkFor)) {
/*  450: 933 */       isApplicable = returnValForAll;
/*  451: 934 */     } else if (CheckFor.CHECK_ANY.equals(checkFor)) {
/*  452: 935 */       isApplicable = returnValForAny;
/*  453:     */     } else {
/*  454: 937 */       return false;
/*  455:     */     }
/*  456: 940 */     return isApplicable;
/*  457:     */   }
/*  458:     */   
/*  459:     */   public static String performCalculationAndReturnString(String val1, String val2, ArithmeticOperations operation)
/*  460:     */     throws Exception
/*  461:     */   {
/*  462: 958 */     return NumericUtil.doubleToString(performCalculation(NumericUtil.getDoubleValue(val1), NumericUtil.getDoubleValue(val2), operation));
/*  463:     */   }
/*  464:     */   
/*  465:     */   public static double performCalculation(String val1, String val2, ArithmeticOperations operation)
/*  466:     */     throws Exception
/*  467:     */   {
/*  468: 976 */     return performCalculation(NumericUtil.getDoubleValue(val1), NumericUtil.getDoubleValue(val2), operation);
/*  469:     */   }
/*  470:     */   
/*  471:     */   public static double performCalculation(double val1, double val2, ArithmeticOperations operation)
/*  472:     */     throws Exception
/*  473:     */   {
/*  474: 994 */     double value = 0.0D;
/*  475: 996 */     if (ArithmeticOperations.ADD.equals(operation)) {
/*  476: 997 */       value = val1 + val2;
/*  477: 999 */     } else if (ArithmeticOperations.SUBTRACT.equals(operation)) {
/*  478:1000 */       value = val1 - val2;
/*  479:1002 */     } else if (ArithmeticOperations.MULTIPLY.equals(operation)) {
/*  480:1003 */       value = val1 * val2;
/*  481:1005 */     } else if (ArithmeticOperations.DIVIDE.equals(operation)) {
/*  482:1006 */       value = val1 / val2;
/*  483:     */     }
/*  484:1010 */     return value;
/*  485:     */   }
/*  486:     */   
/*  487:     */   public static boolean stringCompare(String val1, String val2, String comparator)
/*  488:     */     throws Exception
/*  489:     */   {
/*  490:1027 */     return stringCompare(val1, val2, Comparators.valueOf(comparator));
/*  491:     */   }
/*  492:     */   
/*  493:     */   public static boolean stringCompare(String val1, String val2, Comparators comparator)
/*  494:     */     throws Exception
/*  495:     */   {
/*  496:1046 */     boolean isCompare = false;
/*  497:1048 */     if (Comparators.START_WITH.equals(comparator)) {
/*  498:1049 */       isCompare = val1.startsWith(val2);
/*  499:1051 */     } else if (Comparators.CONTAINS.equals(comparator)) {
/*  500:1052 */       isCompare = val1.contains(val2);
/*  501:1054 */     } else if (Comparators.EQUAL.equals(comparator)) {
/*  502:1055 */       isCompare = val1.equals(val2);
/*  503:1057 */     } else if (Comparators.EQUAL_IGNORE_CASE.equals(comparator)) {
/*  504:1058 */       isCompare = val1.equalsIgnoreCase(val2);
/*  505:1060 */     } else if (Comparators.NULL.equals(comparator)) {
/*  506:1061 */       isCompare = isObjectNull(val1);
/*  507:1063 */     } else if (Comparators.NOT_NULL.equals(comparator)) {
/*  508:1064 */       isCompare = isObjectNotNull(val1);
/*  509:1066 */     } else if (Comparators.EMPTY.equals(comparator)) {
/*  510:1067 */       isCompare = isEqual(val1, "");
/*  511:1069 */     } else if (Comparators.NULL_OR_EMPTY.equals(comparator)) {
/*  512:1070 */       isCompare = isNullOrEmpty(val1);
/*  513:1072 */     } else if (Comparators.NOT_NULL_OR_EMPTY.equals(comparator)) {
/*  514:1073 */       isCompare = isNotNullOrEmpty(val1);
/*  515:     */     }
/*  516:1076 */     return isCompare;
/*  517:     */   }
/*  518:     */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.util.CommonUtil
 * JD-Core Version:    0.7.0.1
 */