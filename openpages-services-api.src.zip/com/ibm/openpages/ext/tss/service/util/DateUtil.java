/*    1:     */ package com.ibm.openpages.ext.tss.service.util;
/*    2:     */ 
/*    3:     */ import com.ibm.openpages.ext.tss.service.ILoggerUtil;
/*    4:     */ import com.ibm.openpages.ext.tss.service.config.OPSServiceFactory;
/*    5:     */ import com.ibm.openpages.ext.tss.service.constants.Comparators;
/*    6:     */ import com.ibm.openpages.ext.tss.service.constants.DateConstants;
/*    7:     */ import com.ibm.openpages.ext.tss.service.constants.DateFrequency;
/*    8:     */ import java.sql.Timestamp;
/*    9:     */ import java.text.DateFormat;
/*   10:     */ import java.text.ParseException;
/*   11:     */ import java.text.SimpleDateFormat;
/*   12:     */ import java.util.Calendar;
/*   13:     */ import java.util.Date;
/*   14:     */ import java.util.GregorianCalendar;
/*   15:     */ import java.util.List;
/*   16:     */ import java.util.SortedSet;
/*   17:     */ import java.util.TreeSet;
/*   18:     */ import org.apache.commons.logging.Log;
/*   19:     */ 
/*   20:     */ public final class DateUtil
/*   21:     */ {
/*   22:  47 */   private static Log logger = null;
/*   23:     */   
/*   24:     */   private static void initLogger()
/*   25:     */   {
/*   26:  56 */     if (CommonUtil.isObjectNull(logger)) {
/*   27:  57 */       logger = OPSServiceFactory.getLoggerUtil().getExtLogger();
/*   28:     */     }
/*   29:     */   }
/*   30:     */   
/*   31:     */   public static String getCurrentDateAsString()
/*   32:     */     throws Exception
/*   33:     */   {
/*   34:  70 */     return getCurrentDateInSpecificFormat("MM/dd/yyyy HH:mm:ss");
/*   35:     */   }
/*   36:     */   
/*   37:     */   public static String getCurrentDateInOpenPagesFormat()
/*   38:     */     throws Exception
/*   39:     */   {
/*   40:  83 */     return getCurrentDateInSpecificFormat("yyyy-MM-dd HH:mm:ss");
/*   41:     */   }
/*   42:     */   
/*   43:     */   public static Date getCurrentDate()
/*   44:     */     throws Exception
/*   45:     */   {
/*   46:  96 */     initLogger();
/*   47:  97 */     logger.debug("getDateValueOfOpenPagesSystemDate()Start");
/*   48:     */     
/*   49:  99 */     logger.debug("getDateValueOfOpenPagesSystemDate()End");
/*   50: 100 */     return parseStringToDate(getCurrentDateAsString());
/*   51:     */   }
/*   52:     */   
/*   53:     */   public static Date parseStringToDate(String date)
/*   54:     */     throws Exception
/*   55:     */   {
/*   56: 115 */     initLogger();
/*   57: 116 */     logger.debug("getDateValueOfOpenPagesSystemDate()Start");
/*   58:     */     
/*   59: 118 */     String dateFormat = "";
/*   60:     */     
/*   61:     */ 
/*   62: 121 */     dateFormat = getDateFormat(date);
/*   63: 122 */     SimpleDateFormat formatter = new SimpleDateFormat(dateFormat);
/*   64: 123 */     Date dateValue = formatter.parse(date);
/*   65:     */     
/*   66:     */ 
/*   67:     */ 
/*   68: 127 */     logger.debug("getDateValueOfOpenPagesSystemDate()End");
/*   69: 128 */     return dateValue;
/*   70:     */   }
/*   71:     */   
/*   72:     */   public static String getDateValueInOpenPagesFormat(Date date)
/*   73:     */     throws Exception
/*   74:     */   {
/*   75: 143 */     initLogger();
/*   76: 144 */     logger.debug("getDateValueOfOpenPagesSystemDate()Start");
/*   77:     */     
/*   78: 146 */     String toFormat = "";
/*   79:     */     
/*   80:     */ 
/*   81: 149 */     toFormat = "yyyy-MM-dd HH:mm:ss";
/*   82: 150 */     SimpleDateFormat formatter = new SimpleDateFormat(toFormat);
/*   83:     */     
/*   84:     */ 
/*   85: 153 */     logger.debug("getDateValueOfOpenPagesSystemDate()End");
/*   86: 154 */     return formatter.format(date);
/*   87:     */   }
/*   88:     */   
/*   89:     */   public static String getCurrentDateInSpecificFormat(String format)
/*   90:     */     throws Exception
/*   91:     */   {
/*   92: 167 */     return getDateInSpecificFormat(Calendar.getInstance(), format);
/*   93:     */   }
/*   94:     */   
/*   95:     */   public static String getDateFormat(String date)
/*   96:     */     throws Exception
/*   97:     */   {
/*   98: 184 */     String dateFormat = "";
/*   99: 185 */     SimpleDateFormat formatter = null;
/*  100: 187 */     for (int i = 0; i < DateConstants.DATE_FORMATS.length; i++)
/*  101:     */     {
/*  102: 189 */       formatter = new SimpleDateFormat(DateConstants.DATE_FORMATS[i]);
/*  103:     */       try
/*  104:     */       {
/*  105: 192 */         formatter.setLenient(false);
/*  106: 193 */         formatter.parse(date);
/*  107: 194 */         dateFormat = DateConstants.DATE_FORMATS[i];
/*  108:     */       }
/*  109:     */       catch (ParseException localParseException) {}catch (Exception ex)
/*  110:     */       {
/*  111: 199 */         throw ex;
/*  112:     */       }
/*  113:     */     }
/*  114: 203 */     return dateFormat;
/*  115:     */   }
/*  116:     */   
/*  117:     */   public static Date convertDateStringToDate(String date)
/*  118:     */     throws Exception
/*  119:     */   {
/*  120: 218 */     return new SimpleDateFormat(getDateFormat(date)).parse(date);
/*  121:     */   }
/*  122:     */   
/*  123:     */   public static Date convertDateStringToDate(String date, String dateFormat)
/*  124:     */     throws Exception
/*  125:     */   {
/*  126: 234 */     return new SimpleDateFormat(dateFormat).parse(date);
/*  127:     */   }
/*  128:     */   
/*  129:     */   public static Calendar convertDateStringToCalendar(String date)
/*  130:     */     throws Exception
/*  131:     */   {
/*  132: 249 */     return convertDateToCalendar(convertDateStringToDate(date));
/*  133:     */   }
/*  134:     */   
/*  135:     */   public static Calendar convertDateToCalendar(Date date)
/*  136:     */     throws Exception
/*  137:     */   {
/*  138: 264 */     Calendar cal = null;
/*  139: 265 */     cal = Calendar.getInstance();
/*  140: 266 */     cal.setTime(date);
/*  141:     */     
/*  142: 268 */     return cal;
/*  143:     */   }
/*  144:     */   
/*  145:     */   public static String getDateInSpecificFormat(Date date, String format)
/*  146:     */     throws Exception
/*  147:     */   {
/*  148: 284 */     initLogger();
/*  149: 285 */     logger.debug("getCurrentDateInSpecificFormat()Start");
/*  150:     */     
/*  151:     */ 
/*  152: 288 */     String formattedDate = "";
/*  153: 289 */     DateFormat dateFormat = null;
/*  154:     */     
/*  155:     */ 
/*  156: 292 */     dateFormat = new SimpleDateFormat(format);
/*  157: 293 */     formattedDate = dateFormat.format(convertDateToCalendar(date).getTime());
/*  158:     */     
/*  159: 295 */     logger.debug("getCurrentDateInSpecificFormat()End");
/*  160: 296 */     return formattedDate;
/*  161:     */   }
/*  162:     */   
/*  163:     */   public static String getDateInSpecificFormat(Calendar cal, String format)
/*  164:     */     throws Exception
/*  165:     */   {
/*  166: 312 */     initLogger();
/*  167: 313 */     logger.debug("getCurrentDateInSpecificFormat()Start");
/*  168:     */     
/*  169:     */ 
/*  170: 316 */     String formattedDate = "";
/*  171: 317 */     DateFormat dateFormat = null;
/*  172:     */     
/*  173:     */ 
/*  174: 320 */     dateFormat = new SimpleDateFormat(format);
/*  175: 321 */     formattedDate = dateFormat.format(cal.getTime());
/*  176:     */     
/*  177: 323 */     logger.debug("getCurrentDateInSpecificFormat()End");
/*  178: 324 */     return formattedDate;
/*  179:     */   }
/*  180:     */   
/*  181:     */   public static String changeDateFormat(String dateString, String toFormat)
/*  182:     */     throws Exception
/*  183:     */   {
/*  184: 340 */     initLogger();
/*  185: 341 */     logger.debug("changeDateFormatForDisplay()Start");
/*  186:     */     
/*  187:     */ 
/*  188: 344 */     String fromFormat = "";
/*  189: 345 */     String formattedDate = "";
/*  190: 346 */     Date parsedDate = null;
/*  191: 347 */     Date date = null;
/*  192: 348 */     SimpleDateFormat formatter = null;
/*  193: 351 */     if (CommonUtil.isNotNullOrEmpty(dateString))
/*  194:     */     {
/*  195: 353 */       fromFormat = getDateFormat(dateString);
/*  196: 354 */       formatter = new SimpleDateFormat(fromFormat);
/*  197: 355 */       date = formatter.parse(dateString);
/*  198: 356 */       formattedDate = formatter.format(date);
/*  199: 357 */       parsedDate = formatter.parse(formattedDate);
/*  200:     */       
/*  201: 359 */       formatter = new SimpleDateFormat(toFormat);
/*  202: 360 */       formattedDate = formatter.format(parsedDate);
/*  203:     */     }
/*  204: 363 */     logger.debug("changeDateFormatForDisplay()End");
/*  205: 364 */     return formattedDate;
/*  206:     */   }
/*  207:     */   
/*  208:     */   public static String changeDateFormat(Calendar calendar, String fromFormat, String toFormat)
/*  209:     */     throws Exception
/*  210:     */   {
/*  211: 381 */     initLogger();
/*  212: 382 */     logger.debug("changeDateFormatForDisplay()Start");
/*  213:     */     
/*  214:     */ 
/*  215: 385 */     SimpleDateFormat formatter = new SimpleDateFormat(fromFormat);
/*  216:     */     
/*  217: 387 */     String formattedDate = formatter.format(calendar.getTime());
/*  218: 388 */     Date date1 = formatter.parse(formattedDate);
/*  219:     */     
/*  220:     */ 
/*  221: 391 */     formatter = new SimpleDateFormat(toFormat);
/*  222: 392 */     formattedDate = formatter.format(date1);
/*  223:     */     
/*  224: 394 */     logger.debug("changeDateFormatForDisplay()End");
/*  225: 395 */     return formattedDate;
/*  226:     */   }
/*  227:     */   
/*  228:     */   public static long getNumberOfDaysBetweenDates(String givenDate, String compareDate)
/*  229:     */     throws Exception
/*  230:     */   {
/*  231: 411 */     initLogger();
/*  232: 412 */     logger.debug("getNumberOfDaysBetweenDates()Start");
/*  233:     */     
/*  234:     */ 
/*  235: 415 */     String format = "";
/*  236:     */     
/*  237: 417 */     Date date1 = null;
/*  238: 418 */     Date date2 = null;
/*  239: 419 */     SimpleDateFormat simpleDateFormat = null;
/*  240:     */     
/*  241:     */ 
/*  242: 422 */     format = getDateFormat(givenDate);
/*  243: 423 */     simpleDateFormat = new SimpleDateFormat(format);
/*  244: 424 */     date1 = simpleDateFormat.parse(givenDate);
/*  245:     */     
/*  246: 426 */     format = getDateFormat(compareDate);
/*  247: 427 */     simpleDateFormat = new SimpleDateFormat(format);
/*  248: 428 */     date2 = simpleDateFormat.parse(compareDate);
/*  249:     */     
/*  250: 430 */     logger.debug("getNumberOfDaysBetweenDates()End");
/*  251: 431 */     return getNumberOfDaysBetweenDates(date1, date2);
/*  252:     */   }
/*  253:     */   
/*  254:     */   public static long getNumberOfDaysBetweenDates(Date givenDate, String compareDate)
/*  255:     */     throws Exception
/*  256:     */   {
/*  257: 447 */     initLogger();
/*  258: 448 */     logger.debug("getNumberOfDaysBetweenDates()Start");
/*  259:     */     
/*  260:     */ 
/*  261: 451 */     String format = "";
/*  262:     */     
/*  263: 453 */     Date date2 = null;
/*  264: 454 */     SimpleDateFormat simpleDateFormat = null;
/*  265:     */     
/*  266:     */ 
/*  267: 457 */     format = getDateFormat(compareDate);
/*  268: 458 */     simpleDateFormat = new SimpleDateFormat(format);
/*  269: 459 */     date2 = simpleDateFormat.parse(compareDate);
/*  270:     */     
/*  271: 461 */     logger.debug("getNumberOfDaysBetweenDates()End");
/*  272: 462 */     return getNumberOfDaysBetweenDates(givenDate, date2);
/*  273:     */   }
/*  274:     */   
/*  275:     */   public static long getNumberOfDaysBetweenDates(String givenDate, Date compareDate)
/*  276:     */     throws Exception
/*  277:     */   {
/*  278: 478 */     initLogger();
/*  279: 479 */     logger.debug("getNumberOfDaysBetweenDates()Start");
/*  280:     */     
/*  281:     */ 
/*  282: 482 */     String format = "";
/*  283:     */     
/*  284: 484 */     Date date1 = null;
/*  285: 485 */     SimpleDateFormat simpleDateFormat = null;
/*  286:     */     
/*  287:     */ 
/*  288: 488 */     format = getDateFormat(givenDate);
/*  289: 489 */     simpleDateFormat = new SimpleDateFormat(format);
/*  290: 490 */     date1 = simpleDateFormat.parse(givenDate);
/*  291:     */     
/*  292: 492 */     logger.debug("getNumberOfDaysBetweenDates()End");
/*  293: 493 */     return getNumberOfDaysBetweenDates(date1, compareDate);
/*  294:     */   }
/*  295:     */   
/*  296:     */   public static long getNumberOfDaysBetweenDates(Date givenDate, Date compareDate)
/*  297:     */     throws Exception
/*  298:     */   {
/*  299: 509 */     return (givenDate.getTime() - compareDate.getTime()) / 86400000L;
/*  300:     */   }
/*  301:     */   
/*  302:     */   public static boolean isCurrentDateGreaterOrEqualToSpecifiedDate(String compareDate)
/*  303:     */     throws Exception
/*  304:     */   {
/*  305: 524 */     initLogger();
/*  306: 525 */     logger.debug("isCurrentDateLessThanAttestationEndDate()Start");
/*  307:     */     
/*  308:     */ 
/*  309: 528 */     long numberOfDays = 0L;
/*  310: 529 */     String format = "";
/*  311: 530 */     String currentDate = "";
/*  312:     */     
/*  313: 532 */     Calendar cal = Calendar.getInstance();
/*  314: 533 */     SimpleDateFormat simpleDateFormat = null;
/*  315:     */     
/*  316:     */ 
/*  317: 536 */     format = getDateFormat(compareDate);
/*  318: 537 */     simpleDateFormat = new SimpleDateFormat(format);
/*  319: 538 */     currentDate = simpleDateFormat.format(cal.getTime());
/*  320:     */     
/*  321: 540 */     numberOfDays = getNumberOfDaysBetweenDates(currentDate, compareDate);
/*  322:     */     
/*  323: 542 */     logger.debug("isCurrentDateLessThanAttestationEndDate()End");
/*  324: 543 */     return numberOfDays >= 0L;
/*  325:     */   }
/*  326:     */   
/*  327:     */   public static boolean isGivenDateGreaterOrEqualToCompareDate(String givenDate, String compareDate)
/*  328:     */     throws Exception
/*  329:     */   {
/*  330: 559 */     initLogger();
/*  331: 560 */     logger.debug("getNumberOfDaysBetweenDates()Start");
/*  332:     */     
/*  333:     */ 
/*  334: 563 */     long numberOfDays = 0L;
/*  335:     */     
/*  336:     */ 
/*  337: 566 */     numberOfDays = getNumberOfDaysBetweenDates(givenDate, compareDate);
/*  338:     */     
/*  339: 568 */     logger.debug("isCurrentDateLessThanAttestationEndDate()End");
/*  340: 569 */     return numberOfDays >= 0L;
/*  341:     */   }
/*  342:     */   
/*  343:     */   public static boolean isCurrentDateLesserOrEqualToSpecifiedDate(String compareDate)
/*  344:     */     throws Exception
/*  345:     */   {
/*  346: 584 */     initLogger();
/*  347: 585 */     logger.debug("isCurrentDateLessThanAttestationEndDate()Start");
/*  348:     */     
/*  349:     */ 
/*  350: 588 */     long numberOfDays = 0L;
/*  351: 589 */     String format = "";
/*  352: 590 */     String currentDate = "";
/*  353:     */     
/*  354: 592 */     Calendar cal = Calendar.getInstance();
/*  355: 593 */     SimpleDateFormat simpleDateFormat = null;
/*  356:     */     
/*  357:     */ 
/*  358: 596 */     format = getDateFormat(compareDate);
/*  359: 597 */     simpleDateFormat = new SimpleDateFormat(format);
/*  360: 598 */     currentDate = simpleDateFormat.format(cal.getTime());
/*  361:     */     
/*  362: 600 */     numberOfDays = getNumberOfDaysBetweenDates(currentDate, compareDate);
/*  363:     */     
/*  364: 602 */     logger.debug("isCurrentDateLessThanAttestationEndDate()End");
/*  365: 603 */     return numberOfDays <= 0L;
/*  366:     */   }
/*  367:     */   
/*  368:     */   public static boolean isGivenDateLesserOrEqualToCompareDate(String givenDate, String compareDate)
/*  369:     */     throws Exception
/*  370:     */   {
/*  371: 619 */     initLogger();
/*  372: 620 */     logger.debug("getNumberOfDaysBetweenDates()Start");
/*  373:     */     
/*  374:     */ 
/*  375: 623 */     long numberOfDays = 0L;
/*  376:     */     
/*  377:     */ 
/*  378: 626 */     numberOfDays = getNumberOfDaysBetweenDates(givenDate, compareDate);
/*  379:     */     
/*  380: 628 */     logger.debug("isCurrentDateLessThanAttestationEndDate()End");
/*  381: 629 */     return numberOfDays <= 0L;
/*  382:     */   }
/*  383:     */   
/*  384:     */   public static boolean isCurrentDateGreaterThanSpecifiedDate(String compareDate)
/*  385:     */     throws Exception
/*  386:     */   {
/*  387: 644 */     initLogger();
/*  388: 645 */     logger.debug("isCurrentDateLessThanAttestationEndDate()Start");
/*  389:     */     
/*  390:     */ 
/*  391: 648 */     long numberOfDays = 0L;
/*  392: 649 */     String format = "";
/*  393: 650 */     String currentDate = "";
/*  394:     */     
/*  395: 652 */     Calendar cal = Calendar.getInstance();
/*  396: 653 */     SimpleDateFormat simpleDateFormat = null;
/*  397:     */     
/*  398:     */ 
/*  399: 656 */     format = getDateFormat(compareDate);
/*  400: 657 */     simpleDateFormat = new SimpleDateFormat(format);
/*  401: 658 */     currentDate = simpleDateFormat.format(cal.getTime());
/*  402:     */     
/*  403: 660 */     numberOfDays = getNumberOfDaysBetweenDates(currentDate, compareDate);
/*  404:     */     
/*  405: 662 */     logger.debug("isCurrentDateLessThanAttestationEndDate()End");
/*  406: 663 */     return numberOfDays > 0L;
/*  407:     */   }
/*  408:     */   
/*  409:     */   public static boolean isGivenDateGreaterThanCompareDate(String givenDate, String compareDate)
/*  410:     */     throws Exception
/*  411:     */   {
/*  412: 679 */     initLogger();
/*  413: 680 */     logger.debug("getNumberOfDaysBetweenDates()Start");
/*  414:     */     
/*  415:     */ 
/*  416: 683 */     long numberOfDays = 0L;
/*  417:     */     
/*  418:     */ 
/*  419: 686 */     numberOfDays = getNumberOfDaysBetweenDates(givenDate, compareDate);
/*  420:     */     
/*  421: 688 */     logger.debug("isCurrentDateLessThanAttestationEndDate()End");
/*  422: 689 */     return numberOfDays > 0L;
/*  423:     */   }
/*  424:     */   
/*  425:     */   public static boolean isCurrentDateLesserThanSpecifiedDate(String dateString)
/*  426:     */     throws Exception
/*  427:     */   {
/*  428: 704 */     initLogger();
/*  429: 705 */     logger.debug("isCurrentDateLessThanAttestationEndDate()Start");
/*  430:     */     
/*  431:     */ 
/*  432: 708 */     long numberOfDays = 0L;
/*  433: 709 */     String format = "";
/*  434: 710 */     String currentDate = "";
/*  435:     */     
/*  436: 712 */     Calendar cal = Calendar.getInstance();
/*  437: 713 */     SimpleDateFormat simpleDateFormat = null;
/*  438:     */     
/*  439:     */ 
/*  440: 716 */     format = getDateFormat(dateString);
/*  441: 717 */     simpleDateFormat = new SimpleDateFormat(format);
/*  442: 718 */     currentDate = simpleDateFormat.format(cal.getTime());
/*  443:     */     
/*  444: 720 */     numberOfDays = getNumberOfDaysBetweenDates(currentDate, dateString);
/*  445:     */     
/*  446: 722 */     logger.debug("isCurrentDateLessThanAttestationEndDate()End");
/*  447: 723 */     return numberOfDays < 0L;
/*  448:     */   }
/*  449:     */   
/*  450:     */   public static boolean isGivenDateLesserThanCompareDate(String givenDate, String compareDate)
/*  451:     */     throws Exception
/*  452:     */   {
/*  453: 739 */     initLogger();
/*  454: 740 */     logger.debug("getNumberOfDaysBetweenDates()Start");
/*  455:     */     
/*  456:     */ 
/*  457: 743 */     long numberOfDays = 0L;
/*  458:     */     
/*  459:     */ 
/*  460: 746 */     numberOfDays = getNumberOfDaysBetweenDates(givenDate, compareDate);
/*  461:     */     
/*  462: 748 */     logger.debug("isCurrentDateLessThanAttestationEndDate()End");
/*  463: 749 */     return numberOfDays < 0L;
/*  464:     */   }
/*  465:     */   
/*  466:     */   public static boolean isCurrentDateEqualToSpecifiedDate(String dateString)
/*  467:     */     throws Exception
/*  468:     */   {
/*  469: 764 */     initLogger();
/*  470: 765 */     logger.debug("isCurrentDateLessThanAttestationEndDate()Start");
/*  471:     */     
/*  472:     */ 
/*  473: 768 */     long numberOfDays = 0L;
/*  474: 769 */     String format = "";
/*  475: 770 */     String currentDate = "";
/*  476:     */     
/*  477: 772 */     Calendar cal = Calendar.getInstance();
/*  478: 773 */     SimpleDateFormat simpleDateFormat = null;
/*  479:     */     
/*  480:     */ 
/*  481: 776 */     format = getDateFormat(dateString);
/*  482: 777 */     simpleDateFormat = new SimpleDateFormat(format);
/*  483: 778 */     currentDate = simpleDateFormat.format(cal.getTime());
/*  484:     */     
/*  485: 780 */     numberOfDays = getNumberOfDaysBetweenDates(currentDate, dateString);
/*  486:     */     
/*  487: 782 */     logger.debug("isCurrentDateLessThanAttestationEndDate()End");
/*  488: 783 */     return numberOfDays == 0L;
/*  489:     */   }
/*  490:     */   
/*  491:     */   public static boolean isGivenDateEqualToCompareDate(String givenDate, String compareDate)
/*  492:     */     throws Exception
/*  493:     */   {
/*  494: 799 */     initLogger();
/*  495: 800 */     logger.debug("getNumberOfDaysBetweenDates()Start");
/*  496:     */     
/*  497:     */ 
/*  498: 803 */     long numberOfDays = 0L;
/*  499:     */     
/*  500:     */ 
/*  501: 806 */     numberOfDays = getNumberOfDaysBetweenDates(givenDate, compareDate);
/*  502:     */     
/*  503: 808 */     logger.debug("isCurrentDateLessThanAttestationEndDate()End");
/*  504: 809 */     return numberOfDays == 0L;
/*  505:     */   }
/*  506:     */   
/*  507:     */   public static boolean compareDates(String date1, String date2, Comparators comparator)
/*  508:     */     throws Exception
/*  509:     */   {
/*  510: 827 */     initLogger();
/*  511: 828 */     boolean isCompareDate = false;
/*  512: 830 */     if (Comparators.EQUAL.equals(comparator)) {
/*  513: 832 */       isCompareDate = isGivenDateEqualToCompareDate(date1, date2);
/*  514: 834 */     } else if (Comparators.LESSER_THAN.equals(comparator)) {
/*  515: 836 */       isCompareDate = isGivenDateLesserThanCompareDate(date1, date2);
/*  516: 838 */     } else if (Comparators.GREATER_THAN.equals(comparator)) {
/*  517: 840 */       isCompareDate = isGivenDateGreaterThanCompareDate(date1, date2);
/*  518: 842 */     } else if (Comparators.LESSER_THAN_OR_EQUAL.equals(comparator)) {
/*  519: 844 */       isCompareDate = isGivenDateLesserOrEqualToCompareDate(date1, date2);
/*  520: 846 */     } else if (Comparators.GREATER_THAN_OR_EQUAL.equals(comparator)) {
/*  521: 848 */       isCompareDate = isGivenDateGreaterOrEqualToCompareDate(date1, date2);
/*  522:     */     }
/*  523: 851 */     return isCompareDate;
/*  524:     */   }
/*  525:     */   
/*  526:     */   public static String processFrequencyForDate(String date, int numberOfDays, int numberOfYears, DateFrequency frequency)
/*  527:     */     throws Exception
/*  528:     */   {
/*  529: 874 */     Calendar calendar = GregorianCalendar.getInstance();
/*  530: 875 */     calendar.setTime(convertDateStringToDate(date));
/*  531: 877 */     if (DateFrequency.ADD_NUMBER_OF_DAYS.equals(frequency)) {
/*  532: 879 */       calendar = addNumberOfDaystoCalendar(calendar, numberOfDays);
/*  533: 881 */     } else if (DateFrequency.MONTHLY.equals(frequency)) {
/*  534: 883 */       calendar.add(2, 1);
/*  535: 885 */     } else if (DateFrequency.EVERY_OTHER_MONTH.equals(frequency)) {
/*  536: 887 */       calendar.add(2, 2);
/*  537: 889 */     } else if (DateFrequency.QUARTERLY.equals(frequency)) {
/*  538: 891 */       calendar.add(2, 3);
/*  539: 893 */     } else if (DateFrequency.SEMI_ANNUALLY.equals(frequency)) {
/*  540: 895 */       calendar.add(2, 6);
/*  541: 897 */     } else if (DateFrequency.ANNUALLY.equals(frequency)) {
/*  542: 899 */       calendar.add(1, 1);
/*  543: 901 */     } else if (DateFrequency.ADD_NUMBER_OF_YEARS.equals(frequency)) {
/*  544: 903 */       calendar.add(1, numberOfYears);
/*  545:     */     }
/*  546: 906 */     return getDateValueInOpenPagesFormat(calendar.getTime());
/*  547:     */   }
/*  548:     */   
/*  549:     */   public static Calendar getCalendarForDate(String dateString)
/*  550:     */     throws Exception
/*  551:     */   {
/*  552: 921 */     initLogger();
/*  553: 922 */     logger.debug("getCalendarForDate()Start");
/*  554:     */     
/*  555:     */ 
/*  556: 925 */     String format = "";
/*  557: 926 */     String formattedDate = "";
/*  558:     */     
/*  559: 928 */     Calendar calendar = null;
/*  560: 929 */     Date parsedDate = null;
/*  561: 930 */     Date formattedAndParseDate = null;
/*  562: 931 */     SimpleDateFormat formatter = null;
/*  563:     */     
/*  564:     */ 
/*  565: 934 */     calendar = Calendar.getInstance();
/*  566: 935 */     format = getDateFormat(dateString);
/*  567: 936 */     formatter = new SimpleDateFormat(format);
/*  568: 937 */     parsedDate = formatter.parse(dateString);
/*  569: 938 */     formattedDate = formatter.format(parsedDate);
/*  570: 939 */     formattedAndParseDate = formatter.parse(formattedDate);
/*  571: 940 */     calendar.setTime(formattedAndParseDate);
/*  572:     */     
/*  573: 942 */     logger.debug("getCalendarForDate()End");
/*  574: 943 */     return calendar;
/*  575:     */   }
/*  576:     */   
/*  577:     */   public static String addNumberOfDaystoCurrentDate(int numberOfDays, String format)
/*  578:     */     throws Exception
/*  579:     */   {
/*  580: 960 */     initLogger();
/*  581: 961 */     logger.debug("addNumberOfDaystoCurrentDate()Start");
/*  582:     */     
/*  583:     */ 
/*  584: 964 */     Calendar calen = Calendar.getInstance();
/*  585:     */     
/*  586:     */ 
/*  587: 967 */     calen.setTime(new Date());
/*  588:     */     
/*  589: 969 */     logger.debug("addNumberOfDaystoCurrentDate()End");
/*  590: 970 */     return addNumberOfDaystoDate(calen, numberOfDays, format);
/*  591:     */   }
/*  592:     */   
/*  593:     */   public static Calendar addNumberOfDaystoCalendar(Calendar calendar, int numberOfDays)
/*  594:     */     throws Exception
/*  595:     */   {
/*  596: 987 */     initLogger();
/*  597: 988 */     calendar.add(5, numberOfDays);
/*  598: 989 */     logger.debug("addNumberOfDaystoCalendar()Start");
/*  599: 990 */     return calendar;
/*  600:     */   }
/*  601:     */   
/*  602:     */   public static String addNumberOfDaystoDate(Calendar calendar, int numberOfDays, String format)
/*  603:     */     throws Exception
/*  604:     */   {
/*  605:1008 */     initLogger();
/*  606:1009 */     logger.debug("addNumberOfDaystoDate()Start");
/*  607:     */     
/*  608:     */ 
/*  609:1012 */     SimpleDateFormat dateFormat = null;
/*  610:     */     
/*  611:     */ 
/*  612:1015 */     calendar.add(5, numberOfDays);
/*  613:1016 */     dateFormat = new SimpleDateFormat(format);
/*  614:     */     
/*  615:1018 */     logger.debug("addNumberOfDaystoDate()End");
/*  616:1019 */     return dateFormat.format(calendar.getTime());
/*  617:     */   }
/*  618:     */   
/*  619:     */   public static String getDateValueOfOpenPagesSystemDate(String dateValue, String toFormat)
/*  620:     */     throws Exception
/*  621:     */   {
/*  622:1036 */     initLogger();
/*  623:1037 */     logger.debug("getDateValueOfOpenPagesSystemDate()Start");
/*  624:     */     
/*  625:     */ 
/*  626:1040 */     dateValue = dateValue.lastIndexOf(".") < 0 ? dateValue : dateValue.substring(0, dateValue.lastIndexOf("."));
/*  627:     */     
/*  628:1042 */     logger.debug("getDateValueOfOpenPagesSystemDate()End");
/*  629:1043 */     return changeDateFormat(dateValue, toFormat);
/*  630:     */   }
/*  631:     */   
/*  632:     */   public static Date getSmallestOfTheDates(List<String> datesList)
/*  633:     */     throws Exception
/*  634:     */   {
/*  635:1050 */     SortedSet<Date> dateSet = null;
/*  636:1052 */     if (CommonUtil.isListNotNullOrEmpty(datesList))
/*  637:     */     {
/*  638:1054 */       dateSet = new TreeSet();
/*  639:1056 */       for (String dateVal : datesList) {
/*  640:1058 */         dateSet.add(convertDateStringToDate(dateVal));
/*  641:     */       }
/*  642:     */     }
/*  643:1063 */     return (Date)dateSet.first();
/*  644:     */   }
/*  645:     */   
/*  646:     */   public static Timestamp getTimeStamp(String date)
/*  647:     */     throws Exception
/*  648:     */   {
/*  649:1078 */     int offset = 0;
/*  650:1079 */     Calendar cal = null;
/*  651:1080 */     String[] dateValues = null;
/*  652:     */     
/*  653:1082 */     String dateFormat = "";
/*  654:1083 */     Timestamp timestamp = null;
/*  655:1084 */     SimpleDateFormat sdf = null;
/*  656:     */     
/*  657:1086 */     cal = Calendar.getInstance();
/*  658:1087 */     cal.set(11, 0);
/*  659:1088 */     cal.set(12, 0);
/*  660:1089 */     cal.set(13, 0);
/*  661:1090 */     cal.set(14, 0);
/*  662:1092 */     if (isToday(date))
/*  663:     */     {
/*  664:1094 */       offset = getOffset(date);
/*  665:1095 */       cal.add(5, offset);
/*  666:1096 */       timestamp = new Timestamp(cal.getTimeInMillis());
/*  667:     */     }
/*  668:1097 */     else if (date.matches("[0-9]([0-9])?/[0-9]([0-9])?/[0-9][0-9][0-9][0-9]"))
/*  669:     */     {
/*  670:1099 */       dateValues = date.split("/");
/*  671:1100 */       cal.set(2, Integer.parseInt(dateValues[0]));
/*  672:1101 */       cal.set(5, Integer.parseInt(dateValues[1]));
/*  673:1102 */       cal.set(1, Integer.parseInt(dateValues[2]));
/*  674:1103 */       timestamp = new Timestamp(cal.getTimeInMillis());
/*  675:     */     }
/*  676:     */     else
/*  677:     */     {
/*  678:1105 */       dateFormat = getDateFormat(date);
/*  679:1106 */       sdf = new SimpleDateFormat(dateFormat);
/*  680:1107 */       timestamp = new Timestamp(sdf.parse(date).getTime());
/*  681:     */     }
/*  682:1110 */     return timestamp;
/*  683:     */   }
/*  684:     */   
/*  685:     */   private static boolean isToday(String dateValue)
/*  686:     */   {
/*  687:1125 */     return (dateValue != null) && ((dateValue.startsWith("TODAY")) || (dateValue.startsWith("today")));
/*  688:     */   }
/*  689:     */   
/*  690:     */   private static int getOffset(String value)
/*  691:     */     throws Exception
/*  692:     */   {
/*  693:1139 */     int offset = 0;
/*  694:1140 */     String num = "";
/*  695:     */     
/*  696:1142 */     num = value.replaceAll("[a-zA-Z]", "");
/*  697:1144 */     if (CommonUtil.isNotNullOrEmpty(num)) {
/*  698:     */       try
/*  699:     */       {
/*  700:1148 */         offset = Integer.parseInt(num);
/*  701:     */       }
/*  702:     */       catch (NumberFormatException e)
/*  703:     */       {
/*  704:1151 */         throw new Exception("value next to today not a digit");
/*  705:     */       }
/*  706:     */     }
/*  707:1155 */     return offset;
/*  708:     */   }
/*  709:     */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.util.DateUtil
 * JD-Core Version:    0.7.0.1
 */