package com.ibm.openpages.ext.tss.service;

import com.ibm.openpages.api.metadata.ITypeDefinition;
import com.ibm.openpages.api.resource.IField;
import com.ibm.openpages.api.resource.IGRCObject;
import com.ibm.openpages.ext.tss.service.beans.FieldValueChangeInfo;
import com.ibm.openpages.ext.tss.service.beans.FieldValueChangeOnConditionInfo;
import java.util.List;

public abstract interface IFieldUtil
{
  public abstract void initService();
  
  public abstract IField getField(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract List<IField> getFields(IGRCObject paramIGRCObject, List<String> paramList)
    throws Exception;
  
  public abstract boolean isFieldNull(IField paramIField)
    throws Exception;
  
  public abstract boolean isFieldNull(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract boolean isFieldNotNull(IField paramIField)
    throws Exception;
  
  public abstract boolean isFieldNotNull(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract boolean isFieldValueNull(IField paramIField)
    throws Exception;
  
  public abstract boolean isFieldValueNull(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract boolean isFieldValueNotNull(IField paramIField)
    throws Exception;
  
  public abstract boolean isFieldValueNotNull(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract boolean isFieldNullOrFieldValueNull(IField paramIField)
    throws Exception;
  
  public abstract boolean isFieldNullOrFieldValueNull(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract boolean isFieldValueNullOrEmpty(IField paramIField)
    throws Exception;
  
  public abstract boolean isFieldValueNullOrEmpty(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract boolean isFieldValueNotNullOrEmpty(IField paramIField)
    throws Exception;
  
  public abstract boolean isFieldValueNotNullOrEmpty(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract String getFieldName(IField paramIField)
    throws Exception;
  
  public abstract String getFieldName(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract String getFieldValueAsString(IField paramIField)
    throws Exception;
  
  public abstract Object getFieldValue(IField paramIField)
    throws Exception;
  
  public abstract String getFieldValueAsString(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract Object getOriginalValueOfField(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract String getOriginalValueOfFieldAsString(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract void setFieldValue(IField paramIField, String paramString)
    throws Exception;
  
  public abstract void setFieldValue(IGRCObject paramIGRCObject, String paramString1, String paramString2)
    throws Exception;
  
  public abstract void setFieldValue(IField paramIField, Object paramObject)
    throws Exception;
  
  public abstract void setFieldValueWithNull(IField paramIField)
    throws Exception;
  
  public abstract void setFieldValueWithNull(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract boolean isFieldValueChanged(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract boolean isAllorAnyFieldValueChanged(IGRCObject paramIGRCObject, List<String> paramList, String paramString)
    throws Exception;
  
  public abstract boolean isAllOrAnyFieldHasValues(IGRCObject paramIGRCObject, List<String> paramList, String paramString)
    throws Exception;
  
  public abstract boolean isAllOrAnyFieldHasValues(IGRCObject paramIGRCObject, String paramString1, String paramString2)
    throws Exception;
  
  public abstract boolean isAllFieldsHasMatchingValues(IGRCObject paramIGRCObject, List<String> paramList1, List<String> paramList2)
    throws Exception;
  
  public abstract Double getNumericFieldValueAsDouble(IField paramIField)
    throws Exception;
  
  public abstract Double getNumericFieldValueAsDouble(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract void displayAllFieldsInObject(IGRCObject paramIGRCObject)
    throws Exception;
  
  public abstract List<String> getFieldNamesAsList(List<IField> paramList);
  
  public abstract List<IField> getFieldsFromFieldNamesList(IGRCObject paramIGRCObject, List<String> paramList)
    throws Exception;
  
  public abstract List<String> getFieldValuesFromFieldNamesList(List<IField> paramList)
    throws Exception;
  
  public abstract List<String> getFieldValuesFromFieldNamesList(IGRCObject paramIGRCObject, List<String> paramList)
    throws Exception;
  
  public abstract boolean isFieldValueChangedToExpectedCondition(FieldValueChangeOnConditionInfo paramFieldValueChangeOnConditionInfo)
    throws Exception;
  
  public abstract boolean hasValueChangedForFields(FieldValueChangeInfo paramFieldValueChangeInfo)
    throws Exception;
  
  public abstract List<IField> getModifiedFields(IGRCObject paramIGRCObject)
    throws Exception;
  
  public abstract List<IField> getModifiedFieldsMatchingGivenFields(FieldValueChangeInfo paramFieldValueChangeInfo)
    throws Exception;
  
  public abstract List<String> getModifiedFieldsInfoMatchingGivenFields(FieldValueChangeInfo paramFieldValueChangeInfo)
    throws Exception;
  
  public abstract boolean compareFields(IField paramIField1, IField paramIField2, String paramString)
    throws Exception;
  
  public abstract boolean compareFields(IField paramIField, String paramString1, String paramString2)
    throws Exception;
  
  public abstract boolean compareFields(String paramString1, IField paramIField, String paramString2)
    throws Exception;
  
  public abstract boolean compareFields(String paramString1, String paramString2, String paramString3, String paramString4)
    throws Exception;
  
  public abstract List<String> getLocalizedLabelsForFields(IGRCObject paramIGRCObject, List<String> paramList);
  
  public abstract List<String> getLocalizedLabelsForFields(String paramString, List<String> paramList);
  
  public abstract List<String> getLocalizedLabelsForFields(ITypeDefinition paramITypeDefinition, List<String> paramList);
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.IFieldUtil
 * JD-Core Version:    0.7.0.1
 */