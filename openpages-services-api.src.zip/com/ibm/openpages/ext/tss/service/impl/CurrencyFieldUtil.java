/*   1:    */ package com.ibm.openpages.ext.tss.service.impl;
/*   2:    */ 
/*   3:    */ import com.ibm.openpages.api.configuration.ICurrency;
/*   4:    */ import com.ibm.openpages.api.configuration.ISOCurrencyCode;
/*   5:    */ import com.ibm.openpages.api.metadata.DataType;
/*   6:    */ import com.ibm.openpages.api.resource.ICurrencyField;
/*   7:    */ import com.ibm.openpages.api.resource.IField;
/*   8:    */ import com.ibm.openpages.api.resource.IGRCObject;
/*   9:    */ import com.ibm.openpages.api.service.IConfigurationService;
/*  10:    */ import com.ibm.openpages.api.service.IServiceFactory;
/*  11:    */ import com.ibm.openpages.ext.tss.service.ICurrencyFieldUtil;
/*  12:    */ import com.ibm.openpages.ext.tss.service.ILoggerUtil;
/*  13:    */ import com.ibm.openpages.ext.tss.service.proxy.IServiceFactoryProxy;
/*  14:    */ import com.ibm.openpages.ext.tss.service.util.CommonUtil;
/*  15:    */ import java.util.Date;
/*  16:    */ import javax.annotation.PostConstruct;
/*  17:    */ import org.apache.commons.logging.Log;
/*  18:    */ import org.springframework.beans.factory.annotation.Autowired;
/*  19:    */ import org.springframework.stereotype.Service;
/*  20:    */ 
/*  21:    */ @Service("currencyFieldUtil")
/*  22:    */ public class CurrencyFieldUtil
/*  23:    */   implements ICurrencyFieldUtil
/*  24:    */ {
/*  25:    */   private Log logger;
/*  26:    */   @Autowired
/*  27:    */   ILoggerUtil loggerUtil;
/*  28:    */   @Autowired
/*  29:    */   IServiceFactoryProxy serviceFactoryProxy;
/*  30:    */   
/*  31:    */   @PostConstruct
/*  32:    */   public void initService()
/*  33:    */   {
/*  34: 61 */     this.logger = this.loggerUtil.getExtLogger();
/*  35:    */   }
/*  36:    */   
/*  37:    */   public ICurrencyField getCurrencyField(IField field)
/*  38:    */     throws Exception
/*  39:    */   {
/*  40: 80 */     return DataType.CURRENCY_TYPE.equals(field.getDataType()) ? (ICurrencyField)field : null;
/*  41:    */   }
/*  42:    */   
/*  43:    */   public ICurrencyField getCurrencyField(IGRCObject object, String fieldInfo)
/*  44:    */     throws Exception
/*  45:    */   {
/*  46:100 */     return getCurrencyField(object.getField(fieldInfo));
/*  47:    */   }
/*  48:    */   
/*  49:    */   public boolean isCurrencyFieldNull(IField field)
/*  50:    */     throws Exception
/*  51:    */   {
/*  52:116 */     return CommonUtil.isObjectNull(getCurrencyField(field));
/*  53:    */   }
/*  54:    */   
/*  55:    */   public boolean isCurrencyFieldNull(IGRCObject object, String fieldInfo)
/*  56:    */     throws Exception
/*  57:    */   {
/*  58:135 */     return isCurrencyFieldNull(getCurrencyField(object, fieldInfo));
/*  59:    */   }
/*  60:    */   
/*  61:    */   public boolean isCurrencyFieldNotNull(IField field)
/*  62:    */     throws Exception
/*  63:    */   {
/*  64:151 */     return !isCurrencyFieldNull(field);
/*  65:    */   }
/*  66:    */   
/*  67:    */   public boolean isCurrencyFieldNotNull(IGRCObject object, String fieldInfo)
/*  68:    */     throws Exception
/*  69:    */   {
/*  70:170 */     return isCurrencyFieldNotNull(getCurrencyField(object, fieldInfo));
/*  71:    */   }
/*  72:    */   
/*  73:    */   public boolean isCurrencyFieldBaseAmountNull(IField field)
/*  74:    */     throws Exception
/*  75:    */   {
/*  76:186 */     return CommonUtil.isObjectNull(getCurrencyFieldBaseAmount(field));
/*  77:    */   }
/*  78:    */   
/*  79:    */   public boolean isCurrencyFieldBaseAmountNull(IGRCObject object, String fieldInfo)
/*  80:    */     throws Exception
/*  81:    */   {
/*  82:205 */     return isCurrencyFieldBaseAmountNull(getCurrencyField(object, fieldInfo));
/*  83:    */   }
/*  84:    */   
/*  85:    */   public boolean isCurrencyFieldBaseAmountNotNull(IField field)
/*  86:    */     throws Exception
/*  87:    */   {
/*  88:221 */     return !isCurrencyFieldBaseAmountNull(field);
/*  89:    */   }
/*  90:    */   
/*  91:    */   public boolean isCurrencyFieldBaseAmountNotNull(IGRCObject object, String fieldInfo)
/*  92:    */     throws Exception
/*  93:    */   {
/*  94:240 */     return isCurrencyFieldBaseAmountNull(getCurrencyField(object, fieldInfo));
/*  95:    */   }
/*  96:    */   
/*  97:    */   public boolean isCurrencyFieldLocalAmountNull(IField field)
/*  98:    */     throws Exception
/*  99:    */   {
/* 100:256 */     return CommonUtil.isObjectNull(getCurrencyFieldLocalAmount(field));
/* 101:    */   }
/* 102:    */   
/* 103:    */   public boolean isCurrencyFieldLocalAmountNull(IGRCObject object, String fieldInfo)
/* 104:    */     throws Exception
/* 105:    */   {
/* 106:275 */     return isCurrencyFieldBaseAmountNull(getCurrencyField(object, fieldInfo));
/* 107:    */   }
/* 108:    */   
/* 109:    */   public boolean isCurrencyFieldLocalAmountNotNull(IField field)
/* 110:    */     throws Exception
/* 111:    */   {
/* 112:291 */     return !isCurrencyFieldLocalAmountNull(field);
/* 113:    */   }
/* 114:    */   
/* 115:    */   public boolean isCurrencyFieldLocalAmountNotNull(IGRCObject object, String fieldInfo)
/* 116:    */     throws Exception
/* 117:    */   {
/* 118:310 */     return isCurrencyFieldLocalAmountNull(getCurrencyField(object, fieldInfo));
/* 119:    */   }
/* 120:    */   
/* 121:    */   public Double getCurrencyFieldBaseAmount(IField field)
/* 122:    */     throws Exception
/* 123:    */   {
/* 124:329 */     return isCurrencyFieldNotNull(field) ? getCurrencyField(field).getBaseAmount() : null;
/* 125:    */   }
/* 126:    */   
/* 127:    */   public Double getCurrencyFieldBaseAmount(IGRCObject object, String fieldInfo)
/* 128:    */     throws Exception
/* 129:    */   {
/* 130:348 */     return getCurrencyFieldBaseAmount(getCurrencyField(object, fieldInfo));
/* 131:    */   }
/* 132:    */   
/* 133:    */   public String getCurrencyFieldBaseCurrencyCode(IField field)
/* 134:    */     throws Exception
/* 135:    */   {
/* 136:366 */     return isCurrencyFieldNotNull(field) ? getCurrencyField(field).getBaseCurrency().getCurrencyCode().toString() : null;
/* 137:    */   }
/* 138:    */   
/* 139:    */   public String getCurrencyFieldBaseCurrencyCode(IGRCObject object, String fieldInfo)
/* 140:    */     throws Exception
/* 141:    */   {
/* 142:385 */     return getCurrencyFieldBaseCurrencyCode(getCurrencyField(object, fieldInfo));
/* 143:    */   }
/* 144:    */   
/* 145:    */   public Double getCurrencyFieldLocalAmount(IField field)
/* 146:    */     throws Exception
/* 147:    */   {
/* 148:404 */     return isCurrencyFieldNotNull(field) ? getCurrencyField(field).getLocalAmount() : null;
/* 149:    */   }
/* 150:    */   
/* 151:    */   public Double getCurrencyFieldLocalAmount(IGRCObject object, String fieldInfo)
/* 152:    */     throws Exception
/* 153:    */   {
/* 154:423 */     return getCurrencyFieldLocalAmount(getCurrencyField(object, fieldInfo));
/* 155:    */   }
/* 156:    */   
/* 157:    */   public String getCurrencyFieldLocalAmountAsString(IField field)
/* 158:    */     throws Exception
/* 159:    */   {
/* 160:442 */     return CommonUtil.isObjectNotNull(getCurrencyFieldLocalAmount(field)) ? getCurrencyFieldLocalAmount(field).toString() : null;
/* 161:    */   }
/* 162:    */   
/* 163:    */   public String getCurrencyFieldLocalAmountAsString(IGRCObject object, String fieldInfo)
/* 164:    */     throws Exception
/* 165:    */   {
/* 166:461 */     return getCurrencyFieldLocalAmountAsString(getCurrencyField(object, fieldInfo));
/* 167:    */   }
/* 168:    */   
/* 169:    */   public String getCurrencyFieldLocalCurrencyCode(IField field)
/* 170:    */     throws Exception
/* 171:    */   {
/* 172:479 */     return isCurrencyFieldNotNull(field) ? getCurrencyField(field).getLocalCurrency().getCurrencyCode().toString() : null;
/* 173:    */   }
/* 174:    */   
/* 175:    */   public String getCurrencyFieldLocalCurrencyCode(IGRCObject object, String fieldInfo)
/* 176:    */     throws Exception
/* 177:    */   {
/* 178:498 */     return getCurrencyFieldLocalCurrencyCode(getCurrencyField(object, fieldInfo));
/* 179:    */   }
/* 180:    */   
/* 181:    */   public void setCurrencyFieldLocalAmount(IField field, Double localAmount)
/* 182:    */     throws Exception
/* 183:    */   {
/* 184:535 */     ICurrencyField currencyField = null;
/* 185:    */     
/* 186:537 */     currencyField = getCurrencyField(field);
/* 187:539 */     if ((isCurrencyFieldNotNull(currencyField)) && (currencyField.canWrite())) {
/* 188:541 */       if ((isCurrencyFieldLocalAmountNotNull(currencyField)) || (CommonUtil.isObjectNotNull(localAmount)))
/* 189:    */       {
/* 190:542 */         this.logger.debug("Inside CurrencyFieldUtil: Name is: " + currencyField.getName() + " with value: " + localAmount);
/* 191:543 */         currencyField.setLocalAmount(localAmount);
/* 192:    */       }
/* 193:    */       else
/* 194:    */       {
/* 195:546 */         this.logger.debug("Inside CurrencyFieldUtil: Name is: " + currencyField.getName() + " with value: " + "0.0");
/* 196:547 */         currencyField.setLocalAmount(new Double(0.0D));
/* 197:    */       }
/* 198:    */     }
/* 199:    */   }
/* 200:    */   
/* 201:    */   public void setCurrencyFieldLocalAmount(IGRCObject object, String fieldInfo, Double localAmount)
/* 202:    */     throws Exception
/* 203:    */   {
/* 204:566 */     setCurrencyFieldLocalAmount(getCurrencyField(object, fieldInfo), localAmount);
/* 205:    */   }
/* 206:    */   
/* 207:    */   public void setCurrencyFieldLocalCurrency(IField field, ICurrency localCurrency)
/* 208:    */     throws Exception
/* 209:    */   {
/* 210:583 */     ICurrencyField currencyField = null;
/* 211:    */     
/* 212:585 */     currencyField = getCurrencyField(field);
/* 213:587 */     if ((isCurrencyFieldNotNull(currencyField)) && (currencyField.canWrite()) && (CommonUtil.isObjectNotNull(localCurrency)) && (localCurrency.isEnabled())) {
/* 214:589 */       currencyField.setLocalCurrency(localCurrency);
/* 215:    */     }
/* 216:    */   }
/* 217:    */   
/* 218:    */   public void setCurrencyFieldLocalCurrency(IGRCObject object, String fieldInfo, ICurrency localCurrency)
/* 219:    */     throws Exception
/* 220:    */   {
/* 221:607 */     setCurrencyFieldLocalCurrency(getCurrencyField(object, fieldInfo), localCurrency);
/* 222:    */   }
/* 223:    */   
/* 224:    */   public double getCurrencyFieldExchangeRate(IGRCObject object, String fieldInfo, Date date)
/* 225:    */     throws Exception
/* 226:    */   {
/* 227:625 */     return getCurrencyFieldExchangeRate(getCurrencyField(object, fieldInfo), date);
/* 228:    */   }
/* 229:    */   
/* 230:    */   public double getCurrencyFieldExchangeRate(IField field, Date date)
/* 231:    */     throws Exception
/* 232:    */   {
/* 233:642 */     double exchangeRate = 0.0D;
/* 234:643 */     ICurrencyField currencyField = null;
/* 235:644 */     IConfigurationService configurationService = null;
/* 236:    */     
/* 237:646 */     currencyField = getCurrencyField(field);
/* 238:648 */     if (CommonUtil.isObjectNotNull(currencyField))
/* 239:    */     {
/* 240:650 */       configurationService = this.serviceFactoryProxy.getServiceFactory().createConfigurationService();
/* 241:651 */       exchangeRate = configurationService.getExchangeRate(currencyField.getLocalCurrency(), date);
/* 242:    */     }
/* 243:654 */     return exchangeRate;
/* 244:    */   }
/* 245:    */   
/* 246:    */   public void setCurrencyFieldExchangeRate(IField field, Double exchangeRate)
/* 247:    */     throws Exception
/* 248:    */   {
/* 249:673 */     ICurrencyField currencyField = null;
/* 250:    */     
/* 251:675 */     currencyField = getCurrencyField(field);
/* 252:677 */     if ((isCurrencyFieldNotNull(currencyField)) && (currencyField.canWrite())) {
/* 253:679 */       currencyField.setExchangeRate(exchangeRate);
/* 254:    */     }
/* 255:    */   }
/* 256:    */   
/* 257:    */   public void setCurrencyFieldExchangeRate(IGRCObject object, String fieldInfo, Double exchangeRate)
/* 258:    */     throws Exception
/* 259:    */   {
/* 260:697 */     setCurrencyFieldExchangeRate(getCurrencyField(object, fieldInfo), exchangeRate);
/* 261:    */   }
/* 262:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.impl.CurrencyFieldUtil
 * JD-Core Version:    0.7.0.1
 */