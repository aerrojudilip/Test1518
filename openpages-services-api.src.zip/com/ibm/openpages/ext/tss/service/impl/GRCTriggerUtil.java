/*   1:    */ package com.ibm.openpages.ext.tss.service.impl;
/*   2:    */ 
/*   3:    */ import com.ibm.openpages.api.resource.IField;
/*   4:    */ import com.ibm.openpages.api.resource.IGRCObject;
/*   5:    */ import com.ibm.openpages.api.trigger.events.AbstractEvent;
/*   6:    */ import com.ibm.openpages.ext.tss.service.IFieldUtil;
/*   7:    */ import com.ibm.openpages.ext.tss.service.IGRCObjectSearchUtil;
/*   8:    */ import com.ibm.openpages.ext.tss.service.IGRCTriggerUtil;
/*   9:    */ import com.ibm.openpages.ext.tss.service.ILoggerUtil;
/*  10:    */ import com.ibm.openpages.ext.tss.service.beans.FieldValueChangeForSetTriggerAttributesInfo;
/*  11:    */ import com.ibm.openpages.ext.tss.service.beans.FieldValueChangeInfo;
/*  12:    */ import com.ibm.openpages.ext.tss.service.beans.IGRCFieldValidateInformation;
/*  13:    */ import com.ibm.openpages.ext.tss.service.constants.CheckFor;
/*  14:    */ import com.ibm.openpages.ext.tss.service.constants.Comparators;
/*  15:    */ import com.ibm.openpages.ext.tss.service.util.CommonUtil;
/*  16:    */ import com.openpages.sdk.trigger.grc.GRCTriggerCache;
/*  17:    */ import com.openpages.sdk.trigger.grc.GRCTriggerDefinition;
/*  18:    */ import java.util.HashMap;
/*  19:    */ import java.util.List;
/*  20:    */ import javax.annotation.PostConstruct;
/*  21:    */ import org.apache.commons.logging.Log;
/*  22:    */ import org.springframework.beans.factory.annotation.Autowired;
/*  23:    */ import org.springframework.stereotype.Service;
/*  24:    */ 
/*  25:    */ @Service("grcTriggerUtil")
/*  26:    */ public class GRCTriggerUtil
/*  27:    */   implements IGRCTriggerUtil
/*  28:    */ {
/*  29:    */   private Log logger;
/*  30:    */   @Autowired
/*  31:    */   ILoggerUtil loggerUtil;
/*  32:    */   @Autowired
/*  33:    */   IFieldUtil fieldUtil;
/*  34:    */   @Autowired
/*  35:    */   IGRCObjectSearchUtil objectSearchUtil;
/*  36:    */   
/*  37:    */   @PostConstruct
/*  38:    */   public void initService()
/*  39:    */   {
/*  40: 79 */     this.logger = this.loggerUtil.getExtLogger();
/*  41:    */   }
/*  42:    */   
/*  43:    */   public String getAttributeName(HashMap<String, String> attributesMap, String propertyName)
/*  44:    */     throws Exception
/*  45:    */   {
/*  46:101 */     return (String)attributesMap.get(propertyName);
/*  47:    */   }
/*  48:    */   
/*  49:    */   public void setAttributeInGRCTriggerDefinition(FieldValueChangeForSetTriggerAttributesInfo fieldValueChangeInfo)
/*  50:    */     throws Exception
/*  51:    */   {
/*  52:121 */     boolean isMatchingTriggerDefFound = false;
/*  53:    */     
/*  54:123 */     GRCTriggerCache triggerCache = null;
/*  55:124 */     List<GRCTriggerDefinition> triggerDefinitions = null;
/*  56:125 */     this.logger.debug("START setAttributeInGRCTriggerDefinition()");
/*  57:126 */     this.logger.debug("Trigger name to set attribute in:" + fieldValueChangeInfo.getTriggerName());
/*  58:127 */     this.logger.debug("Position: " + fieldValueChangeInfo.getTriggerPosition());
/*  59:128 */     this.logger.debug("Event Type: " + fieldValueChangeInfo.getTriggerEvent());
/*  60:129 */     this.logger.debug("Attribute Name: " + fieldValueChangeInfo.getTriggerAttributeName());
/*  61:130 */     this.logger.debug("Attribute Value" + fieldValueChangeInfo.getTriggerAttributeValue());
/*  62:131 */     triggerCache = GRCTriggerCache.getCache();
/*  63:132 */     triggerDefinitions = triggerCache.getGRCTriggerDefinition(fieldValueChangeInfo.getTriggerPosition(), fieldValueChangeInfo.getTriggerEvent());
/*  64:134 */     for (GRCTriggerDefinition triggerDefinition : triggerDefinitions)
/*  65:    */     {
/*  66:136 */       this.logger.debug("Trigger Definition Name:" + triggerDefinition.getName());
/*  67:138 */       if (CommonUtil.isEqual(fieldValueChangeInfo.getTriggerName(), triggerDefinition.getName()))
/*  68:    */       {
/*  69:140 */         this.logger.debug("Setting the value in the " + triggerDefinition.getName() + " attribute =" + fieldValueChangeInfo.getTriggerAttributeName() + " attributeValue =" + fieldValueChangeInfo.getTriggerAttributeValue());
/*  70:    */         
/*  71:142 */         triggerDefinition.setAttribute(fieldValueChangeInfo.getTriggerAttributeName(), fieldValueChangeInfo.getTriggerAttributeValue());
/*  72:    */       }
/*  73:    */     }
/*  74:146 */     this.logger.debug("Is Value found in trigger cache and attribute set: " + isMatchingTriggerDefFound);
/*  75:147 */     this.logger.debug("END setAttributeInGRCTriggerDefinition()");
/*  76:    */   }
/*  77:    */   
/*  78:    */   public String getAttributeInGRCTriggerDefinition(FieldValueChangeForSetTriggerAttributesInfo fieldValueChangeInfo)
/*  79:    */     throws Exception
/*  80:    */   {
/*  81:168 */     boolean isMatchingTriggerDefFound = false;
/*  82:    */     
/*  83:170 */     String attributeValue = "";
/*  84:171 */     GRCTriggerCache triggerCache = null;
/*  85:172 */     List<GRCTriggerDefinition> triggerDefinitions = null;
/*  86:    */     
/*  87:174 */     this.logger.debug("START getAttributeInGRCTriggerDefinition()");
/*  88:175 */     this.logger.debug("Trigger name to set attribute in:" + fieldValueChangeInfo.getTriggerName());
/*  89:176 */     this.logger.debug("Position: " + fieldValueChangeInfo.getTriggerPosition());
/*  90:177 */     this.logger.debug("Event Type: " + fieldValueChangeInfo.getTriggerEvent());
/*  91:178 */     this.logger.debug("Attribute Name: " + fieldValueChangeInfo.getTriggerAttributeName());
/*  92:    */     
/*  93:180 */     triggerCache = GRCTriggerCache.getCache();
/*  94:181 */     triggerDefinitions = triggerCache.getGRCTriggerDefinition(fieldValueChangeInfo.getTriggerPosition(), fieldValueChangeInfo.getTriggerEvent());
/*  95:183 */     for (GRCTriggerDefinition triggerDefinition : triggerDefinitions)
/*  96:    */     {
/*  97:185 */       this.logger.debug("Trigger Definition Name:" + triggerDefinition.getName());
/*  98:187 */       if (CommonUtil.isEqual(fieldValueChangeInfo.getTriggerName(), triggerDefinition.getName()))
/*  99:    */       {
/* 100:189 */         isMatchingTriggerDefFound = true;
/* 101:190 */         attributeValue = triggerDefinition.getAttribute(fieldValueChangeInfo.getTriggerAttributeName());
/* 102:    */         
/* 103:192 */         this.logger.debug("Attribute Value" + attributeValue);
/* 104:193 */         this.logger.debug("Setting the value in the " + triggerDefinition.getName() + " attribute =" + fieldValueChangeInfo.getTriggerAttributeName() + " attributeValue =" + attributeValue);
/* 105:    */       }
/* 106:    */     }
/* 107:197 */     this.logger.debug("Is Value found in trigger cache: " + isMatchingTriggerDefFound);
/* 108:198 */     this.logger.debug("END getAttributeInGRCTriggerDefinition()");
/* 109:199 */     return attributeValue;
/* 110:    */   }
/* 111:    */   
/* 112:    */   public FieldValueChangeForSetTriggerAttributesInfo populateTriggerSetAttributesP(AbstractEvent event, FieldValueChangeForSetTriggerAttributesInfo fieldValueChangeInfo, HashMap<String, String> attributesMap)
/* 113:    */     throws Exception
/* 114:    */   {
/* 115:222 */     fieldValueChangeInfo = CommonUtil.isObjectNotNull(fieldValueChangeInfo) ? fieldValueChangeInfo : new FieldValueChangeForSetTriggerAttributesInfo();
/* 116:223 */     fieldValueChangeInfo.setTriggerEvent(event.getTriggerEventType());
/* 117:224 */     fieldValueChangeInfo.setTriggerPosition(event.getPosition());
/* 118:225 */     fieldValueChangeInfo.setTriggerName(getAttributeName(attributesMap, "trigger.name"));
/* 119:    */     
/* 120:227 */     return fieldValueChangeInfo;
/* 121:    */   }
/* 122:    */   
/* 123:    */   public boolean matchFieldValueToAGivenValue(IGRCObject object, IGRCFieldValidateInformation fieldValidateInfo)
/* 124:    */     throws Exception
/* 125:    */   {
/* 126:248 */     boolean isApplicable = false;
/* 127:249 */     boolean returnValForAll = true;
/* 128:250 */     boolean returnValForAny = false;
/* 129:    */     
/* 130:    */ 
/* 131:    */ 
/* 132:254 */     initService();
/* 133:255 */     this.logger.debug("Field Value Change Information: " + fieldValidateInfo.toString());
/* 134:    */     try
/* 135:    */     {
/* 136:259 */       int count = 0;
/* 137:261 */       if (CheckFor.contains(fieldValidateInfo.getCheckFor())) {
/* 138:264 */         for (String fieldInfo : fieldValidateInfo.getFieldsList())
/* 139:    */         {
/* 140:266 */           boolean flag = false;
/* 141:268 */           if (this.fieldUtil.compareFields(this.fieldUtil.getField(object, fieldInfo), (String)fieldValidateInfo.getFieldValuesList().get(count), (String)fieldValidateInfo.getComparatorsList().get(count)))
/* 142:    */           {
/* 143:272 */             if (CheckFor.CHECK_ANY.equals(CheckFor.valueOf(fieldValidateInfo.getCheckFor())))
/* 144:    */             {
/* 145:274 */               returnValForAny = true;
/* 146:275 */               break;
/* 147:    */             }
/* 148:276 */             if (CheckFor.CHECK_ALL.equals(CheckFor.valueOf(fieldValidateInfo.getCheckFor()))) {
/* 149:278 */               flag = true;
/* 150:    */             }
/* 151:    */           }
/* 152:282 */           if ((CheckFor.CHECK_ALL.equals(fieldValidateInfo.getCheckFor())) && (!flag))
/* 153:    */           {
/* 154:284 */             returnValForAll = false;
/* 155:285 */             break;
/* 156:    */           }
/* 157:288 */           count++;
/* 158:    */         }
/* 159:    */       }
/* 160:292 */       if (CheckFor.CHECK_ALL.equals(CheckFor.valueOf(fieldValidateInfo.getCheckFor()))) {
/* 161:294 */         isApplicable = returnValForAll;
/* 162:295 */       } else if (CheckFor.CHECK_ANY.equals(CheckFor.valueOf(fieldValidateInfo.getCheckFor()))) {
/* 163:297 */         isApplicable = returnValForAny;
/* 164:    */       } else {
/* 165:300 */         return false;
/* 166:    */       }
/* 167:    */     }
/* 168:    */     catch (Exception e)
/* 169:    */     {
/* 170:303 */       this.logger.error("EXCEPTION!!!!!!!!!!!!!!! detectPropertyChangeToAGivenValue: " + CommonUtil.getStackTrace(e));
/* 171:304 */       isApplicable = false;
/* 172:    */     }
/* 173:307 */     this.logger.debug("Returning :" + isApplicable);
/* 174:308 */     return isApplicable;
/* 175:    */   }
/* 176:    */   
/* 177:    */   public boolean detectPropertyChange(FieldValueChangeInfo fieldValueChangeInfo)
/* 178:    */     throws Exception
/* 179:    */   {
/* 180:329 */     boolean isApplicable = false;
/* 181:330 */     boolean returnValForAll = true;
/* 182:331 */     boolean returnValForAny = false;
/* 183:    */     
/* 184:    */ 
/* 185:    */ 
/* 186:335 */     this.logger.debug("Detect Property Change Information: " + fieldValueChangeInfo.toString());
/* 187:    */     try
/* 188:    */     {
/* 189:339 */       for (String fieldName : fieldValueChangeInfo.getFieldNamesList())
/* 190:    */       {
/* 191:341 */         boolean flag = false;
/* 192:342 */         for (IField modifiedField : fieldValueChangeInfo.getModifiedFields()) {
/* 193:344 */           if (modifiedField.getName().equals(fieldName))
/* 194:    */           {
/* 195:346 */             if (CheckFor.CHECK_ANY.equals(fieldValueChangeInfo.getCheckFor()))
/* 196:    */             {
/* 197:347 */               returnValForAny = true;
/* 198:348 */               break;
/* 199:    */             }
/* 200:349 */             if (CheckFor.CHECK_ALL.equals(fieldValueChangeInfo.getCheckFor())) {
/* 201:350 */               flag = true;
/* 202:    */             }
/* 203:    */           }
/* 204:    */         }
/* 205:355 */         if ((CheckFor.CHECK_ALL.equals(fieldValueChangeInfo.getCheckFor())) && (!flag))
/* 206:    */         {
/* 207:356 */           returnValForAll = false;
/* 208:357 */           break;
/* 209:    */         }
/* 210:    */       }
/* 211:    */     }
/* 212:    */     catch (Exception e)
/* 213:    */     {
/* 214:361 */       this.logger.error("EXCEPTION!!!!!!!!!!!!!!! handleEvent(CreateResourceEvent)" + CommonUtil.getStackTrace(e));
/* 215:362 */       isApplicable = false;
/* 216:    */     }
/* 217:365 */     if (CheckFor.CHECK_ALL.equals(fieldValueChangeInfo.getCheckFor())) {
/* 218:366 */       isApplicable = returnValForAll;
/* 219:367 */     } else if (CheckFor.CHECK_ANY.equals(fieldValueChangeInfo.getCheckFor())) {
/* 220:368 */       isApplicable = returnValForAny;
/* 221:    */     } else {
/* 222:370 */       return false;
/* 223:    */     }
/* 224:373 */     return isApplicable;
/* 225:    */   }
/* 226:    */   
/* 227:    */   public boolean detectPropertyChangeToAGivenValue(FieldValueChangeInfo fieldValueChangeInfo)
/* 228:    */     throws Exception
/* 229:    */   {
/* 230:394 */     boolean isApplicable = false;
/* 231:395 */     boolean returnValForAll = true;
/* 232:396 */     boolean returnValForAny = false;
/* 233:    */     
/* 234:    */ 
/* 235:    */ 
/* 236:400 */     initService();
/* 237:401 */     this.logger.debug("Field Value Change Information: " + fieldValueChangeInfo.toString());
/* 238:    */     try
/* 239:    */     {
/* 240:405 */       count = 0;
/* 241:407 */       for (String field : fieldValueChangeInfo.getFieldNamesList())
/* 242:    */       {
/* 243:409 */         boolean flag = false;
/* 244:410 */         for (IField modifiedField : fieldValueChangeInfo.getModifiedFields()) {
/* 245:412 */           if (modifiedField.getName().equals(field))
/* 246:    */           {
/* 247:414 */             this.logger.debug("Modified Field name is equal to Field Name");
/* 248:416 */             if ((CommonUtil.isEqual((String)fieldValueChangeInfo.getValuesList().get(count), Comparators.NOT_NULL_OR_EMPTY.toString())) && (CommonUtil.isNotNullOrEmpty(this.fieldUtil.getFieldValueAsString(modifiedField))))
/* 249:    */             {
/* 250:419 */               this.logger.debug("Check if Field value is NOT_NULL_OR_EMPTY");
/* 251:420 */               if (CheckFor.CHECK_ANY.equals(fieldValueChangeInfo.getCheckFor()))
/* 252:    */               {
/* 253:421 */                 returnValForAny = true;
/* 254:422 */                 break;
/* 255:    */               }
/* 256:423 */               if (CheckFor.CHECK_ALL.equals(fieldValueChangeInfo.getCheckFor())) {
/* 257:424 */                 flag = true;
/* 258:    */               }
/* 259:    */             }
/* 260:427 */             else if ((CommonUtil.isEqual((String)fieldValueChangeInfo.getValuesList().get(count), Comparators.NULL_OR_EMPTY.toString())) && (CommonUtil.isNullOrEmpty(this.fieldUtil.getFieldValueAsString(modifiedField))))
/* 261:    */             {
/* 262:430 */               this.logger.debug("Check if Field value is NULL_OR_EMPTY");
/* 263:431 */               if (CheckFor.CHECK_ANY.equals(fieldValueChangeInfo.getCheckFor()))
/* 264:    */               {
/* 265:432 */                 returnValForAny = true;
/* 266:433 */                 break;
/* 267:    */               }
/* 268:434 */               if (CheckFor.CHECK_ALL.equals(fieldValueChangeInfo.getCheckFor())) {
/* 269:435 */                 flag = true;
/* 270:    */               }
/* 271:    */             }
/* 272:438 */             else if (CommonUtil.isEqual(this.fieldUtil.getFieldValueAsString(modifiedField), (String)fieldValueChangeInfo.getValuesList().get(count)))
/* 273:    */             {
/* 274:440 */               this.logger.debug("Check if Field value is equal to expected value");
/* 275:441 */               if (CheckFor.CHECK_ANY.equals(fieldValueChangeInfo.getCheckFor()))
/* 276:    */               {
/* 277:442 */                 returnValForAny = true;
/* 278:443 */                 break;
/* 279:    */               }
/* 280:444 */               if (CheckFor.CHECK_ALL.equals(fieldValueChangeInfo.getCheckFor())) {
/* 281:445 */                 flag = true;
/* 282:    */               }
/* 283:    */             }
/* 284:    */           }
/* 285:    */         }
/* 286:450 */         if ((CheckFor.CHECK_ALL.equals(fieldValueChangeInfo.getCheckFor())) && (!flag))
/* 287:    */         {
/* 288:451 */           returnValForAll = false;
/* 289:452 */           break;
/* 290:    */         }
/* 291:455 */         count++;
/* 292:    */       }
/* 293:    */     }
/* 294:    */     catch (Exception e)
/* 295:    */     {
/* 296:    */       int count;
/* 297:458 */       this.logger.error("EXCEPTION!!!!!!!!!!!!!!! detectPropertyChangeToAGivenValue: " + CommonUtil.getStackTrace(e));
/* 298:459 */       isApplicable = false;
/* 299:    */     }
/* 300:462 */     if (CheckFor.CHECK_ALL.equals(fieldValueChangeInfo.getCheckFor())) {
/* 301:463 */       isApplicable = returnValForAll;
/* 302:464 */     } else if (CheckFor.CHECK_ANY.equals(fieldValueChangeInfo.getCheckFor())) {
/* 303:465 */       isApplicable = returnValForAny;
/* 304:    */     } else {
/* 305:467 */       return false;
/* 306:    */     }
/* 307:470 */     return isApplicable;
/* 308:    */   }
/* 309:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.impl.GRCTriggerUtil
 * JD-Core Version:    0.7.0.1
 */