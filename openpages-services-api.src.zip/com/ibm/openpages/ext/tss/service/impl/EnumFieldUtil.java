/*   1:    */ package com.ibm.openpages.ext.tss.service.impl;
/*   2:    */ 
/*   3:    */ import com.ibm.openpages.api.metadata.DataType;
/*   4:    */ import com.ibm.openpages.api.metadata.IEnumValue;
/*   5:    */ import com.ibm.openpages.api.metadata.IFieldDefinition;
/*   6:    */ import com.ibm.openpages.api.resource.IEnumField;
/*   7:    */ import com.ibm.openpages.api.resource.IField;
/*   8:    */ import com.ibm.openpages.api.resource.IGRCObject;
/*   9:    */ import com.ibm.openpages.ext.tss.service.IEnumFieldUtil;
/*  10:    */ import com.ibm.openpages.ext.tss.service.ILoggerUtil;
/*  11:    */ import com.ibm.openpages.ext.tss.service.util.CommonUtil;
/*  12:    */ import java.util.ArrayList;
/*  13:    */ import java.util.List;
/*  14:    */ import javax.annotation.PostConstruct;
/*  15:    */ import org.apache.commons.logging.Log;
/*  16:    */ import org.springframework.beans.factory.annotation.Autowired;
/*  17:    */ import org.springframework.stereotype.Service;
/*  18:    */ 
/*  19:    */ @Service("enumFieldUtil")
/*  20:    */ public class EnumFieldUtil
/*  21:    */   implements IEnumFieldUtil
/*  22:    */ {
/*  23:    */   private Log logger;
/*  24:    */   @Autowired
/*  25:    */   ILoggerUtil loggerUtil;
/*  26:    */   
/*  27:    */   @PostConstruct
/*  28:    */   public void initService()
/*  29:    */   {
/*  30: 59 */     this.logger = this.loggerUtil.getExtLogger();
/*  31:    */   }
/*  32:    */   
/*  33:    */   public IEnumField getEnumField(IField field)
/*  34:    */     throws Exception
/*  35:    */   {
/*  36: 78 */     return DataType.ENUM_TYPE.equals(field.getDataType()) ? (IEnumField)field : null;
/*  37:    */   }
/*  38:    */   
/*  39:    */   public IEnumField getEnumField(IGRCObject object, String fieldInfo)
/*  40:    */     throws Exception
/*  41:    */   {
/*  42: 98 */     return getEnumField(object.getField(fieldInfo));
/*  43:    */   }
/*  44:    */   
/*  45:    */   public boolean isEnumFieldNull(IField field)
/*  46:    */     throws Exception
/*  47:    */   {
/*  48:114 */     return CommonUtil.isObjectNull(getEnumField(field));
/*  49:    */   }
/*  50:    */   
/*  51:    */   public boolean isEnumFieldNull(IGRCObject object, String fieldInfo)
/*  52:    */     throws Exception
/*  53:    */   {
/*  54:133 */     return isEnumFieldNull(getEnumField(object, fieldInfo));
/*  55:    */   }
/*  56:    */   
/*  57:    */   public boolean isEnumFieldNotNull(IField field)
/*  58:    */     throws Exception
/*  59:    */   {
/*  60:149 */     return !isEnumFieldNull(field);
/*  61:    */   }
/*  62:    */   
/*  63:    */   public boolean isEnumFieldNotNull(IGRCObject object, String fieldInfo)
/*  64:    */     throws Exception
/*  65:    */   {
/*  66:168 */     return isEnumFieldNotNull(getEnumField(object, fieldInfo));
/*  67:    */   }
/*  68:    */   
/*  69:    */   public boolean isEnumFieldValueNull(IField field)
/*  70:    */     throws Exception
/*  71:    */   {
/*  72:184 */     return CommonUtil.isObjectNull(getEnumFieldValue(field));
/*  73:    */   }
/*  74:    */   
/*  75:    */   public boolean isEnumFieldValueNull(IGRCObject object, String fieldInfo)
/*  76:    */     throws Exception
/*  77:    */   {
/*  78:203 */     return isEnumFieldValueNull(getEnumField(object, fieldInfo));
/*  79:    */   }
/*  80:    */   
/*  81:    */   public boolean isEnumFieldValueNotNull(IField field)
/*  82:    */     throws Exception
/*  83:    */   {
/*  84:219 */     return !isEnumFieldValueNull(field);
/*  85:    */   }
/*  86:    */   
/*  87:    */   public boolean isEnumFieldValueNotNull(IGRCObject object, String fieldInfo)
/*  88:    */     throws Exception
/*  89:    */   {
/*  90:238 */     return isEnumFieldValueNotNull(getEnumField(object, fieldInfo));
/*  91:    */   }
/*  92:    */   
/*  93:    */   public IEnumValue getEnumFieldValue(IField field)
/*  94:    */     throws Exception
/*  95:    */   {
/*  96:257 */     return isEnumFieldNotNull(field) ? getEnumField(field).getEnumValue() : null;
/*  97:    */   }
/*  98:    */   
/*  99:    */   public IEnumValue getEnumFieldValue(IGRCObject object, String fieldInfo)
/* 100:    */     throws Exception
/* 101:    */   {
/* 102:276 */     return getEnumFieldValue(getEnumField(object, fieldInfo));
/* 103:    */   }
/* 104:    */   
/* 105:    */   public String getEnumFieldSelectedValue(IField field)
/* 106:    */     throws Exception
/* 107:    */   {
/* 108:295 */     return CommonUtil.isObjectNotNull(getEnumFieldValue(field)) ? getEnumFieldValue(field).getName() : null;
/* 109:    */   }
/* 110:    */   
/* 111:    */   public String getEnumFieldSelectedValue(IGRCObject object, String fieldInfo)
/* 112:    */     throws Exception
/* 113:    */   {
/* 114:314 */     return getEnumFieldSelectedValue(getEnumField(object, fieldInfo));
/* 115:    */   }
/* 116:    */   
/* 117:    */   public List<String> getAllValuesInEnumFieldAsList(IFieldDefinition fieldDefinition)
/* 118:    */     throws Exception
/* 119:    */   {
/* 120:333 */     List<String> enumValues = null;
/* 121:    */     
/* 122:335 */     enumValues = new ArrayList();
/* 123:336 */     List<IEnumValue> enumVals = fieldDefinition.getEnumValues();
/* 124:338 */     for (IEnumValue enumVal : enumVals) {
/* 125:340 */       enumValues.add(enumVal.getName());
/* 126:    */     }
/* 127:343 */     return enumValues;
/* 128:    */   }
/* 129:    */   
/* 130:    */   public List<String> getActiveValuesInEnumFieldAsList(IFieldDefinition fieldDefinition)
/* 131:    */     throws Exception
/* 132:    */   {
/* 133:362 */     List<String> enumValues = null;
/* 134:    */     
/* 135:364 */     enumValues = new ArrayList();
/* 136:365 */     List<IEnumValue> enumVals = fieldDefinition.getEnumValues();
/* 137:367 */     for (IEnumValue enumVal : enumVals) {
/* 138:369 */       if (!enumVal.isHidden()) {
/* 139:371 */         enumValues.add(enumVal.getName());
/* 140:    */       }
/* 141:    */     }
/* 142:375 */     return enumValues;
/* 143:    */   }
/* 144:    */   
/* 145:    */   public List<String> getHiddenValuesInEnumFieldAsList(IFieldDefinition fieldDefinition)
/* 146:    */     throws Exception
/* 147:    */   {
/* 148:394 */     List<String> enumValues = null;
/* 149:    */     
/* 150:396 */     enumValues = new ArrayList();
/* 151:397 */     List<IEnumValue> enumVals = fieldDefinition.getEnumValues();
/* 152:399 */     for (IEnumValue enumVal : enumVals) {
/* 153:401 */       if (enumVal.isHidden()) {
/* 154:403 */         enumValues.add(enumVal.getName());
/* 155:    */       }
/* 156:    */     }
/* 157:407 */     return enumValues;
/* 158:    */   }
/* 159:    */   
/* 160:    */   public List<String> getAllValuesInEnumFieldAsList(IField field)
/* 161:    */     throws Exception
/* 162:    */   {
/* 163:426 */     return getAllValuesInEnumFieldAsList(getEnumField(field).getFieldDefinition());
/* 164:    */   }
/* 165:    */   
/* 166:    */   public List<String> getAllValuesInEnumFieldAsList(IGRCObject object, String fieldInfo)
/* 167:    */     throws Exception
/* 168:    */   {
/* 169:445 */     return getAllValuesInEnumFieldAsList(getEnumField(object, fieldInfo));
/* 170:    */   }
/* 171:    */   
/* 172:    */   public List<String> getActiveValuesInEnumFieldAsList(IField field)
/* 173:    */     throws Exception
/* 174:    */   {
/* 175:464 */     return getAllValuesInEnumFieldAsList(getEnumField(field).getFieldDefinition());
/* 176:    */   }
/* 177:    */   
/* 178:    */   public List<String> getActiveValuesInEnumFieldAsList(IGRCObject object, String fieldInfo)
/* 179:    */     throws Exception
/* 180:    */   {
/* 181:484 */     return getAllValuesInEnumFieldAsList(getEnumField(object, fieldInfo));
/* 182:    */   }
/* 183:    */   
/* 184:    */   public List<String> getHiddenValuesInEnumFieldAsList(IField field)
/* 185:    */     throws Exception
/* 186:    */   {
/* 187:503 */     return getAllValuesInEnumFieldAsList(getEnumField(field).getFieldDefinition());
/* 188:    */   }
/* 189:    */   
/* 190:    */   public List<String> getHiddenValuesInEnumFieldAsList(IGRCObject object, String fieldInfo)
/* 191:    */     throws Exception
/* 192:    */   {
/* 193:523 */     return getAllValuesInEnumFieldAsList(getEnumField(object, fieldInfo));
/* 194:    */   }
/* 195:    */   
/* 196:    */   public boolean isEnumFieldValueMatchExpectedValue(IField field, String expectedFieldValue)
/* 197:    */     throws Exception
/* 198:    */   {
/* 199:544 */     String enumFieldValue = getEnumFieldSelectedValue(field);
/* 200:546 */     if (CommonUtil.isNotNullOrEmpty(enumFieldValue)) {
/* 201:548 */       if (enumFieldValue.equalsIgnoreCase(expectedFieldValue)) {
/* 202:549 */         return true;
/* 203:    */       }
/* 204:    */     }
/* 205:552 */     return false;
/* 206:    */   }
/* 207:    */   
/* 208:    */   public boolean isEnumFieldValueMatchExpectedValue(IGRCObject object, String fieldInfo, String expectedFieldValue)
/* 209:    */     throws Exception
/* 210:    */   {
/* 211:573 */     return isEnumFieldValueMatchExpectedValue(getEnumField(object, fieldInfo), expectedFieldValue);
/* 212:    */   }
/* 213:    */   
/* 214:    */   public boolean isEnumFieldValueMatchAnyDesiredValues(IField field, List<String> desiredValuesList)
/* 215:    */     throws Exception
/* 216:    */   {
/* 217:594 */     boolean isEnumFieldValueMatchDesiredValues = false;
/* 218:596 */     for (String fieldValue : desiredValuesList)
/* 219:    */     {
/* 220:598 */       isEnumFieldValueMatchDesiredValues = (isEnumFieldValueMatchDesiredValues) || (isEnumFieldValueMatchExpectedValue(field, fieldValue));
/* 221:600 */       if (isEnumFieldValueMatchDesiredValues) {
/* 222:    */         break;
/* 223:    */       }
/* 224:    */     }
/* 225:604 */     return isEnumFieldValueMatchDesiredValues;
/* 226:    */   }
/* 227:    */   
/* 228:    */   public boolean isEnumFieldValueMatchAnyDesiredValues(IGRCObject object, String fieldInfo, List<String> desiredValuesList)
/* 229:    */     throws Exception
/* 230:    */   {
/* 231:626 */     return isEnumFieldValueMatchAnyDesiredValues(getEnumField(object, fieldInfo), desiredValuesList);
/* 232:    */   }
/* 233:    */   
/* 234:    */   public boolean isEnumFieldValueMatchAnyDesiredValues(IField field, String desiredValues)
/* 235:    */     throws Exception
/* 236:    */   {
/* 237:647 */     return isEnumFieldValueMatchAnyDesiredValues(field, CommonUtil.parseDelimitedValues(desiredValues, ","));
/* 238:    */   }
/* 239:    */   
/* 240:    */   public boolean isEnumFieldValueMatchAnyDesiredValues(IGRCObject object, String fieldInfo, String desiredValues)
/* 241:    */     throws Exception
/* 242:    */   {
/* 243:670 */     return isEnumFieldValueMatchAnyDesiredValues(getEnumField(object, fieldInfo), desiredValues);
/* 244:    */   }
/* 245:    */   
/* 246:    */   public void setEnumFieldValue(IGRCObject object, String fieldInfo, String setValue)
/* 247:    */     throws Exception
/* 248:    */   {
/* 249:690 */     setEnumFieldValue(getEnumField(object, fieldInfo), setValue);
/* 250:    */   }
/* 251:    */   
/* 252:    */   public void setEnumFieldValue(IEnumField field, String setValue)
/* 253:    */     throws Exception
/* 254:    */   {
/* 255:709 */     setEnumFieldValue(field, getEnumValueFromField(field, setValue));
/* 256:    */   }
/* 257:    */   
/* 258:    */   public void setEnumFieldValue(IEnumField enumField, IEnumValue value)
/* 259:    */     throws Exception
/* 260:    */   {
/* 261:726 */     if (isEnumFieldNotNull(enumField)) {
/* 262:727 */       enumField.setEnumValue(value);
/* 263:    */     }
/* 264:    */   }
/* 265:    */   
/* 266:    */   private IEnumValue getEnumValueFromField(IField field, String enumVal)
/* 267:    */     throws Exception
/* 268:    */   {
/* 269:732 */     IEnumValue returnValue = null;
/* 270:733 */     IFieldDefinition fieldDef = field.getFieldDefinition();
/* 271:734 */     List<IEnumValue> enumValues = fieldDef.getEnumValues();
/* 272:736 */     if (CommonUtil.isObjectNotNull(enumVal)) {
/* 273:738 */       for (IEnumValue val : enumValues)
/* 274:    */       {
/* 275:739 */         String name = val.getName();
/* 276:740 */         this.logger.debug("Value in the Enumerated field: " + name);
/* 277:741 */         this.logger.debug("Is " + name + " Equal to " + enumVal + ": " + name.equals(enumVal));
/* 278:742 */         if (name.equals(enumVal)) {
/* 279:744 */           returnValue = val;
/* 280:    */         }
/* 281:    */       }
/* 282:    */     }
/* 283:749 */     return returnValue;
/* 284:    */   }
/* 285:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.impl.EnumFieldUtil
 * JD-Core Version:    0.7.0.1
 */