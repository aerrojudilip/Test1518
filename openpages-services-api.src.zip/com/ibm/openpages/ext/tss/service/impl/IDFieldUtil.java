/*   1:    */ package com.ibm.openpages.ext.tss.service.impl;
/*   2:    */ 
/*   3:    */ import com.ibm.openpages.api.metadata.DataType;
/*   4:    */ import com.ibm.openpages.api.metadata.Id;
/*   5:    */ import com.ibm.openpages.api.resource.IField;
/*   6:    */ import com.ibm.openpages.api.resource.IGRCObject;
/*   7:    */ import com.ibm.openpages.api.resource.IIdField;
/*   8:    */ import com.ibm.openpages.ext.tss.service.IIDFieldUtil;
/*   9:    */ import com.ibm.openpages.ext.tss.service.ILoggerUtil;
/*  10:    */ import com.ibm.openpages.ext.tss.service.util.CommonUtil;
/*  11:    */ import javax.annotation.PostConstruct;
/*  12:    */ import org.apache.commons.logging.Log;
/*  13:    */ import org.springframework.beans.factory.annotation.Autowired;
/*  14:    */ import org.springframework.stereotype.Service;
/*  15:    */ 
/*  16:    */ @Service("idFieldUtil")
/*  17:    */ public class IDFieldUtil
/*  18:    */   implements IIDFieldUtil
/*  19:    */ {
/*  20:    */   private Log logger;
/*  21:    */   @Autowired
/*  22:    */   ILoggerUtil loggerUtil;
/*  23:    */   
/*  24:    */   @PostConstruct
/*  25:    */   public void initService()
/*  26:    */   {
/*  27: 56 */     this.logger = this.loggerUtil.getExtLogger();
/*  28:    */   }
/*  29:    */   
/*  30:    */   public IIdField getIdField(IField field)
/*  31:    */     throws Exception
/*  32:    */   {
/*  33: 75 */     return DataType.ID_TYPE.equals(field.getDataType()) ? (IIdField)field : null;
/*  34:    */   }
/*  35:    */   
/*  36:    */   public IIdField getIdField(IGRCObject object, String fieldInfo)
/*  37:    */     throws Exception
/*  38:    */   {
/*  39: 95 */     return getIdField(object.getField(fieldInfo));
/*  40:    */   }
/*  41:    */   
/*  42:    */   public boolean isIdFieldNull(IField field)
/*  43:    */     throws Exception
/*  44:    */   {
/*  45:111 */     return CommonUtil.isObjectNull(getIdField(field));
/*  46:    */   }
/*  47:    */   
/*  48:    */   public boolean isIdFieldNull(IGRCObject object, String fieldInfo)
/*  49:    */     throws Exception
/*  50:    */   {
/*  51:130 */     return isIdFieldNull(getIdField(object, fieldInfo));
/*  52:    */   }
/*  53:    */   
/*  54:    */   public boolean isIdFieldNotNull(IField field)
/*  55:    */     throws Exception
/*  56:    */   {
/*  57:146 */     return !isIdFieldNull(field);
/*  58:    */   }
/*  59:    */   
/*  60:    */   public boolean isIdFieldNotNull(IGRCObject object, String fieldInfo)
/*  61:    */     throws Exception
/*  62:    */   {
/*  63:165 */     return isIdFieldNotNull(getIdField(object, fieldInfo));
/*  64:    */   }
/*  65:    */   
/*  66:    */   public String getIdFieldValueAsString(IField field)
/*  67:    */     throws Exception
/*  68:    */   {
/*  69:184 */     return (isIdFieldNotNull(field)) && (CommonUtil.isObjectNotNull(getIdField(field))) && (CommonUtil.isObjectNotNull(getIdField(field).getValue())) ? getIdField(field).getValue().toString() : null;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public String getIdFieldValueAsString(IGRCObject object, String fieldInfo)
/*  73:    */     throws Exception
/*  74:    */   {
/*  75:204 */     return getIdFieldValueAsString(getIdField(object, fieldInfo));
/*  76:    */   }
/*  77:    */   
/*  78:    */   public Id getIdFieldValue(IGRCObject object, String fieldInfo)
/*  79:    */     throws Exception
/*  80:    */   {
/*  81:223 */     return getIdFieldValue(getIdField(object, fieldInfo));
/*  82:    */   }
/*  83:    */   
/*  84:    */   public Id getIdFieldValue(IField field)
/*  85:    */     throws Exception
/*  86:    */   {
/*  87:242 */     return isIdFieldNotNull(field) ? getIdField(field).getValue() : null;
/*  88:    */   }
/*  89:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.impl.IDFieldUtil
 * JD-Core Version:    0.7.0.1
 */