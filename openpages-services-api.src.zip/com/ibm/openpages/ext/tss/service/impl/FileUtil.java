/*   1:    */ package com.ibm.openpages.ext.tss.service.impl;
/*   2:    */ 
/*   3:    */ import com.ibm.openpages.ext.tss.service.IFileUtil;
/*   4:    */ import com.ibm.openpages.ext.tss.service.constants.CommonConstants;
/*   5:    */ import com.ibm.openpages.ext.tss.service.util.CommonUtil;
/*   6:    */ import com.openpages.aurora.util.FileIOUtil;
/*   7:    */ import java.io.File;
/*   8:    */ import java.util.Map;
/*   9:    */ import org.springframework.stereotype.Service;
/*  10:    */ 
/*  11:    */ @Service("fileUtil")
/*  12:    */ public class FileUtil
/*  13:    */   implements IFileUtil
/*  14:    */ {
/*  15:    */   public String copyFile(String newFileNamePrefix, String absoluteSourceFileName)
/*  16:    */     throws Exception
/*  17:    */   {
/*  18: 45 */     String fileName = "";
/*  19: 46 */     String fileDirectoryPath = "";
/*  20:    */     
/*  21:    */ 
/*  22: 49 */     fileName = absoluteSourceFileName.substring(absoluteSourceFileName.lastIndexOf("\\") + 1);
/*  23: 50 */     fileDirectoryPath = absoluteSourceFileName.substring(0, absoluteSourceFileName.lastIndexOf("\\") + 1);
/*  24:    */     
/*  25: 52 */     return copyFile(newFileNamePrefix, fileDirectoryPath, fileName);
/*  26:    */   }
/*  27:    */   
/*  28:    */   public String copyFile(String prefix, String sourceFilePath, String sourceFileName)
/*  29:    */     throws Exception
/*  30:    */   {
/*  31: 72 */     File destFile = null;
/*  32: 73 */     File sourceFile = null;
/*  33: 74 */     FileIOUtil fileIOUtil = null;
/*  34:    */     
/*  35:    */ 
/*  36: 77 */     fileIOUtil = new FileIOUtil();
/*  37: 78 */     sourceFile = new File(sourceFilePath + sourceFileName);
/*  38: 79 */     destFile = new File(sourceFilePath + prefix + sourceFileName);
/*  39:    */     
/*  40: 81 */     fileIOUtil.copyFile(sourceFile, destFile, true);
/*  41: 82 */     return destFile.getAbsolutePath();
/*  42:    */   }
/*  43:    */   
/*  44:    */   public void deleteFile(String filePath)
/*  45:    */     throws Exception
/*  46:    */   {
/*  47: 97 */     File file = null;
/*  48: 98 */     FileIOUtil fileIOUtil = null;
/*  49:    */     
/*  50:    */ 
/*  51:101 */     fileIOUtil = new FileIOUtil();
/*  52:102 */     file = new File(filePath);
/*  53:103 */     fileIOUtil.deleteFile(file);
/*  54:    */   }
/*  55:    */   
/*  56:    */   public String getFileNameWithoutExtension(String filePath)
/*  57:    */   {
/*  58:123 */     int index = 0;
/*  59:124 */     String fileName = "";
/*  60:127 */     if (CommonUtil.isNotNullOrEmpty(filePath))
/*  61:    */     {
/*  62:129 */       index = filePath.lastIndexOf("/");
/*  63:130 */       if (index > 0)
/*  64:    */       {
/*  65:132 */         fileName = filePath.substring(index + 1, filePath.length());
/*  66:133 */         index = fileName.lastIndexOf(".");
/*  67:134 */         if (index > 0) {
/*  68:136 */           fileName = fileName.substring(0, index);
/*  69:    */         }
/*  70:    */       }
/*  71:    */       else
/*  72:    */       {
/*  73:140 */         index = filePath.lastIndexOf("//");
/*  74:141 */         if (index > 0)
/*  75:    */         {
/*  76:143 */           fileName = filePath.substring(index + 1, filePath.length());
/*  77:144 */           index = fileName.lastIndexOf(".");
/*  78:145 */           if (index > 0) {
/*  79:147 */             fileName = fileName.substring(0, index);
/*  80:    */           }
/*  81:    */         }
/*  82:    */         else
/*  83:    */         {
/*  84:151 */           index = filePath.lastIndexOf("\\");
/*  85:153 */           if (index > 0)
/*  86:    */           {
/*  87:155 */             fileName = filePath.substring(index + 1, filePath.length());
/*  88:156 */             index = fileName.lastIndexOf(".");
/*  89:157 */             if (index > 0) {
/*  90:159 */               fileName = fileName.substring(0, index);
/*  91:    */             }
/*  92:    */           }
/*  93:    */         }
/*  94:    */       }
/*  95:    */     }
/*  96:168 */     return fileName;
/*  97:    */   }
/*  98:    */   
/*  99:    */   public String getFileNameWithExtension(String filePath)
/* 100:    */   {
/* 101:184 */     int index = 0;
/* 102:185 */     String fileName = "";
/* 103:188 */     if (CommonUtil.isNotNullOrEmpty(filePath))
/* 104:    */     {
/* 105:190 */       index = filePath.lastIndexOf("/");
/* 106:191 */       if (index > 0)
/* 107:    */       {
/* 108:193 */         fileName = filePath.substring(index + 1, filePath.length());
/* 109:    */       }
/* 110:    */       else
/* 111:    */       {
/* 112:196 */         index = filePath.lastIndexOf("//");
/* 113:197 */         if (index > 0)
/* 114:    */         {
/* 115:199 */           fileName = filePath.substring(index + 1, filePath.length());
/* 116:    */         }
/* 117:    */         else
/* 118:    */         {
/* 119:202 */           index = filePath.lastIndexOf("\\");
/* 120:204 */           if (index > 0) {
/* 121:206 */             fileName = filePath.substring(index + 1, filePath.length());
/* 122:    */           }
/* 123:    */         }
/* 124:    */       }
/* 125:    */     }
/* 126:213 */     return fileName;
/* 127:    */   }
/* 128:    */   
/* 129:    */   public String getFileExtension(String filename)
/* 130:    */   {
/* 131:229 */     int index = 0;
/* 132:230 */     String extension = "";
/* 133:233 */     if (CommonUtil.isNotNullOrEmpty(filename))
/* 134:    */     {
/* 135:235 */       index = filename.lastIndexOf(".");
/* 136:236 */       if (index > 0) {
/* 137:238 */         extension = filename.substring(index + 1, filename.length());
/* 138:    */       }
/* 139:    */     }
/* 140:242 */     return extension;
/* 141:    */   }
/* 142:    */   
/* 143:    */   public String getMimeType(String fileNameOrPath)
/* 144:    */   {
/* 145:255 */     return (CommonUtil.isNotNullOrEmpty(fileNameOrPath)) && (CommonUtil.isNotNullOrEmpty(getFileExtension(fileNameOrPath))) ? (String)CommonConstants.FILE_EXTENSION_TO_FILE_MIME_TYPES_MAP.get(getFileExtension(fileNameOrPath)) : "";
/* 146:    */   }
/* 147:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.impl.FileUtil
 * JD-Core Version:    0.7.0.1
 */