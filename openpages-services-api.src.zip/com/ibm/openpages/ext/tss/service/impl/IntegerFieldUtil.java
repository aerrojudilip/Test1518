/*   1:    */ package com.ibm.openpages.ext.tss.service.impl;
/*   2:    */ 
/*   3:    */ import com.ibm.openpages.api.metadata.DataType;
/*   4:    */ import com.ibm.openpages.api.resource.IField;
/*   5:    */ import com.ibm.openpages.api.resource.IGRCObject;
/*   6:    */ import com.ibm.openpages.api.resource.IIntegerField;
/*   7:    */ import com.ibm.openpages.ext.tss.service.IIntegerFieldUtil;
/*   8:    */ import com.ibm.openpages.ext.tss.service.ILoggerUtil;
/*   9:    */ import com.ibm.openpages.ext.tss.service.util.CommonUtil;
/*  10:    */ import com.ibm.openpages.ext.tss.service.util.NumericUtil;
/*  11:    */ import javax.annotation.PostConstruct;
/*  12:    */ import org.apache.commons.logging.Log;
/*  13:    */ import org.springframework.beans.factory.annotation.Autowired;
/*  14:    */ import org.springframework.stereotype.Service;
/*  15:    */ 
/*  16:    */ @Service("integerFieldUtil")
/*  17:    */ public class IntegerFieldUtil
/*  18:    */   implements IIntegerFieldUtil
/*  19:    */ {
/*  20:    */   private Log logger;
/*  21:    */   @Autowired
/*  22:    */   ILoggerUtil loggerUtil;
/*  23:    */   
/*  24:    */   @PostConstruct
/*  25:    */   public void initService()
/*  26:    */   {
/*  27: 54 */     this.logger = this.loggerUtil.getExtLogger();
/*  28:    */   }
/*  29:    */   
/*  30:    */   public IIntegerField getIntegerField(IField field)
/*  31:    */     throws Exception
/*  32:    */   {
/*  33: 73 */     return DataType.INTEGER_TYPE.equals(field.getDataType()) ? (IIntegerField)field : null;
/*  34:    */   }
/*  35:    */   
/*  36:    */   public IIntegerField getIntegerField(IGRCObject object, String fieldInfo)
/*  37:    */     throws Exception
/*  38:    */   {
/*  39: 93 */     return getIntegerField(object.getField(fieldInfo));
/*  40:    */   }
/*  41:    */   
/*  42:    */   public boolean isIntegerFieldNull(IField field)
/*  43:    */     throws Exception
/*  44:    */   {
/*  45:109 */     return CommonUtil.isObjectNull(getIntegerField(field));
/*  46:    */   }
/*  47:    */   
/*  48:    */   public boolean isIntegerFieldNull(IGRCObject object, String fieldInfo)
/*  49:    */     throws Exception
/*  50:    */   {
/*  51:128 */     return isIntegerFieldNull(getIntegerField(object, fieldInfo));
/*  52:    */   }
/*  53:    */   
/*  54:    */   public boolean isIntegerFieldNotNull(IField field)
/*  55:    */     throws Exception
/*  56:    */   {
/*  57:144 */     return !isIntegerFieldNull(field);
/*  58:    */   }
/*  59:    */   
/*  60:    */   public boolean isIntegerFieldNotNull(IGRCObject object, String fieldInfo)
/*  61:    */     throws Exception
/*  62:    */   {
/*  63:163 */     return isIntegerFieldNotNull(getIntegerField(object, fieldInfo));
/*  64:    */   }
/*  65:    */   
/*  66:    */   public boolean isIntegerFieldValueNull(IField field)
/*  67:    */     throws Exception
/*  68:    */   {
/*  69:179 */     return CommonUtil.isObjectNull(getIntegerFieldValue(field));
/*  70:    */   }
/*  71:    */   
/*  72:    */   public boolean isIntegerFieldValueNull(IGRCObject object, String fieldInfo)
/*  73:    */     throws Exception
/*  74:    */   {
/*  75:198 */     return isIntegerFieldValueNull(getIntegerField(object, fieldInfo));
/*  76:    */   }
/*  77:    */   
/*  78:    */   public boolean isIntegerFieldValueNotNull(IField field)
/*  79:    */     throws Exception
/*  80:    */   {
/*  81:214 */     return !isIntegerFieldValueNull(field);
/*  82:    */   }
/*  83:    */   
/*  84:    */   public boolean isIntegerFieldValueNotNull(IGRCObject object, String fieldInfo)
/*  85:    */     throws Exception
/*  86:    */   {
/*  87:233 */     return isIntegerFieldValueNotNull(getIntegerField(object, fieldInfo));
/*  88:    */   }
/*  89:    */   
/*  90:    */   public String getIntegerFieldValueAsString(IGRCObject object, String fieldInfo)
/*  91:    */     throws Exception
/*  92:    */   {
/*  93:252 */     return getIntegerFieldValueAsString(getIntegerField(object, fieldInfo));
/*  94:    */   }
/*  95:    */   
/*  96:    */   public String getIntegerFieldValueAsString(IField field)
/*  97:    */     throws Exception
/*  98:    */   {
/*  99:271 */     return CommonUtil.isObjectNotNull(getIntegerFieldValue(field)) ? getIntegerFieldValue(field).toString() : null;
/* 100:    */   }
/* 101:    */   
/* 102:    */   public Integer getIntegerFieldValue(IField field)
/* 103:    */     throws Exception
/* 104:    */   {
/* 105:290 */     return isIntegerFieldNotNull(field) ? getIntegerField(field).getValue() : null;
/* 106:    */   }
/* 107:    */   
/* 108:    */   public Integer getIntegerFieldValue(IGRCObject object, String fieldInfo)
/* 109:    */     throws Exception
/* 110:    */   {
/* 111:309 */     return getIntegerFieldValue(getIntegerField(object, fieldInfo));
/* 112:    */   }
/* 113:    */   
/* 114:    */   public float getIntegerFieldValueAsFloat(IField field)
/* 115:    */     throws Exception
/* 116:    */   {
/* 117:328 */     Integer integerFieldVale = getIntegerFieldValue(field);
/* 118:    */     
/* 119:330 */     return CommonUtil.isObjectNotNull(integerFieldVale) ? integerFieldVale.floatValue() : (0.0F / 0.0F);
/* 120:    */   }
/* 121:    */   
/* 122:    */   public float getIntegerFieldValueAsFloat(IGRCObject object, String fieldInfo)
/* 123:    */     throws Exception
/* 124:    */   {
/* 125:349 */     return getIntegerFieldValueAsFloat(getIntegerField(object, fieldInfo));
/* 126:    */   }
/* 127:    */   
/* 128:    */   public double getIntegerFieldValueAsDouble(IField field)
/* 129:    */     throws Exception
/* 130:    */   {
/* 131:368 */     Integer integerFieldVale = getIntegerFieldValue(field);
/* 132:    */     
/* 133:370 */     return CommonUtil.isObjectNotNull(integerFieldVale) ? integerFieldVale.doubleValue() : (0.0D / 0.0D);
/* 134:    */   }
/* 135:    */   
/* 136:    */   public double getIntegerFieldValueAsDouble(IGRCObject object, String fieldInfo)
/* 137:    */     throws Exception
/* 138:    */   {
/* 139:389 */     return getIntegerFieldValueAsDouble(getIntegerField(object, fieldInfo));
/* 140:    */   }
/* 141:    */   
/* 142:    */   public long getIntegerFieldValueAsLong(IField field)
/* 143:    */     throws Exception
/* 144:    */   {
/* 145:408 */     Integer integerFieldVale = getIntegerFieldValue(field);
/* 146:    */     
/* 147:410 */     return CommonUtil.isObjectNotNull(integerFieldVale) ? integerFieldVale.longValue() : -9223372036854775808L;
/* 148:    */   }
/* 149:    */   
/* 150:    */   public long getIntegerFieldValueAsLong(IGRCObject object, String fieldInfo)
/* 151:    */     throws Exception
/* 152:    */   {
/* 153:429 */     return getIntegerFieldValueAsLong(getIntegerField(object, fieldInfo));
/* 154:    */   }
/* 155:    */   
/* 156:    */   public int getIntegerFieldValueAsInt(IField field)
/* 157:    */     throws Exception
/* 158:    */   {
/* 159:448 */     Integer integerFieldVale = getIntegerFieldValue(field);
/* 160:    */     
/* 161:450 */     return CommonUtil.isObjectNotNull(integerFieldVale) ? integerFieldVale.intValue() : -2147483648;
/* 162:    */   }
/* 163:    */   
/* 164:    */   public long getIntegerFieldValueAsInt(IGRCObject object, String fieldInfo)
/* 165:    */     throws Exception
/* 166:    */   {
/* 167:469 */     return getIntegerFieldValueAsInt(getIntegerField(object, fieldInfo));
/* 168:    */   }
/* 169:    */   
/* 170:    */   public void setIntegerField(IGRCObject object, String fieldInfo, String value)
/* 171:    */     throws Exception
/* 172:    */   {
/* 173:487 */     setIntegerField(getIntegerField(object, fieldInfo), value);
/* 174:    */   }
/* 175:    */   
/* 176:    */   public void setIntegerField(IGRCObject object, String fieldInfo, Integer value)
/* 177:    */     throws Exception
/* 178:    */   {
/* 179:505 */     setIntegerField(getIntegerField(object, fieldInfo), value);
/* 180:    */   }
/* 181:    */   
/* 182:    */   public void setIntegerField(IIntegerField integerField, String value)
/* 183:    */     throws Exception
/* 184:    */   {
/* 185:522 */     if (NumericUtil.isNumeric(value)) {
/* 186:523 */       setIntegerField(integerField, new Integer(NumericUtil.getIntValue(value)));
/* 187:    */     }
/* 188:    */   }
/* 189:    */   
/* 190:    */   public void setIntegerField(IIntegerField integerField, Integer value)
/* 191:    */     throws Exception
/* 192:    */   {
/* 193:540 */     if (isIntegerFieldNotNull(integerField)) {
/* 194:541 */       integerField.setValue(value);
/* 195:    */     }
/* 196:    */   }
/* 197:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.impl.IntegerFieldUtil
 * JD-Core Version:    0.7.0.1
 */