/*   1:    */ package com.ibm.openpages.ext.tss.service.impl;
/*   2:    */ 
/*   3:    */ import com.ibm.openpages.api.Context;
/*   4:    */ import com.ibm.openpages.api.configuration.IConfigProperties;
/*   5:    */ import com.ibm.openpages.api.metadata.Id;
/*   6:    */ import com.ibm.openpages.api.resource.IGRCObject;
/*   7:    */ import com.ibm.openpages.api.service.IConfigurationService;
/*   8:    */ import com.ibm.openpages.api.service.IServiceFactory;
/*   9:    */ import com.ibm.openpages.api.service.ServiceFactory;
/*  10:    */ import com.ibm.openpages.ext.tss.service.IApplicationUtil;
/*  11:    */ import com.ibm.openpages.ext.tss.service.IGRCObjectUtil;
/*  12:    */ import com.ibm.openpages.ext.tss.service.ILoggerUtil;
/*  13:    */ import com.ibm.openpages.ext.tss.service.beans.AppServerInformation;
/*  14:    */ import com.ibm.openpages.ext.tss.service.proxy.IOPSessionProxy;
/*  15:    */ import com.ibm.openpages.ext.tss.service.proxy.IServiceFactoryProxy;
/*  16:    */ import com.ibm.openpages.ext.tss.service.util.CommonUtil;
/*  17:    */ import com.openpages.apps.common.util.NameGenerator;
/*  18:    */ import com.openpages.aurora.common.AuroraEnv;
/*  19:    */ import com.openpages.sdk.LoginOptions;
/*  20:    */ import com.openpages.sdk.Openpages;
/*  21:    */ import com.openpages.sdk.OpenpagesSession;
/*  22:    */ import com.openpages.sdk.admin.AdminService;
/*  23:    */ import com.openpages.sdk.metadata.ContentTypeId;
/*  24:    */ import com.openpages.sdk.metadata.MetaDataService;
/*  25:    */ import java.text.MessageFormat;
/*  26:    */ import java.util.ArrayList;
/*  27:    */ import java.util.HashMap;
/*  28:    */ import java.util.List;
/*  29:    */ import java.util.Map;
/*  30:    */ import javax.annotation.PostConstruct;
/*  31:    */ import org.apache.commons.logging.Log;
/*  32:    */ import org.springframework.beans.factory.annotation.Autowired;
/*  33:    */ import org.springframework.stereotype.Service;
/*  34:    */ 
/*  35:    */ @Service("applicationUtil")
/*  36:    */ public class ApplicationUtil
/*  37:    */   implements IApplicationUtil
/*  38:    */ {
/*  39:    */   private Log logger;
/*  40:    */   @Autowired
/*  41:    */   IOPSessionProxy opSessionProxy;
/*  42:    */   @Autowired
/*  43:    */   IGRCObjectUtil objectUtil;
/*  44:    */   @Autowired
/*  45:    */   IServiceFactoryProxy serviceFactoryProxy;
/*  46:    */   @Autowired
/*  47:    */   ILoggerUtil loggerUtil;
/*  48:    */   
/*  49:    */   @PostConstruct
/*  50:    */   public void initService()
/*  51:    */   {
/*  52:113 */     this.logger = this.loggerUtil.getExtLogger();
/*  53:    */   }
/*  54:    */   
/*  55:    */   public OpenpagesSession createNewOpenpagesSessionForUser(AppServerInformation appServerInformationVO)
/*  56:    */     throws Exception
/*  57:    */   {
/*  58:133 */     Openpages openpages = null;
/*  59:134 */     LoginOptions loginOptions = null;
/*  60:135 */     OpenpagesSession openpagesSession = null;
/*  61:    */     
/*  62:    */ 
/*  63:138 */     loginOptions = new LoginOptions();
/*  64:139 */     openpages = Openpages.getInstance(appServerInformationVO.getAppServer(), appServerInformationVO.getOpenPagesServer(), Integer.parseInt(appServerInformationVO.getOpenPagesPort()));
/*  65:    */     
/*  66:    */ 
/*  67:142 */     openpagesSession = openpages.createSession(appServerInformationVO.getUserName(), appServerInformationVO.getPassword(), loginOptions);
/*  68:    */     
/*  69:    */ 
/*  70:    */ 
/*  71:146 */     return openpagesSession;
/*  72:    */   }
/*  73:    */   
/*  74:    */   public IServiceFactory createServiceFactoryForUser(AppServerInformation appServerInformationVO)
/*  75:    */     throws Exception
/*  76:    */   {
/*  77:166 */     Context context = null;
/*  78:    */     
/*  79:    */ 
/*  80:169 */     context = new Context();
/*  81:    */     
/*  82:171 */     context.put("com.ibm.openpages.sdk.service.username", appServerInformationVO.getUserName());
/*  83:    */     
/*  84:173 */     context.put("com.ibm.openpages.sdk.service.password", appServerInformationVO.getPassword());
/*  85:    */     
/*  86:175 */     return ServiceFactory.getServiceFactory(context);
/*  87:    */   }
/*  88:    */   
/*  89:    */   public boolean isRegistrySettingExists(String settingsPath)
/*  90:    */     throws Exception
/*  91:    */   {
/*  92:195 */     IServiceFactory serviceFactory = null;
/*  93:196 */     IConfigurationService configrServ = null;
/*  94:    */     
/*  95:    */ 
/*  96:    */ 
/*  97:200 */     serviceFactory = this.serviceFactoryProxy.getServiceFactory();
/*  98:201 */     configrServ = serviceFactory.createConfigurationService();
/*  99:    */     
/* 100:203 */     return configrServ.getConfigProperties().propertyExists(settingsPath);
/* 101:    */   }
/* 102:    */   
/* 103:    */   public String getRegistrySetting(String settingsPath)
/* 104:    */     throws Exception
/* 105:    */   {
/* 106:224 */     String registryValue = null;
/* 107:225 */     IServiceFactory serviceFactory = null;
/* 108:226 */     IConfigurationService configrServ = null;
/* 109:    */     
/* 110:    */ 
/* 111:    */ 
/* 112:230 */     serviceFactory = this.serviceFactoryProxy.getServiceFactory();
/* 113:231 */     configrServ = serviceFactory.createConfigurationService();
/* 114:    */     
/* 115:    */ 
/* 116:234 */     registryValue = configrServ.getConfigProperties().getProperty(settingsPath);
/* 117:    */     
/* 118:    */ 
/* 119:237 */     return registryValue;
/* 120:    */   }
/* 121:    */   
/* 122:    */   public String getRegistrySetting(String settingsPath, String defaultValue)
/* 123:    */     throws Exception
/* 124:    */   {
/* 125:262 */     String registryValue = null;
/* 126:263 */     IServiceFactory serviceFactory = null;
/* 127:264 */     IConfigurationService configrServ = null;
/* 128:    */     
/* 129:    */ 
/* 130:    */ 
/* 131:268 */     serviceFactory = this.serviceFactoryProxy.getServiceFactory();
/* 132:269 */     configrServ = serviceFactory.createConfigurationService();
/* 133:    */     
/* 134:    */ 
/* 135:272 */     registryValue = configrServ.getConfigProperties().getProperty(settingsPath, defaultValue);
/* 136:    */     
/* 137:    */ 
/* 138:275 */     return registryValue;
/* 139:    */   }
/* 140:    */   
/* 141:    */   public Map<String, String> getRegistrySettings(List<String> registryKeys)
/* 142:    */     throws Exception
/* 143:    */   {
/* 144:297 */     Map<String, String> registryValues = null;
/* 145:    */     
/* 146:    */ 
/* 147:    */ 
/* 148:301 */     registryValues = new HashMap();
/* 149:309 */     for (String registryKey : registryKeys) {
/* 150:312 */       registryValues.put(registryKey, getRegistrySetting(registryKey, ""));
/* 151:    */     }
/* 152:316 */     return registryValues;
/* 153:    */   }
/* 154:    */   
/* 155:    */   public void setValueForRegistrySetting(String settingsPath, String value)
/* 156:    */     throws Exception
/* 157:    */   {
/* 158:338 */     OpenpagesSession opSession = null;
/* 159:    */     
/* 160:    */ 
/* 161:341 */     opSession = this.opSessionProxy.getOpenpagesSession();
/* 162:342 */     opSession.getAdminService().setEntryValue(settingsPath, value);
/* 163:    */   }
/* 164:    */   
/* 165:    */   public List<String> getSecurityPoints()
/* 166:    */     throws Exception
/* 167:    */   {
/* 168:360 */     String entryValue = "";
/* 169:    */     
/* 170:    */ 
/* 171:363 */     entryValue = getRegistrySetting("/OpenPages/Common/Security/Model");
/* 172:364 */     return CommonUtil.parseDelimitedValues(entryValue, ",");
/* 173:    */   }
/* 174:    */   
/* 175:    */   public List<String> getAllSelfContainedObjectTypes()
/* 176:    */     throws Exception
/* 177:    */   {
/* 178:382 */     String entryValue = "";
/* 179:    */     
/* 180:    */ 
/* 181:385 */     entryValue = getRegistrySetting("/OpenPages/Common/Self Contained Object Types");
/* 182:386 */     return CommonUtil.parseDelimitedValues(entryValue, ",");
/* 183:    */   }
/* 184:    */   
/* 185:    */   public String getAutoNamePatternForContentType(String contentType)
/* 186:    */     throws Exception
/* 187:    */   {
/* 188:408 */     StringBuilder autoNameRegistryEntry = null;
/* 189:    */     
/* 190:    */ 
/* 191:    */ 
/* 192:    */ 
/* 193:    */ 
/* 194:    */ 
/* 195:415 */     autoNameRegistryEntry = new StringBuilder("/OpenPages/Applications/GRCM/Auto Naming/{0}/Format");
/* 196:416 */     autoNameRegistryEntry.replace(autoNameRegistryEntry.indexOf("{0}"), autoNameRegistryEntry.indexOf("{0}") + 3, contentType);
/* 197:    */     
/* 198:    */ 
/* 199:    */ 
/* 200:    */ 
/* 201:421 */     return getRegistrySetting(autoNameRegistryEntry.toString());
/* 202:    */   }
/* 203:    */   
/* 204:    */   public String getObjectDetailViewLink(IGRCObject object)
/* 205:    */     throws Exception
/* 206:    */   {
/* 207:441 */     return "<a href=\"" + getObjectDetailViewURL(object.getId().toString()) + "\">" + object.getName() + "</a>";
/* 208:    */   }
/* 209:    */   
/* 210:    */   public String getObjectDetailViewLink(String objectId, String objectName)
/* 211:    */     throws Exception
/* 212:    */   {
/* 213:466 */     return "<a href=\"" + getObjectDetailViewURL(objectId) + "\">" + objectName + "</a>";
/* 214:    */   }
/* 215:    */   
/* 216:    */   public String getObjectDetailViewURL(String objectId)
/* 217:    */     throws Exception
/* 218:    */   {
/* 219:487 */     return getRegistrySetting("/OpenPages/Platform/Reporting Schema/Object URL Generator/Protocol") + ":" + "//" + getRegistrySetting("/OpenPages/Platform/Reporting Schema/Object URL Generator/Host") + ":" + getRegistrySetting("/OpenPages/Platform/Reporting Schema/Object URL Generator/Port") + getObjectDetailViewRelativeURL(objectId);
/* 220:    */   }
/* 221:    */   
/* 222:    */   public String getCommandCenterReportViewURL(String objectId)
/* 223:    */     throws Exception
/* 224:    */   {
/* 225:513 */     return getRegistrySetting("/OpenPages/Platform/Reporting Schema/Object URL Generator/Protocol") + ":" + "//" + getRegistrySetting("/OpenPages/Platform/Reporting Schema/Object URL Generator/Host") + ":" + getRegistrySetting("/OpenPages/Platform/Reporting Schema/Object URL Generator/Port") + getCommandCenterReportViewRelativeURL(objectId);
/* 226:    */   }
/* 227:    */   
/* 228:    */   public String getObjectDetailViewRelativeURL(String objectId)
/* 229:    */     throws Exception
/* 230:    */   {
/* 231:538 */     return getRegistrySetting("/OpenPages/Platform/Reporting Schema/Object URL Generator/Detail Page") + "?" + getRegistrySetting("/OpenPages/Platform/Reporting Schema/Object URL Generator/Object ID Parameter Name") + "=" + objectId;
/* 232:    */   }
/* 233:    */   
/* 234:    */   public String getCommandCenterReportViewRelativeURL(String resourceId)
/* 235:    */     throws Exception
/* 236:    */   {
/* 237:564 */     return "/openpages/report.tree.post.do?submitAction=preview&actionContext=preview&reportId=" + resourceId;
/* 238:    */   }
/* 239:    */   
/* 240:    */   public String getAutoName(IGRCObject object)
/* 241:    */     throws Exception
/* 242:    */   {
/* 243:587 */     Map paramMap = null;
/* 244:588 */     String autoNameFormat = null;
/* 245:589 */     OpenpagesSession opSession = null;
/* 246:590 */     NameGenerator nameGenerator = null;
/* 247:591 */     ContentTypeId contentTypeId = null;
/* 248:    */     
/* 249:    */ 
/* 250:594 */     paramMap = new HashMap();
/* 251:595 */     opSession = this.opSessionProxy.getOpenpagesSession();
/* 252:596 */     autoNameFormat = "/OpenPages/Applications/GRCM/Auto Naming/{0}/Format".replace("{0}", object.getType().toString());
/* 253:    */     
/* 254:598 */     contentTypeId = opSession.getMetaDataService().getContentTypeId(object.getType().toString());
/* 255:    */     
/* 256:600 */     paramMap.put("parent.name.key", this.objectUtil.getObjectFromId(object.getPrimaryParent()));
/* 257:    */     
/* 258:602 */     nameGenerator = new NameGenerator();
/* 259:    */     
/* 260:604 */     return nameGenerator.generateName(contentTypeId, autoNameFormat, (HashMap)paramMap, opSession) + ".txt";
/* 261:    */   }
/* 262:    */   
/* 263:    */   public String getApplicationString(String applicationStringKey)
/* 264:    */     throws Exception
/* 265:    */   {
/* 266:628 */     String applicationTextVal = "";
/* 267:    */     
/* 268:630 */     IServiceFactory serviceFactory = null;
/* 269:631 */     IConfigurationService configrServ = null;
/* 270:    */     
/* 271:    */ 
/* 272:    */ 
/* 273:635 */     serviceFactory = this.serviceFactoryProxy.getServiceFactory();
/* 274:636 */     configrServ = serviceFactory.createConfigurationService();
/* 275:    */     try
/* 276:    */     {
/* 277:646 */       applicationTextVal = configrServ.getLocalizedApplicationText(applicationStringKey);
/* 278:    */     }
/* 279:    */     catch (Exception ex)
/* 280:    */     {
/* 281:656 */       applicationTextVal = "MISSING KEY[" + applicationStringKey + "]";
/* 282:    */     }
/* 283:659 */     return applicationTextVal;
/* 284:    */   }
/* 285:    */   
/* 286:    */   public String getApplicationString(String applicationStringKey, List<String> placeHolderValues)
/* 287:    */     throws Exception
/* 288:    */   {
/* 289:688 */     String applicationTextVal = "";
/* 290:    */     
/* 291:690 */     IServiceFactory serviceFactory = null;
/* 292:691 */     IConfigurationService configrServ = null;
/* 293:    */     
/* 294:    */ 
/* 295:    */ 
/* 296:695 */     serviceFactory = this.serviceFactoryProxy.getServiceFactory();
/* 297:696 */     configrServ = serviceFactory.createConfigurationService();
/* 298:    */     try
/* 299:    */     {
/* 300:706 */       applicationTextVal = configrServ.getLocalizedApplicationText(applicationStringKey);
/* 301:708 */       if ((CommonUtil.isNotNullOrEmpty(applicationTextVal)) && (CommonUtil.isListNotNullOrEmpty(placeHolderValues))) {
/* 302:710 */         applicationTextVal = MessageFormat.format(applicationTextVal, placeHolderValues.toArray());
/* 303:    */       }
/* 304:    */     }
/* 305:    */     catch (Exception ex)
/* 306:    */     {
/* 307:720 */       applicationTextVal = "MISSING KEY[" + applicationStringKey + "]";
/* 308:    */     }
/* 309:723 */     return applicationTextVal;
/* 310:    */   }
/* 311:    */   
/* 312:    */   public List<String> getApplicationStringsAsList(Map<String, List<String>> applicationKeysInfo)
/* 313:    */     throws Exception
/* 314:    */   {
/* 315:745 */     String formattedText = "";
/* 316:746 */     String applicationTextVal = "";
/* 317:    */     
/* 318:748 */     List<String> appStringParams = null;
/* 319:749 */     List<String> appStrings = null;
/* 320:    */     
/* 321:    */ 
/* 322:    */ 
/* 323:753 */     appStrings = new ArrayList();
/* 324:755 */     if ((CommonUtil.isObjectNotNull(applicationKeysInfo)) && (!applicationKeysInfo.isEmpty())) {
/* 325:765 */       for (String applicationStringKey : applicationKeysInfo.keySet())
/* 326:    */       {
/* 327:768 */         applicationTextVal = getApplicationString(applicationStringKey);
/* 328:769 */         appStringParams = (List)applicationKeysInfo.get(applicationStringKey);
/* 329:770 */         formattedText = CommonUtil.isListNullOrEmpty(appStringParams) ? applicationTextVal : getApplicationString(applicationStringKey, appStringParams);
/* 330:    */         
/* 331:    */ 
/* 332:    */ 
/* 333:    */ 
/* 334:    */ 
/* 335:776 */         appStrings.add(formattedText);
/* 336:    */       }
/* 337:    */     }
/* 338:780 */     return appStrings;
/* 339:    */   }
/* 340:    */   
/* 341:    */   public Map<String, String> getApplicationStringsAsMap(Map<String, List<String>> applicationKeysInfo)
/* 342:    */     throws Exception
/* 343:    */   {
/* 344:803 */     String formattedText = "";
/* 345:804 */     String applicationTextVal = "";
/* 346:    */     
/* 347:806 */     List<String> appStringParams = null;
/* 348:807 */     Map<String, String> appStrings = null;
/* 349:    */     
/* 350:    */ 
/* 351:    */ 
/* 352:811 */     appStrings = new HashMap();
/* 353:813 */     if ((CommonUtil.isObjectNotNull(applicationKeysInfo)) && (!applicationKeysInfo.isEmpty())) {
/* 354:823 */       for (String applicationStringKey : applicationKeysInfo.keySet())
/* 355:    */       {
/* 356:826 */         applicationTextVal = getApplicationString(applicationStringKey);
/* 357:827 */         appStringParams = (List)applicationKeysInfo.get(applicationStringKey);
/* 358:828 */         formattedText = CommonUtil.isListNullOrEmpty(appStringParams) ? applicationTextVal : getApplicationString(applicationStringKey, appStringParams);
/* 359:    */         
/* 360:    */ 
/* 361:    */ 
/* 362:    */ 
/* 363:    */ 
/* 364:834 */         appStrings.put(applicationStringKey, formattedText);
/* 365:    */       }
/* 366:    */     }
/* 367:838 */     return appStrings;
/* 368:    */   }
/* 369:    */   
/* 370:    */   public String getAutoNameBasedOnFormat(IGRCObject object, String format, int num)
/* 371:    */     throws Exception
/* 372:    */   {
/* 373:864 */     return getAutoNameBasedOnFormat(object.getName(), format, num);
/* 374:    */   }
/* 375:    */   
/* 376:    */   public String getAutoNameBasedOnFormat(String objectName, String format, int num)
/* 377:    */     throws Exception
/* 378:    */   {
/* 379:890 */     this.logger.debug("Object name:" + objectName + " Format: " + format + " num: " + num);
/* 380:    */     
/* 381:    */ 
/* 382:    */ 
/* 383:894 */     int digits = 0;
/* 384:895 */     int numEndIndex = 0;
/* 385:896 */     int percentagePIndex = 0;
/* 386:897 */     int percentageNIndex = 0;
/* 387:    */     
/* 388:899 */     String numStr = "";
/* 389:900 */     StringBuffer autoName = null;
/* 390:901 */     String objectNameWithoutExtnsion = "";
/* 391:    */     try
/* 392:    */     {
/* 393:911 */       autoName = new StringBuffer(format);
/* 394:912 */       percentagePIndex = autoName.indexOf("%P;");
/* 395:913 */       percentageNIndex = autoName.indexOf("%N");
/* 396:    */       
/* 397:    */ 
/* 398:    */ 
/* 399:    */ 
/* 400:    */ 
/* 401:919 */       objectNameWithoutExtnsion = objectName.contains(".txt") ? objectName.replace(".txt", "") : objectName;
/* 402:928 */       while (percentagePIndex > -1)
/* 403:    */       {
/* 404:931 */         autoName.replace(percentagePIndex, percentagePIndex + 3, objectNameWithoutExtnsion);
/* 405:    */         
/* 406:933 */         percentagePIndex = autoName.indexOf("%P;");
/* 407:    */       }
/* 408:940 */       if (percentageNIndex > -1)
/* 409:    */       {
/* 410:943 */         percentageNIndex = autoName.indexOf("%N");
/* 411:944 */         numStr = autoName.substring(percentageNIndex);
/* 412:945 */         numEndIndex = numStr.indexOf(":");
/* 413:946 */         numStr = numStr.substring(2, numEndIndex);
/* 414:    */         
/* 415:948 */         digits = Integer.parseInt(numStr);
/* 416:949 */         numStr = Integer.toString(num);
/* 417:951 */         while (numStr.length() < digits) {
/* 418:954 */           numStr = 0 + numStr;
/* 419:    */         }
/* 420:957 */         numEndIndex = autoName.indexOf(":");
/* 421:958 */         autoName.replace(percentageNIndex, numEndIndex + 3, numStr);
/* 422:    */       }
/* 423:    */     }
/* 424:    */     catch (Exception ex)
/* 425:    */     {
/* 426:968 */       autoName = new StringBuffer();
/* 427:969 */       this.logger.error("Error occurred while retrieving autoname based on format" + CommonUtil.getStackTrace(ex));
/* 428:    */       
/* 429:    */ 
/* 430:972 */       throw ex;
/* 431:    */     }
/* 432:975 */     this.logger.debug("Autoname format is: " + autoName.toString() + ".txt" + "End");
/* 433:    */     
/* 434:977 */     return autoName.toString() + ".txt";
/* 435:    */   }
/* 436:    */   
/* 437:    */   public String getAuroraEnvProperty(String propertyKey)
/* 438:    */     throws Exception
/* 439:    */   {
/* 440:997 */     return AuroraEnv.getProperty(propertyKey);
/* 441:    */   }
/* 442:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.impl.ApplicationUtil
 * JD-Core Version:    0.7.0.1
 */