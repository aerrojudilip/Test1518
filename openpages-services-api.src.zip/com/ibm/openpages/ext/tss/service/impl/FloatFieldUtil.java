/*   1:    */ package com.ibm.openpages.ext.tss.service.impl;
/*   2:    */ 
/*   3:    */ import com.ibm.openpages.api.metadata.DataType;
/*   4:    */ import com.ibm.openpages.api.resource.IField;
/*   5:    */ import com.ibm.openpages.api.resource.IFloatField;
/*   6:    */ import com.ibm.openpages.api.resource.IGRCObject;
/*   7:    */ import com.ibm.openpages.ext.tss.service.IFloatFieldUtil;
/*   8:    */ import com.ibm.openpages.ext.tss.service.ILoggerUtil;
/*   9:    */ import com.ibm.openpages.ext.tss.service.util.CommonUtil;
/*  10:    */ import com.ibm.openpages.ext.tss.service.util.NumericUtil;
/*  11:    */ import javax.annotation.PostConstruct;
/*  12:    */ import org.apache.commons.logging.Log;
/*  13:    */ import org.springframework.beans.factory.annotation.Autowired;
/*  14:    */ import org.springframework.stereotype.Service;
/*  15:    */ 
/*  16:    */ @Service("floatFieldUtil")
/*  17:    */ public class FloatFieldUtil
/*  18:    */   implements IFloatFieldUtil
/*  19:    */ {
/*  20:    */   private Log logger;
/*  21:    */   @Autowired
/*  22:    */   ILoggerUtil loggerUtil;
/*  23:    */   
/*  24:    */   @PostConstruct
/*  25:    */   public void initService()
/*  26:    */   {
/*  27: 53 */     this.logger = this.loggerUtil.getExtLogger();
/*  28:    */   }
/*  29:    */   
/*  30:    */   public IFloatField getFloatField(IField field)
/*  31:    */     throws Exception
/*  32:    */   {
/*  33: 70 */     return DataType.FLOAT_TYPE.equals(field.getDataType()) ? (IFloatField)field : null;
/*  34:    */   }
/*  35:    */   
/*  36:    */   public IFloatField getFloatField(IGRCObject object, String fieldInfo)
/*  37:    */     throws Exception
/*  38:    */   {
/*  39: 90 */     return getFloatField(object.getField(fieldInfo));
/*  40:    */   }
/*  41:    */   
/*  42:    */   public boolean isFloatFieldNull(IField field)
/*  43:    */     throws Exception
/*  44:    */   {
/*  45:106 */     return CommonUtil.isObjectNull(getFloatField(field));
/*  46:    */   }
/*  47:    */   
/*  48:    */   public boolean isFloatFieldNull(IGRCObject object, String fieldInfo)
/*  49:    */     throws Exception
/*  50:    */   {
/*  51:125 */     return isFloatFieldNull(getFloatField(object, fieldInfo));
/*  52:    */   }
/*  53:    */   
/*  54:    */   public boolean isFloatFieldNotNull(IField field)
/*  55:    */     throws Exception
/*  56:    */   {
/*  57:141 */     return !isFloatFieldNull(field);
/*  58:    */   }
/*  59:    */   
/*  60:    */   public boolean isFloatFieldNotNull(IGRCObject object, String fieldInfo)
/*  61:    */     throws Exception
/*  62:    */   {
/*  63:160 */     return isFloatFieldNotNull(getFloatField(object, fieldInfo));
/*  64:    */   }
/*  65:    */   
/*  66:    */   public boolean isFloatFieldValueNull(IField field)
/*  67:    */     throws Exception
/*  68:    */   {
/*  69:176 */     return CommonUtil.isObjectNull(getFloatFieldValue(field));
/*  70:    */   }
/*  71:    */   
/*  72:    */   public boolean isFloatFieldValueNull(IGRCObject object, String fieldInfo)
/*  73:    */     throws Exception
/*  74:    */   {
/*  75:195 */     return isFloatFieldValueNull(getFloatField(object, fieldInfo));
/*  76:    */   }
/*  77:    */   
/*  78:    */   public boolean isFloatFieldValueNotNull(IField field)
/*  79:    */     throws Exception
/*  80:    */   {
/*  81:211 */     return !isFloatFieldValueNull(field);
/*  82:    */   }
/*  83:    */   
/*  84:    */   public boolean isFloatFieldValueNotNull(IGRCObject object, String fieldInfo)
/*  85:    */     throws Exception
/*  86:    */   {
/*  87:230 */     return isFloatFieldValueNotNull(getFloatField(object, fieldInfo));
/*  88:    */   }
/*  89:    */   
/*  90:    */   public String getFloatFieldValueAsString(IGRCObject object, String fieldInfo)
/*  91:    */     throws Exception
/*  92:    */   {
/*  93:249 */     return getFloatFieldValueAsString(getFloatField(object, fieldInfo));
/*  94:    */   }
/*  95:    */   
/*  96:    */   public String getFloatFieldValueAsString(IField field)
/*  97:    */     throws Exception
/*  98:    */   {
/*  99:268 */     return CommonUtil.isObjectNotNull(getFloatFieldValue(field)) ? getFloatFieldValue(field).toString() : null;
/* 100:    */   }
/* 101:    */   
/* 102:    */   public Double getFloatFieldValue(IField field)
/* 103:    */     throws Exception
/* 104:    */   {
/* 105:287 */     return isFloatFieldNotNull(field) ? getFloatField(field).getValue() : null;
/* 106:    */   }
/* 107:    */   
/* 108:    */   public Double getFloatFieldValue(IGRCObject object, String fieldInfo)
/* 109:    */     throws Exception
/* 110:    */   {
/* 111:306 */     return getFloatFieldValue(getFloatField(object, fieldInfo));
/* 112:    */   }
/* 113:    */   
/* 114:    */   public float getFloatFieldValueAsFloat(IField field)
/* 115:    */     throws Exception
/* 116:    */   {
/* 117:325 */     Double floatFieldVale = getFloatFieldValue(field);
/* 118:    */     
/* 119:327 */     return CommonUtil.isObjectNotNull(floatFieldVale) ? floatFieldVale.floatValue() : (0.0F / 0.0F);
/* 120:    */   }
/* 121:    */   
/* 122:    */   public float getFloatFieldValueAsFloat(IGRCObject object, String fieldInfo)
/* 123:    */     throws Exception
/* 124:    */   {
/* 125:346 */     return getFloatFieldValueAsFloat(getFloatField(object, fieldInfo));
/* 126:    */   }
/* 127:    */   
/* 128:    */   public double getFloatFieldValueAsDouble(IField field)
/* 129:    */     throws Exception
/* 130:    */   {
/* 131:365 */     Double floatFieldVale = getFloatFieldValue(field);
/* 132:    */     
/* 133:367 */     return CommonUtil.isObjectNotNull(floatFieldVale) ? floatFieldVale.doubleValue() : (0.0D / 0.0D);
/* 134:    */   }
/* 135:    */   
/* 136:    */   public double getFloatFieldValueAsDouble(IGRCObject object, String fieldInfo)
/* 137:    */     throws Exception
/* 138:    */   {
/* 139:386 */     return getFloatFieldValueAsDouble(getFloatField(object, fieldInfo));
/* 140:    */   }
/* 141:    */   
/* 142:    */   public long getFloatFieldValueAsLong(IField field)
/* 143:    */     throws Exception
/* 144:    */   {
/* 145:405 */     Double floatFieldVale = getFloatFieldValue(field);
/* 146:    */     
/* 147:407 */     return CommonUtil.isObjectNotNull(floatFieldVale) ? floatFieldVale.longValue() : -9223372036854775808L;
/* 148:    */   }
/* 149:    */   
/* 150:    */   public long getFloatFieldValueAsLong(IGRCObject object, String fieldInfo)
/* 151:    */     throws Exception
/* 152:    */   {
/* 153:426 */     return getFloatFieldValueAsLong(getFloatField(object, fieldInfo));
/* 154:    */   }
/* 155:    */   
/* 156:    */   public long getFloatFieldValueAsInt(IField field)
/* 157:    */     throws Exception
/* 158:    */   {
/* 159:445 */     Double floatFieldVale = getFloatFieldValue(field);
/* 160:    */     
/* 161:447 */     return (CommonUtil.isObjectNotNull(floatFieldVale) ? Integer.valueOf(floatFieldVale.intValue()) : null).intValue();
/* 162:    */   }
/* 163:    */   
/* 164:    */   public long getFloatFieldValueAsInt(IGRCObject object, String fieldInfo)
/* 165:    */     throws Exception
/* 166:    */   {
/* 167:466 */     return getFloatFieldValueAsInt(getFloatField(object, fieldInfo));
/* 168:    */   }
/* 169:    */   
/* 170:    */   public void setFloatField(IGRCObject object, String fieldInfo, String value)
/* 171:    */     throws Exception
/* 172:    */   {
/* 173:485 */     setFloatField(getFloatField(object, fieldInfo), value);
/* 174:    */   }
/* 175:    */   
/* 176:    */   public void setFloatField(IGRCObject object, String fieldInfo, Double value)
/* 177:    */     throws Exception
/* 178:    */   {
/* 179:504 */     setFloatField(getFloatField(object, fieldInfo), value);
/* 180:    */   }
/* 181:    */   
/* 182:    */   public void setFloatField(IFloatField floatField, String value)
/* 183:    */     throws Exception
/* 184:    */   {
/* 185:521 */     if (NumericUtil.isNumeric(value)) {
/* 186:522 */       setFloatField(floatField, new Double(NumericUtil.getDoubleValue(value)));
/* 187:    */     }
/* 188:    */   }
/* 189:    */   
/* 190:    */   public void setFloatField(IFloatField floatField, Double value)
/* 191:    */     throws Exception
/* 192:    */   {
/* 193:539 */     if (isFloatFieldNotNull(floatField)) {
/* 194:540 */       floatField.setValue(value);
/* 195:    */     }
/* 196:    */   }
/* 197:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.impl.FloatFieldUtil
 * JD-Core Version:    0.7.0.1
 */