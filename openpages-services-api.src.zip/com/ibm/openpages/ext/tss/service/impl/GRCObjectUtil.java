/*   1:    */ package com.ibm.openpages.ext.tss.service.impl;
/*   2:    */ 
/*   3:    */ import com.ibm.openpages.api.application.MoveObjectOptions;
/*   4:    */ import com.ibm.openpages.api.metadata.DataType;
/*   5:    */ import com.ibm.openpages.api.metadata.IFileTypeDefinition;
/*   6:    */ import com.ibm.openpages.api.metadata.ITypeDefinition;
/*   7:    */ import com.ibm.openpages.api.metadata.Id;
/*   8:    */ import com.ibm.openpages.api.resource.GRCObjectFilter;
/*   9:    */ import com.ibm.openpages.api.resource.IDocument;
/*  10:    */ import com.ibm.openpages.api.resource.IField;
/*  11:    */ import com.ibm.openpages.api.resource.IGRCObject;
/*  12:    */ import com.ibm.openpages.api.resource.IResourceFactory;
/*  13:    */ import com.ibm.openpages.api.service.IApplicationService;
/*  14:    */ import com.ibm.openpages.api.service.IMetaDataService;
/*  15:    */ import com.ibm.openpages.api.service.IResourceService;
/*  16:    */ import com.ibm.openpages.api.service.IServiceFactory;
/*  17:    */ import com.ibm.openpages.ext.tss.service.IFieldUtil;
/*  18:    */ import com.ibm.openpages.ext.tss.service.IGRCObjectSearchUtil;
/*  19:    */ import com.ibm.openpages.ext.tss.service.IGRCObjectUtil;
/*  20:    */ import com.ibm.openpages.ext.tss.service.ILoggerUtil;
/*  21:    */ import com.ibm.openpages.ext.tss.service.beans.IGRCObjectAssociationInformation;
/*  22:    */ import com.ibm.openpages.ext.tss.service.beans.SnapshotObjectInformation;
/*  23:    */ import com.ibm.openpages.ext.tss.service.proxy.IServiceFactoryProxy;
/*  24:    */ import com.ibm.openpages.ext.tss.service.util.CommonUtil;
/*  25:    */ import com.ibm.openpages.ext.tss.service.util.FileUtil;
/*  26:    */ import java.io.File;
/*  27:    */ import java.io.FileInputStream;
/*  28:    */ import java.util.ArrayList;
/*  29:    */ import java.util.List;
/*  30:    */ import java.util.Map;
/*  31:    */ import java.util.Set;
/*  32:    */ import javax.annotation.PostConstruct;
/*  33:    */ import org.apache.commons.logging.Log;
/*  34:    */ import org.springframework.beans.factory.annotation.Autowired;
/*  35:    */ import org.springframework.stereotype.Service;
/*  36:    */ 
/*  37:    */ @Service("grcObjectUtil")
/*  38:    */ public class GRCObjectUtil
/*  39:    */   implements IGRCObjectUtil
/*  40:    */ {
/*  41:    */   private Log logger;
/*  42:    */   @Autowired
/*  43:    */   ILoggerUtil loggerUtil;
/*  44:    */   @Autowired
/*  45:    */   IFieldUtil fieldUtil;
/*  46:    */   @Autowired
/*  47:    */   IServiceFactoryProxy serviceFactoryProxy;
/*  48:    */   @Autowired
/*  49:    */   IGRCObjectSearchUtil objectSearchUtil;
/*  50:    */   
/*  51:    */   @PostConstruct
/*  52:    */   public void initService()
/*  53:    */   {
/*  54: 91 */     this.logger = this.loggerUtil.getExtLogger();
/*  55:    */   }
/*  56:    */   
/*  57:    */   public IGRCObject getObjectFromId(Id objectId)
/*  58:    */     throws Exception
/*  59:    */   {
/*  60:108 */     IServiceFactory serviceFactory = null;
/*  61:    */     
/*  62:110 */     serviceFactory = this.serviceFactoryProxy.getServiceFactory();
/*  63:111 */     return serviceFactory.createResourceService().getGRCObject(objectId);
/*  64:    */   }
/*  65:    */   
/*  66:    */   public IGRCObject getObjectFromId(String objectId)
/*  67:    */     throws Exception
/*  68:    */   {
/*  69:127 */     IServiceFactory serviceFactory = null;
/*  70:    */     
/*  71:129 */     serviceFactory = this.serviceFactoryProxy.getServiceFactory();
/*  72:130 */     return serviceFactory.createResourceService().getGRCObject(new Id(objectId));
/*  73:    */   }
/*  74:    */   
/*  75:    */   public IGRCObject getObjectFromId(Id objectId, GRCObjectFilter objectFilters)
/*  76:    */     throws Exception
/*  77:    */   {
/*  78:149 */     IServiceFactory serviceFactory = null;
/*  79:    */     
/*  80:151 */     serviceFactory = this.serviceFactoryProxy.getServiceFactory();
/*  81:152 */     return serviceFactory.createResourceService().getGRCObject(objectId, objectFilters);
/*  82:    */   }
/*  83:    */   
/*  84:    */   public IGRCObject getObjectFromId(String objectId, GRCObjectFilter objectFilters)
/*  85:    */     throws Exception
/*  86:    */   {
/*  87:171 */     IServiceFactory serviceFactory = null;
/*  88:    */     
/*  89:173 */     serviceFactory = this.serviceFactoryProxy.getServiceFactory();
/*  90:174 */     return serviceFactory.createResourceService().getGRCObject(new Id(objectId), objectFilters);
/*  91:    */   }
/*  92:    */   
/*  93:    */   public IGRCObject createAutoNamedObject(String objectType)
/*  94:    */     throws Exception
/*  95:    */   {
/*  96:190 */     IGRCObject object = null;
/*  97:191 */     ITypeDefinition iTypeDefinition = null;
/*  98:192 */     IServiceFactory serviceFactory = null;
/*  99:    */     
/* 100:194 */     serviceFactory = this.serviceFactoryProxy.getServiceFactory();
/* 101:195 */     iTypeDefinition = serviceFactory.createMetaDataService().getType(objectType);
/* 102:196 */     object = serviceFactory.createResourceService().getResourceFactory().createAutoNamedGRCObject(iTypeDefinition);
/* 103:197 */     return object;
/* 104:    */   }
/* 105:    */   
/* 106:    */   public void lockObjectsBasedOnId(Set<String> objectIdList)
/* 107:    */     throws Exception
/* 108:    */   {
/* 109:214 */     this.logger.debug("lockObjectsBasedOnId() Start");
/* 110:    */     
/* 111:216 */     IServiceFactory serviceFactory = null;
/* 112:217 */     IApplicationService applicationService = null;
/* 113:    */     
/* 114:219 */     serviceFactory = this.serviceFactoryProxy.getServiceFactory();
/* 115:220 */     applicationService = serviceFactory.createApplicationService();
/* 116:    */     
/* 117:222 */     this.logger.debug("Is input given  null" + CommonUtil.isSetNullOrEmpty(objectIdList));
/* 118:224 */     for (String objectId : objectIdList)
/* 119:    */     {
/* 120:226 */       IGRCObject object = getObjectFromId(objectId);
/* 121:227 */       this.logger.debug("Locking Object: " + (CommonUtil.isObjectNotNull(object) ? object.getName().toString() : "Null"));
/* 122:228 */       this.logger.debug("Is Object Locked: " + object.isLocked());
/* 123:230 */       if (!object.isLocked()) {
/* 124:232 */         applicationService.lockGRCObject(object.getId());
/* 125:    */       }
/* 126:    */     }
/* 127:236 */     this.logger.debug("lockObjectsBasedOnId() End");
/* 128:    */   }
/* 129:    */   
/* 130:    */   public void unLockChildObjects(Set<String> childObjectIdList)
/* 131:    */     throws Exception
/* 132:    */   {
/* 133:253 */     IServiceFactory serviceFactory = null;
/* 134:254 */     IApplicationService applicationService = null;
/* 135:    */     
/* 136:256 */     serviceFactory = this.serviceFactoryProxy.getServiceFactory();
/* 137:257 */     applicationService = serviceFactory.createApplicationService();
/* 138:259 */     for (String objectId : childObjectIdList)
/* 139:    */     {
/* 140:261 */       IGRCObject object = getObjectFromId(objectId);
/* 141:263 */       if (object.isLocked()) {
/* 142:265 */         applicationService.unlockGRCObject(object.getId());
/* 143:    */       }
/* 144:    */     }
/* 145:    */   }
/* 146:    */   
/* 147:    */   public IGRCObject saveResource(IGRCObject object)
/* 148:    */     throws Exception
/* 149:    */   {
/* 150:281 */     IServiceFactory serviceFactory = null;
/* 151:282 */     IResourceService resourceService = null;
/* 152:    */     
/* 153:284 */     serviceFactory = this.serviceFactoryProxy.getServiceFactory();
/* 154:285 */     resourceService = serviceFactory.createResourceService();
/* 155:    */     
/* 156:287 */     return (IGRCObject)resourceService.saveResource(object);
/* 157:    */   }
/* 158:    */   
/* 159:    */   public void deleteResource(IGRCObject object)
/* 160:    */     throws Exception
/* 161:    */   {
/* 162:301 */     IServiceFactory serviceFactory = null;
/* 163:302 */     IResourceService resourceService = null;
/* 164:    */     
/* 165:304 */     serviceFactory = this.serviceFactoryProxy.getServiceFactory();
/* 166:305 */     resourceService = serviceFactory.createResourceService();
/* 167:    */     
/* 168:307 */     resourceService.deleteResource(object);
/* 169:    */   }
/* 170:    */   
/* 171:    */   public void deleteResource(Id objectId)
/* 172:    */     throws Exception
/* 173:    */   {
/* 174:321 */     IServiceFactory serviceFactory = null;
/* 175:322 */     IResourceService resourceService = null;
/* 176:    */     
/* 177:324 */     serviceFactory = this.serviceFactoryProxy.getServiceFactory();
/* 178:325 */     resourceService = serviceFactory.createResourceService();
/* 179:    */     
/* 180:327 */     resourceService.deleteResource(objectId);
/* 181:    */   }
/* 182:    */   
/* 183:    */   public IGRCObject associateParentAndChildrentToAnObject(IGRCObject object, IGRCObjectAssociationInformation objectAssociationInfo)
/* 184:    */     throws Exception
/* 185:    */   {
/* 186:342 */     List<Id> childrenIdList = null;
/* 187:343 */     List<Id> secondaryParentIdList = null;
/* 188:    */     
/* 189:345 */     IServiceFactory serviceFactory = null;
/* 190:346 */     IResourceService resourceService = null;
/* 191:    */     
/* 192:348 */     serviceFactory = this.serviceFactoryProxy.getServiceFactory();
/* 193:349 */     resourceService = serviceFactory.createResourceService();
/* 194:351 */     if (objectAssociationInfo.isSetPrimaryParent())
/* 195:    */     {
/* 196:353 */       object.setPrimaryParent(objectAssociationInfo.getPrimaryParentAssociationId());
/* 197:354 */       object = saveResource(object);
/* 198:    */     }
/* 199:358 */     childrenIdList = CommonUtil.isListNotNullOrEmpty(objectAssociationInfo.getChildAssociationsList()) ? objectAssociationInfo.getChildAssociationsList() : new ArrayList();
/* 200:359 */     secondaryParentIdList = CommonUtil.isListNotNullOrEmpty(objectAssociationInfo.getSecondaryParentAssociationList()) ? objectAssociationInfo.getSecondaryParentAssociationList() : new ArrayList();
/* 201:    */     
/* 202:361 */     resourceService.associate(object.getId(), secondaryParentIdList, childrenIdList);
/* 203:    */     
/* 204:363 */     return object;
/* 205:    */   }
/* 206:    */   
/* 207:    */   public void disassociateParentAndChildrentFromAnObject(IGRCObject object, IGRCObjectAssociationInformation objectAssociationInfo)
/* 208:    */     throws Exception
/* 209:    */   {
/* 210:378 */     List<Id> childrenIdList = null;
/* 211:379 */     List<Id> secondaryParentIdList = null;
/* 212:    */     
/* 213:381 */     IServiceFactory serviceFactory = null;
/* 214:382 */     IResourceService resourceService = null;
/* 215:    */     
/* 216:384 */     serviceFactory = this.serviceFactoryProxy.getServiceFactory();
/* 217:385 */     resourceService = serviceFactory.createResourceService();
/* 218:387 */     if (objectAssociationInfo.isSetPrimaryParent()) {
/* 219:388 */       object.setPrimaryParent(objectAssociationInfo.getPrimaryParentAssociationId());
/* 220:    */     }
/* 221:390 */     childrenIdList = CommonUtil.isListNotNullOrEmpty(objectAssociationInfo.getChildAssociationsList()) ? objectAssociationInfo.getChildAssociationsList() : new ArrayList();
/* 222:391 */     secondaryParentIdList = CommonUtil.isListNotNullOrEmpty(objectAssociationInfo.getSecondaryParentAssociationList()) ? objectAssociationInfo.getSecondaryParentAssociationList() : new ArrayList();
/* 223:    */     
/* 224:393 */     resourceService.dissociate(object.getId(), secondaryParentIdList, childrenIdList);
/* 225:    */   }
/* 226:    */   
/* 227:    */   public void moveAnIGRCObject(IGRCObject parentObject, IGRCObject childObjectToMove, MoveObjectOptions moveObjectOptions)
/* 228:    */     throws Exception
/* 229:    */   {
/* 230:409 */     List<Id> childObjectsToMove = null;
/* 231:    */     
/* 232:411 */     childObjectsToMove = new ArrayList();
/* 233:413 */     if ((CommonUtil.isObjectNotNull(parentObject)) && (CommonUtil.isObjectNotNull(childObjectToMove)) && (CommonUtil.isObjectNotNull(childObjectToMove.getId())))
/* 234:    */     {
/* 235:415 */       childObjectsToMove.add(childObjectToMove.getId());
/* 236:416 */       moveIGRCObjects(parentObject, childObjectsToMove, moveObjectOptions);
/* 237:    */     }
/* 238:    */   }
/* 239:    */   
/* 240:    */   public void moveIGRCObjects(IGRCObject parentObject, List<Id> childObjectsToMove, MoveObjectOptions moveObjectOptions)
/* 241:    */     throws Exception
/* 242:    */   {
/* 243:434 */     IServiceFactory serviceFactory = null;
/* 244:435 */     IApplicationService applicationService = null;
/* 245:437 */     if ((CommonUtil.isObjectNotNull(parentObject)) && (CommonUtil.isListNotNullOrEmpty(childObjectsToMove)))
/* 246:    */     {
/* 247:439 */       serviceFactory = this.serviceFactoryProxy.getServiceFactory();
/* 248:440 */       applicationService = serviceFactory.createApplicationService();
/* 249:    */       
/* 250:442 */       applicationService.moveGRCObject(parentObject.getId(), childObjectsToMove, moveObjectOptions);
/* 251:    */     }
/* 252:    */   }
/* 253:    */   
/* 254:    */   public IGRCObject createSnapShotForObject(IGRCObject object, SnapshotObjectInformation snapshotObjectInfo, IGRCObjectAssociationInformation objectAssociationInfo)
/* 255:    */     throws Exception
/* 256:    */   {
/* 257:463 */     IField destinationField = null;
/* 258:464 */     IGRCObject snapshotObject = null;
/* 259:465 */     List<IField> sourceObjectFieldsList = null;
/* 260:467 */     if ((CommonUtil.isNotNullOrEmpty(snapshotObjectInfo.getSnapshotObjectType())) && (CommonUtil.isListNotNullOrEmpty(snapshotObjectInfo.getIgnoreFieldsToCopyList())))
/* 261:    */     {
/* 262:470 */       snapshotObject = createAutoNamedObject(snapshotObjectInfo.getSnapshotObjectType());
/* 263:471 */       sourceObjectFieldsList = object.getFields();
/* 264:473 */       for (IField sourceObjectField : sourceObjectFieldsList) {
/* 265:475 */         if (!snapshotObjectInfo.getIgnoreFieldsToCopyList().contains(sourceObjectField.getName()))
/* 266:    */         {
/* 267:477 */           destinationField = this.fieldUtil.getField(snapshotObject, sourceObjectField.getName());
/* 268:479 */           if (this.fieldUtil.isFieldNotNull(destinationField)) {
/* 269:481 */             if (DataType.CURRENCY_TYPE.equals(destinationField.getDataType())) {
/* 270:483 */               this.fieldUtil.setFieldValue(destinationField, sourceObjectField);
/* 271:    */             } else {
/* 272:487 */               this.fieldUtil.setFieldValue(destinationField, this.fieldUtil.getFieldValue(sourceObjectField));
/* 273:    */             }
/* 274:    */           }
/* 275:    */         }
/* 276:    */       }
/* 277:494 */       if (snapshotObjectInfo.isCopyDescription()) {
/* 278:495 */         snapshotObject.setDescription(object.getDescription());
/* 279:    */       }
/* 280:497 */       objectAssociationInfo.setSetPrimaryParent(false);
/* 281:498 */       snapshotObject.setPrimaryParent(objectAssociationInfo.getPrimaryParentAssociationId());
/* 282:499 */       snapshotObject = saveResource(snapshotObject);
/* 283:    */       
/* 284:501 */       associateParentAndChildrentToAnObject(snapshotObject, objectAssociationInfo);
/* 285:    */     }
/* 286:504 */     return snapshotObject;
/* 287:    */   }
/* 288:    */   
/* 289:    */   public IGRCObject createDocument(IGRCObject parentObject, String filePath)
/* 290:    */     throws Exception
/* 291:    */   {
/* 292:520 */     File newFile = null;
/* 293:521 */     IDocument newDocument = null;
/* 294:522 */     IDocument savedDocResource = null;
/* 295:523 */     FileInputStream attachment = null;
/* 296:524 */     ITypeDefinition typeDefinition = null;
/* 297:525 */     IFileTypeDefinition fileTypeDefinition = null;
/* 298:    */     
/* 299:527 */     newFile = new File(filePath);
/* 300:528 */     attachment = new FileInputStream(newFile);
/* 301:529 */     typeDefinition = this.serviceFactoryProxy.getServiceFactory().createMetaDataService().getType("SOXDocument");
/* 302:530 */     fileTypeDefinition = this.serviceFactoryProxy.getServiceFactory().createMetaDataService().getFileType(FileUtil.getFileExtension(filePath), FileUtil.getMimeType(filePath));
/* 303:531 */     newDocument = this.serviceFactoryProxy.getServiceFactory().createResourceService().getResourceFactory().createDocument(FileUtil.getFileNameWithoutExtension(filePath), typeDefinition, fileTypeDefinition);
/* 304:532 */     newDocument.setContent(attachment, newFile.length());
/* 305:533 */     newDocument.setPrimaryParent(parentObject.getId());
/* 306:534 */     savedDocResource = (IDocument)this.serviceFactoryProxy.getServiceFactory().createResourceService().saveResource(newDocument);
/* 307:    */     
/* 308:536 */     return savedDocResource;
/* 309:    */   }
/* 310:    */   
/* 311:    */   public boolean isChildObjectOfGivenObjectTypePresent(IGRCObject object, String childObjectType, boolean honorPrimaryAssociation)
/* 312:    */     throws Exception
/* 313:    */   {
/* 314:552 */     List<String> childObjList = null;
/* 315:    */     
/* 316:554 */     childObjList = this.objectSearchUtil.getAllChildObjectIdsOfGivenObject(object, childObjectType, honorPrimaryAssociation);
/* 317:    */     
/* 318:556 */     return CommonUtil.isListNotNullOrEmpty(childObjList);
/* 319:    */   }
/* 320:    */   
/* 321:    */   public void updateFieldsInObject(String objectId, Map<String, String> inputData)
/* 322:    */     throws Exception
/* 323:    */   {
/* 324:562 */     updateFieldsInObject(getObjectFromId(objectId), inputData);
/* 325:    */   }
/* 326:    */   
/* 327:    */   public void updateFieldsInObject(IGRCObject object, Map<String, String> inputData)
/* 328:    */     throws Exception
/* 329:    */   {
/* 330:569 */     Set<String> inputDataKeySet = inputData.keySet();
/* 331:571 */     for (String key : inputDataKeySet) {
/* 332:573 */       this.fieldUtil.setFieldValue(object, key, (String)inputData.get(key));
/* 333:    */     }
/* 334:    */   }
/* 335:    */   
/* 336:    */   public void updateFieldsInObjectAndSave(String objectId, Map<String, String> inputData)
/* 337:    */     throws Exception
/* 338:    */   {
/* 339:580 */     updateFieldsInObjectAndSave(getObjectFromId(objectId), inputData);
/* 340:    */   }
/* 341:    */   
/* 342:    */   public void updateFieldsInObjectAndSave(IGRCObject object, Map<String, String> inputData)
/* 343:    */     throws Exception
/* 344:    */   {
/* 345:587 */     Set<String> inputDataKeySet = inputData.keySet();
/* 346:589 */     for (String key : inputDataKeySet) {
/* 347:591 */       this.fieldUtil.setFieldValue(object, key, (String)inputData.get(key));
/* 348:    */     }
/* 349:593 */     saveResource(object);
/* 350:    */   }
/* 351:    */   
/* 352:    */   public void updateFieldsInObject(String sourceObjectId, String destinationObjectId, List<String> fieldsToCopy)
/* 353:    */     throws Exception
/* 354:    */   {
/* 355:599 */     IGRCObject sourceObject = getObjectFromId(sourceObjectId);
/* 356:600 */     IGRCObject destinationObject = getObjectFromId(destinationObjectId);
/* 357:    */     
/* 358:602 */     updateFieldsInObject(sourceObject, destinationObject, fieldsToCopy);
/* 359:    */   }
/* 360:    */   
/* 361:    */   public void updateFieldsInObject(IGRCObject sourceObject, IGRCObject destinationObject, List<String> fieldsToCopy)
/* 362:    */     throws Exception
/* 363:    */   {
/* 364:608 */     this.logger.info("updateFieldsInObject() START");
/* 365:609 */     this.logger.info("Is Fields to copy not nul or empty: " + CommonUtil.isListNotNullOrEmpty(fieldsToCopy));
/* 366:610 */     if (CommonUtil.isListNotNullOrEmpty(fieldsToCopy)) {
/* 367:612 */       for (String fieldInfo : fieldsToCopy)
/* 368:    */       {
/* 369:614 */         this.logger.info("Field Information: " + fieldInfo);
/* 370:615 */         this.logger.info("Is Field not null in Source: " + CommonUtil.isObjectNotNull(this.fieldUtil.getField(sourceObject, fieldInfo)));
/* 371:616 */         this.logger.info("Is Field not null in destination: " + CommonUtil.isObjectNotNull(this.fieldUtil.getField(destinationObject, fieldInfo)));
/* 372:617 */         if ((CommonUtil.isObjectNotNull(this.fieldUtil.getField(sourceObject, fieldInfo))) && (CommonUtil.isObjectNotNull(this.fieldUtil.getField(destinationObject, fieldInfo))))
/* 373:    */         {
/* 374:620 */           this.logger.info("Field Name: " + this.fieldUtil.getField(destinationObject, fieldInfo).getName());
/* 375:621 */           this.logger.info("Field Value: " + (CommonUtil.isObjectNotNull(this.fieldUtil.getFieldValue(this.fieldUtil.getField(sourceObject, fieldInfo))) ? this.fieldUtil.getFieldValue(this.fieldUtil.getField(sourceObject, fieldInfo)).toString() : null));
/* 376:    */           
/* 377:623 */           this.fieldUtil.setFieldValue(this.fieldUtil.getField(destinationObject, fieldInfo), this.fieldUtil.getFieldValue(this.fieldUtil.getField(sourceObject, fieldInfo)));
/* 378:    */         }
/* 379:    */       }
/* 380:    */     }
/* 381:628 */     this.logger.info("updateFieldsInObject() END");
/* 382:629 */     saveResource(destinationObject);
/* 383:    */   }
/* 384:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.impl.GRCObjectUtil
 * JD-Core Version:    0.7.0.1
 */