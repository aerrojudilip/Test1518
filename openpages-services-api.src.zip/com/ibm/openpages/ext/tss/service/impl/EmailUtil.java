/*   1:    */ package com.ibm.openpages.ext.tss.service.impl;
/*   2:    */ 
/*   3:    */ import com.ibm.openpages.ext.tss.service.IEmailUtil;
/*   4:    */ import com.ibm.openpages.ext.tss.service.ILoggerUtil;
/*   5:    */ import com.ibm.openpages.ext.tss.service.beans.EmailInformation;
/*   6:    */ import com.ibm.openpages.ext.tss.service.util.CommonUtil;
/*   7:    */ import java.io.File;
/*   8:    */ import java.util.ArrayList;
/*   9:    */ import java.util.List;
/*  10:    */ import java.util.Properties;
/*  11:    */ import java.util.regex.Matcher;
/*  12:    */ import java.util.regex.Pattern;
/*  13:    */ import javax.activation.DataHandler;
/*  14:    */ import javax.activation.FileDataSource;
/*  15:    */ import javax.annotation.PostConstruct;
/*  16:    */ import javax.mail.Address;
/*  17:    */ import javax.mail.Message.RecipientType;
/*  18:    */ import javax.mail.Multipart;
/*  19:    */ import javax.mail.SendFailedException;
/*  20:    */ import javax.mail.Session;
/*  21:    */ import javax.mail.Transport;
/*  22:    */ import javax.mail.internet.InternetAddress;
/*  23:    */ import javax.mail.internet.MimeBodyPart;
/*  24:    */ import javax.mail.internet.MimeMessage;
/*  25:    */ import javax.mail.internet.MimeMultipart;
/*  26:    */ import org.apache.commons.logging.Log;
/*  27:    */ import org.springframework.beans.factory.annotation.Autowired;
/*  28:    */ import org.springframework.stereotype.Service;
/*  29:    */ 
/*  30:    */ @Service("emailUtil")
/*  31:    */ public class EmailUtil
/*  32:    */   implements IEmailUtil
/*  33:    */ {
/*  34:    */   private Log logger;
/*  35:    */   @Autowired
/*  36:    */   ILoggerUtil loggerUtil;
/*  37:    */   
/*  38:    */   @PostConstruct
/*  39:    */   public void initService()
/*  40:    */   {
/*  41: 90 */     this.logger = this.loggerUtil.getExtLogger();
/*  42:    */   }
/*  43:    */   
/*  44:    */   public void sendEmail(EmailInformation emailInformation)
/*  45:    */     throws Exception
/*  46:    */   {
/*  47:110 */     this.logger.debug("sendNotification()Start");
/*  48:    */     
/*  49:    */ 
/*  50:113 */     String emailContent = "";
/*  51:114 */     Properties props = null;
/*  52:115 */     Session session = null;
/*  53:116 */     MimeMessage msg = null;
/*  54:117 */     Multipart multipart = null;
/*  55:118 */     InternetAddress addressFrom = null;
/*  56:119 */     InternetAddress[] addressTo = null;
/*  57:120 */     InternetAddress[] addressCc = null;
/*  58:121 */     MimeBodyPart messageBodyPart = null;
/*  59:122 */     Address[] invalidEmailAddresses = null;
/*  60:    */     
/*  61:    */ 
/*  62:125 */     this.logger.debug("Email Sent with the following Values: " + emailInformation.toString());
/*  63:127 */     if (validateBeforeSendEmail(emailInformation))
/*  64:    */     {
/*  65:    */       try
/*  66:    */       {
/*  67:137 */         props = new Properties();
/*  68:138 */         props.put("mail.smtp.host", emailInformation.getMailServer());
/*  69:139 */         session = Session.getInstance(props, null);
/*  70:140 */         msg = new MimeMessage(session);
/*  71:146 */         if (!CommonUtil.isNullOrEmpty(emailInformation.getFromName())) {
/*  72:147 */           addressFrom = new InternetAddress(emailInformation.getFromAddress(), emailInformation.getFromName());
/*  73:    */         } else {
/*  74:150 */           addressFrom = new InternetAddress(emailInformation.getFromAddress());
/*  75:    */         }
/*  76:152 */         addressTo = getEmailAddresses(emailInformation, true, false);
/*  77:153 */         addressCc = emailInformation.isCCRequired() ? getEmailAddresses(emailInformation, false, true) : addressCc;
/*  78:    */         
/*  79:    */ 
/*  80:156 */         this.logger.debug("To Address: " + addressTo.toString());
/*  81:157 */         this.logger.debug("Email Body: " + emailInformation.getEmailBody());
/*  82:158 */         emailContent = emailInformation.isFormattedEmail() ? emailInformation.getEmailBody() : emailInformation.getEmailContent();
/*  83:    */         
/*  84:    */ 
/*  85:    */ 
/*  86:    */ 
/*  87:    */ 
/*  88:    */ 
/*  89:165 */         msg.setFrom(addressFrom);
/*  90:166 */         msg.setRecipients(Message.RecipientType.TO, addressTo);
/*  91:167 */         msg.setRecipients(Message.RecipientType.CC, addressCc);
/*  92:168 */         msg.setSubject(emailInformation.getEmailSubject(), "utf-8");
/*  93:171 */         if ((emailInformation.isAttachments()) && (CommonUtil.isListNotNullOrEmpty(emailInformation.getAttachments())))
/*  94:    */         {
/*  95:173 */           multipart = new MimeMultipart();
/*  96:176 */           for (File file : emailInformation.getAttachments())
/*  97:    */           {
/*  98:178 */             messageBodyPart = new MimeBodyPart();
/*  99:179 */             messageBodyPart.setDataHandler(new DataHandler(new FileDataSource(file)));
/* 100:180 */             messageBodyPart.setFileName(file.getName());
/* 101:181 */             multipart.addBodyPart(messageBodyPart);
/* 102:    */           }
/* 103:184 */           messageBodyPart = new MimeBodyPart();
/* 104:185 */           messageBodyPart.setText(emailContent);
/* 105:186 */           msg.setContent(multipart);
/* 106:    */         }
/* 107:    */         else
/* 108:    */         {
/* 109:189 */           msg.setContent(emailContent, "text/html;charset=utf-8");
/* 110:    */         }
/* 111:192 */         Transport.send(msg);
/* 112:193 */         emailInformation.setEmailSent(emailInformation.getEmailSent() + 1);
/* 113:    */       }
/* 114:    */       catch (SendFailedException sendFailedException)
/* 115:    */       {
/* 116:197 */         emailInformation.setEmailFailed(emailInformation.getEmailFailed() + 1);
/* 117:198 */         invalidEmailAddresses = sendFailedException.getInvalidAddresses();
/* 118:199 */         this.logger.debug("EXCEPTION !!!!!!!!!!!!!!!! Email Information" + emailInformation);
/* 119:200 */         this.logger.debug("EXCEPTION !!!!!!!!!!!!!!!! Invalid Email Addresses" + invalidEmailAddresses);
/* 120:201 */         this.logger.debug("Send mail error occured, message not sent to with following Email Information" + CommonUtil.getStackTrace(sendFailedException));
/* 121:    */       }
/* 122:    */       catch (Exception ex)
/* 123:    */       {
/* 124:205 */         emailInformation.setEmailFailed(emailInformation.getEmailFailed() + 1);
/* 125:206 */         this.logger.debug("Send mail error occured, message not sent to with following Email Information" + CommonUtil.getStackTrace(ex));
/* 126:    */       }
/* 127:    */       finally
/* 128:    */       {
/* 129:211 */         msg = null;
/* 130:212 */         session = null;
/* 131:    */       }
/* 132:    */     }
/* 133:    */     else
/* 134:    */     {
/* 135:217 */       if (CommonUtil.isListNotNullOrEmpty(emailInformation.getInvalidToAddresses())) {
/* 136:218 */         this.logger.error("Warning !!!!!!!!!!!!!!!! Invalid CC Email Addresses" + emailInformation.getInvalidToAddresses());
/* 137:    */       }
/* 138:220 */       if (CommonUtil.isListNotNullOrEmpty(emailInformation.getInvalidCCAddresses())) {
/* 139:221 */         this.logger.error("Warning !!!!!!!!!!!!!!!! Invalid TO Email Addresses" + emailInformation.getInvalidCCAddresses());
/* 140:    */       }
/* 141:    */     }
/* 142:225 */     this.logger.debug("sendNotification()End");
/* 143:    */   }
/* 144:    */   
/* 145:    */   public void getEmailBodyInHTMLFormat(EmailInformation emailInformation)
/* 146:    */     throws Exception
/* 147:    */   {
/* 148:241 */     StringBuilder htmlTableForEmailBody = null;
/* 149:242 */     List<String> bodyValueList = null;
/* 150:243 */     List<String> invalidBodyValueList = null;
/* 151:    */     
/* 152:245 */     htmlTableForEmailBody = new StringBuilder();
/* 153:247 */     if ((CommonUtil.isListNotNullOrEmpty(emailInformation.getEmailBodytableHeaderInfo())) && (CommonUtil.isListNotNullOrEmpty(emailInformation.getEmailBodytableBodyInfo())))
/* 154:    */     {
/* 155:250 */       htmlTableForEmailBody.append("<table>");
/* 156:251 */       htmlTableForEmailBody.append("<thead>");
/* 157:253 */       for (String tableHeader : emailInformation.getEmailBodytableHeaderInfo())
/* 158:    */       {
/* 159:255 */         htmlTableForEmailBody.append("<th>");
/* 160:256 */         htmlTableForEmailBody.append(tableHeader);
/* 161:257 */         htmlTableForEmailBody.append("</th>");
/* 162:    */       }
/* 163:259 */       htmlTableForEmailBody.append("</thead>");
/* 164:260 */       htmlTableForEmailBody.append("<tbody>");
/* 165:262 */       for (String bodyValues : emailInformation.getEmailBodytableBodyInfo())
/* 166:    */       {
/* 167:264 */         bodyValueList = CommonUtil.parseDelimitedValues(bodyValues, ";");
/* 168:266 */         if ((CommonUtil.isListNotNullOrEmpty(bodyValueList)) && (bodyValueList.size() == emailInformation.getEmailBodytableHeaderInfo().size()))
/* 169:    */         {
/* 170:269 */           htmlTableForEmailBody.append("<tr>");
/* 171:271 */           for (String bodyValue : bodyValueList)
/* 172:    */           {
/* 173:273 */             htmlTableForEmailBody.append("<td>");
/* 174:274 */             htmlTableForEmailBody.append(bodyValue);
/* 175:275 */             htmlTableForEmailBody.append("</td>");
/* 176:    */           }
/* 177:278 */           htmlTableForEmailBody.append("</tr>");
/* 178:    */         }
/* 179:279 */         else if (CommonUtil.isListNotNullOrEmpty(bodyValueList))
/* 180:    */         {
/* 181:281 */           invalidBodyValueList = CommonUtil.isListNotNullOrEmpty(invalidBodyValueList) ? invalidBodyValueList : new ArrayList();
/* 182:    */           
/* 183:283 */           invalidBodyValueList.add(bodyValues);
/* 184:    */         }
/* 185:    */       }
/* 186:287 */       htmlTableForEmailBody.append("</tbody>");
/* 187:288 */       htmlTableForEmailBody.append("</table>");
/* 188:    */     }
/* 189:291 */     emailInformation.setEmailContent(htmlTableForEmailBody.toString());
/* 190:293 */     if (CommonUtil.isListNotNullOrEmpty(invalidBodyValueList))
/* 191:    */     {
/* 192:295 */       emailInformation.setInvalidBodyRows(invalidBodyValueList);
/* 193:296 */       this.logger.error("WARNING!!!!!!!!!!! The following rows were not added to the email body as they didnt match the number of columns: " + invalidBodyValueList);
/* 194:    */     }
/* 195:    */   }
/* 196:    */   
/* 197:    */   public boolean isSendEmail(EmailInformation emailInformation)
/* 198:    */     throws Exception
/* 199:    */   {
/* 200:315 */     boolean isToAddressesPresent = true;
/* 201:316 */     boolean isCCAddressesPresent = true;
/* 202:    */     
/* 203:318 */     isToAddressesPresent = emailInformation.isEmailToMultipleEmailAddresses() ? CommonUtil.isListNotNullOrEmpty(emailInformation.getToAddresses()) : CommonUtil.isNotNullOrEmpty(emailInformation.getToAddress());
/* 204:    */     
/* 205:    */ 
/* 206:321 */     isCCAddressesPresent = emailInformation.isCCRequired() ? CommonUtil.isNotNullOrEmpty(emailInformation.getCcAddress()) : emailInformation.isEmailToMultipleCCAddress() ? CommonUtil.isListNotNullOrEmpty(emailInformation.getCcAddresses()) : true;
/* 207:    */     
/* 208:    */ 
/* 209:    */ 
/* 210:325 */     this.logger.debug("Is valid Email Content: " + CommonUtil.isNotNullOrEmpty(emailInformation.getEmailContent()));
/* 211:326 */     this.logger.debug("Is valid To Address: " + isToAddressesPresent);
/* 212:327 */     this.logger.debug("Is valid CC Address: " + isCCAddressesPresent);
/* 213:328 */     return (CommonUtil.isNotNullOrEmpty(emailInformation.getEmailContent())) && (isToAddressesPresent) && (isCCAddressesPresent);
/* 214:    */   }
/* 215:    */   
/* 216:    */   private boolean validateBeforeSendEmail(EmailInformation emailInformation)
/* 217:    */     throws Exception
/* 218:    */   {
/* 219:345 */     this.logger.debug("validateBeforeSendNotification()Start");
/* 220:    */     
/* 221:347 */     boolean validToAddressInfo = true;
/* 222:348 */     boolean validCCAddressInfo = true;
/* 223:    */     
/* 224:350 */     List<String> invalidTOAddress = null;
/* 225:351 */     List<String> invalidCCAddress = null;
/* 226:    */     
/* 227:353 */     validToAddressInfo = (CommonUtil.isNotNullOrEmpty(emailInformation.getToAddress())) || ((emailInformation.isEmailToMultipleEmailAddresses()) && (CommonUtil.isListNotNullOrEmpty(emailInformation.getToAddresses())));
/* 228:    */     
/* 229:    */ 
/* 230:356 */     invalidTOAddress = emailInformation.isEmailToMultipleEmailAddresses() ? validateListOfEmailAddresses(emailInformation.getToAddresses()) : invalidTOAddress;
/* 231:    */     
/* 232:    */ 
/* 233:359 */     this.logger.debug("validToAddressInfo: " + validToAddressInfo);
/* 234:360 */     this.logger.debug("Invalid To Address" + invalidTOAddress);
/* 235:362 */     if ((!emailInformation.isEmailToMultipleEmailAddresses()) && (!validateEmailAddress(emailInformation.getToAddress())))
/* 236:    */     {
/* 237:365 */       invalidTOAddress = new ArrayList();
/* 238:366 */       invalidTOAddress.add(emailInformation.getToAddress());
/* 239:367 */       validToAddressInfo = false;
/* 240:    */     }
/* 241:370 */     emailInformation.setInvalidToAddresses(invalidTOAddress);
/* 242:372 */     if (emailInformation.isCCRequired())
/* 243:    */     {
/* 244:374 */       validCCAddressInfo = (CommonUtil.isNotNullOrEmpty(emailInformation.getCcAddress())) || ((emailInformation.isEmailToMultipleCCAddress()) && (CommonUtil.isListNotNullOrEmpty(emailInformation.getCcAddresses())));
/* 245:    */       
/* 246:    */ 
/* 247:377 */       invalidCCAddress = emailInformation.isEmailToMultipleCCAddress() ? validateListOfEmailAddresses(emailInformation.getCcAddresses()) : invalidCCAddress;
/* 248:380 */       if ((!emailInformation.isEmailToMultipleCCAddress()) && (!validateEmailAddress(emailInformation.getCcAddress())))
/* 249:    */       {
/* 250:383 */         invalidCCAddress = new ArrayList();
/* 251:384 */         invalidCCAddress.add(emailInformation.getCcAddress());
/* 252:385 */         validCCAddressInfo = false;
/* 253:    */       }
/* 254:388 */       emailInformation.setInvalidCCAddresses(invalidCCAddress);
/* 255:    */     }
/* 256:391 */     if (emailInformation.isEmailToMultipleEmailAddresses())
/* 257:    */     {
/* 258:393 */       removeInvalidAddresses(emailInformation.getToAddresses(), emailInformation.getInvalidToAddresses());
/* 259:394 */       validToAddressInfo = (emailInformation.isEmailToMultipleEmailAddresses()) && (CommonUtil.isListNotNullOrEmpty(emailInformation.getToAddresses()));
/* 260:    */     }
/* 261:399 */     if (emailInformation.isEmailToMultipleCCAddress())
/* 262:    */     {
/* 263:401 */       removeInvalidAddresses(emailInformation.getCcAddresses(), emailInformation.getInvalidCCAddresses());
/* 264:402 */       validCCAddressInfo = (emailInformation.isCCRequired()) && (emailInformation.isEmailToMultipleCCAddress()) && (CommonUtil.isListNotNullOrEmpty(emailInformation.getCcAddresses()));
/* 265:    */     }
/* 266:406 */     this.logger.debug("is valid: " + ((validToAddressInfo) && (validCCAddressInfo)));
/* 267:407 */     this.logger.debug("Is Email information Valid: " + ((validToAddressInfo) && (validCCAddressInfo)));
/* 268:408 */     this.logger.debug("validateBeforeSendNotification()End");
/* 269:409 */     return (validToAddressInfo) && (validCCAddressInfo);
/* 270:    */   }
/* 271:    */   
/* 272:    */   private InternetAddress[] getEmailAddresses(EmailInformation emailInformation, boolean isTOAddress, boolean isCCAddress)
/* 273:    */     throws Exception
/* 274:    */   {
/* 275:428 */     this.logger.debug("getAddresses()Start");
/* 276:429 */     InternetAddress[] addresses = null;
/* 277:431 */     if (isTOAddress)
/* 278:    */     {
/* 279:432 */       if ((emailInformation.isEmailToMultipleEmailAddresses()) && (CommonUtil.isListNotNullOrEmpty(emailInformation.getToAddresses()))) {
/* 280:435 */         addresses = getEmailAddresses(emailInformation.getToAddresses());
/* 281:    */       } else {
/* 282:437 */         addresses = getEmailAddress(emailInformation.getToAddress());
/* 283:    */       }
/* 284:    */     }
/* 285:438 */     else if (isCCAddress) {
/* 286:439 */       if ((emailInformation.isEmailToMultipleEmailAddresses()) && (CommonUtil.isListNotNullOrEmpty(emailInformation.getCcAddresses()))) {
/* 287:442 */         addresses = getEmailAddresses(emailInformation.getCcAddresses());
/* 288:    */       } else {
/* 289:444 */         addresses = getEmailAddress(emailInformation.getCcAddress());
/* 290:    */       }
/* 291:    */     }
/* 292:447 */     this.logger.debug("getAddresses()End");
/* 293:448 */     return addresses;
/* 294:    */   }
/* 295:    */   
/* 296:    */   private InternetAddress[] getEmailAddress(String emailAddress)
/* 297:    */     throws Exception
/* 298:    */   {
/* 299:463 */     this.logger.debug("getEmailAddress()Start");
/* 300:    */     
/* 301:465 */     InternetAddress[] address = null;
/* 302:    */     
/* 303:467 */     address = new InternetAddress[] { new InternetAddress(emailAddress) };
/* 304:    */     
/* 305:469 */     this.logger.debug("getEmailAddress()End");
/* 306:470 */     return address;
/* 307:    */   }
/* 308:    */   
/* 309:    */   private InternetAddress[] getEmailAddresses(List<String> emailAddresses)
/* 310:    */     throws Exception
/* 311:    */   {
/* 312:485 */     this.logger.debug("getEmailAddresses()Start");
/* 313:    */     
/* 314:487 */     int counter = 0;
/* 315:488 */     InternetAddress[] addresses = null;
/* 316:    */     
/* 317:490 */     addresses = new InternetAddress[emailAddresses.size()];
/* 318:492 */     for (String recipient : emailAddresses)
/* 319:    */     {
/* 320:493 */       addresses[counter] = new InternetAddress(recipient.trim());
/* 321:494 */       counter++;
/* 322:    */     }
/* 323:497 */     this.logger.debug("getEmailAddresses()End");
/* 324:498 */     return addresses;
/* 325:    */   }
/* 326:    */   
/* 327:    */   public List<String> validateListOfEmailAddresses(List<String> emailAddresses)
/* 328:    */   {
/* 329:516 */     List<String> invalidEmailAddresses = null;
/* 330:    */     
/* 331:    */ 
/* 332:    */ 
/* 333:    */ 
/* 334:    */ 
/* 335:    */ 
/* 336:523 */     invalidEmailAddresses = new ArrayList();
/* 337:525 */     for (String emailAddress : emailAddresses) {
/* 338:527 */       if (!validateEmailAddress(emailAddress)) {
/* 339:528 */         invalidEmailAddresses.add(emailAddress);
/* 340:    */       }
/* 341:    */     }
/* 342:532 */     return invalidEmailAddresses;
/* 343:    */   }
/* 344:    */   
/* 345:    */   public boolean validateEmailAddress(String emailAddress)
/* 346:    */   {
/* 347:550 */     Matcher matcher = null;
/* 348:551 */     Pattern pattern = null;
/* 349:    */     
/* 350:    */ 
/* 351:    */ 
/* 352:    */ 
/* 353:    */ 
/* 354:    */ 
/* 355:558 */     pattern = Pattern.compile(".+@.+\\.[a-z]+");
/* 356:559 */     matcher = pattern.matcher(emailAddress);
/* 357:    */     
/* 358:    */ 
/* 359:562 */     return matcher.matches();
/* 360:    */   }
/* 361:    */   
/* 362:    */   private List<String> removeInvalidAddresses(List<String> emailAddresses, List<String> invalidAddresses)
/* 363:    */     throws Exception
/* 364:    */   {
/* 365:580 */     this.logger.debug("removeInvalidAddresses()Start");
/* 366:581 */     this.logger.debug("Invalid email Addresses: " + invalidAddresses);
/* 367:583 */     if ((CommonUtil.isListNotNullOrEmpty(emailAddresses)) && (CommonUtil.isListNotNullOrEmpty(invalidAddresses))) {
/* 368:585 */       emailAddresses.removeAll(invalidAddresses);
/* 369:    */     }
/* 370:588 */     this.logger.debug("Final List of Addresses" + emailAddresses);
/* 371:589 */     this.logger.debug("removeInvalidAddresses()End");
/* 372:590 */     return emailAddresses;
/* 373:    */   }
/* 374:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.impl.EmailUtil
 * JD-Core Version:    0.7.0.1
 */