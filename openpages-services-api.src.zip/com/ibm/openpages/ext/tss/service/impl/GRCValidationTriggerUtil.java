/*   1:    */ package com.ibm.openpages.ext.tss.service.impl;
/*   2:    */ 
/*   3:    */ import com.ibm.openpages.api.resource.IField;
/*   4:    */ import com.ibm.openpages.ext.tss.service.IFieldUtil;
/*   5:    */ import com.ibm.openpages.ext.tss.service.IGRCObjectSearchUtil;
/*   6:    */ import com.ibm.openpages.ext.tss.service.IGRCValidationTriggerUtil;
/*   7:    */ import com.ibm.openpages.ext.tss.service.ILoggerUtil;
/*   8:    */ import com.ibm.openpages.ext.tss.service.beans.IGRCFieldInformationForQuery;
/*   9:    */ import com.ibm.openpages.ext.tss.service.beans.IGRCObjectValidateInformation;
/*  10:    */ import com.ibm.openpages.ext.tss.service.constants.CheckFor;
/*  11:    */ import com.ibm.openpages.ext.tss.service.util.CommonUtil;
/*  12:    */ import java.util.ArrayList;
/*  13:    */ import java.util.List;
/*  14:    */ import java.util.Map;
/*  15:    */ import java.util.SortedSet;
/*  16:    */ import java.util.TreeSet;
/*  17:    */ import javax.annotation.PostConstruct;
/*  18:    */ import org.apache.commons.logging.Log;
/*  19:    */ import org.springframework.beans.factory.annotation.Autowired;
/*  20:    */ import org.springframework.stereotype.Service;
/*  21:    */ 
/*  22:    */ @Service("grcValidationTriggerUtil")
/*  23:    */ public class GRCValidationTriggerUtil
/*  24:    */   implements IGRCValidationTriggerUtil
/*  25:    */ {
/*  26:    */   private Log logger;
/*  27:    */   @Autowired
/*  28:    */   ILoggerUtil loggerUtil;
/*  29:    */   @Autowired
/*  30:    */   IFieldUtil fieldUtil;
/*  31:    */   @Autowired
/*  32:    */   IGRCObjectSearchUtil objectSearchUtil;
/*  33:    */   
/*  34:    */   @PostConstruct
/*  35:    */   public void initService()
/*  36:    */   {
/*  37: 74 */     this.logger = this.loggerUtil.getExtLogger();
/*  38:    */   }
/*  39:    */   
/*  40:    */   public IGRCObjectValidateInformation validateObject(IGRCObjectValidateInformation objectValidationInformation)
/*  41:    */     throws Exception
/*  42:    */   {
/*  43: 87 */     initService();
/*  44:    */     
/*  45: 89 */     this.logger.debug("Is Event on All Children: " + objectValidationInformation.isEventOnAllChild());
/*  46: 90 */     if (objectValidationInformation.isEventOnAllParent()) {
/*  47: 92 */       validateObjectBasedOnInformationOnAllParent(objectValidationInformation);
/*  48: 94 */     } else if (objectValidationInformation.isEventOnAllChild()) {
/*  49: 96 */       validateObjectBasedOnInformationOnAllChildren(objectValidationInformation);
/*  50: 98 */     } else if (objectValidationInformation.isEventOnObject()) {
/*  51:100 */       validateObjectBasedOnInformationOnObject(objectValidationInformation);
/*  52:    */     }
/*  53:104 */     return objectValidationInformation;
/*  54:    */   }
/*  55:    */   
/*  56:    */   private IGRCObjectValidateInformation validateObjectBasedOnInformationOnObject(IGRCObjectValidateInformation objectValidationInformation)
/*  57:    */     throws Exception
/*  58:    */   {
/*  59:109 */     int index = 0;
/*  60:110 */     boolean returnValForAny = false;
/*  61:111 */     boolean returnValForAll = true;
/*  62:112 */     CheckFor checkFor = null;
/*  63:113 */     List<List<?>> compareList = null;
/*  64:    */     
/*  65:115 */     boolean isConditionMatch = false;
/*  66:    */     
/*  67:117 */     this.logger.debug("START validateObjectBasedOnInformationOnObject()");
/*  68:    */     
/*  69:119 */     compareList = new ArrayList();
/*  70:120 */     compareList.add(objectValidationInformation.getFieldsList());
/*  71:121 */     compareList.add(objectValidationInformation.getFieldValuesList());
/*  72:122 */     compareList.add(objectValidationInformation.getComparatorsList());
/*  73:124 */     if (CommonUtil.isListsOfTheSameSize(compareList))
/*  74:    */     {
/*  75:126 */       checkFor = CommonUtil.getCheckFor(objectValidationInformation.getCheckFor());
/*  76:128 */       for (String fieldInfo : objectValidationInformation.getFieldsList())
/*  77:    */       {
/*  78:130 */         boolean flag = false;
/*  79:131 */         isConditionMatch = this.fieldUtil.compareFields((String)objectValidationInformation.getFieldValuesList().get(index), this.fieldUtil.getField(objectValidationInformation.getSourceObject(), fieldInfo), (String)objectValidationInformation.getComparatorsList().get(index));
/*  80:136 */         if (isConditionMatch)
/*  81:    */         {
/*  82:138 */           if (CheckFor.CHECK_ANY.equals(checkFor))
/*  83:    */           {
/*  84:139 */             returnValForAny = true;
/*  85:140 */             break;
/*  86:    */           }
/*  87:141 */           if (CheckFor.CHECK_ALL.equals(checkFor)) {
/*  88:142 */             flag = true;
/*  89:    */           }
/*  90:    */         }
/*  91:146 */         if ((CheckFor.CHECK_ALL.equals(checkFor)) && (!flag))
/*  92:    */         {
/*  93:147 */           returnValForAll = false;
/*  94:148 */           break;
/*  95:    */         }
/*  96:152 */         index++;
/*  97:    */       }
/*  98:    */     }
/*  99:156 */     if (CheckFor.CHECK_ALL.equals(checkFor)) {
/* 100:157 */       isConditionMatch = returnValForAll;
/* 101:158 */     } else if (CheckFor.CHECK_ANY.equals(checkFor)) {
/* 102:159 */       isConditionMatch = returnValForAny;
/* 103:    */     } else {
/* 104:161 */       isConditionMatch = true;
/* 105:    */     }
/* 106:164 */     this.logger.debug("REturn value for all: " + returnValForAll);
/* 107:165 */     this.logger.debug("REturn value for any: " + returnValForAny);
/* 108:166 */     this.logger.debug("Is Condition: " + isConditionMatch);
/* 109:168 */     if (!isConditionMatch)
/* 110:    */     {
/* 111:170 */       objectValidationInformation.setException(true);
/* 112:171 */       objectValidationInformation.setExceptionMessage(objectValidationInformation.getCheckAllExceptionMessage());
/* 113:    */     }
/* 114:174 */     this.logger.debug("END validateObjectBasedOnInformationOnObject()");
/* 115:175 */     return objectValidationInformation;
/* 116:    */   }
/* 117:    */   
/* 118:    */   private IGRCObjectValidateInformation validateObjectBasedOnInformationOnAllParent(IGRCObjectValidateInformation objectValidationInformation)
/* 119:    */     throws Exception
/* 120:    */   {
/* 121:181 */     initService();
/* 122:182 */     int index = 0;
/* 123:183 */     boolean isConditionMatch = false;
/* 124:184 */     List<List<?>> compareList = null;
/* 125:185 */     List<String> objectHeirarchyList = null;
/* 126:186 */     List<String> dateValuesList = null;
/* 127:187 */     boolean returnValForAny = false;
/* 128:188 */     boolean returnValForAll = true;
/* 129:189 */     CheckFor checkFor = null;
/* 130:    */     
/* 131:191 */     this.logger.debug("START validateObjectBasedOnInformationOnAllChild()");
/* 132:192 */     this.logger.debug("Is the Heirarchy List not null or empty: " + CommonUtil.isListNotNullOrEmpty(objectValidationInformation.getHeirarchyList()));
/* 133:193 */     if (CommonUtil.isListNotNullOrEmpty(objectValidationInformation.getHeirarchyList()))
/* 134:    */     {
/* 135:195 */       dateValuesList = new ArrayList();
/* 136:196 */       checkFor = CommonUtil.getCheckFor(objectValidationInformation.getCheckFor());
/* 137:198 */       for (String objectHeirarchy : objectValidationInformation.getHeirarchyList())
/* 138:    */       {
/* 139:200 */         index = 0;
/* 140:201 */         compareList = new ArrayList();
/* 141:202 */         this.logger.debug("Object Heirarchy to process: " + objectHeirarchy);
/* 142:203 */         objectHeirarchyList = CommonUtil.parseCommaDelimitedValues(objectHeirarchy);
/* 143:204 */         compareList.add(objectValidationInformation.getFieldsList());
/* 144:205 */         compareList.add(objectValidationInformation.getFieldValuesList());
/* 145:206 */         compareList.add(objectValidationInformation.getComparatorsList());
/* 146:    */         
/* 147:208 */         this.logger.debug("Are comparison lists of the same size: " + CommonUtil.isListsOfTheSameSize(compareList));
/* 148:209 */         if (CommonUtil.isListsOfTheSameSize(compareList)) {
/* 149:211 */           for (String fieldsInfo : objectValidationInformation.getFieldsList())
/* 150:    */           {
/* 151:213 */             boolean flag = false;
/* 152:214 */             StringBuilder queryString = this.objectSearchUtil.getQueryForMultipleParentAssociation(CommonUtil.parsePipeDelimitedValues(fieldsInfo), objectHeirarchyList);
/* 153:215 */             queryString = this.objectSearchUtil.appendResourceIdWhereClauseToQuery(queryString.toString(), objectValidationInformation.getSourceObject());
/* 154:    */             
/* 155:217 */             this.logger.debug("Going to execute query: " + queryString.toString());
/* 156:218 */             SortedSet<String> test = new TreeSet();
/* 157:219 */             dateValuesList = this.objectSearchUtil.getMultipleValuesFromQueryAsList(queryString.toString(), false);
/* 158:    */             
/* 159:221 */             test.addAll(this.objectSearchUtil.getMultipleValuesFromQueryAsList(queryString.toString(), false));
/* 160:222 */             this.logger.debug("Test Set values set in: " + test.toString());
/* 161:223 */             test.remove("");
/* 162:224 */             test.remove("null");
/* 163:225 */             this.logger.debug("Test Set values set in removing null: " + test.toString());
/* 164:227 */             if (objectValidationInformation.isCompareFieldToField())
/* 165:    */             {
/* 166:229 */               IField field = this.fieldUtil.getField(objectValidationInformation.getSourceObject(), (String)objectValidationInformation.getFieldValuesList().get(index));
/* 167:    */               
/* 168:231 */               this.logger.debug("Going to compare field value 1: " + this.fieldUtil.getFieldValueAsString(field));
/* 169:232 */               this.logger.debug("Comparator: " + (String)objectValidationInformation.getComparatorsList().get(index));
/* 170:233 */               this.logger.debug("With the value 2: " + (String)test.first());
/* 171:234 */               isConditionMatch = this.fieldUtil.compareFields((String)test.first(), field, (String)objectValidationInformation.getComparatorsList().get(index));
/* 172:    */               
/* 173:236 */               this.logger.debug("Is Condition Match: " + isConditionMatch);
/* 174:238 */               if (isConditionMatch)
/* 175:    */               {
/* 176:240 */                 if (CheckFor.CHECK_ANY.equals(checkFor))
/* 177:    */                 {
/* 178:241 */                   returnValForAny = true;
/* 179:242 */                   break;
/* 180:    */                 }
/* 181:243 */                 if (CheckFor.CHECK_ALL.equals(checkFor)) {
/* 182:244 */                   flag = true;
/* 183:    */                 }
/* 184:    */               }
/* 185:    */             }
/* 186:249 */             if ((CheckFor.CHECK_ALL.equals(checkFor)) && (!flag))
/* 187:    */             {
/* 188:250 */               returnValForAll = false;
/* 189:251 */               break;
/* 190:    */             }
/* 191:254 */             index++;
/* 192:    */           }
/* 193:    */         }
/* 194:258 */         if ((returnValForAny) || (!returnValForAll)) {
/* 195:    */           break;
/* 196:    */         }
/* 197:    */       }
/* 198:263 */       this.logger.debug("Check For: " + objectValidationInformation.getCheckFor());
/* 199:264 */       this.logger.debug("Is Check ALL: " + CheckFor.CHECK_ALL.equals(checkFor));
/* 200:265 */       this.logger.debug("Is Check Any: " + CheckFor.CHECK_ANY.equals(checkFor));
/* 201:267 */       if (CheckFor.CHECK_ALL.equals(checkFor)) {
/* 202:268 */         isConditionMatch = returnValForAll;
/* 203:269 */       } else if (CheckFor.CHECK_ANY.equals(checkFor)) {
/* 204:270 */         isConditionMatch = returnValForAny;
/* 205:    */       } else {
/* 206:272 */         isConditionMatch = true;
/* 207:    */       }
/* 208:275 */       this.logger.debug("REturn value for all: " + returnValForAll);
/* 209:276 */       this.logger.debug("REturn value for any: " + returnValForAny);
/* 210:277 */       this.logger.debug("Is Condition: " + isConditionMatch);
/* 211:279 */       if (!isConditionMatch)
/* 212:    */       {
/* 213:281 */         objectValidationInformation.setException(true);
/* 214:282 */         objectValidationInformation.setExceptionMessage(objectValidationInformation.getCheckAllExceptionMessage());
/* 215:    */       }
/* 216:285 */       this.logger.debug("Date Values identified: " + dateValuesList);
/* 217:    */     }
/* 218:288 */     return objectValidationInformation;
/* 219:    */   }
/* 220:    */   
/* 221:    */   private IGRCObjectValidateInformation validateObjectBasedOnInformationOnAllChildren(IGRCObjectValidateInformation objectValidationInformation)
/* 222:    */     throws Exception
/* 223:    */   {
/* 224:294 */     initService();
/* 225:295 */     boolean isConditionMatch = false;
/* 226:296 */     List<String> objectHeirarchyList = null;
/* 227:297 */     IGRCFieldInformationForQuery fieldInformationForQuery = null;
/* 228:    */     
/* 229:299 */     this.logger.debug("START validateObjectBasedOnInformationOnAllChild()");
/* 230:300 */     this.logger.debug("Is the Heirarchy List not null or empty: " + CommonUtil.isListNotNullOrEmpty(objectValidationInformation.getHeirarchyList()));
/* 231:301 */     if (CommonUtil.isListNotNullOrEmpty(objectValidationInformation.getHeirarchyList()))
/* 232:    */     {
/* 233:303 */       fieldInformationForQuery = new IGRCFieldInformationForQuery();
/* 234:304 */       fieldInformationForQuery.setFieldsList(objectValidationInformation.getFieldsList());
/* 235:305 */       fieldInformationForQuery.setSourceObject(objectValidationInformation.getSourceObject());
/* 236:306 */       fieldInformationForQuery.setFieldValuesList(objectValidationInformation.getFieldValuesList());
/* 237:308 */       for (String objectHeirarchy : objectValidationInformation.getHeirarchyList())
/* 238:    */       {
/* 239:310 */         this.logger.debug("Object Heirarchy to process: " + objectHeirarchy);
/* 240:311 */         objectHeirarchyList = CommonUtil.parseCommaDelimitedValues(objectHeirarchy);
/* 241:    */         
/* 242:313 */         StringBuilder queryString = this.objectSearchUtil.getBaseQueryForMultipleChildAssociation(objectHeirarchyList);
/* 243:314 */         fieldInformationForQuery.setObjectTypeForQuery((String)objectHeirarchyList.get(0));
/* 244:315 */         isConditionMatch = processComparison(objectValidationInformation, fieldInformationForQuery, queryString);
/* 245:317 */         if (!isConditionMatch)
/* 246:    */         {
/* 247:319 */           objectValidationInformation.setException(true);
/* 248:320 */           objectValidationInformation.setExceptionMessage(objectValidationInformation.getCheckAllExceptionMessage());
/* 249:321 */           break;
/* 250:    */         }
/* 251:    */       }
/* 252:    */     }
/* 253:326 */     this.logger.debug("START validateObjectBasedOnInformationOnAllChild()");
/* 254:327 */     return objectValidationInformation;
/* 255:    */   }
/* 256:    */   
/* 257:    */   private boolean processComparison(IGRCObjectValidateInformation objectValidationInformation, IGRCFieldInformationForQuery fieldInformationForQuery, StringBuilder queryString)
/* 258:    */     throws Exception
/* 259:    */   {
/* 260:332 */     this.logger.debug("START getAssociationQuery()");
/* 261:    */     
/* 262:334 */     boolean isConditionMatch = true;
/* 263:    */     
/* 264:336 */     int queryCount = 0;
/* 265:337 */     int allQueryCount = 0;
/* 266:338 */     StringBuilder allChildObjectsQuery = null;
/* 267:339 */     Map<String, StringBuilder> queriesMap = null;
/* 268:340 */     StringBuilder satisfyingChildObjectsQuery = null;
/* 269:343 */     if (!objectValidationInformation.isCompareFieldToField())
/* 270:    */     {
/* 271:348 */       this.logger.debug("Is the Fields List and the Field Values List same size: " + CommonUtil.isListsOfTheSameSize(objectValidationInformation.getFieldsList(), objectValidationInformation.getFieldValuesList()));
/* 272:350 */       if (CommonUtil.isListsOfTheSameSize(objectValidationInformation.getFieldsList(), objectValidationInformation.getFieldValuesList()))
/* 273:    */       {
/* 274:352 */         this.logger.debug("Fields List: " + objectValidationInformation.getFieldsList());
/* 275:353 */         this.logger.debug("Field Values List: " + objectValidationInformation.getFieldValuesList());
/* 276:    */         
/* 277:355 */         allChildObjectsQuery = this.objectSearchUtil.appendResourceIdWhereClauseToQuery(queryString.toString(), objectValidationInformation.getSourceObject());
/* 278:356 */         satisfyingChildObjectsQuery = this.objectSearchUtil.appendFieldsToWhereClauseInQuery(allChildObjectsQuery.toString(), fieldInformationForQuery);
/* 279:    */         
/* 280:358 */         this.logger.debug("All Child Values query: " + allChildObjectsQuery);
/* 281:359 */         allQueryCount = this.objectSearchUtil.getTotalNumberOfRecordsReturned(allChildObjectsQuery.toString());
/* 282:360 */         this.logger.debug("All Child Values Count: " + allQueryCount);
/* 283:362 */         if (allQueryCount != 0)
/* 284:    */         {
/* 285:364 */           this.logger.debug("Satisfying Child Values query: " + satisfyingChildObjectsQuery);
/* 286:365 */           queryCount = this.objectSearchUtil.getTotalNumberOfRecordsReturned(satisfyingChildObjectsQuery.toString());
/* 287:366 */           this.logger.debug("Satisfying Child Values Count: " + queryCount);
/* 288:    */           
/* 289:368 */           isConditionMatch = allQueryCount == queryCount;
/* 290:    */         }
/* 291:    */       }
/* 292:    */       else
/* 293:    */       {
/* 294:372 */         this.logger.debug("The Fields list: " + objectValidationInformation.getFieldsList() + " and the Field Values list: " + objectValidationInformation.getFieldValuesList() + " are not of the same size.");
/* 295:    */       }
/* 296:    */     }
/* 297:377 */     this.logger.debug("Query String returned: " + queriesMap);
/* 298:378 */     this.logger.debug("END getAssociationQuery()");
/* 299:379 */     return isConditionMatch;
/* 300:    */   }
/* 301:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.impl.GRCValidationTriggerUtil
 * JD-Core Version:    0.7.0.1
 */