/*    1:     */ package com.ibm.openpages.ext.tss.service.impl;
/*    2:     */ 
/*    3:     */ import com.ibm.openpages.api.metadata.DataType;
/*    4:     */ import com.ibm.openpages.api.metadata.ITypeDefinition;
/*    5:     */ import com.ibm.openpages.api.metadata.Id;
/*    6:     */ import com.ibm.openpages.api.query.IQuery;
/*    7:     */ import com.ibm.openpages.api.query.IResultSetRow;
/*    8:     */ import com.ibm.openpages.api.query.ITabularResultSet;
/*    9:     */ import com.ibm.openpages.api.resource.AssociationFilter;
/*   10:     */ import com.ibm.openpages.api.resource.GRCObjectFilter;
/*   11:     */ import com.ibm.openpages.api.resource.IAssociationNode;
/*   12:     */ import com.ibm.openpages.api.resource.IField;
/*   13:     */ import com.ibm.openpages.api.resource.IGRCObject;
/*   14:     */ import com.ibm.openpages.api.resource.IncludeAssociations;
/*   15:     */ import com.ibm.openpages.api.service.IConfigurationService;
/*   16:     */ import com.ibm.openpages.api.service.IMetaDataService;
/*   17:     */ import com.ibm.openpages.api.service.IQueryService;
/*   18:     */ import com.ibm.openpages.api.service.IResourceService;
/*   19:     */ import com.ibm.openpages.api.service.IServiceFactory;
/*   20:     */ import com.ibm.openpages.ext.tss.service.IFieldUtil;
/*   21:     */ import com.ibm.openpages.ext.tss.service.IGRCObjectSearchUtil;
/*   22:     */ import com.ibm.openpages.ext.tss.service.IGRCObjectUtil;
/*   23:     */ import com.ibm.openpages.ext.tss.service.ILoggerUtil;
/*   24:     */ import com.ibm.openpages.ext.tss.service.beans.IGRCFieldInformationForQuery;
/*   25:     */ import com.ibm.openpages.ext.tss.service.proxy.IServiceFactoryProxy;
/*   26:     */ import com.ibm.openpages.ext.tss.service.util.CommonUtil;
/*   27:     */ import com.ibm.openpages.ext.tss.service.util.NumericUtil;
/*   28:     */ import java.util.ArrayList;
/*   29:     */ import java.util.List;
/*   30:     */ import javax.annotation.PostConstruct;
/*   31:     */ import org.apache.commons.logging.Log;
/*   32:     */ import org.springframework.beans.factory.annotation.Autowired;
/*   33:     */ import org.springframework.stereotype.Service;
/*   34:     */ 
/*   35:     */ @Service("grcObjectSearchUtil")
/*   36:     */ public class GRCObjectSearchUtil
/*   37:     */   implements IGRCObjectSearchUtil
/*   38:     */ {
/*   39:     */   private Log logger;
/*   40:     */   @Autowired
/*   41:     */   IFieldUtil fieldUtil;
/*   42:     */   @Autowired
/*   43:     */   IGRCObjectUtil objectUtil;
/*   44:     */   @Autowired
/*   45:     */   ILoggerUtil loggerUtil;
/*   46:     */   @Autowired
/*   47:     */   IServiceFactoryProxy serviceFactoryProxy;
/*   48:     */   
/*   49:     */   @PostConstruct
/*   50:     */   public void initService()
/*   51:     */   {
/*   52:  85 */     this.logger = this.loggerUtil.getExtLogger();
/*   53:     */   }
/*   54:     */   
/*   55:     */   public ITabularResultSet executeQuery(String queryString, boolean isHonorPrimaryAssociation)
/*   56:     */     throws Exception
/*   57:     */   {
/*   58:  92 */     IServiceFactory serviceFactory = this.serviceFactoryProxy.getServiceFactory();
/*   59:  93 */     IQuery query = serviceFactory.createQueryService().buildQuery(queryString.toString());
/*   60:  95 */     if (isHonorPrimaryAssociation) {
/*   61:  96 */       query.setHonorPrimary(true);
/*   62:     */     }
/*   63:  98 */     ITabularResultSet resultset = query.fetchRows(0);
/*   64:     */     
/*   65: 100 */     return resultset;
/*   66:     */   }
/*   67:     */   
/*   68:     */   public ITabularResultSet executeQuery(String queryString)
/*   69:     */     throws Exception
/*   70:     */   {
/*   71: 112 */     IServiceFactory serviceFactory = this.serviceFactoryProxy.getServiceFactory();
/*   72: 113 */     IQuery query = serviceFactory.createQueryService().buildQuery(queryString.toString());
/*   73:     */     
/*   74: 115 */     ITabularResultSet resultset = query.fetchRows(0);
/*   75:     */     
/*   76: 117 */     return resultset;
/*   77:     */   }
/*   78:     */   
/*   79:     */   public int getTotalNumberOfRecordsReturned(String queryString, boolean isHonorPrimaryAssociation)
/*   80:     */     throws Exception
/*   81:     */   {
/*   82: 131 */     int queryCount = 0;
/*   83: 132 */     ITabularResultSet resultset = null;
/*   84:     */     
/*   85: 134 */     resultset = executeQuery(queryString, isHonorPrimaryAssociation);
/*   86: 136 */     for (IResultSetRow row : resultset) {
/*   87: 137 */       queryCount++;
/*   88:     */     }
/*   89: 140 */     return queryCount;
/*   90:     */   }
/*   91:     */   
/*   92:     */   public int getTotalNumberOfRecordsReturned(String queryString)
/*   93:     */     throws Exception
/*   94:     */   {
/*   95: 153 */     int queryCount = 0;
/*   96: 154 */     ITabularResultSet resultset = null;
/*   97:     */     
/*   98: 156 */     resultset = executeQuery(queryString);
/*   99: 158 */     for (IResultSetRow row : resultset) {
/*  100: 159 */       queryCount++;
/*  101:     */     }
/*  102: 162 */     return queryCount;
/*  103:     */   }
/*  104:     */   
/*  105:     */   public IGRCObject getImmediatePrimaryParentFromId(String objectId, List<String> objectHeirarchyList, boolean honorPrimaryAssociation)
/*  106:     */     throws Exception
/*  107:     */   {
/*  108: 182 */     StringBuilder queryString = null;
/*  109: 183 */     IGRCObject parentBusEntity = null;
/*  110:     */     
/*  111: 185 */     IServiceFactory serviceFactory = this.serviceFactoryProxy.getServiceFactory();
/*  112:     */     
/*  113: 187 */     queryString = getBaseQueryForParentAssociation(objectHeirarchyList);
/*  114: 188 */     queryString.append("].[Resource ID] = '");
/*  115: 189 */     queryString.append(objectId);
/*  116: 190 */     queryString.append("'");
/*  117:     */     
/*  118: 192 */     this.logger.debug("Created Query: " + queryString.toString());
/*  119: 193 */     String entityId = getSingleValueFromQuery(queryString.toString(), honorPrimaryAssociation);
/*  120:     */     
/*  121: 195 */     this.logger.debug("parent entity id not null and numeric: " + NumericUtil.isNumeric(entityId));
/*  122: 196 */     if (NumericUtil.isNumeric(entityId)) {
/*  123: 198 */       parentBusEntity = serviceFactory.createResourceService().getGRCObject(new Id(entityId));
/*  124:     */     }
/*  125: 201 */     return parentBusEntity;
/*  126:     */   }
/*  127:     */   
/*  128:     */   public IGRCObject getImmediatePrimaryParentFromName(String objectName, List<String> objectHeirarchyList, boolean honorPrimaryAssociation)
/*  129:     */     throws Exception
/*  130:     */   {
/*  131: 221 */     StringBuilder queryString = null;
/*  132: 222 */     IGRCObject parentBusEntity = null;
/*  133: 223 */     IServiceFactory serviceFactory = this.serviceFactoryProxy.getServiceFactory();
/*  134:     */     
/*  135: 225 */     queryString = getBaseQueryForParentAssociation(objectHeirarchyList);
/*  136: 226 */     queryString.append("].[Name] = '");
/*  137: 227 */     queryString.append(objectName);
/*  138: 228 */     queryString.append("'");
/*  139:     */     
/*  140: 230 */     this.logger.debug("Created Query: " + queryString.toString());
/*  141: 231 */     String entityId = getSingleValueFromQuery(queryString.toString(), honorPrimaryAssociation);
/*  142:     */     
/*  143: 233 */     this.logger.debug("parent entity id not null and numeric: " + NumericUtil.isNumeric(entityId));
/*  144: 234 */     if (NumericUtil.isNumeric(entityId)) {
/*  145: 236 */       parentBusEntity = serviceFactory.createResourceService().getGRCObject(new Id(entityId));
/*  146:     */     }
/*  147: 239 */     return parentBusEntity;
/*  148:     */   }
/*  149:     */   
/*  150:     */   public List<IAssociationNode> getAllParentsOfGivenType(String objectId, String parentObjectType, boolean honorPrimaryAssociation)
/*  151:     */     throws Exception
/*  152:     */   {
/*  153: 259 */     return getAllParentsOfGivenType(new Id(objectId), parentObjectType, honorPrimaryAssociation);
/*  154:     */   }
/*  155:     */   
/*  156:     */   public List<IAssociationNode> getAllParentsOfGivenType(Id objectId, String parentObjectType, boolean honorPrimaryAssociation)
/*  157:     */     throws Exception
/*  158:     */   {
/*  159: 279 */     IGRCObject grcObject = null;
/*  160: 280 */     IServiceFactory serviceFactory = null;
/*  161: 281 */     GRCObjectFilter objectFilters = null;
/*  162: 282 */     IMetaDataService metadataService = null;
/*  163: 283 */     IConfigurationService configService = null;
/*  164: 284 */     AssociationFilter associationFilter = null;
/*  165: 285 */     List<IAssociationNode> parentAssociations = null;
/*  166:     */     
/*  167: 287 */     serviceFactory = this.serviceFactoryProxy.getServiceFactory();
/*  168: 288 */     metadataService = serviceFactory.createMetaDataService();
/*  169: 289 */     configService = serviceFactory.createConfigurationService();
/*  170:     */     
/*  171: 291 */     objectFilters = new GRCObjectFilter(configService.getCurrentReportingPeriod());
/*  172: 292 */     associationFilter = objectFilters.getAssociationFilter();
/*  173:     */     
/*  174:     */ 
/*  175: 295 */     associationFilter.setIncludeAssociations(IncludeAssociations.PARENT);
/*  176: 296 */     associationFilter.setTypeFilters(new ITypeDefinition[] { metadataService.getType(parentObjectType) });
/*  177:     */     
/*  178: 298 */     grcObject = this.objectUtil.getObjectFromId(objectId, objectFilters);
/*  179: 299 */     parentAssociations = grcObject.getParents();
/*  180:     */     
/*  181: 301 */     return parentAssociations;
/*  182:     */   }
/*  183:     */   
/*  184:     */   public List<String> getAllChildObjectIdsOfGivenObject(IGRCObject object, String childObjectTypeName, boolean honorPrimaryAssociation)
/*  185:     */     throws Exception
/*  186:     */   {
/*  187: 322 */     StringBuilder queryString = null;
/*  188:     */     
/*  189: 324 */     queryString = getBaseQueryForSingleChildAssociation(object.getType().getName(), childObjectTypeName);
/*  190: 325 */     queryString.append("].[Resource ID] = '");
/*  191: 326 */     queryString.append(object.getId());
/*  192: 327 */     queryString.append("'");
/*  193:     */     
/*  194: 329 */     this.logger.debug("Created Query: " + queryString.toString());
/*  195: 330 */     List<String> childObjectIds = getMultipleValuesFromQueryAsList(queryString.toString(), honorPrimaryAssociation);
/*  196:     */     
/*  197: 332 */     this.logger.debug("Child Object Id's List: " + childObjectIds);
/*  198:     */     
/*  199: 334 */     return childObjectIds;
/*  200:     */   }
/*  201:     */   
/*  202:     */   public List<String> getAllChildObjectIdsOfGivenObject(IGRCObject object, List<String> childObjectHeirarchyPath, boolean honorPrimaryAssociation)
/*  203:     */     throws Exception
/*  204:     */   {
/*  205: 355 */     StringBuilder queryString = null;
/*  206:     */     
/*  207: 357 */     queryString = getBaseQueryForChildAssociation(childObjectHeirarchyPath);
/*  208: 358 */     queryString.append("].[Resource ID] = '");
/*  209: 359 */     queryString.append(object.getId());
/*  210: 360 */     queryString.append("'");
/*  211:     */     
/*  212: 362 */     this.logger.debug("Created Query: " + queryString.toString());
/*  213: 363 */     List<String> childObjectIds = getMultipleValuesFromQueryAsList(queryString.toString(), honorPrimaryAssociation);
/*  214:     */     
/*  215: 365 */     this.logger.debug("Child Object Id's List: " + childObjectIds);
/*  216:     */     
/*  217: 367 */     return childObjectIds;
/*  218:     */   }
/*  219:     */   
/*  220:     */   public String getFieldValueFromObjectBasedOnId(String objectId, String objectType, String fieldInfo)
/*  221:     */     throws Exception
/*  222:     */   {
/*  223: 386 */     StringBuilder queryString = null;
/*  224:     */     
/*  225: 388 */     queryString = new StringBuilder();
/*  226:     */     
/*  227: 390 */     queryString.append("SELECT [");
/*  228: 391 */     queryString.append(objectType);
/*  229: 392 */     queryString.append("].[");
/*  230: 393 */     queryString.append(fieldInfo);
/*  231: 394 */     queryString.append("] FROM [");
/*  232: 395 */     queryString.append(objectType);
/*  233: 396 */     queryString.append("] WHERE [");
/*  234: 397 */     queryString.append(objectType);
/*  235: 398 */     queryString.append("].[Resource ID] =");
/*  236: 399 */     queryString.append(objectId);
/*  237:     */     
/*  238: 401 */     this.logger.debug("Created Query: " + queryString.toString());
/*  239: 402 */     String fieldValue = getSingleValueFromQuery(queryString.toString());
/*  240: 403 */     this.logger.debug("Created Query: " + fieldValue);
/*  241:     */     
/*  242: 405 */     return fieldValue;
/*  243:     */   }
/*  244:     */   
/*  245:     */   public ITabularResultSet getFieldValuesFromObjectBasedOnId(String objectId, String objectType, List<String> fieldInfoList)
/*  246:     */     throws Exception
/*  247:     */   {
/*  248: 424 */     StringBuilder queryString = null;
/*  249:     */     
/*  250: 426 */     queryString = new StringBuilder();
/*  251: 428 */     if (CommonUtil.isListNotNullOrEmpty(fieldInfoList))
/*  252:     */     {
/*  253: 430 */       queryString = getBaseQueryToGetFieldValues(objectType, fieldInfoList);
/*  254: 431 */       queryString.append(objectType);
/*  255: 432 */       queryString.append("].[Resource ID] =");
/*  256: 433 */       queryString.append(objectId);
/*  257:     */     }
/*  258: 436 */     this.logger.debug("Created Query: " + queryString.toString());
/*  259:     */     
/*  260: 438 */     return executeQuery(queryString.toString());
/*  261:     */   }
/*  262:     */   
/*  263:     */   public ITabularResultSet getFieldValuesFromObjectBasedOnLocation(String objectLocation, String objectType, List<String> fieldInfoList, boolean isLike)
/*  264:     */     throws Exception
/*  265:     */   {
/*  266: 457 */     StringBuilder queryString = null;
/*  267:     */     
/*  268: 459 */     queryString = new StringBuilder();
/*  269: 461 */     if (CommonUtil.isListNotNullOrEmpty(fieldInfoList))
/*  270:     */     {
/*  271: 463 */       queryString = getBaseQueryToGetFieldValues(objectType, fieldInfoList);
/*  272: 464 */       queryString.append(objectType);
/*  273: 466 */       if (isLike) {
/*  274: 467 */         queryString.append("].[Location] LIKE '");
/*  275:     */       } else {
/*  276: 469 */         queryString.append("].[Location] = '");
/*  277:     */       }
/*  278: 472 */       queryString.append(objectLocation);
/*  279: 473 */       queryString.append("'");
/*  280:     */     }
/*  281: 476 */     this.logger.debug("Created Query: " + queryString.toString());
/*  282:     */     
/*  283: 478 */     return executeQuery(queryString.toString());
/*  284:     */   }
/*  285:     */   
/*  286:     */   public String getSingleValueFromQuery(String queryString)
/*  287:     */     throws Exception
/*  288:     */   {
/*  289: 495 */     String singleValue = "";
/*  290: 496 */     ITabularResultSet resultset = executeQuery(queryString);
/*  291: 498 */     for (IResultSetRow row : resultset) {
/*  292: 500 */       for (IField field : row) {
/*  293: 502 */         singleValue = this.fieldUtil.getFieldValueAsString(field);
/*  294:     */       }
/*  295:     */     }
/*  296: 506 */     return singleValue;
/*  297:     */   }
/*  298:     */   
/*  299:     */   public String getSingleValueFromQuery(String queryString, boolean honorPrimaryAssociation)
/*  300:     */     throws Exception
/*  301:     */   {
/*  302: 524 */     String singleValue = "";
/*  303: 525 */     ITabularResultSet resultset = executeQuery(queryString, honorPrimaryAssociation);
/*  304: 527 */     for (IResultSetRow row : resultset) {
/*  305: 529 */       for (IField field : row) {
/*  306: 531 */         singleValue = this.fieldUtil.getFieldValueAsString(field);
/*  307:     */       }
/*  308:     */     }
/*  309: 535 */     return singleValue;
/*  310:     */   }
/*  311:     */   
/*  312:     */   public List<String> getMultipleValuesFromQueryAsList(String queryString, boolean honorPrimaryAssociation)
/*  313:     */     throws Exception
/*  314:     */   {
/*  315: 554 */     List<String> returnValueList = null;
/*  316: 555 */     ITabularResultSet resultset = executeQuery(queryString, honorPrimaryAssociation);
/*  317: 556 */     int count = 0;
/*  318:     */     
/*  319: 558 */     returnValueList = new ArrayList();
/*  320: 559 */     this.loggerUtil.getExtLogger().debug("Is Result not null: " + (resultset != null));
/*  321: 561 */     for (IResultSetRow row : resultset)
/*  322:     */     {
/*  323: 563 */       this.loggerUtil.getExtLogger().debug("Entering iterator");
/*  324: 565 */       for (IField field : row)
/*  325:     */       {
/*  326: 567 */         this.loggerUtil.getExtLogger().debug("Field Data type: " + field.getDataType().toString());
/*  327: 568 */         this.loggerUtil.getExtLogger().debug("Field Value returned: " + this.fieldUtil.getFieldValueAsString(field));
/*  328: 569 */         returnValueList.add(this.fieldUtil.getFieldValueAsString(field));
/*  329:     */       }
/*  330: 572 */       count++;
/*  331:     */     }
/*  332: 575 */     this.loggerUtil.getExtLogger().debug("Return values: " + returnValueList);
/*  333: 576 */     this.loggerUtil.getExtLogger().debug("Total number of rows returned: " + count);
/*  334: 577 */     return returnValueList;
/*  335:     */   }
/*  336:     */   
/*  337:     */   public StringBuilder appendResourceIdWhereClauseToQuery(String queryString, IGRCObject object)
/*  338:     */     throws Exception
/*  339:     */   {
/*  340: 594 */     return CommonUtil.isObjectNotNull(object) ? appendResourceIdWhereClauseToQuery(queryString, object.getId().toString()) : new StringBuilder();
/*  341:     */   }
/*  342:     */   
/*  343:     */   public StringBuilder appendResourceIdWhereClauseToQuery(String queryString, String objectId)
/*  344:     */     throws Exception
/*  345:     */   {
/*  346: 611 */     StringBuilder resourceIdWhereClauseQuery = null;
/*  347:     */     
/*  348: 613 */     resourceIdWhereClauseQuery = new StringBuilder();
/*  349: 614 */     resourceIdWhereClauseQuery.append(queryString.toString());
/*  350: 615 */     resourceIdWhereClauseQuery.append("[Resource ID] = '");
/*  351: 616 */     resourceIdWhereClauseQuery.append(objectId);
/*  352: 617 */     resourceIdWhereClauseQuery.append("'");
/*  353:     */     
/*  354: 619 */     return resourceIdWhereClauseQuery;
/*  355:     */   }
/*  356:     */   
/*  357:     */   public StringBuilder appendFieldsToWhereClauseInQuery(String queryString, IGRCFieldInformationForQuery fieldInformationForQuery)
/*  358:     */     throws Exception
/*  359:     */   {
/*  360: 638 */     int count = 0;
/*  361: 639 */     String objectType = "";
/*  362: 640 */     StringBuilder matchingValuesQuery = null;
/*  363:     */     
/*  364: 642 */     matchingValuesQuery = new StringBuilder();
/*  365:     */     
/*  366: 644 */     matchingValuesQuery = fieldInformationForQuery.isIncludeResourceId() ? appendResourceIdWhereClauseToQuery(queryString, fieldInformationForQuery.getSourceObject()) : matchingValuesQuery.append(queryString);
/*  367:     */     
/*  368:     */ 
/*  369: 647 */     objectType = fieldInformationForQuery.isQueryOnSameObjectType() ? fieldInformationForQuery.getSourceObject().getType().toString() : fieldInformationForQuery.getObjectTypeForQuery();
/*  370: 650 */     for (String fieldName : fieldInformationForQuery.getFieldsList())
/*  371:     */     {
/*  372: 652 */       matchingValuesQuery.append(" AND ");
/*  373: 653 */       matchingValuesQuery.append("[");
/*  374: 654 */       matchingValuesQuery.append(objectType);
/*  375: 655 */       matchingValuesQuery.append("].[");
/*  376: 656 */       matchingValuesQuery.append(fieldName);
/*  377: 657 */       matchingValuesQuery.append("] = '");
/*  378: 658 */       matchingValuesQuery.append((String)fieldInformationForQuery.getFieldValuesList().get(count));
/*  379: 659 */       matchingValuesQuery.append("'");
/*  380:     */       
/*  381: 661 */       count++;
/*  382:     */     }
/*  383: 664 */     return matchingValuesQuery;
/*  384:     */   }
/*  385:     */   
/*  386:     */   public StringBuilder getBaseQueryForMultipleParentAssociation(List<String> objectHeirarchyList)
/*  387:     */     throws Exception
/*  388:     */   {
/*  389: 681 */     int count = 0;
/*  390: 682 */     String parentObjectType = "";
/*  391: 683 */     StringBuilder queryString = null;
/*  392: 685 */     if (CommonUtil.isListNotNullOrEmpty(objectHeirarchyList))
/*  393:     */     {
/*  394: 687 */       parentObjectType = (String)objectHeirarchyList.get(0);
/*  395: 688 */       queryString = new StringBuilder();
/*  396: 689 */       queryString.append("SELECT [");
/*  397: 690 */       queryString.append(parentObjectType);
/*  398: 691 */       queryString.append("].[Resource ID] FROM [");
/*  399: 692 */       queryString.append(parentObjectType);
/*  400: 693 */       queryString.append("] ");
/*  401: 695 */       for (String childObjectTypeName : objectHeirarchyList)
/*  402:     */       {
/*  403: 697 */         if (count != 0)
/*  404:     */         {
/*  405: 699 */           queryString.append("JOIN [");
/*  406: 700 */           queryString.append(childObjectTypeName);
/*  407: 701 */           queryString.append("] ON PARENT([");
/*  408: 702 */           queryString.append(parentObjectType);
/*  409: 703 */           queryString.append("]) ");
/*  410:     */           
/*  411: 705 */           parentObjectType = childObjectTypeName;
/*  412:     */         }
/*  413: 707 */         count++;
/*  414:     */       }
/*  415:     */     }
/*  416: 711 */     queryString.append("WHERE [");
/*  417: 712 */     queryString.append(parentObjectType);
/*  418: 713 */     queryString.append("].");
/*  419:     */     
/*  420: 715 */     return queryString;
/*  421:     */   }
/*  422:     */   
/*  423:     */   public StringBuilder getQueryForMultipleParentAssociation(List<String> fieldInfoList, List<String> objectHeirarchyList)
/*  424:     */     throws Exception
/*  425:     */   {
/*  426: 732 */     int count = 0;
/*  427: 733 */     String parentObjectType = "";
/*  428: 734 */     StringBuilder queryString = null;
/*  429: 736 */     if ((CommonUtil.isListNotNullOrEmpty(fieldInfoList)) && (CommonUtil.isListNotNullOrEmpty(objectHeirarchyList)))
/*  430:     */     {
/*  431: 738 */       parentObjectType = (String)objectHeirarchyList.get(0);
/*  432: 739 */       queryString = new StringBuilder();
/*  433: 740 */       queryString.append("SELECT");
/*  434: 742 */       for (String fieldInfo : fieldInfoList)
/*  435:     */       {
/*  436: 744 */         queryString.append(" [");
/*  437: 745 */         queryString.append(parentObjectType);
/*  438: 746 */         queryString.append("].[");
/*  439: 747 */         queryString.append(fieldInfo);
/*  440: 748 */         queryString.append("]");
/*  441: 750 */         if (count != fieldInfoList.size() - 1) {
/*  442: 751 */           queryString.append(",");
/*  443:     */         }
/*  444: 753 */         count++;
/*  445:     */       }
/*  446: 756 */       count = 0;
/*  447: 757 */       queryString.append(" FROM [");
/*  448: 758 */       queryString.append(parentObjectType);
/*  449: 759 */       queryString.append("] ");
/*  450: 761 */       for (String childObjectTypeName : objectHeirarchyList)
/*  451:     */       {
/*  452: 763 */         if (count != 0)
/*  453:     */         {
/*  454: 765 */           queryString.append("JOIN [");
/*  455: 766 */           queryString.append(childObjectTypeName);
/*  456: 767 */           queryString.append("] ON PARENT([");
/*  457: 768 */           queryString.append(parentObjectType);
/*  458: 769 */           queryString.append("]) ");
/*  459:     */           
/*  460: 771 */           parentObjectType = childObjectTypeName;
/*  461:     */         }
/*  462: 773 */         count++;
/*  463:     */       }
/*  464:     */     }
/*  465: 777 */     queryString.append("WHERE [");
/*  466: 778 */     queryString.append(parentObjectType);
/*  467: 779 */     queryString.append("].");
/*  468:     */     
/*  469: 781 */     return queryString;
/*  470:     */   }
/*  471:     */   
/*  472:     */   public StringBuilder getBaseQueryForMultipleChildAssociation(List<String> objectHeirarchyList)
/*  473:     */     throws Exception
/*  474:     */   {
/*  475: 798 */     int count = 0;
/*  476: 799 */     String childObjectType = "";
/*  477: 800 */     StringBuilder queryString = null;
/*  478: 802 */     if (CommonUtil.isListNotNullOrEmpty(objectHeirarchyList))
/*  479:     */     {
/*  480: 804 */       childObjectType = (String)objectHeirarchyList.get(0);
/*  481: 805 */       queryString = new StringBuilder();
/*  482: 806 */       queryString.append("SELECT [");
/*  483: 807 */       queryString.append(childObjectType);
/*  484: 808 */       queryString.append("].[Resource ID] FROM [");
/*  485: 809 */       queryString.append(childObjectType);
/*  486: 810 */       queryString.append("] ");
/*  487: 812 */       for (String childObjectTypeName : objectHeirarchyList)
/*  488:     */       {
/*  489: 814 */         if (count != 0)
/*  490:     */         {
/*  491: 816 */           queryString.append("JOIN [");
/*  492: 817 */           queryString.append(childObjectTypeName);
/*  493: 818 */           queryString.append("] ON CHILD([");
/*  494: 819 */           queryString.append(childObjectType);
/*  495: 820 */           queryString.append("]) ");
/*  496:     */           
/*  497: 822 */           childObjectType = childObjectTypeName;
/*  498:     */         }
/*  499: 824 */         count++;
/*  500:     */       }
/*  501:     */     }
/*  502: 828 */     queryString.append("WHERE [");
/*  503: 829 */     queryString.append(childObjectType);
/*  504: 830 */     queryString.append("].");
/*  505:     */     
/*  506: 832 */     return queryString;
/*  507:     */   }
/*  508:     */   
/*  509:     */   private StringBuilder getBaseQueryForSingleChildAssociation(String parentObjectTypeName, String childObjectTypeName)
/*  510:     */     throws Exception
/*  511:     */   {
/*  512: 850 */     boolean isRecursiveType = false;
/*  513: 851 */     StringBuilder queryString = null;
/*  514: 853 */     if (CommonUtil.isNotNullOrEmpty(childObjectTypeName))
/*  515:     */     {
/*  516: 855 */       this.logger.debug("Parent Oject Name: " + parentObjectTypeName);
/*  517: 856 */       this.logger.debug("Child Oject Name: " + childObjectTypeName);
/*  518: 857 */       this.logger.debug("Are they equal: " + CommonUtil.isEqualIgnoreCase(parentObjectTypeName, childObjectTypeName));
/*  519:     */       
/*  520: 859 */       isRecursiveType = CommonUtil.isEqualIgnoreCase(parentObjectTypeName, childObjectTypeName);
/*  521:     */       
/*  522:     */ 
/*  523:     */ 
/*  524:     */ 
/*  525: 864 */       this.logger.debug("Child Oject Name After check: " + childObjectTypeName);
/*  526: 866 */       if (CommonUtil.isEqualIgnoreCase(parentObjectTypeName, childObjectTypeName)) {
/*  527: 867 */         childObjectTypeName = "CHILD_OBJ";
/*  528:     */       }
/*  529: 869 */       this.logger.debug("Child Oject Name After check: " + childObjectTypeName);
/*  530: 870 */       queryString = new StringBuilder();
/*  531: 871 */       queryString.append("SELECT [");
/*  532: 872 */       queryString.append(childObjectTypeName);
/*  533: 873 */       queryString.append("].[Resource ID] FROM [");
/*  534: 875 */       if (isRecursiveType)
/*  535:     */       {
/*  536: 877 */         queryString.append(parentObjectTypeName);
/*  537: 878 */         queryString.append("] ");
/*  538: 879 */         queryString.append("JOIN [");
/*  539: 880 */         queryString.append(parentObjectTypeName);
/*  540: 881 */         queryString.append("] AS [CHILD_OBJ] ON PARENT([");
/*  541: 882 */         queryString.append(parentObjectTypeName);
/*  542: 883 */         queryString.append("] , 1)");
/*  543:     */       }
/*  544:     */       else
/*  545:     */       {
/*  546: 886 */         queryString.append(childObjectTypeName);
/*  547: 887 */         queryString.append("] ");
/*  548: 888 */         queryString.append("JOIN [");
/*  549: 889 */         queryString.append(parentObjectTypeName);
/*  550: 890 */         queryString.append("] ON CHILD([");
/*  551: 891 */         queryString.append(childObjectTypeName);
/*  552: 892 */         queryString.append("]) ");
/*  553:     */       }
/*  554:     */     }
/*  555: 896 */     queryString.append("WHERE [");
/*  556: 897 */     queryString.append(parentObjectTypeName);
/*  557:     */     
/*  558: 899 */     return queryString;
/*  559:     */   }
/*  560:     */   
/*  561:     */   private StringBuilder getBaseQueryForParentAssociation(List<String> objectHeirarchyList)
/*  562:     */     throws Exception
/*  563:     */   {
/*  564: 915 */     int count = 0;
/*  565: 916 */     String childObjectType = "";
/*  566: 917 */     String parentObjectType = "";
/*  567: 918 */     StringBuilder queryString = null;
/*  568: 920 */     if (CommonUtil.isListNotNullOrEmpty(objectHeirarchyList))
/*  569:     */     {
/*  570: 922 */       parentObjectType = (String)objectHeirarchyList.get(0);
/*  571: 923 */       queryString = new StringBuilder();
/*  572: 924 */       queryString.append("SELECT [");
/*  573: 925 */       queryString.append(parentObjectType);
/*  574: 926 */       queryString.append("].[Resource ID] FROM [");
/*  575: 927 */       queryString.append(parentObjectType);
/*  576: 928 */       queryString.append("] ");
/*  577: 930 */       for (String childObjectTypeName : objectHeirarchyList)
/*  578:     */       {
/*  579: 932 */         if (count != 0)
/*  580:     */         {
/*  581: 934 */           queryString.append("JOIN [");
/*  582: 935 */           queryString.append(childObjectTypeName);
/*  583: 936 */           queryString.append("] ON PARENT([");
/*  584: 937 */           queryString.append(parentObjectType);
/*  585: 938 */           queryString.append("]) ");
/*  586:     */           
/*  587: 940 */           parentObjectType = childObjectTypeName;
/*  588: 941 */           childObjectType = childObjectTypeName;
/*  589:     */         }
/*  590: 943 */         count++;
/*  591:     */       }
/*  592:     */     }
/*  593: 947 */     queryString.append("WHERE [");
/*  594: 948 */     queryString.append(childObjectType);
/*  595:     */     
/*  596: 950 */     return queryString;
/*  597:     */   }
/*  598:     */   
/*  599:     */   private StringBuilder getBaseQueryForChildAssociation(List<String> objectHeirarchyList)
/*  600:     */     throws Exception
/*  601:     */   {
/*  602: 966 */     int count = 0;
/*  603: 967 */     String childObjectType = "";
/*  604: 968 */     String parentObjectType = "";
/*  605: 969 */     StringBuilder queryString = null;
/*  606: 971 */     if (CommonUtil.isListNotNullOrEmpty(objectHeirarchyList))
/*  607:     */     {
/*  608: 973 */       parentObjectType = (String)objectHeirarchyList.get(0);
/*  609: 974 */       queryString = new StringBuilder();
/*  610: 975 */       queryString.append("SELECT [");
/*  611: 976 */       queryString.append(parentObjectType);
/*  612: 977 */       queryString.append("].[Resource ID] FROM [");
/*  613: 978 */       queryString.append(parentObjectType);
/*  614: 979 */       queryString.append("] ");
/*  615: 981 */       for (String childObjectTypeName : objectHeirarchyList)
/*  616:     */       {
/*  617: 983 */         if (count != 0)
/*  618:     */         {
/*  619: 985 */           queryString.append("JOIN [");
/*  620: 986 */           queryString.append(childObjectTypeName);
/*  621: 987 */           queryString.append("] ON CHILD([");
/*  622: 988 */           queryString.append(parentObjectType);
/*  623: 989 */           queryString.append("]) ");
/*  624:     */           
/*  625: 991 */           parentObjectType = childObjectTypeName;
/*  626: 992 */           childObjectType = childObjectTypeName;
/*  627:     */         }
/*  628: 994 */         count++;
/*  629:     */       }
/*  630:     */     }
/*  631: 998 */     queryString.append("WHERE [");
/*  632: 999 */     queryString.append(childObjectType);
/*  633:     */     
/*  634:1001 */     return queryString;
/*  635:     */   }
/*  636:     */   
/*  637:     */   private StringBuilder getBaseQueryToGetFieldValues(String objectType, List<String> fieldInfoList)
/*  638:     */     throws Exception
/*  639:     */   {
/*  640:1019 */     int count = 1;
/*  641:1020 */     StringBuilder queryString = null;
/*  642:     */     
/*  643:1022 */     queryString = new StringBuilder();
/*  644:1024 */     if (CommonUtil.isListNotNullOrEmpty(fieldInfoList))
/*  645:     */     {
/*  646:1026 */       queryString.append("SELECT [");
/*  647:1028 */       for (String fieldInfo : fieldInfoList)
/*  648:     */       {
/*  649:1030 */         queryString.append(objectType);
/*  650:1031 */         queryString.append("].[");
/*  651:     */         
/*  652:1033 */         fieldInfo = fieldInfo.indexOf("System Fields:") != -1 ? fieldInfo.replace("System Fields:", "") : fieldInfo;
/*  653:     */         
/*  654:1035 */         queryString.append(fieldInfo);
/*  655:1037 */         if (count == fieldInfoList.size()) {
/*  656:1038 */           queryString.append("] ");
/*  657:     */         } else {
/*  658:1040 */           queryString.append("], [");
/*  659:     */         }
/*  660:1042 */         count++;
/*  661:     */       }
/*  662:1045 */       queryString.append("FROM [");
/*  663:1046 */       queryString.append(objectType);
/*  664:1047 */       queryString.append("] WHERE [");
/*  665:     */     }
/*  666:1050 */     return queryString;
/*  667:     */   }
/*  668:     */   
/*  669:     */   public IGRCObject getObjectFromNameAndPath(String objectType, String objectName, String objectLocation, boolean honorPrimaryAssociation)
/*  670:     */     throws Exception
/*  671:     */   {
/*  672:1071 */     IGRCObject object = null;
/*  673:1072 */     StringBuilder queryString = null;
/*  674:1073 */     IServiceFactory serviceFactory = this.serviceFactoryProxy.getServiceFactory();
/*  675:     */     
/*  676:1075 */     queryString = new StringBuilder();
/*  677:1076 */     queryString.append("SELECT [");
/*  678:1077 */     queryString.append(objectType);
/*  679:1078 */     queryString.append("].[Resource ID] FROM [");
/*  680:1079 */     queryString.append(objectType);
/*  681:1080 */     queryString.append("] ");
/*  682:1081 */     queryString.append("WHERE [");
/*  683:1082 */     queryString.append(objectType);
/*  684:1083 */     queryString.append("].[");
/*  685:1084 */     queryString.append("Name");
/*  686:1085 */     queryString.append("] = '");
/*  687:1086 */     queryString.append(objectName);
/*  688:1087 */     queryString.append("' AND [");
/*  689:1088 */     queryString.append(objectType);
/*  690:1089 */     queryString.append("].[");
/*  691:1090 */     queryString.append("Location");
/*  692:1091 */     queryString.append("] = '");
/*  693:1092 */     queryString.append(objectLocation);
/*  694:1093 */     queryString.append("'");
/*  695:     */     
/*  696:1095 */     this.logger.debug("Created Query: " + queryString.toString());
/*  697:1096 */     String entityId = getSingleValueFromQuery(queryString.toString(), honorPrimaryAssociation);
/*  698:     */     
/*  699:1098 */     this.logger.debug("parent entity id not null and numeric: " + NumericUtil.isNumeric(entityId));
/*  700:1099 */     if (NumericUtil.isNumeric(entityId)) {
/*  701:1101 */       object = serviceFactory.createResourceService().getGRCObject(new Id(entityId));
/*  702:     */     }
/*  703:1104 */     return object;
/*  704:     */   }
/*  705:     */   
/*  706:     */   public List<IGRCObject> getImmediateParentsFromId(String objectId, List<String> objectHeirarchyList)
/*  707:     */     throws Exception
/*  708:     */   {
/*  709:1110 */     StringBuilder queryString = null;
/*  710:1111 */     IGRCObject parentBusEntity = null;
/*  711:1112 */     List<IGRCObject> entities = new ArrayList();
/*  712:1113 */     IServiceFactory serviceFactory = this.serviceFactoryProxy.getServiceFactory();
/*  713:     */     
/*  714:1115 */     List<String> objectHierarchies = null;
/*  715:1116 */     List<String> parents = null;
/*  716:1117 */     for (String objectHierarchy : objectHeirarchyList)
/*  717:     */     {
/*  718:1118 */       objectHierarchies = CommonUtil.parseDelimitedValues(objectHierarchy, ":");
/*  719:     */       
/*  720:1120 */       objectHierarchy.split(":[\\s]*");
/*  721:1121 */       queryString = getBaseQueryForParentAssociation(objectHierarchies);
/*  722:1122 */       queryString.append("].[Resource ID] = '");
/*  723:1123 */       queryString.append(objectId);
/*  724:1124 */       queryString.append("'");
/*  725:     */       
/*  726:1126 */       this.logger.debug("Created Query: " + queryString.toString());
/*  727:1127 */       parents = getMultipleValuesFromQueryAsList(queryString.toString(), false);
/*  728:1129 */       for (String parent : parents)
/*  729:     */       {
/*  730:1130 */         this.logger.debug("parent resource id not null and numeric: " + NumericUtil.isNumeric(parent));
/*  731:1131 */         if (NumericUtil.isNumeric(parent))
/*  732:     */         {
/*  733:1133 */           parentBusEntity = serviceFactory.createResourceService().getGRCObject(new Id(parent));
/*  734:1134 */           entities.add(parentBusEntity);
/*  735:     */         }
/*  736:     */       }
/*  737:     */     }
/*  738:1139 */     return entities;
/*  739:     */   }
/*  740:     */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.impl.GRCObjectSearchUtil
 * JD-Core Version:    0.7.0.1
 */