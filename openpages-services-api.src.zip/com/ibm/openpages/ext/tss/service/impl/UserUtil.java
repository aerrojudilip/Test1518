/*    1:     */ package com.ibm.openpages.ext.tss.service.impl;
/*    2:     */ 
/*    3:     */ import com.ibm.openpages.api.metadata.Id;
/*    4:     */ import com.ibm.openpages.api.resource.IGRCObject;
/*    5:     */ import com.ibm.openpages.api.security.IGroup;
/*    6:     */ import com.ibm.openpages.api.security.IRoleAssignment;
/*    7:     */ import com.ibm.openpages.api.security.IUser;
/*    8:     */ import com.ibm.openpages.api.service.ISecurityService;
/*    9:     */ import com.ibm.openpages.api.service.IServiceFactory;
/*   10:     */ import com.ibm.openpages.ext.tss.service.IFieldUtil;
/*   11:     */ import com.ibm.openpages.ext.tss.service.ILoggerUtil;
/*   12:     */ import com.ibm.openpages.ext.tss.service.IUserUtil;
/*   13:     */ import com.ibm.openpages.ext.tss.service.constants.CheckFor;
/*   14:     */ import com.ibm.openpages.ext.tss.service.proxy.IServiceFactoryProxy;
/*   15:     */ import com.ibm.openpages.ext.tss.service.util.CommonUtil;
/*   16:     */ import java.util.ArrayList;
/*   17:     */ import java.util.Iterator;
/*   18:     */ import java.util.List;
/*   19:     */ import javax.annotation.PostConstruct;
/*   20:     */ import org.apache.commons.logging.Log;
/*   21:     */ import org.springframework.beans.factory.annotation.Autowired;
/*   22:     */ import org.springframework.stereotype.Service;
/*   23:     */ 
/*   24:     */ @Service("userUtil")
/*   25:     */ public class UserUtil
/*   26:     */   implements IUserUtil
/*   27:     */ {
/*   28:     */   private Log logger;
/*   29:     */   @Autowired
/*   30:     */   ILoggerUtil loggerUtil;
/*   31:     */   @Autowired
/*   32:     */   IServiceFactoryProxy serviceFactoryProxy;
/*   33:     */   @Autowired
/*   34:     */   IFieldUtil fieldUtil;
/*   35:     */   
/*   36:     */   @PostConstruct
/*   37:     */   public void initService()
/*   38:     */   {
/*   39:  80 */     this.logger = this.loggerUtil.getExtLogger();
/*   40:     */   }
/*   41:     */   
/*   42:     */   public IUser getLoggedInUser()
/*   43:     */     throws Exception
/*   44:     */   {
/*   45:  97 */     IServiceFactory sf = this.serviceFactoryProxy.getServiceFactory();
/*   46:  98 */     IUser loggedInUser = sf.createSecurityService().getCurrentUser();
/*   47:     */     
/*   48: 100 */     return loggedInUser;
/*   49:     */   }
/*   50:     */   
/*   51:     */   public String getLoggedInUserName()
/*   52:     */     throws Exception
/*   53:     */   {
/*   54: 115 */     return getLoggedInUser().getName();
/*   55:     */   }
/*   56:     */   
/*   57:     */   public Id getLoggedInUserId()
/*   58:     */     throws Exception
/*   59:     */   {
/*   60: 131 */     return getLoggedInUser().getId();
/*   61:     */   }
/*   62:     */   
/*   63:     */   public String getUserIdAsString()
/*   64:     */     throws Exception
/*   65:     */   {
/*   66: 146 */     return getLoggedInUser().getId().toString();
/*   67:     */   }
/*   68:     */   
/*   69:     */   public String getLoggedInUsersFirstName()
/*   70:     */     throws Exception
/*   71:     */   {
/*   72: 161 */     return getLoggedInUser().getFirstName();
/*   73:     */   }
/*   74:     */   
/*   75:     */   public String getLoggedInUsersLastName()
/*   76:     */     throws Exception
/*   77:     */   {
/*   78: 176 */     return getLoggedInUser().getLastName();
/*   79:     */   }
/*   80:     */   
/*   81:     */   public String getLoggedInUsersMiddleName()
/*   82:     */     throws Exception
/*   83:     */   {
/*   84: 191 */     return getLoggedInUser().getLastName();
/*   85:     */   }
/*   86:     */   
/*   87:     */   public String getLoggedInUsersFulleName()
/*   88:     */     throws Exception
/*   89:     */   {
/*   90: 207 */     IUser user = getLoggedInUser();
/*   91:     */     
/*   92: 209 */     return user.getFirstName() + user.getMiddleName() + user.getLastName();
/*   93:     */   }
/*   94:     */   
/*   95:     */   public String getLoggedInUsersEmailAddress()
/*   96:     */     throws Exception
/*   97:     */   {
/*   98: 224 */     return getLoggedInUser().getEmailAddress();
/*   99:     */   }
/*  100:     */   
/*  101:     */   public IUser getUser(Id userId)
/*  102:     */     throws Exception
/*  103:     */   {
/*  104: 243 */     ISecurityService securityService = this.serviceFactoryProxy.getServiceFactory().createSecurityService();
/*  105:     */     
/*  106: 245 */     return securityService.getUser(userId);
/*  107:     */   }
/*  108:     */   
/*  109:     */   public List<IUser> getUsersListFromUserNameList(List<String> userNamesList)
/*  110:     */     throws Exception
/*  111:     */   {
/*  112: 265 */     List<IUser> usersList = null;
/*  113: 266 */     IServiceFactory sf = this.serviceFactoryProxy.getServiceFactory();
/*  114: 267 */     ISecurityService secService = sf.createSecurityService();
/*  115:     */     
/*  116: 269 */     usersList = new ArrayList();
/*  117: 271 */     for (String userName : userNamesList) {
/*  118: 274 */       if (CommonUtil.isNotNullOrEmpty(userName)) {
/*  119: 275 */         usersList.add(secService.getUser(userName));
/*  120:     */       }
/*  121:     */     }
/*  122: 278 */     return usersList;
/*  123:     */   }
/*  124:     */   
/*  125:     */   public String getUserName(Id userId)
/*  126:     */     throws Exception
/*  127:     */   {
/*  128: 296 */     return getUser(userId).getName();
/*  129:     */   }
/*  130:     */   
/*  131:     */   public IUser getUser(String userName)
/*  132:     */     throws Exception
/*  133:     */   {
/*  134: 314 */     ISecurityService securityService = this.serviceFactoryProxy.getServiceFactory().createSecurityService();
/*  135:     */     
/*  136: 316 */     return securityService.getUser(userName);
/*  137:     */   }
/*  138:     */   
/*  139:     */   public boolean isLoggedInUserSameUser(String userName)
/*  140:     */     throws Exception
/*  141:     */   {
/*  142: 334 */     return CommonUtil.isEqual(getLoggedInUser().getName(), userName);
/*  143:     */   }
/*  144:     */   
/*  145:     */   public boolean isUserSameAsGivenUser(IUser user1, IUser user2)
/*  146:     */     throws Exception
/*  147:     */   {
/*  148: 356 */     return (CommonUtil.isObjectNotNull(user1)) && (CommonUtil.isObjectNotNull(user2)) && ((CommonUtil.isEqual(user1.getId().toString(), user2.getId().toString())) || (CommonUtil.isEqual(user1.getName().toString(), user2.getName().toString())));
/*  149:     */   }
/*  150:     */   
/*  151:     */   public boolean isUserSameAsGivenUser(IUser user, String userName)
/*  152:     */     throws Exception
/*  153:     */   {
/*  154: 380 */     return (CommonUtil.isNotNullOrEmpty(userName)) && (CommonUtil.isObjectNotNull(user)) && (CommonUtil.isEqual(user.getName(), userName));
/*  155:     */   }
/*  156:     */   
/*  157:     */   public boolean isUserSameAsLoggedInUser(String userName)
/*  158:     */     throws Exception
/*  159:     */   {
/*  160: 400 */     return (CommonUtil.isNotNullOrEmpty(userName)) && (CommonUtil.isObjectNotNull(getLoggedInUserName())) && (CommonUtil.isEqual(getLoggedInUserName(), userName));
/*  161:     */   }
/*  162:     */   
/*  163:     */   public String getUsersFirstName(Id userId)
/*  164:     */     throws Exception
/*  165:     */   {
/*  166: 420 */     return getUser(userId).getFirstName();
/*  167:     */   }
/*  168:     */   
/*  169:     */   public String getUsersFirstName(String userName)
/*  170:     */     throws Exception
/*  171:     */   {
/*  172: 436 */     return getUser(userName).getFirstName();
/*  173:     */   }
/*  174:     */   
/*  175:     */   public String getUsersLastName(Id userId)
/*  176:     */     throws Exception
/*  177:     */   {
/*  178: 454 */     return getUser(userId).getLastName();
/*  179:     */   }
/*  180:     */   
/*  181:     */   public String getUsersLastName(String userName)
/*  182:     */     throws Exception
/*  183:     */   {
/*  184: 473 */     return getUser(userName).getLastName();
/*  185:     */   }
/*  186:     */   
/*  187:     */   public String getUsersMiddleName(Id userId)
/*  188:     */     throws Exception
/*  189:     */   {
/*  190: 491 */     return getUser(userId).getLastName();
/*  191:     */   }
/*  192:     */   
/*  193:     */   public String getUsersMiddleName(String userName)
/*  194:     */     throws Exception
/*  195:     */   {
/*  196: 510 */     return getUser(userName).getLastName();
/*  197:     */   }
/*  198:     */   
/*  199:     */   public String getUsersFullName(Id userId)
/*  200:     */     throws Exception
/*  201:     */   {
/*  202: 529 */     IUser user = getUser(userId);
/*  203:     */     
/*  204: 531 */     return user.getFirstName() + user.getMiddleName() + user.getLastName();
/*  205:     */   }
/*  206:     */   
/*  207:     */   public String getUsersFullName(String userName)
/*  208:     */     throws Exception
/*  209:     */   {
/*  210: 551 */     IUser user = getUser(userName);
/*  211:     */     
/*  212: 553 */     return user.getFirstName() + user.getMiddleName() + user.getLastName();
/*  213:     */   }
/*  214:     */   
/*  215:     */   public String getEmailAddressesOfUser(Id userId)
/*  216:     */     throws Exception
/*  217:     */   {
/*  218: 571 */     return getUser(userId).getEmailAddress();
/*  219:     */   }
/*  220:     */   
/*  221:     */   public String getEmailAddressesOfUser(String userName)
/*  222:     */     throws Exception
/*  223:     */   {
/*  224: 590 */     return getUser(userName).getEmailAddress();
/*  225:     */   }
/*  226:     */   
/*  227:     */   public List<String> getEmailAddressesOfUsers(String userNames)
/*  228:     */     throws Exception
/*  229:     */   {
/*  230: 612 */     return getEmailAddressesOfUsers(CommonUtil.parseDelimitedValues(userNames, ","));
/*  231:     */   }
/*  232:     */   
/*  233:     */   public List<String> getEmailAddressesOfUsers(List<String> userNamesList)
/*  234:     */     throws Exception
/*  235:     */   {
/*  236: 635 */     IUser userObj = null;
/*  237: 636 */     List<String> emailAddressesList = null;
/*  238:     */     
/*  239: 638 */     IServiceFactory sf = this.serviceFactoryProxy.getServiceFactory();
/*  240: 639 */     ISecurityService secService = sf.createSecurityService();
/*  241:     */     
/*  242: 641 */     emailAddressesList = new ArrayList();
/*  243: 643 */     if (CommonUtil.isListNotNullOrEmpty(userNamesList)) {
/*  244: 646 */       for (String user : userNamesList) {
/*  245: 649 */         if (CommonUtil.isNotNullOrEmpty(user))
/*  246:     */         {
/*  247: 652 */           userObj = secService.getUser(user);
/*  248: 653 */           emailAddressesList.add(userObj.getEmailAddress());
/*  249:     */         }
/*  250:     */       }
/*  251:     */     }
/*  252: 658 */     return emailAddressesList;
/*  253:     */   }
/*  254:     */   
/*  255:     */   public List<String> getEmailAddressesOfUsersFromFields(IGRCObject object, List<String> userFieldsInfoList)
/*  256:     */     throws Exception
/*  257:     */   {
/*  258: 684 */     String user = "";
/*  259: 685 */     List<String> usersList = null;
/*  260:     */     
/*  261: 687 */     usersList = new ArrayList();
/*  262: 689 */     if (CommonUtil.isListNotNullOrEmpty(userFieldsInfoList)) {
/*  263: 692 */       for (String userFieldInfo : userFieldsInfoList) {
/*  264: 695 */         if (CommonUtil.isNotNullOrEmpty(userFieldInfo))
/*  265:     */         {
/*  266: 698 */           user = this.fieldUtil.getFieldValueAsString(object, userFieldInfo);
/*  267: 700 */           if (CommonUtil.isNotNullOrEmpty(user)) {}
/*  268: 702 */           usersList.add(user);
/*  269:     */         }
/*  270:     */       }
/*  271:     */     }
/*  272: 707 */     return getEmailAddressesOfUsers(usersList);
/*  273:     */   }
/*  274:     */   
/*  275:     */   public Iterator<IRoleAssignment> getRoleAssignmentsForLoggedInUser()
/*  276:     */     throws Exception
/*  277:     */   {
/*  278: 725 */     return getLoggedInUser().getRoleAssignments();
/*  279:     */   }
/*  280:     */   
/*  281:     */   public Iterator<IRoleAssignment> getRoleAssignmentsForUser(Id userId)
/*  282:     */     throws Exception
/*  283:     */   {
/*  284: 746 */     return getUser(userId).getRoleAssignments();
/*  285:     */   }
/*  286:     */   
/*  287:     */   public Iterator<IRoleAssignment> getRoleAssignmentsForUser(String userName)
/*  288:     */     throws Exception
/*  289:     */   {
/*  290: 767 */     return getUser(userName).getRoleAssignments();
/*  291:     */   }
/*  292:     */   
/*  293:     */   public boolean isLoggedInUserHasRoleAssignments(Iterator<IRoleAssignment> preferedRoleAssignments, CheckFor checkFor)
/*  294:     */     throws Exception
/*  295:     */   {
/*  296: 796 */     return isUserHasRoleAssignments(getLoggedInUser(), preferedRoleAssignments, checkFor);
/*  297:     */   }
/*  298:     */   
/*  299:     */   public boolean isUserHasRoleAssignments(IUser user, Iterator<IRoleAssignment> preferedRoleAssignments, CheckFor checkFor)
/*  300:     */     throws Exception
/*  301:     */   {
/*  302: 828 */     boolean returnValForAll = true;
/*  303: 829 */     boolean returnValForAny = false;
/*  304: 830 */     boolean isUserRoleValid = false;
/*  305: 831 */     List<String> assignedRoleListForUserAsList = null;
/*  306: 832 */     List<String> preferredRoleAssignementAsList = null;
/*  307: 833 */     Iterator<IRoleAssignment> assignedRoleListForUser = null;
/*  308:     */     
/*  309:     */ 
/*  310: 836 */     assignedRoleListForUser = user.getRoleAssignments();
/*  311: 837 */     assignedRoleListForUserAsList = getRoleAssignmentNamesAsList(assignedRoleListForUser);
/*  312:     */     
/*  313: 839 */     preferredRoleAssignementAsList = getRoleAssignmentNamesAsList(preferedRoleAssignments);
/*  314: 842 */     if ((CommonUtil.isListNotNullOrEmpty(preferredRoleAssignementAsList)) && (CommonUtil.isListNotNullOrEmpty(assignedRoleListForUserAsList))) {
/*  315: 846 */       for (String roleTemplateName : preferredRoleAssignementAsList) {
/*  316: 849 */         if (!assignedRoleListForUserAsList.contains(roleTemplateName))
/*  317:     */         {
/*  318: 852 */           if (CheckFor.CHECK_ANY.equals(checkFor))
/*  319:     */           {
/*  320: 854 */             returnValForAny = true;
/*  321: 855 */             break;
/*  322:     */           }
/*  323: 857 */           if (CheckFor.CHECK_ALL.equals(checkFor)) {
/*  324: 859 */             returnValForAll = true;
/*  325:     */           }
/*  326:     */         }
/*  327: 862 */         else if (CheckFor.CHECK_ALL.equals(checkFor))
/*  328:     */         {
/*  329: 864 */           returnValForAll = false;
/*  330: 865 */           break;
/*  331:     */         }
/*  332:     */       }
/*  333:     */     }
/*  334: 870 */     if (CheckFor.CHECK_ANY.equals(checkFor)) {
/*  335: 871 */       isUserRoleValid = returnValForAny;
/*  336: 872 */     } else if (CheckFor.CHECK_ALL.equals(checkFor)) {
/*  337: 873 */       isUserRoleValid = returnValForAll;
/*  338:     */     }
/*  339: 875 */     return isUserRoleValid;
/*  340:     */   }
/*  341:     */   
/*  342:     */   public List<String> getRoleAssignmentNamesAsList(Iterator<IRoleAssignment> rolesAssignments)
/*  343:     */     throws Exception
/*  344:     */   {
/*  345: 900 */     List<String> roleAssignmentsAsList = null;
/*  346: 903 */     if (CommonUtil.isObjectNotNull(rolesAssignments))
/*  347:     */     {
/*  348: 906 */       roleAssignmentsAsList = new ArrayList();
/*  349: 907 */       while (rolesAssignments.hasNext())
/*  350:     */       {
/*  351: 910 */         IRoleAssignment userRole = (IRoleAssignment)rolesAssignments.next();
/*  352: 911 */         roleAssignmentsAsList.add(userRole.getRoleTemplateName());
/*  353:     */       }
/*  354:     */     }
/*  355: 915 */     return roleAssignmentsAsList;
/*  356:     */   }
/*  357:     */   
/*  358:     */   public boolean isLoggedInUserPartOfGivenGroups(String groupNames, CheckFor checkFor)
/*  359:     */     throws Exception
/*  360:     */   {
/*  361: 939 */     boolean isUserInMentionedUserGroups = true;
/*  362: 940 */     List<String> userGroupsMentionedList = null;
/*  363: 946 */     if (CommonUtil.isNotNullOrEmpty(groupNames))
/*  364:     */     {
/*  365: 953 */       userGroupsMentionedList = CommonUtil.parseDelimitedValues(groupNames, ",");
/*  366:     */       
/*  367: 955 */       isUserInMentionedUserGroups = isLoggedInUserPartOfGivenGroups(userGroupsMentionedList, checkFor);
/*  368:     */     }
/*  369: 958 */     return isUserInMentionedUserGroups;
/*  370:     */   }
/*  371:     */   
/*  372:     */   public boolean isLoggedInUserPartOfGivenGroups(List<String> groupNamesList, CheckFor checkFor)
/*  373:     */     throws Exception
/*  374:     */   {
/*  375: 982 */     boolean isUserPartOfGivenGroups = true;
/*  376: 983 */     Iterator<IGroup> userGroupList = null;
/*  377: 984 */     List<String> userGroupNamesList = null;
/*  378:     */     
/*  379:     */ 
/*  380:     */ 
/*  381:     */ 
/*  382:     */ 
/*  383:     */ 
/*  384: 991 */     userGroupNamesList = new ArrayList();
/*  385: 992 */     userGroupList = getLoggedInUser().getGroups();
/*  386: 994 */     while (userGroupList.hasNext()) {
/*  387: 996 */       userGroupNamesList.add(((IGroup)userGroupList.next()).getName());
/*  388:     */     }
/*  389:1003 */     if (groupNamesList.size() != userGroupNamesList.size()) {
/*  390:1006 */       isUserPartOfGivenGroups = false;
/*  391:     */     } else {
/*  392:1015 */       isUserPartOfGivenGroups = userGroupNamesList.containsAll(groupNamesList);
/*  393:     */     }
/*  394:1019 */     return isUserPartOfGivenGroups;
/*  395:     */   }
/*  396:     */   
/*  397:     */   public IGroup getGroup(Id groupId)
/*  398:     */     throws Exception
/*  399:     */   {
/*  400:1038 */     ISecurityService securityService = this.serviceFactoryProxy.getServiceFactory().createSecurityService();
/*  401:     */     
/*  402:1040 */     return securityService.getGroup(groupId);
/*  403:     */   }
/*  404:     */   
/*  405:     */   public IGroup getGroup(String groupName)
/*  406:     */     throws Exception
/*  407:     */   {
/*  408:1059 */     ISecurityService securityService = this.serviceFactoryProxy.getServiceFactory().createSecurityService();
/*  409:     */     
/*  410:1061 */     return securityService.getGroup(groupName);
/*  411:     */   }
/*  412:     */   
/*  413:     */   public List<IGroup> getGroupFromGroupNameList(List<String> groupNamesList)
/*  414:     */     throws Exception
/*  415:     */   {
/*  416:1081 */     List<IGroup> groupsList = null;
/*  417:     */     
/*  418:1083 */     IServiceFactory sf = this.serviceFactoryProxy.getServiceFactory();
/*  419:1084 */     ISecurityService secService = sf.createSecurityService();
/*  420:     */     
/*  421:1086 */     groupsList = new ArrayList();
/*  422:1088 */     for (String groupName : groupNamesList) {
/*  423:1091 */       if (CommonUtil.isNotNullOrEmpty(groupName)) {
/*  424:1092 */         groupsList.add(secService.getGroup(groupName));
/*  425:     */       }
/*  426:     */     }
/*  427:1095 */     return groupsList;
/*  428:     */   }
/*  429:     */   
/*  430:     */   public boolean isLoggedInUserMemberOfAGroup(IGroup group)
/*  431:     */     throws Exception
/*  432:     */   {
/*  433:1116 */     return isGivenUserMemberOfAGroup(getLoggedInUser(), group);
/*  434:     */   }
/*  435:     */   
/*  436:     */   public boolean isLoggedInUserMemberOfAGroup(String group)
/*  437:     */     throws Exception
/*  438:     */   {
/*  439:1136 */     return isGivenUserMemberOfAGroup(getLoggedInUser(), group);
/*  440:     */   }
/*  441:     */   
/*  442:     */   public boolean isGivenUserMemberOfAGroup(IUser user, String group)
/*  443:     */     throws Exception
/*  444:     */   {
/*  445:1159 */     IServiceFactory sf = this.serviceFactoryProxy.getServiceFactory();
/*  446:1160 */     ISecurityService secService = sf.createSecurityService();
/*  447:1161 */     return isGivenUserMemberOfAGroup(user, secService.getGroup(group));
/*  448:     */   }
/*  449:     */   
/*  450:     */   public boolean isGivenUserMemberOfAGroup(String userName, IGroup group)
/*  451:     */     throws Exception
/*  452:     */   {
/*  453:1184 */     IServiceFactory sf = this.serviceFactoryProxy.getServiceFactory();
/*  454:1185 */     ISecurityService secService = sf.createSecurityService();
/*  455:1186 */     return isGivenUserMemberOfAGroup(secService.getUser(userName), group);
/*  456:     */   }
/*  457:     */   
/*  458:     */   public boolean isGivenUserMemberOfAGroup(String userName, String groupName)
/*  459:     */     throws Exception
/*  460:     */   {
/*  461:1208 */     IServiceFactory sf = this.serviceFactoryProxy.getServiceFactory();
/*  462:1209 */     ISecurityService secService = sf.createSecurityService();
/*  463:1210 */     return isGivenUserMemberOfAGroup(secService.getUser(userName), secService.getGroup(groupName));
/*  464:     */   }
/*  465:     */   
/*  466:     */   public boolean isGivenUserMemberOfAGroup(IUser user, IGroup group)
/*  467:     */     throws Exception
/*  468:     */   {
/*  469:1235 */     return user.isMember(group);
/*  470:     */   }
/*  471:     */   
/*  472:     */   public boolean isUserMemberOfGivenGroups(IUser user, List<IGroup> groupNamesList, CheckFor checkFor)
/*  473:     */     throws Exception
/*  474:     */   {
/*  475:1263 */     boolean isApplicable = false;
/*  476:1264 */     boolean returnValForAll = false;
/*  477:1265 */     boolean returnValForAny = false;
/*  478:1269 */     for (IGroup groupToCheck : groupNamesList)
/*  479:     */     {
/*  480:1272 */       boolean flag = false;
/*  481:1274 */       if (isGivenUserMemberOfAGroup(user, groupToCheck))
/*  482:     */       {
/*  483:1277 */         if (checkFor.equals(CheckFor.CHECK_ANY))
/*  484:     */         {
/*  485:1279 */           returnValForAny = true;
/*  486:1280 */           break;
/*  487:     */         }
/*  488:1282 */         if (checkFor.equals(CheckFor.CHECK_ALL)) {
/*  489:1284 */           flag = true;
/*  490:     */         }
/*  491:     */       }
/*  492:1288 */       if ((checkFor.equals(CheckFor.CHECK_ALL)) && (!flag))
/*  493:     */       {
/*  494:1290 */         returnValForAll = false;
/*  495:1291 */         break;
/*  496:     */       }
/*  497:     */     }
/*  498:1296 */     if (checkFor.equals(CheckFor.CHECK_ALL)) {
/*  499:1298 */       isApplicable = returnValForAll;
/*  500:1300 */     } else if (checkFor.equals(CheckFor.CHECK_ANY)) {
/*  501:1302 */       isApplicable = returnValForAny;
/*  502:     */     }
/*  503:1305 */     return isApplicable;
/*  504:     */   }
/*  505:     */   
/*  506:     */   public String getUserDisplayNameLastFirst(String userName)
/*  507:     */     throws Exception
/*  508:     */   {
/*  509:1325 */     return getUserDisplayNameLastFirst(getUser(userName));
/*  510:     */   }
/*  511:     */   
/*  512:     */   public String getUserDisplayNameLastFirst(IUser user)
/*  513:     */     throws Exception
/*  514:     */   {
/*  515:1345 */     return user.getLastName() + "," + " " + user.getFirstName();
/*  516:     */   }
/*  517:     */   
/*  518:     */   public String getUserDisplayNameFirstLast(String userName)
/*  519:     */     throws Exception
/*  520:     */   {
/*  521:1366 */     return getUserDisplayNameFirstLast(getUser(userName));
/*  522:     */   }
/*  523:     */   
/*  524:     */   public String getUserDisplayNameFirstLast(IUser user)
/*  525:     */     throws Exception
/*  526:     */   {
/*  527:1386 */     return user.getFirstName() + "," + " " + user.getLastName();
/*  528:     */   }
/*  529:     */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.impl.UserUtil
 * JD-Core Version:    0.7.0.1
 */