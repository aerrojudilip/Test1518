/*  1:   */ package com.ibm.openpages.ext.tss.service.impl;
/*  2:   */ 
/*  3:   */ import com.ibm.openpages.ext.tss.service.ILoggerUtil;
/*  4:   */ import com.ibm.openpages.ext.tss.service.logging.EXTLogger;
/*  5:   */ import com.ibm.openpages.ext.tss.service.logging.EXTLoggerFactoryImpl;
/*  6:   */ import javax.annotation.PostConstruct;
/*  7:   */ import org.apache.commons.logging.Log;
/*  8:   */ import org.apache.commons.logging.LogFactory;
/*  9:   */ import org.springframework.stereotype.Service;
/* 10:   */ 
/* 11:   */ @Service("loggerUtil")
/* 12:   */ public class LoggerUtil
/* 13:   */   implements ILoggerUtil
/* 14:   */ {
/* 15:30 */   LogFactory logFactory = null;
/* 16:   */   
/* 17:   */   @PostConstruct
/* 18:   */   public void initService()
/* 19:   */   {
/* 20:41 */     this.logFactory = new EXTLoggerFactoryImpl();
/* 21:   */   }
/* 22:   */   
/* 23:   */   public Log getExtLogger()
/* 24:   */   {
/* 25:53 */     return this.logFactory.getInstance(EXTLogger.class);
/* 26:   */   }
/* 27:   */   
/* 28:   */   public Log getExtLogger(String classname)
/* 29:   */   {
/* 30:59 */     return this.logFactory.getInstance(classname);
/* 31:   */   }
/* 32:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.impl.LoggerUtil
 * JD-Core Version:    0.7.0.1
 */