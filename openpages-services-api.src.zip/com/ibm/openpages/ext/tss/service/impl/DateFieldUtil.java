/*   1:    */ package com.ibm.openpages.ext.tss.service.impl;
/*   2:    */ 
/*   3:    */ import com.ibm.openpages.api.metadata.DataType;
/*   4:    */ import com.ibm.openpages.api.resource.IDateField;
/*   5:    */ import com.ibm.openpages.api.resource.IField;
/*   6:    */ import com.ibm.openpages.api.resource.IGRCObject;
/*   7:    */ import com.ibm.openpages.ext.tss.service.IDateFieldUtil;
/*   8:    */ import com.ibm.openpages.ext.tss.service.ILoggerUtil;
/*   9:    */ import com.ibm.openpages.ext.tss.service.util.CommonUtil;
/*  10:    */ import com.ibm.openpages.ext.tss.service.util.DateUtil;
/*  11:    */ import java.util.Date;
/*  12:    */ import javax.annotation.PostConstruct;
/*  13:    */ import org.apache.commons.logging.Log;
/*  14:    */ import org.springframework.beans.factory.annotation.Autowired;
/*  15:    */ import org.springframework.stereotype.Service;
/*  16:    */ 
/*  17:    */ @Service("dateFieldUtil")
/*  18:    */ public class DateFieldUtil
/*  19:    */   implements IDateFieldUtil
/*  20:    */ {
/*  21:    */   private Log logger;
/*  22:    */   @Autowired
/*  23:    */   ILoggerUtil loggerUtil;
/*  24:    */   
/*  25:    */   @PostConstruct
/*  26:    */   public void initService()
/*  27:    */   {
/*  28: 63 */     this.logger = this.loggerUtil.getExtLogger();
/*  29:    */   }
/*  30:    */   
/*  31:    */   public IDateField getDateField(IField field)
/*  32:    */     throws Exception
/*  33:    */   {
/*  34: 82 */     return DataType.DATE_TYPE.equals(field.getDataType()) ? (IDateField)field : null;
/*  35:    */   }
/*  36:    */   
/*  37:    */   public IDateField getDateField(IGRCObject object, String fieldInfo)
/*  38:    */     throws Exception
/*  39:    */   {
/*  40:102 */     return getDateField(object.getField(fieldInfo));
/*  41:    */   }
/*  42:    */   
/*  43:    */   public boolean isDateFieldNull(IField field)
/*  44:    */     throws Exception
/*  45:    */   {
/*  46:118 */     return CommonUtil.isObjectNull(field);
/*  47:    */   }
/*  48:    */   
/*  49:    */   public boolean isDateFieldNull(IGRCObject object, String fieldInfo)
/*  50:    */     throws Exception
/*  51:    */   {
/*  52:137 */     return isDateFieldNull(getDateField(object, fieldInfo));
/*  53:    */   }
/*  54:    */   
/*  55:    */   public boolean isDateFieldNotNull(IField field)
/*  56:    */     throws Exception
/*  57:    */   {
/*  58:153 */     return !isDateFieldNull(field);
/*  59:    */   }
/*  60:    */   
/*  61:    */   public boolean isDateFieldNotNull(IGRCObject object, String fieldInfo)
/*  62:    */     throws Exception
/*  63:    */   {
/*  64:172 */     return isDateFieldNotNull(getDateField(object, fieldInfo));
/*  65:    */   }
/*  66:    */   
/*  67:    */   public boolean isDateFieldValueNull(IField field)
/*  68:    */     throws Exception
/*  69:    */   {
/*  70:188 */     return CommonUtil.isObjectNull(getDateFieldValue(field));
/*  71:    */   }
/*  72:    */   
/*  73:    */   public boolean isDateFieldValueNull(IGRCObject object, String fieldInfo)
/*  74:    */     throws Exception
/*  75:    */   {
/*  76:207 */     return isDateFieldValueNull(getDateField(object, fieldInfo));
/*  77:    */   }
/*  78:    */   
/*  79:    */   public boolean isDateFieldValueNotNull(IField field)
/*  80:    */     throws Exception
/*  81:    */   {
/*  82:223 */     return !isDateFieldValueNull(field);
/*  83:    */   }
/*  84:    */   
/*  85:    */   public boolean isDateFieldValueNotNull(IGRCObject object, String fieldInfo)
/*  86:    */     throws Exception
/*  87:    */   {
/*  88:242 */     return isDateFieldValueNotNull(getDateField(object, fieldInfo));
/*  89:    */   }
/*  90:    */   
/*  91:    */   public String getDateFieldValueInSpecificFormat(IField field, String format)
/*  92:    */     throws Exception
/*  93:    */   {
/*  94:261 */     return isDateFieldValueNotNull(field) ? DateUtil.getDateInSpecificFormat(getDateFieldValue(field), format) : "";
/*  95:    */   }
/*  96:    */   
/*  97:    */   public String getDateFieldValueAsString(IField field)
/*  98:    */     throws Exception
/*  99:    */   {
/* 100:280 */     return isDateFieldValueNotNull(field) ? DateUtil.getDateValueInOpenPagesFormat(getDateFieldValue(field)) : "";
/* 101:    */   }
/* 102:    */   
/* 103:    */   public String getDateFieldValueInSpecificFormat(IGRCObject object, String fieldInfo, String format)
/* 104:    */     throws Exception
/* 105:    */   {
/* 106:299 */     return getDateFieldValueInSpecificFormat(getDateField(object, fieldInfo), format);
/* 107:    */   }
/* 108:    */   
/* 109:    */   public String getDateFieldValueAsString(IGRCObject object, String fieldInfo)
/* 110:    */     throws Exception
/* 111:    */   {
/* 112:318 */     return getDateFieldValueAsString(getDateField(object, fieldInfo));
/* 113:    */   }
/* 114:    */   
/* 115:    */   public Date getDateFieldValue(IField field)
/* 116:    */     throws Exception
/* 117:    */   {
/* 118:337 */     return isDateFieldNotNull(field) ? getDateField(field).getValue() : null;
/* 119:    */   }
/* 120:    */   
/* 121:    */   public Date getDateFieldValue(IGRCObject object, String fieldInfo)
/* 122:    */     throws Exception
/* 123:    */   {
/* 124:356 */     return getDateFieldValue(getDateField(object, fieldInfo));
/* 125:    */   }
/* 126:    */   
/* 127:    */   public void setDateField(IGRCObject object, String fieldInfo, String value)
/* 128:    */     throws Exception
/* 129:    */   {
/* 130:376 */     setDateField(getDateField(object, fieldInfo), value);
/* 131:    */   }
/* 132:    */   
/* 133:    */   public void setDateField(IDateField dateField, String value)
/* 134:    */     throws Exception
/* 135:    */   {
/* 136:395 */     Date dateValue = (CommonUtil.isEqualIgnoreCase(value, "EMPTY")) || (CommonUtil.isNullOrEmpty(value)) ? null : CommonUtil.isEqualIgnoreCase(value, "CURRENT_DATE") ? DateUtil.getCurrentDate() : DateUtil.parseStringToDate(value);
/* 137:    */     
/* 138:    */ 
/* 139:398 */     setDateField(dateField, dateValue);
/* 140:    */   }
/* 141:    */   
/* 142:    */   public void setDateField(IDateField dateField, Date value)
/* 143:    */     throws Exception
/* 144:    */   {
/* 145:415 */     if (isDateFieldNotNull(dateField)) {
/* 146:416 */       dateField.setValue(value);
/* 147:    */     }
/* 148:    */   }
/* 149:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.impl.DateFieldUtil
 * JD-Core Version:    0.7.0.1
 */