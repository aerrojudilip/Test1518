/*   1:    */ package com.ibm.openpages.ext.tss.service.impl;
/*   2:    */ 
/*   3:    */ import com.ibm.openpages.api.metadata.DataType;
/*   4:    */ import com.ibm.openpages.api.resource.IField;
/*   5:    */ import com.ibm.openpages.api.resource.IGRCObject;
/*   6:    */ import com.ibm.openpages.api.resource.IStringField;
/*   7:    */ import com.ibm.openpages.ext.tss.service.ILoggerUtil;
/*   8:    */ import com.ibm.openpages.ext.tss.service.IStringFieldUtil;
/*   9:    */ import com.ibm.openpages.ext.tss.service.util.CommonUtil;
/*  10:    */ import com.ibm.openpages.ext.tss.service.util.NumericUtil;
/*  11:    */ import javax.annotation.PostConstruct;
/*  12:    */ import org.apache.commons.logging.Log;
/*  13:    */ import org.springframework.beans.factory.annotation.Autowired;
/*  14:    */ import org.springframework.stereotype.Service;
/*  15:    */ 
/*  16:    */ @Service("stringFieldUtil")
/*  17:    */ public class StringFieldUtil
/*  18:    */   implements IStringFieldUtil
/*  19:    */ {
/*  20:    */   private Log logger;
/*  21:    */   @Autowired
/*  22:    */   ILoggerUtil loggerUtil;
/*  23:    */   
/*  24:    */   @PostConstruct
/*  25:    */   public void initService()
/*  26:    */   {
/*  27: 59 */     this.logger = this.loggerUtil.getExtLogger();
/*  28:    */   }
/*  29:    */   
/*  30:    */   public IStringField getStringField(IField field)
/*  31:    */   {
/*  32: 78 */     return isStringFieldDataType(field) ? (IStringField)field : null;
/*  33:    */   }
/*  34:    */   
/*  35:    */   public IStringField getStringField(IGRCObject object, String fieldInfo)
/*  36:    */   {
/*  37: 98 */     return getStringField(object.getField(fieldInfo));
/*  38:    */   }
/*  39:    */   
/*  40:    */   public boolean isStringFieldNull(IField field)
/*  41:    */   {
/*  42:114 */     return CommonUtil.isObjectNull(getStringField(field));
/*  43:    */   }
/*  44:    */   
/*  45:    */   public boolean isStringFieldNull(IGRCObject object, String fieldInfo)
/*  46:    */   {
/*  47:133 */     return isStringFieldNull(getStringField(object, fieldInfo));
/*  48:    */   }
/*  49:    */   
/*  50:    */   public boolean isStringFieldNotNull(IField field)
/*  51:    */   {
/*  52:149 */     return !isStringFieldNull(field);
/*  53:    */   }
/*  54:    */   
/*  55:    */   public boolean isStringFieldNotNull(IGRCObject object, String fieldInfo)
/*  56:    */   {
/*  57:168 */     return isStringFieldNotNull(getStringField(object, fieldInfo));
/*  58:    */   }
/*  59:    */   
/*  60:    */   public boolean isStringFieldValueNull(IField field)
/*  61:    */   {
/*  62:184 */     return CommonUtil.isObjectNull(getStringFieldValue(field));
/*  63:    */   }
/*  64:    */   
/*  65:    */   public boolean isStringFieldValueNull(IGRCObject object, String fieldInfo)
/*  66:    */   {
/*  67:203 */     return isStringFieldValueNull(getStringField(object, fieldInfo));
/*  68:    */   }
/*  69:    */   
/*  70:    */   public boolean isStringFieldValueNotNull(IField field)
/*  71:    */   {
/*  72:219 */     return !isStringFieldValueNull(field);
/*  73:    */   }
/*  74:    */   
/*  75:    */   public boolean isStringFieldValueNotNull(IGRCObject object, String fieldInfo)
/*  76:    */   {
/*  77:238 */     return isStringFieldValueNotNull(getStringField(object, fieldInfo));
/*  78:    */   }
/*  79:    */   
/*  80:    */   public boolean isStringFieldValueNullorEmpty(IField field)
/*  81:    */   {
/*  82:254 */     return (isStringFieldNull(field)) || (CommonUtil.isNullOrEmpty(getStringFieldValue(field)));
/*  83:    */   }
/*  84:    */   
/*  85:    */   public boolean isStringFieldValueNullorEmpty(IGRCObject object, String fieldInfo)
/*  86:    */   {
/*  87:273 */     return isStringFieldValueNullorEmpty(getStringField(object, fieldInfo));
/*  88:    */   }
/*  89:    */   
/*  90:    */   public boolean isStringFieldValueNotNullorEmpty(IField field)
/*  91:    */   {
/*  92:289 */     return !isStringFieldValueNullorEmpty(field);
/*  93:    */   }
/*  94:    */   
/*  95:    */   public boolean isStringFieldValueNotNullorEmpty(IGRCObject object, String fieldInfo)
/*  96:    */   {
/*  97:308 */     return isStringFieldValueNotNullorEmpty(getStringField(object, fieldInfo));
/*  98:    */   }
/*  99:    */   
/* 100:    */   public boolean isStringFieldValueNumeric(IField field)
/* 101:    */   {
/* 102:325 */     return (isStringFieldValueNotNullorEmpty(field)) && (NumericUtil.isNumeric(getStringFieldValue(field)));
/* 103:    */   }
/* 104:    */   
/* 105:    */   public boolean isStringFieldValueNumeric(IGRCObject object, String fieldInfo)
/* 106:    */   {
/* 107:345 */     return isStringFieldValueNumeric(getStringField(object, fieldInfo));
/* 108:    */   }
/* 109:    */   
/* 110:    */   public String getStringFieldValue(IField field)
/* 111:    */   {
/* 112:364 */     return (isStringFieldNotNull(field)) && (CommonUtil.isObjectNotNull(getStringField(field))) && (CommonUtil.isNotNullOrEmpty(getStringField(field).getValue())) ? getStringField(field).getValue() : null;
/* 113:    */   }
/* 114:    */   
/* 115:    */   public String getStringFieldValue(IGRCObject object, String fieldInfo)
/* 116:    */   {
/* 117:384 */     return getStringFieldValue(getStringField(object, fieldInfo));
/* 118:    */   }
/* 119:    */   
/* 120:    */   public int getStringFieldValueAsInt(IField field)
/* 121:    */   {
/* 122:403 */     return isStringFieldValueNumeric(field) ? NumericUtil.getIntValueWithLocale(getStringFieldValue(field)) : 0;
/* 123:    */   }
/* 124:    */   
/* 125:    */   public int getStringFieldValueAsInt(IGRCObject object, String fieldInfo)
/* 126:    */   {
/* 127:422 */     return getStringFieldValueAsInt(getStringField(object, fieldInfo));
/* 128:    */   }
/* 129:    */   
/* 130:    */   public double getStringFieldValueAsDouble(IField field)
/* 131:    */   {
/* 132:441 */     return isStringFieldValueNumeric(field) ? NumericUtil.getDoubleValueWithLocale(getStringFieldValue(field)) : 0.0D;
/* 133:    */   }
/* 134:    */   
/* 135:    */   public double getStringFieldValueAsDouble(IGRCObject object, String fieldInfo)
/* 136:    */   {
/* 137:460 */     return getStringFieldValueAsDouble(getStringField(object, fieldInfo));
/* 138:    */   }
/* 139:    */   
/* 140:    */   public float getStringFieldValueAsFloat(IField field)
/* 141:    */   {
/* 142:479 */     return isStringFieldValueNumeric(field) ? NumericUtil.getFloatValueWithLocale(getStringFieldValue(field)) : 0.0F;
/* 143:    */   }
/* 144:    */   
/* 145:    */   public float getStringFieldValueAsFloat(IGRCObject object, String fieldInfo)
/* 146:    */   {
/* 147:498 */     return getStringFieldValueAsFloat(getStringField(object, fieldInfo));
/* 148:    */   }
/* 149:    */   
/* 150:    */   public void setStringFieldValue(IGRCObject object, String fieldInfo, String value)
/* 151:    */   {
/* 152:517 */     setStringFieldValue(getStringField(object, fieldInfo), value);
/* 153:    */   }
/* 154:    */   
/* 155:    */   public void setStringFieldValue(IStringField stringField, String value)
/* 156:    */   {
/* 157:535 */     if (isStringFieldNotNull(stringField)) {
/* 158:536 */       stringField.setValue(value);
/* 159:    */     }
/* 160:    */   }
/* 161:    */   
/* 162:    */   public boolean isStringFieldDataType(IField field)
/* 163:    */   {
/* 164:554 */     return (DataType.STRING_TYPE.equals(field.getDataType())) || (DataType.MEDIUM_STRING_TYPE.equals(field.getDataType())) || (DataType.LARGE_STRING_TYPE.equals(field.getDataType())) || (DataType.UNLIMITED_STRING_TYPE.equals(field.getDataType()));
/* 165:    */   }
/* 166:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.impl.StringFieldUtil
 * JD-Core Version:    0.7.0.1
 */