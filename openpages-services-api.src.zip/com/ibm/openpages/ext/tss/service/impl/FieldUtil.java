/*    1:     */ package com.ibm.openpages.ext.tss.service.impl;
/*    2:     */ 
/*    3:     */ import com.ibm.openpages.api.metadata.DataType;
/*    4:     */ import com.ibm.openpages.api.metadata.IEnumValue;
/*    5:     */ import com.ibm.openpages.api.metadata.IFieldDefinition;
/*    6:     */ import com.ibm.openpages.api.metadata.ITypeDefinition;
/*    7:     */ import com.ibm.openpages.api.resource.ICurrencyField;
/*    8:     */ import com.ibm.openpages.api.resource.IDateField;
/*    9:     */ import com.ibm.openpages.api.resource.IEnumField;
/*   10:     */ import com.ibm.openpages.api.resource.IField;
/*   11:     */ import com.ibm.openpages.api.resource.IFloatField;
/*   12:     */ import com.ibm.openpages.api.resource.IGRCObject;
/*   13:     */ import com.ibm.openpages.api.resource.IIntegerField;
/*   14:     */ import com.ibm.openpages.api.resource.IMultiEnumField;
/*   15:     */ import com.ibm.openpages.api.resource.IStringField;
/*   16:     */ import com.ibm.openpages.api.resource.util.ResourceUtil;
/*   17:     */ import com.ibm.openpages.api.service.IMetaDataService;
/*   18:     */ import com.ibm.openpages.api.service.IServiceFactory;
/*   19:     */ import com.ibm.openpages.ext.tss.service.ICurrencyFieldUtil;
/*   20:     */ import com.ibm.openpages.ext.tss.service.IDateFieldUtil;
/*   21:     */ import com.ibm.openpages.ext.tss.service.IEnumFieldUtil;
/*   22:     */ import com.ibm.openpages.ext.tss.service.IFieldUtil;
/*   23:     */ import com.ibm.openpages.ext.tss.service.IFloatFieldUtil;
/*   24:     */ import com.ibm.openpages.ext.tss.service.IIDFieldUtil;
/*   25:     */ import com.ibm.openpages.ext.tss.service.IIntegerFieldUtil;
/*   26:     */ import com.ibm.openpages.ext.tss.service.ILoggerUtil;
/*   27:     */ import com.ibm.openpages.ext.tss.service.IMultiEnumFieldUtil;
/*   28:     */ import com.ibm.openpages.ext.tss.service.IStringFieldUtil;
/*   29:     */ import com.ibm.openpages.ext.tss.service.beans.FieldValueChangeInfo;
/*   30:     */ import com.ibm.openpages.ext.tss.service.beans.FieldValueChangeOnConditionInfo;
/*   31:     */ import com.ibm.openpages.ext.tss.service.constants.CheckFor;
/*   32:     */ import com.ibm.openpages.ext.tss.service.constants.Comparators;
/*   33:     */ import com.ibm.openpages.ext.tss.service.proxy.IServiceFactoryProxy;
/*   34:     */ import com.ibm.openpages.ext.tss.service.util.CommonUtil;
/*   35:     */ import com.ibm.openpages.ext.tss.service.util.DateUtil;
/*   36:     */ import com.ibm.openpages.ext.tss.service.util.NumericUtil;
/*   37:     */ import java.util.ArrayList;
/*   38:     */ import java.util.Calendar;
/*   39:     */ import java.util.Date;
/*   40:     */ import java.util.Iterator;
/*   41:     */ import java.util.List;
/*   42:     */ import javax.annotation.PostConstruct;
/*   43:     */ import org.apache.commons.logging.Log;
/*   44:     */ import org.springframework.beans.factory.annotation.Autowired;
/*   45:     */ import org.springframework.stereotype.Service;
/*   46:     */ 
/*   47:     */ @Service("fieldUtil")
/*   48:     */ public class FieldUtil
/*   49:     */   implements IFieldUtil
/*   50:     */ {
/*   51:     */   private Log logger;
/*   52:     */   @Autowired
/*   53:     */   IServiceFactoryProxy serviceFactoryProxy;
/*   54:     */   @Autowired
/*   55:     */   IIDFieldUtil idFieldUtil;
/*   56:     */   @Autowired
/*   57:     */   ICurrencyFieldUtil currencyFieldUtil;
/*   58:     */   @Autowired
/*   59:     */   IDateFieldUtil dateFieldUtil;
/*   60:     */   @Autowired
/*   61:     */   IEnumFieldUtil enumFieldUtil;
/*   62:     */   @Autowired
/*   63:     */   IMultiEnumFieldUtil multiEnumFieldUtil;
/*   64:     */   @Autowired
/*   65:     */   IFloatFieldUtil floatFieldUtil;
/*   66:     */   @Autowired
/*   67:     */   IStringFieldUtil stringFieldUtil;
/*   68:     */   @Autowired
/*   69:     */   IIntegerFieldUtil integerFieldUtil;
/*   70:     */   @Autowired
/*   71:     */   ILoggerUtil loggerUtil;
/*   72:     */   
/*   73:     */   @PostConstruct
/*   74:     */   public void initService()
/*   75:     */   {
/*   76: 123 */     this.logger = this.loggerUtil.getExtLogger();
/*   77:     */   }
/*   78:     */   
/*   79:     */   public IField getField(IGRCObject object, String fieldInfo)
/*   80:     */     throws Exception
/*   81:     */   {
/*   82: 143 */     return object.getField(fieldInfo);
/*   83:     */   }
/*   84:     */   
/*   85:     */   public List<IField> getFields(IGRCObject object, List<String> fieldInfoList)
/*   86:     */     throws Exception
/*   87:     */   {
/*   88: 162 */     List<IField> listOfFields = new ArrayList();
/*   89: 164 */     if (CommonUtil.isListNotNullOrEmpty(fieldInfoList)) {
/*   90: 166 */       for (String fieldInfo : fieldInfoList) {
/*   91: 168 */         if ((CommonUtil.isNotNullOrEmpty(fieldInfo)) && (CommonUtil.isObjectNotNull(getField(object, fieldInfo)))) {
/*   92: 169 */           listOfFields.add(getField(object, fieldInfo));
/*   93:     */         }
/*   94:     */       }
/*   95:     */     }
/*   96: 173 */     return listOfFields;
/*   97:     */   }
/*   98:     */   
/*   99:     */   public boolean isFieldNull(IField field)
/*  100:     */     throws Exception
/*  101:     */   {
/*  102: 189 */     return CommonUtil.isObjectNull(field);
/*  103:     */   }
/*  104:     */   
/*  105:     */   public boolean isFieldNull(IGRCObject object, String fieldInfo)
/*  106:     */     throws Exception
/*  107:     */   {
/*  108: 208 */     return isFieldNull(object.getField(fieldInfo));
/*  109:     */   }
/*  110:     */   
/*  111:     */   public boolean isFieldNotNull(IField field)
/*  112:     */     throws Exception
/*  113:     */   {
/*  114: 224 */     return !isFieldNull(field);
/*  115:     */   }
/*  116:     */   
/*  117:     */   public boolean isFieldNotNull(IGRCObject object, String fieldInfo)
/*  118:     */     throws Exception
/*  119:     */   {
/*  120: 243 */     return isFieldNotNull(object.getField(fieldInfo));
/*  121:     */   }
/*  122:     */   
/*  123:     */   public boolean isFieldValueNull(IField field)
/*  124:     */     throws Exception
/*  125:     */   {
/*  126: 259 */     boolean isFieldValueNull = false;
/*  127: 261 */     if ((CommonUtil.isObjectNotNull(field)) && (field.isNull())) {
/*  128: 262 */       isFieldValueNull = true;
/*  129: 263 */     } else if (DataType.FLOAT_TYPE.equals(field.getDataType())) {
/*  130: 264 */       isFieldValueNull = Float.isNaN(this.floatFieldUtil.getFloatFieldValueAsFloat(field));
/*  131: 265 */     } else if (this.stringFieldUtil.isStringFieldDataType(field)) {
/*  132: 266 */       isFieldValueNull = CommonUtil.isNullOrEmpty(this.stringFieldUtil.getStringFieldValue(field));
/*  133: 267 */     } else if (DataType.DATE_TYPE.equals(field.getDataType())) {
/*  134: 268 */       isFieldValueNull = CommonUtil.isNullOrEmpty(this.dateFieldUtil.getDateFieldValueAsString(field));
/*  135: 269 */     } else if (DataType.ENUM_TYPE.equals(field.getDataType())) {
/*  136: 270 */       isFieldValueNull = CommonUtil.isNullOrEmpty(this.enumFieldUtil.getEnumFieldSelectedValue(field));
/*  137: 271 */     } else if (DataType.ID_TYPE.equals(field.getDataType())) {
/*  138: 272 */       isFieldValueNull = CommonUtil.isNullOrEmpty(this.idFieldUtil.getIdFieldValueAsString(field));
/*  139:     */     }
/*  140: 274 */     return isFieldValueNull;
/*  141:     */   }
/*  142:     */   
/*  143:     */   public boolean isFieldValueNull(IGRCObject object, String fieldInfo)
/*  144:     */     throws Exception
/*  145:     */   {
/*  146: 293 */     return isFieldValueNull(object.getField(fieldInfo));
/*  147:     */   }
/*  148:     */   
/*  149:     */   public boolean isFieldValueNotNull(IField field)
/*  150:     */     throws Exception
/*  151:     */   {
/*  152: 309 */     return !isFieldValueNull(field);
/*  153:     */   }
/*  154:     */   
/*  155:     */   public boolean isFieldValueNotNull(IGRCObject object, String fieldInfo)
/*  156:     */     throws Exception
/*  157:     */   {
/*  158: 328 */     return isFieldValueNotNull(object.getField(fieldInfo));
/*  159:     */   }
/*  160:     */   
/*  161:     */   public boolean isFieldNullOrFieldValueNull(IField field)
/*  162:     */     throws Exception
/*  163:     */   {
/*  164: 344 */     return (isFieldNull(field)) || ((CommonUtil.isObjectNotNull(field)) && (field.isNull()));
/*  165:     */   }
/*  166:     */   
/*  167:     */   public boolean isFieldNullOrFieldValueNull(IGRCObject object, String fieldInfo)
/*  168:     */     throws Exception
/*  169:     */   {
/*  170: 363 */     return (CommonUtil.isObjectNull(object.getField(fieldInfo))) || ((CommonUtil.isObjectNotNull(object.getField(fieldInfo))) && (object.getField(fieldInfo).isNull()));
/*  171:     */   }
/*  172:     */   
/*  173:     */   public boolean isFieldValueNullOrEmpty(IField field)
/*  174:     */     throws Exception
/*  175:     */   {
/*  176: 380 */     String fieldValue = "";
/*  177: 382 */     if (isFieldNotNull(field)) {
/*  178: 384 */       if (DataType.FLOAT_TYPE.equals(field.getDataType())) {
/*  179: 385 */         fieldValue = this.floatFieldUtil.getFloatFieldValueAsFloat(field) + "";
/*  180: 386 */       } else if (this.stringFieldUtil.isStringFieldDataType(field)) {
/*  181: 387 */         fieldValue = this.stringFieldUtil.getStringFieldValue(field);
/*  182: 388 */       } else if (DataType.DATE_TYPE.equals(field.getDataType())) {
/*  183: 389 */         fieldValue = this.dateFieldUtil.getDateFieldValueAsString(field);
/*  184: 390 */       } else if (DataType.ID_TYPE.equals(field.getDataType())) {
/*  185: 391 */         fieldValue = this.idFieldUtil.getIdFieldValueAsString(field);
/*  186:     */       }
/*  187:     */     }
/*  188: 394 */     return CommonUtil.isNullOrEmpty(fieldValue);
/*  189:     */   }
/*  190:     */   
/*  191:     */   public boolean isFieldValueNullOrEmpty(IGRCObject object, String fieldInfo)
/*  192:     */     throws Exception
/*  193:     */   {
/*  194: 413 */     return isFieldValueNullOrEmpty(object.getField(fieldInfo));
/*  195:     */   }
/*  196:     */   
/*  197:     */   public boolean isFieldValueNotNullOrEmpty(IField field)
/*  198:     */     throws Exception
/*  199:     */   {
/*  200: 429 */     return !isFieldValueNullOrEmpty(field);
/*  201:     */   }
/*  202:     */   
/*  203:     */   public boolean isFieldValueNotNullOrEmpty(IGRCObject object, String fieldInfo)
/*  204:     */     throws Exception
/*  205:     */   {
/*  206: 448 */     return isFieldValueNotNullOrEmpty(object.getField(fieldInfo));
/*  207:     */   }
/*  208:     */   
/*  209:     */   public String getFieldName(IField field)
/*  210:     */     throws Exception
/*  211:     */   {
/*  212: 465 */     return isFieldNotNull(field) ? field.getName() : "Null";
/*  213:     */   }
/*  214:     */   
/*  215:     */   public String getFieldName(IGRCObject object, String fieldInfo)
/*  216:     */     throws Exception
/*  217:     */   {
/*  218: 485 */     return getFieldName(object.getField(fieldInfo));
/*  219:     */   }
/*  220:     */   
/*  221:     */   public String getFieldValueAsString(IField field)
/*  222:     */     throws Exception
/*  223:     */   {
/*  224: 503 */     String fieldValue = "";
/*  225: 505 */     if (isFieldNotNull(field)) {
/*  226: 507 */       if (DataType.INTEGER_TYPE.equals(field.getDataType())) {
/*  227: 508 */         fieldValue = this.integerFieldUtil.getIntegerFieldValueAsString(field);
/*  228: 509 */       } else if (DataType.FLOAT_TYPE.equals(field.getDataType())) {
/*  229: 510 */         fieldValue = this.floatFieldUtil.getFloatFieldValueAsString(field);
/*  230: 511 */       } else if (this.stringFieldUtil.isStringFieldDataType(field)) {
/*  231: 512 */         fieldValue = this.stringFieldUtil.getStringFieldValue(field);
/*  232: 513 */       } else if (DataType.DATE_TYPE.equals(field.getDataType())) {
/*  233: 514 */         fieldValue = this.dateFieldUtil.getDateFieldValueAsString(field);
/*  234: 515 */       } else if (DataType.ENUM_TYPE.equals(field.getDataType())) {
/*  235: 516 */         fieldValue = this.enumFieldUtil.getEnumFieldSelectedValue(field);
/*  236: 517 */       } else if (DataType.MULTI_VALUE_ENUM.equals(field.getDataType())) {
/*  237: 518 */         fieldValue = CommonUtil.unParseCommaDelimitedValues(this.multiEnumFieldUtil.getEnumFieldSelectedValue(field));
/*  238: 519 */       } else if (DataType.ID_TYPE.equals(field.getDataType())) {
/*  239: 520 */         fieldValue = this.idFieldUtil.getIdFieldValueAsString(field);
/*  240: 521 */       } else if (DataType.CURRENCY_TYPE.equals(field.getDataType())) {
/*  241: 522 */         fieldValue = this.currencyFieldUtil.getCurrencyFieldLocalAmountAsString(field);
/*  242:     */       }
/*  243:     */     }
/*  244: 525 */     return fieldValue;
/*  245:     */   }
/*  246:     */   
/*  247:     */   public Object getOriginalValueOfField(IGRCObject object, String fieldInfo)
/*  248:     */     throws Exception
/*  249:     */   {
/*  250: 545 */     return null;
/*  251:     */   }
/*  252:     */   
/*  253:     */   public String getOriginalValueOfFieldAsString(IGRCObject object, String fieldInfo)
/*  254:     */     throws Exception
/*  255:     */   {
/*  256: 565 */     return null;
/*  257:     */   }
/*  258:     */   
/*  259:     */   public Object getFieldValue(IField field)
/*  260:     */     throws Exception
/*  261:     */   {
/*  262: 582 */     Object fieldValue = null;
/*  263: 584 */     if (isFieldNotNull(field)) {
/*  264: 586 */       if (DataType.INTEGER_TYPE.equals(field.getDataType())) {
/*  265: 587 */         fieldValue = this.integerFieldUtil.getIntegerFieldValue(field);
/*  266: 588 */       } else if (DataType.FLOAT_TYPE.equals(field.getDataType())) {
/*  267: 589 */         fieldValue = this.floatFieldUtil.getFloatFieldValue(field);
/*  268: 590 */       } else if (this.stringFieldUtil.isStringFieldDataType(field)) {
/*  269: 591 */         fieldValue = this.stringFieldUtil.getStringFieldValue(field);
/*  270: 592 */       } else if (DataType.DATE_TYPE.equals(field.getDataType())) {
/*  271: 593 */         fieldValue = this.dateFieldUtil.getDateFieldValue(field);
/*  272: 594 */       } else if (DataType.ENUM_TYPE.equals(field.getDataType())) {
/*  273: 595 */         fieldValue = this.enumFieldUtil.getEnumFieldValue(field);
/*  274: 596 */       } else if (DataType.ID_TYPE.equals(field.getDataType())) {
/*  275: 597 */         fieldValue = this.idFieldUtil.getIdFieldValueAsString(field);
/*  276: 598 */       } else if (DataType.MULTI_VALUE_ENUM.equals(field.getDataType())) {
/*  277: 599 */         fieldValue = this.multiEnumFieldUtil.getEnumFieldValues(field);
/*  278: 600 */       } else if (DataType.CURRENCY_TYPE.equals(field.getDataType())) {
/*  279: 601 */         fieldValue = this.currencyFieldUtil.getCurrencyFieldLocalAmount(field);
/*  280:     */       }
/*  281:     */     }
/*  282: 604 */     return fieldValue;
/*  283:     */   }
/*  284:     */   
/*  285:     */   public String getFieldValueAsString(IGRCObject object, String fieldInfo)
/*  286:     */     throws Exception
/*  287:     */   {
/*  288: 624 */     return getFieldValueAsString(object.getField(fieldInfo));
/*  289:     */   }
/*  290:     */   
/*  291:     */   public void setFieldValue(IField field, String value)
/*  292:     */     throws Exception
/*  293:     */   {
/*  294: 642 */     if (isFieldNotNull(field)) {
/*  295: 644 */       if (DataType.INTEGER_TYPE.equals(field.getDataType())) {
/*  296: 646 */         this.integerFieldUtil.setIntegerField((IIntegerField)field, value);
/*  297: 648 */       } else if (DataType.FLOAT_TYPE.equals(field.getDataType())) {
/*  298: 650 */         this.floatFieldUtil.setFloatField((IFloatField)field, value);
/*  299: 651 */       } else if (this.stringFieldUtil.isStringFieldDataType(field)) {
/*  300: 653 */         this.stringFieldUtil.setStringFieldValue((IStringField)field, value);
/*  301: 654 */       } else if (DataType.DATE_TYPE.equals(field.getDataType())) {
/*  302: 656 */         this.dateFieldUtil.setDateField((IDateField)field, value);
/*  303: 657 */       } else if (DataType.ENUM_TYPE.equals(field.getDataType())) {
/*  304: 659 */         this.enumFieldUtil.setEnumFieldValue((IEnumField)field, value);
/*  305: 660 */       } else if (DataType.MULTI_VALUE_ENUM.equals(field.getDataType())) {
/*  306: 662 */         this.multiEnumFieldUtil.setEnumFieldValue(field, value);
/*  307: 663 */       } else if (DataType.CURRENCY_TYPE.equals(field.getDataType())) {
/*  308: 665 */         this.currencyFieldUtil.setCurrencyFieldLocalAmount(field, Double.valueOf(Double.parseDouble(value)));
/*  309:     */       }
/*  310:     */     }
/*  311:     */   }
/*  312:     */   
/*  313:     */   public void setFieldValue(IField field, Object value)
/*  314:     */     throws Exception
/*  315:     */   {
/*  316: 687 */     if (isFieldNotNull(field)) {
/*  317: 689 */       if ((DataType.INTEGER_TYPE.equals(field.getDataType())) && ((value instanceof Integer)))
/*  318:     */       {
/*  319: 691 */         this.integerFieldUtil.setIntegerField((IIntegerField)field, (Integer)value);
/*  320:     */       }
/*  321: 693 */       else if ((DataType.FLOAT_TYPE.equals(field.getDataType())) && ((value instanceof Double)))
/*  322:     */       {
/*  323: 695 */         this.floatFieldUtil.setFloatField((IFloatField)field, (Double)value);
/*  324:     */       }
/*  325: 696 */       else if ((this.stringFieldUtil.isStringFieldDataType(field)) && ((value instanceof String)))
/*  326:     */       {
/*  327: 698 */         this.stringFieldUtil.setStringFieldValue((IStringField)field, (String)value);
/*  328:     */       }
/*  329: 699 */       else if ((DataType.DATE_TYPE.equals(field.getDataType())) && ((value instanceof Date)))
/*  330:     */       {
/*  331: 701 */         this.dateFieldUtil.setDateField((IDateField)field, (Date)value);
/*  332:     */       }
/*  333: 702 */       else if ((DataType.ENUM_TYPE.equals(field.getDataType())) && ((value instanceof IEnumValue)))
/*  334:     */       {
/*  335: 704 */         this.enumFieldUtil.setEnumFieldValue((IEnumField)field, (IEnumValue)value);
/*  336:     */       }
/*  337: 705 */       else if ((DataType.MULTI_VALUE_ENUM.equals(field.getDataType())) && ((value instanceof List)))
/*  338:     */       {
/*  339: 707 */         this.multiEnumFieldUtil.setEnumFieldValue((IMultiEnumField)field, (List)value);
/*  340:     */       }
/*  341: 708 */       else if ((DataType.CURRENCY_TYPE.equals(field.getDataType())) && ((value instanceof ICurrencyField)))
/*  342:     */       {
/*  343: 710 */         this.currencyFieldUtil.setCurrencyFieldLocalAmount(field, ((ICurrencyField)value).getLocalAmount());
/*  344: 711 */         this.currencyFieldUtil.setCurrencyFieldLocalCurrency(field, ((ICurrencyField)value).getLocalCurrency());
/*  345:     */       }
/*  346:     */     }
/*  347:     */   }
/*  348:     */   
/*  349:     */   public void setFieldValue(IGRCObject object, String fieldInfo, String value)
/*  350:     */     throws Exception
/*  351:     */   {
/*  352: 733 */     if ((CommonUtil.isNotNullOrEmpty(fieldInfo)) && (fieldInfo.contains("System Fields:")))
/*  353:     */     {
/*  354: 734 */       if (CommonUtil.isEqualIgnoreCase(fieldInfo, "System Fields:Description")) {
/*  355: 735 */         object.setDescription(value);
/*  356:     */       }
/*  357:     */     }
/*  358:     */     else {
/*  359: 739 */       setFieldValue(getField(object, fieldInfo), value);
/*  360:     */     }
/*  361:     */   }
/*  362:     */   
/*  363:     */   public void setFieldValueWithNull(IField field)
/*  364:     */     throws Exception
/*  365:     */   {
/*  366: 756 */     if (isFieldNotNull(field)) {
/*  367: 758 */       if (DataType.INTEGER_TYPE.equals(field.getDataType())) {
/*  368: 760 */         this.integerFieldUtil.getIntegerField(field).setValue(null);
/*  369: 762 */       } else if (DataType.FLOAT_TYPE.equals(field.getDataType())) {
/*  370: 764 */         this.floatFieldUtil.getFloatField(field).setValue(null);
/*  371: 765 */       } else if (this.stringFieldUtil.isStringFieldDataType(field)) {
/*  372: 767 */         this.stringFieldUtil.setStringFieldValue((IStringField)field, null);
/*  373: 768 */       } else if (DataType.DATE_TYPE.equals(field.getDataType())) {
/*  374: 770 */         this.dateFieldUtil.getDateField((IDateField)field).setValue(null);
/*  375: 771 */       } else if (DataType.ENUM_TYPE.equals(field.getDataType())) {
/*  376: 773 */         this.enumFieldUtil.getEnumField((IEnumField)field).setEnumValue(null);
/*  377: 774 */       } else if (DataType.CURRENCY_TYPE.equals(field.getDataType())) {
/*  378: 776 */         this.currencyFieldUtil.setCurrencyFieldLocalAmount(field, null);
/*  379:     */       }
/*  380:     */     }
/*  381:     */   }
/*  382:     */   
/*  383:     */   public void setFieldValueWithNull(IGRCObject object, String fieldInfo)
/*  384:     */     throws Exception
/*  385:     */   {
/*  386: 797 */     setFieldValueWithNull(getField(object, fieldInfo));
/*  387:     */   }
/*  388:     */   
/*  389:     */   public boolean isFieldValueChanged(IGRCObject object, String fieldInfo)
/*  390:     */     throws Exception
/*  391:     */   {
/*  392: 816 */     boolean hasChanged = false;
/*  393: 817 */     List<IField> modifiedFields = getModifiedFields(object);
/*  394: 819 */     for (IField modifiedField : modifiedFields) {
/*  395: 821 */       if (modifiedField.getName().equals(fieldInfo))
/*  396:     */       {
/*  397: 823 */         hasChanged = true;
/*  398: 824 */         break;
/*  399:     */       }
/*  400:     */     }
/*  401: 828 */     return hasChanged;
/*  402:     */   }
/*  403:     */   
/*  404:     */   public boolean isAllorAnyFieldValueChanged(IGRCObject object, List<String> fieldNamesList, String checkFor)
/*  405:     */     throws Exception
/*  406:     */   {
/*  407: 849 */     boolean isAllOrAnyFieldsChanged = false;
/*  408: 851 */     if (CommonUtil.isListNotNullOrEmpty(fieldNamesList))
/*  409:     */     {
/*  410: 853 */       isAllOrAnyFieldsChanged = CommonUtil.isEqualIgnoreCase(checkFor, CheckFor.CHECK_ALL.toString());
/*  411: 855 */       for (String fieldName : fieldNamesList) {
/*  412: 857 */         if (CommonUtil.isNotNullOrEmpty(fieldName)) {
/*  413: 859 */           if (CommonUtil.isEqualIgnoreCase(checkFor, CheckFor.CHECK_ALL.toString()))
/*  414:     */           {
/*  415: 861 */             isAllOrAnyFieldsChanged = (isFieldValueChanged(object, fieldName)) && (isAllOrAnyFieldsChanged);
/*  416: 862 */             if (!isAllOrAnyFieldsChanged) {
/*  417:     */               break;
/*  418:     */             }
/*  419:     */           }
/*  420: 864 */           else if ((CommonUtil.isEqualIgnoreCase(checkFor, CheckFor.CHECK_ANY.toString())) && (isFieldValueChanged(object, fieldName)))
/*  421:     */           {
/*  422: 866 */             isAllOrAnyFieldsChanged = true;
/*  423: 867 */             break;
/*  424:     */           }
/*  425:     */         }
/*  426:     */       }
/*  427:     */     }
/*  428: 873 */     return isAllOrAnyFieldsChanged;
/*  429:     */   }
/*  430:     */   
/*  431:     */   public boolean isAllOrAnyFieldHasValues(IGRCObject object, List<String> fieldNamesList, String checkFor)
/*  432:     */     throws Exception
/*  433:     */   {
/*  434: 894 */     boolean isAllOrAnyEnumFieldHasValues = false;
/*  435: 896 */     if (CommonUtil.isListNotNullOrEmpty(fieldNamesList))
/*  436:     */     {
/*  437: 898 */       isAllOrAnyEnumFieldHasValues = CommonUtil.isEqualIgnoreCase(checkFor, CheckFor.CHECK_ALL.toString());
/*  438: 900 */       for (String fieldName : fieldNamesList)
/*  439:     */       {
/*  440: 902 */         IField field = object.getField(fieldName);
/*  441: 904 */         if (CommonUtil.isObjectNotNull(field)) {
/*  442: 906 */           if (CommonUtil.isEqualIgnoreCase(checkFor, CheckFor.CHECK_ALL.toString()))
/*  443:     */           {
/*  444: 908 */             isAllOrAnyEnumFieldHasValues = (!field.isNull()) && (isAllOrAnyEnumFieldHasValues);
/*  445: 909 */             if (!isAllOrAnyEnumFieldHasValues) {
/*  446:     */               break;
/*  447:     */             }
/*  448:     */           }
/*  449: 911 */           else if ((CommonUtil.isEqualIgnoreCase(checkFor, CheckFor.CHECK_ANY.toString())) && (!field.isNull()))
/*  450:     */           {
/*  451: 913 */             isAllOrAnyEnumFieldHasValues = true;
/*  452: 914 */             break;
/*  453:     */           }
/*  454:     */         }
/*  455:     */       }
/*  456:     */     }
/*  457: 920 */     return isAllOrAnyEnumFieldHasValues;
/*  458:     */   }
/*  459:     */   
/*  460:     */   public boolean isAllOrAnyFieldHasValues(IGRCObject object, String fieldNamesList, String checkFor)
/*  461:     */     throws Exception
/*  462:     */   {
/*  463: 942 */     return isAllOrAnyFieldHasValues(object, CommonUtil.parseDelimitedValues(fieldNamesList, ","), checkFor);
/*  464:     */   }
/*  465:     */   
/*  466:     */   public boolean isAllFieldsHasMatchingValues(IGRCObject object, List<String> fieldNamesList, List<String> matchingFieldValuesList)
/*  467:     */     throws Exception
/*  468:     */   {
/*  469: 967 */     int count = 0;
/*  470: 968 */     boolean isSpecialEvent = true;
/*  471: 969 */     String fieldValue = "";
/*  472: 971 */     for (String specialEventsFldInfo : fieldNamesList)
/*  473:     */     {
/*  474: 973 */       fieldValue = getFieldValueAsString(object, specialEventsFldInfo);
/*  475: 975 */       if (!CommonUtil.isEqual(fieldValue, (String)matchingFieldValuesList.get(count)))
/*  476:     */       {
/*  477: 977 */         isSpecialEvent = false;
/*  478: 978 */         break;
/*  479:     */       }
/*  480: 981 */       count++;
/*  481:     */     }
/*  482: 984 */     return isSpecialEvent;
/*  483:     */   }
/*  484:     */   
/*  485:     */   public Double getNumericFieldValueAsDouble(IField field)
/*  486:     */     throws Exception
/*  487:     */   {
/*  488:1002 */     Double numbericFieldValue = null;
/*  489:     */     
/*  490:1004 */     this.logger.debug("Is Field Value null: " + CommonUtil.isObjectNotNull(field));
/*  491:1005 */     this.logger.debug("Field Data type: " + (CommonUtil.isObjectNotNull(field) ? field.getDataType() : "Null Field"));
/*  492:1007 */     if ((DataType.INTEGER_TYPE.equals(field.getDataType())) && (this.integerFieldUtil.isIntegerFieldValueNotNull(field))) {
/*  493:1009 */       numbericFieldValue = new Double(this.integerFieldUtil.getIntegerFieldValueAsDouble(field));
/*  494:1010 */     } else if ((DataType.FLOAT_TYPE.equals(field.getDataType())) && (this.floatFieldUtil.isFloatFieldValueNotNull(field))) {
/*  495:1012 */       numbericFieldValue = new Double(this.floatFieldUtil.getFloatFieldValueAsDouble(field));
/*  496:     */     }
/*  497:1015 */     return numbericFieldValue;
/*  498:     */   }
/*  499:     */   
/*  500:     */   public Double getNumericFieldValueAsDouble(IGRCObject object, String fieldInfo)
/*  501:     */     throws Exception
/*  502:     */   {
/*  503:1037 */     return getNumericFieldValueAsDouble(getField(object, fieldInfo));
/*  504:     */   }
/*  505:     */   
/*  506:     */   public void displayAllFieldsInObject(IGRCObject object)
/*  507:     */     throws Exception
/*  508:     */   {
/*  509:1053 */     List<IField> fields = object.getFields();
/*  510:1055 */     for (IField field : fields)
/*  511:     */     {
/*  512:1057 */       this.logger.debug("Is Field Null: " + CommonUtil.isObjectNotNull(field));
/*  513:1058 */       this.logger.debug("Field Name: " + field.getName());
/*  514:1059 */       this.logger.debug("Field DataType: " + field.getDataType());
/*  515:     */     }
/*  516:     */   }
/*  517:     */   
/*  518:     */   public List<String> getFieldNamesAsList(List<IField> fields)
/*  519:     */   {
/*  520:1079 */     List<String> fieldNames = null;
/*  521:     */     
/*  522:1081 */     fieldNames = new ArrayList();
/*  523:1083 */     if (CommonUtil.isListNotNullOrEmpty(fields)) {
/*  524:1085 */       for (IField field : fields) {
/*  525:1087 */         fieldNames.add(field.getName());
/*  526:     */       }
/*  527:     */     }
/*  528:1091 */     return fieldNames;
/*  529:     */   }
/*  530:     */   
/*  531:     */   public List<IField> getFieldsFromFieldNamesList(IGRCObject object, List<String> fieldsInfoList)
/*  532:     */     throws Exception
/*  533:     */   {
/*  534:1112 */     List<IField> fieldsList = null;
/*  535:     */     
/*  536:1114 */     fieldsList = new ArrayList();
/*  537:1116 */     for (String fieldInfo : fieldsInfoList) {
/*  538:1118 */       fieldsList.add(getField(object, fieldInfo));
/*  539:     */     }
/*  540:1121 */     return fieldsList;
/*  541:     */   }
/*  542:     */   
/*  543:     */   public List<String> getFieldValuesFromFieldNamesList(List<IField> fieldsInfoList)
/*  544:     */     throws Exception
/*  545:     */   {
/*  546:1139 */     List<String> fieldValuesList = null;
/*  547:     */     
/*  548:1141 */     fieldValuesList = new ArrayList();
/*  549:1143 */     for (IField field : fieldsInfoList) {
/*  550:1145 */       fieldValuesList.add(getFieldValueAsString(field));
/*  551:     */     }
/*  552:1148 */     return fieldValuesList;
/*  553:     */   }
/*  554:     */   
/*  555:     */   public List<String> getFieldValuesFromFieldNamesList(IGRCObject object, List<String> fieldsInfoList)
/*  556:     */     throws Exception
/*  557:     */   {
/*  558:1169 */     List<String> fieldValuesList = null;
/*  559:     */     
/*  560:1171 */     fieldValuesList = new ArrayList();
/*  561:1173 */     for (String fieldInfo : fieldsInfoList) {
/*  562:1175 */       fieldValuesList.add(getFieldValueAsString(object, fieldInfo));
/*  563:     */     }
/*  564:1178 */     return fieldValuesList;
/*  565:     */   }
/*  566:     */   
/*  567:     */   public boolean isFieldValueChangedToExpectedCondition(FieldValueChangeOnConditionInfo fieldValueChangeOnConditionInfo)
/*  568:     */     throws Exception
/*  569:     */   {
/*  570:1198 */     int index = 0;
/*  571:1199 */     boolean isApplicable = false;
/*  572:1200 */     boolean returnValForAll = true;
/*  573:1201 */     boolean returnValForAny = false;
/*  574:     */     
/*  575:1203 */     String fieldValue = "";
/*  576:1204 */     List<List<?>> listofLists = null;
/*  577:     */     
/*  578:     */ 
/*  579:1207 */     listofLists = new ArrayList();
/*  580:1208 */     listofLists.add(fieldValueChangeOnConditionInfo.getFieldsInfoList());
/*  581:1209 */     listofLists.add(fieldValueChangeOnConditionInfo.getFieldValuesList());
/*  582:1210 */     listofLists.add(fieldValueChangeOnConditionInfo.getConditionsList());
/*  583:1212 */     if (CommonUtil.isListsOfTheSameSize(listofLists)) {
/*  584:1214 */       for (String fieldInfo : fieldValueChangeOnConditionInfo.getFieldsInfoList())
/*  585:     */       {
/*  586:1216 */         boolean flag = false;
/*  587:1217 */         getFieldValueAsString(fieldValueChangeOnConditionInfo.getObject(), fieldInfo);
/*  588:1220 */         if ((Comparators.EQUAL.equals(fieldValueChangeOnConditionInfo.getConditionsList().get(index))) && (CommonUtil.isEqualIgnoreCase(fieldValue, (String)fieldValueChangeOnConditionInfo.getFieldValuesList().get(index))))
/*  589:     */         {
/*  590:1223 */           if (CheckFor.CHECK_ANY.equals(fieldValueChangeOnConditionInfo.getCheckFor()))
/*  591:     */           {
/*  592:1224 */             returnValForAny = true;
/*  593:1225 */             break;
/*  594:     */           }
/*  595:1226 */           if (CheckFor.CHECK_ALL.equals(fieldValueChangeOnConditionInfo.getCheckFor())) {
/*  596:1227 */             flag = true;
/*  597:     */           }
/*  598:     */         }
/*  599:1229 */         else if ((Comparators.NOT_EQUAL.equals(fieldValueChangeOnConditionInfo.getConditionsList().get(index))) && (CommonUtil.isEqualIgnoreCase(fieldValue, (String)fieldValueChangeOnConditionInfo.getFieldValuesList().get(index))))
/*  600:     */         {
/*  601:1232 */           if (CheckFor.CHECK_ANY.equals(fieldValueChangeOnConditionInfo.getCheckFor()))
/*  602:     */           {
/*  603:1233 */             returnValForAny = true;
/*  604:1234 */             break;
/*  605:     */           }
/*  606:1235 */           if (CheckFor.CHECK_ALL.equals(fieldValueChangeOnConditionInfo.getCheckFor())) {
/*  607:1236 */             flag = true;
/*  608:     */           }
/*  609:     */         }
/*  610:1240 */         if ((CheckFor.CHECK_ALL.equals(fieldValueChangeOnConditionInfo.getCheckFor())) && (!flag))
/*  611:     */         {
/*  612:1241 */           returnValForAll = false;
/*  613:1242 */           break;
/*  614:     */         }
/*  615:1244 */         index++;
/*  616:     */       }
/*  617:     */     }
/*  618:1247 */     if (CheckFor.CHECK_ALL.equals(fieldValueChangeOnConditionInfo.getCheckFor())) {
/*  619:1248 */       isApplicable = returnValForAll;
/*  620:1249 */     } else if (CheckFor.CHECK_ANY.equals(fieldValueChangeOnConditionInfo.getCheckFor())) {
/*  621:1250 */       isApplicable = returnValForAny;
/*  622:     */     } else {
/*  623:1252 */       return false;
/*  624:     */     }
/*  625:1255 */     return isApplicable;
/*  626:     */   }
/*  627:     */   
/*  628:     */   public boolean hasValueChangedForFields(FieldValueChangeInfo fieldValueChangeInfo)
/*  629:     */     throws Exception
/*  630:     */   {
/*  631:1278 */     boolean isApplicable = false;
/*  632:1279 */     boolean returnValForAll = true;
/*  633:1280 */     boolean returnValForAny = false;
/*  634:1283 */     for (String field : fieldValueChangeInfo.getFieldNamesList())
/*  635:     */     {
/*  636:1285 */       boolean flag = false;
/*  637:1286 */       for (IField modifiedField : fieldValueChangeInfo.getModifiedFields()) {
/*  638:1288 */         if (modifiedField.getName().equals(field))
/*  639:     */         {
/*  640:1290 */           if (CheckFor.CHECK_ANY.equals(fieldValueChangeInfo.getCheckFor()))
/*  641:     */           {
/*  642:1291 */             returnValForAny = true;
/*  643:1292 */             break;
/*  644:     */           }
/*  645:1293 */           if (CheckFor.CHECK_ALL.equals(fieldValueChangeInfo.getCheckFor())) {
/*  646:1294 */             flag = true;
/*  647:     */           }
/*  648:     */         }
/*  649:1297 */         else if (CheckFor.CHECK_ALL.equals(fieldValueChangeInfo.getCheckFor()))
/*  650:     */         {
/*  651:1298 */           flag = false;
/*  652:1299 */           break;
/*  653:     */         }
/*  654:     */       }
/*  655:1303 */       if ((CheckFor.CHECK_ALL.equals(fieldValueChangeInfo.getCheckFor())) && (!flag))
/*  656:     */       {
/*  657:1304 */         returnValForAll = false;
/*  658:1305 */         break;
/*  659:     */       }
/*  660:     */     }
/*  661:1309 */     if (CheckFor.CHECK_ALL.equals(fieldValueChangeInfo.getCheckFor())) {
/*  662:1310 */       isApplicable = returnValForAll;
/*  663:1311 */     } else if (CheckFor.CHECK_ANY.equals(fieldValueChangeInfo.getCheckFor())) {
/*  664:1312 */       isApplicable = returnValForAny;
/*  665:     */     } else {
/*  666:1314 */       return false;
/*  667:     */     }
/*  668:1317 */     return isApplicable;
/*  669:     */   }
/*  670:     */   
/*  671:     */   public List<IField> getModifiedFields(IGRCObject object)
/*  672:     */     throws Exception
/*  673:     */   {
/*  674:1333 */     return ResourceUtil.getModifiedFields(object);
/*  675:     */   }
/*  676:     */   
/*  677:     */   public List<IField> getModifiedFieldsMatchingGivenFields(FieldValueChangeInfo fieldValueChangeInfo)
/*  678:     */     throws Exception
/*  679:     */   {
/*  680:1356 */     List<IField> changedFields = null;
/*  681:     */     
/*  682:     */ 
/*  683:1359 */     changedFields = new ArrayList();
/*  684:1361 */     for (Iterator i$ = fieldValueChangeInfo.getFieldNamesList().iterator(); i$.hasNext();)
/*  685:     */     {
/*  686:1361 */       field = (String)i$.next();
/*  687:1363 */       for (IField modifiedField : fieldValueChangeInfo.getModifiedFields()) {
/*  688:1365 */         if (modifiedField.getName().equals(field)) {
/*  689:1367 */           changedFields.add(modifiedField);
/*  690:     */         }
/*  691:     */       }
/*  692:     */     }
/*  693:     */     String field;
/*  694:1373 */     return changedFields;
/*  695:     */   }
/*  696:     */   
/*  697:     */   public List<String> getModifiedFieldsInfoMatchingGivenFields(FieldValueChangeInfo fieldValueChangeInfo)
/*  698:     */     throws Exception
/*  699:     */   {
/*  700:1396 */     List<String> changedFields = null;
/*  701:     */     
/*  702:     */ 
/*  703:1399 */     changedFields = new ArrayList();
/*  704:1401 */     for (Iterator i$ = fieldValueChangeInfo.getFieldNamesList().iterator(); i$.hasNext();)
/*  705:     */     {
/*  706:1401 */       field = (String)i$.next();
/*  707:1403 */       for (IField modifiedField : fieldValueChangeInfo.getModifiedFields()) {
/*  708:1405 */         if (modifiedField.getName().equals(field)) {
/*  709:1407 */           changedFields.add(modifiedField.getName());
/*  710:     */         }
/*  711:     */       }
/*  712:     */     }
/*  713:     */     String field;
/*  714:1413 */     return changedFields;
/*  715:     */   }
/*  716:     */   
/*  717:     */   public boolean compareFields(IField compareField1, String compareField2, String comparator)
/*  718:     */     throws Exception
/*  719:     */   {
/*  720:1433 */     return compareFields(getFieldValueAsString(compareField1), compareField2, compareField1.getDataType().toString(), comparator);
/*  721:     */   }
/*  722:     */   
/*  723:     */   public boolean compareFields(String compareFieldValue, IField compareField2, String comparator)
/*  724:     */     throws Exception
/*  725:     */   {
/*  726:1453 */     return compareFields(compareFieldValue, getFieldValueAsString(compareField2), compareField2.getDataType().toString(), comparator);
/*  727:     */   }
/*  728:     */   
/*  729:     */   public boolean compareFields(IField compareField1, IField compareField2, String comparator)
/*  730:     */     throws Exception
/*  731:     */   {
/*  732:1471 */     return compareFields(getFieldValueAsString(compareField1), getFieldValueAsString(compareField2), compareField1.getDataType().toString(), comparator);
/*  733:     */   }
/*  734:     */   
/*  735:     */   public boolean compareFields(String compareFieldValue1, String compareFieldValue2, String dataType, String comparator)
/*  736:     */     throws Exception
/*  737:     */   {
/*  738:1489 */     boolean isCompareField = false;
/*  739:1491 */     if ((DataType.FLOAT_TYPE.toString().equals(dataType)) || (DataType.INTEGER_TYPE.toString().equals(dataType)) || (DataType.CURRENCY_TYPE.toString().equals(dataType)))
/*  740:     */     {
/*  741:1495 */       isCompareField = NumericUtil.compareValues(compareFieldValue1, compareFieldValue2, Comparators.valueOf(comparator));
/*  742:     */     }
/*  743:1496 */     else if ((DataType.STRING_TYPE.toString().equals(dataType)) || (DataType.ENUM_TYPE.toString().equals(dataType)))
/*  744:     */     {
/*  745:1499 */       if (CommonUtil.isEqualIgnoreCase(Comparators.EQUAL.toString(), comparator)) {
/*  746:1501 */         isCompareField = CommonUtil.isEqualIgnoreCase(compareFieldValue1, compareFieldValue2);
/*  747:1502 */       } else if (CommonUtil.isEqualIgnoreCase(Comparators.NOT_EQUAL.toString(), comparator)) {
/*  748:1504 */         isCompareField = CommonUtil.isNotEqualIgnoreCase(compareFieldValue1, compareFieldValue2);
/*  749:     */       }
/*  750:     */     }
/*  751:1506 */     else if (DataType.DATE_TYPE.toString().equals(dataType))
/*  752:     */     {
/*  753:1508 */       Calendar calField1 = DateUtil.convertDateStringToCalendar(compareFieldValue1);
/*  754:1509 */       Calendar calField2 = DateUtil.convertDateStringToCalendar(compareFieldValue2);
/*  755:1511 */       if (CommonUtil.isEqualIgnoreCase(Comparators.LESSER_THAN.toString(), comparator)) {
/*  756:1512 */         isCompareField = calField2.compareTo(calField1) < 0;
/*  757:1513 */       } else if (CommonUtil.isEqualIgnoreCase(Comparators.LESSER_THAN_OR_EQUAL.toString(), comparator)) {
/*  758:1514 */         isCompareField = calField2.compareTo(calField1) <= 0;
/*  759:1515 */       } else if (CommonUtil.isEqualIgnoreCase(Comparators.GREATER_THAN.toString(), comparator)) {
/*  760:1516 */         isCompareField = calField2.compareTo(calField1) > 0;
/*  761:1517 */       } else if (CommonUtil.isEqualIgnoreCase(Comparators.GREATER_THAN_OR_EQUAL.toString(), comparator)) {
/*  762:1518 */         isCompareField = calField2.compareTo(calField1) >= 0;
/*  763:1519 */       } else if (CommonUtil.isEqualIgnoreCase(Comparators.EQUAL.toString(), comparator)) {
/*  764:1520 */         isCompareField = calField2.compareTo(calField1) == 0;
/*  765:1521 */       } else if (CommonUtil.isEqualIgnoreCase(Comparators.NOT_EQUAL.toString(), comparator)) {
/*  766:1522 */         isCompareField = calField2.compareTo(calField1) != 0;
/*  767:     */       }
/*  768:     */     }
/*  769:1525 */     else if (DataType.MULTI_VALUE_ENUM.toString().equals(dataType))
/*  770:     */     {
/*  771:1527 */       List<String> multiValues = new ArrayList();
/*  772:1528 */       multiValues = CommonUtil.parseCommaDelimitedValues(compareFieldValue2);
/*  773:1529 */       isCompareField = multiValues.contains(compareFieldValue1);
/*  774:     */     }
/*  775:1532 */     this.logger.debug("Returning: " + isCompareField);
/*  776:1533 */     return isCompareField;
/*  777:     */   }
/*  778:     */   
/*  779:     */   public List<String> getLocalizedLabelsForFields(IGRCObject object, List<String> fieldInfoList)
/*  780:     */   {
/*  781:1546 */     this.logger.debug("Object Name: " + object.getName());
/*  782:1547 */     this.logger.debug("Object Type: " + object.getType());
/*  783:1548 */     return getLocalizedLabelsForFields(object.getType(), fieldInfoList);
/*  784:     */   }
/*  785:     */   
/*  786:     */   public List<String> getLocalizedLabelsForFields(String objectType, List<String> fieldInfoList)
/*  787:     */   {
/*  788:1561 */     ITypeDefinition definition = null;
/*  789:1563 */     if (CommonUtil.isNotNullOrEmpty(objectType)) {
/*  790:1564 */       definition = this.serviceFactoryProxy.getServiceFactory().createMetaDataService().getType(objectType);
/*  791:     */     }
/*  792:1566 */     return getLocalizedLabelsForFields(definition, fieldInfoList);
/*  793:     */   }
/*  794:     */   
/*  795:     */   public List<String> getLocalizedLabelsForFields(ITypeDefinition objectType, List<String> fieldInfoList)
/*  796:     */   {
/*  797:1579 */     this.logger.debug("getLocalizedLabelsForFields() START");
/*  798:     */     
/*  799:1581 */     List<String> fieldLabelsList = new ArrayList();
/*  800:     */     Iterator i$;
/*  801:1583 */     if (CommonUtil.isObjectNotNull(objectType))
/*  802:     */     {
/*  803:1585 */       this.logger.debug("Object Type: " + objectType.getName());
/*  804:1586 */       this.logger.debug("Fields Info List: " + fieldInfoList);
/*  805:1588 */       for (i$ = fieldInfoList.iterator(); i$.hasNext();)
/*  806:     */       {
/*  807:1588 */         fieldName = (String)i$.next();
/*  808:     */         
/*  809:     */ 
/*  810:1591 */         fieldName = fieldName.trim();
/*  811:     */         
/*  812:1593 */         fieldName = fieldName.replaceFirst("System Fields:", "");
/*  813:1594 */         List<IFieldDefinition> iFieldDefinitions = objectType.getFieldsDefinition();
/*  814:1595 */         for (IFieldDefinition field : iFieldDefinitions) {
/*  815:1597 */           if (fieldName.equals(field.getName()))
/*  816:     */           {
/*  817:1599 */             this.logger.debug("Field Name in list: " + fieldName);
/*  818:1600 */             this.logger.debug("Field Name from object: " + field.getName());
/*  819:1601 */             this.logger.debug("Are fields equal: " + fieldName.equals(field.getName()));
/*  820:1602 */             fieldLabelsList.add(field.getLocalizedLabel());
/*  821:     */           }
/*  822:     */         }
/*  823:     */       }
/*  824:     */     }
/*  825:     */     String fieldName;
/*  826:1608 */     this.logger.debug("Localized labels obtained: " + fieldLabelsList);
/*  827:1609 */     this.logger.debug("getLocalizedLabelsForFields() END");
/*  828:1610 */     return fieldLabelsList;
/*  829:     */   }
/*  830:     */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.impl.FieldUtil
 * JD-Core Version:    0.7.0.1
 */