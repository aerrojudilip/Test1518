/*   1:    */ package com.ibm.openpages.ext.tss.service.impl;
/*   2:    */ 
/*   3:    */ import com.ibm.openpages.api.metadata.DataType;
/*   4:    */ import com.ibm.openpages.api.metadata.IEnumValue;
/*   5:    */ import com.ibm.openpages.api.metadata.IFieldDefinition;
/*   6:    */ import com.ibm.openpages.api.resource.IField;
/*   7:    */ import com.ibm.openpages.api.resource.IGRCObject;
/*   8:    */ import com.ibm.openpages.api.resource.IMultiEnumField;
/*   9:    */ import com.ibm.openpages.ext.tss.service.ILoggerUtil;
/*  10:    */ import com.ibm.openpages.ext.tss.service.IMultiEnumFieldUtil;
/*  11:    */ import com.ibm.openpages.ext.tss.service.constants.CheckFor;
/*  12:    */ import com.ibm.openpages.ext.tss.service.util.CommonUtil;
/*  13:    */ import java.util.ArrayList;
/*  14:    */ import java.util.List;
/*  15:    */ import javax.annotation.PostConstruct;
/*  16:    */ import org.apache.commons.logging.Log;
/*  17:    */ import org.springframework.beans.factory.annotation.Autowired;
/*  18:    */ import org.springframework.stereotype.Service;
/*  19:    */ 
/*  20:    */ @Service("multiEnumFieldUtil")
/*  21:    */ public class MultiEnumFieldUtil
/*  22:    */   implements IMultiEnumFieldUtil
/*  23:    */ {
/*  24:    */   private Log logger;
/*  25:    */   @Autowired
/*  26:    */   ILoggerUtil loggerUtil;
/*  27:    */   
/*  28:    */   @PostConstruct
/*  29:    */   public void initService()
/*  30:    */   {
/*  31: 60 */     this.logger = this.loggerUtil.getExtLogger();
/*  32:    */   }
/*  33:    */   
/*  34:    */   public IMultiEnumField getEnumField(IField field)
/*  35:    */     throws Exception
/*  36:    */   {
/*  37: 79 */     return DataType.MULTI_VALUE_ENUM.equals(field.getDataType()) ? (IMultiEnumField)field : null;
/*  38:    */   }
/*  39:    */   
/*  40:    */   public IMultiEnumField getEnumField(IGRCObject object, String fieldInfo)
/*  41:    */     throws Exception
/*  42:    */   {
/*  43: 99 */     return getEnumField(object.getField(fieldInfo));
/*  44:    */   }
/*  45:    */   
/*  46:    */   public boolean isEnumFieldNull(IField field)
/*  47:    */     throws Exception
/*  48:    */   {
/*  49:115 */     return CommonUtil.isObjectNull(getEnumField(field));
/*  50:    */   }
/*  51:    */   
/*  52:    */   public boolean isEnumFieldNull(IGRCObject object, String fieldInfo)
/*  53:    */     throws Exception
/*  54:    */   {
/*  55:134 */     return isEnumFieldNull(getEnumField(object, fieldInfo));
/*  56:    */   }
/*  57:    */   
/*  58:    */   public boolean isEnumFieldNotNull(IField field)
/*  59:    */     throws Exception
/*  60:    */   {
/*  61:150 */     return !isEnumFieldNull(field);
/*  62:    */   }
/*  63:    */   
/*  64:    */   public boolean isEnumFieldNotNull(IGRCObject object, String fieldInfo)
/*  65:    */     throws Exception
/*  66:    */   {
/*  67:169 */     return isEnumFieldNotNull(getEnumField(object, fieldInfo));
/*  68:    */   }
/*  69:    */   
/*  70:    */   public boolean isEnumFieldValueNull(IField field)
/*  71:    */     throws Exception
/*  72:    */   {
/*  73:185 */     return CommonUtil.isObjectNull(getEnumFieldValues(field));
/*  74:    */   }
/*  75:    */   
/*  76:    */   public boolean isEnumFieldValueNull(IGRCObject object, String fieldInfo)
/*  77:    */     throws Exception
/*  78:    */   {
/*  79:204 */     return isEnumFieldValueNull(getEnumField(object, fieldInfo));
/*  80:    */   }
/*  81:    */   
/*  82:    */   public boolean isEnumFieldValueNotNull(IField field)
/*  83:    */     throws Exception
/*  84:    */   {
/*  85:220 */     return !isEnumFieldValueNull(field);
/*  86:    */   }
/*  87:    */   
/*  88:    */   public boolean isEnumFieldValueNotNull(IGRCObject object, String fieldInfo)
/*  89:    */     throws Exception
/*  90:    */   {
/*  91:239 */     return isEnumFieldValueNotNull(getEnumField(object, fieldInfo));
/*  92:    */   }
/*  93:    */   
/*  94:    */   public List<IEnumValue> getEnumFieldValues(IField field)
/*  95:    */     throws Exception
/*  96:    */   {
/*  97:258 */     return isEnumFieldNotNull(field) ? getEnumField(field).getEnumValues() : null;
/*  98:    */   }
/*  99:    */   
/* 100:    */   public List<IEnumValue> getEnumFieldValues(IGRCObject object, String fieldInfo)
/* 101:    */     throws Exception
/* 102:    */   {
/* 103:277 */     return getEnumFieldValues(getEnumField(object, fieldInfo));
/* 104:    */   }
/* 105:    */   
/* 106:    */   public List<String> getEnumFieldSelectedValue(IField field)
/* 107:    */     throws Exception
/* 108:    */   {
/* 109:296 */     List<String> valuesAsString = null;
/* 110:297 */     List<IEnumValue> selectedValues = null;
/* 111:    */     
/* 112:299 */     valuesAsString = new ArrayList();
/* 113:300 */     selectedValues = getEnumFieldValues(field);
/* 114:302 */     for (IEnumValue enumValue : selectedValues) {
/* 115:304 */       valuesAsString.add(enumValue.getName());
/* 116:    */     }
/* 117:306 */     return valuesAsString;
/* 118:    */   }
/* 119:    */   
/* 120:    */   public List<String> getEnumFieldSelectedValue(IGRCObject object, String fieldInfo)
/* 121:    */     throws Exception
/* 122:    */   {
/* 123:325 */     return getEnumFieldSelectedValue(getEnumField(object, fieldInfo));
/* 124:    */   }
/* 125:    */   
/* 126:    */   public List<String> getAllValuesInEnumFieldAsList(IFieldDefinition fieldDefinition)
/* 127:    */     throws Exception
/* 128:    */   {
/* 129:344 */     List<String> enumValues = null;
/* 130:    */     
/* 131:346 */     enumValues = new ArrayList();
/* 132:347 */     List<IEnumValue> enumVals = fieldDefinition.getEnumValues();
/* 133:349 */     for (IEnumValue enumVal : enumVals) {
/* 134:351 */       enumValues.add(enumVal.getName());
/* 135:    */     }
/* 136:354 */     return enumValues;
/* 137:    */   }
/* 138:    */   
/* 139:    */   public List<String> getActiveValuesInEnumFieldAsList(IFieldDefinition fieldDefinition)
/* 140:    */     throws Exception
/* 141:    */   {
/* 142:373 */     List<String> enumValues = null;
/* 143:    */     
/* 144:375 */     enumValues = new ArrayList();
/* 145:376 */     List<IEnumValue> enumVals = fieldDefinition.getEnumValues();
/* 146:378 */     for (IEnumValue enumVal : enumVals) {
/* 147:380 */       if (!enumVal.isHidden()) {
/* 148:382 */         enumValues.add(enumVal.getName());
/* 149:    */       }
/* 150:    */     }
/* 151:386 */     return enumValues;
/* 152:    */   }
/* 153:    */   
/* 154:    */   public List<String> getHiddenValuesInEnumFieldAsList(IFieldDefinition fieldDefinition)
/* 155:    */     throws Exception
/* 156:    */   {
/* 157:405 */     List<String> enumValues = null;
/* 158:    */     
/* 159:407 */     enumValues = new ArrayList();
/* 160:408 */     List<IEnumValue> enumVals = fieldDefinition.getEnumValues();
/* 161:410 */     for (IEnumValue enumVal : enumVals) {
/* 162:412 */       if (enumVal.isHidden()) {
/* 163:414 */         enumValues.add(enumVal.getName());
/* 164:    */       }
/* 165:    */     }
/* 166:418 */     return enumValues;
/* 167:    */   }
/* 168:    */   
/* 169:    */   public List<String> getAllValuesInEnumFieldAsList(IField field)
/* 170:    */     throws Exception
/* 171:    */   {
/* 172:437 */     return getAllValuesInEnumFieldAsList(getEnumField(field).getFieldDefinition());
/* 173:    */   }
/* 174:    */   
/* 175:    */   public List<String> getAllValuesInEnumFieldAsList(IGRCObject object, String fieldInfo)
/* 176:    */     throws Exception
/* 177:    */   {
/* 178:456 */     return getAllValuesInEnumFieldAsList(getEnumField(object, fieldInfo));
/* 179:    */   }
/* 180:    */   
/* 181:    */   public List<String> getActiveValuesInEnumFieldAsList(IField field)
/* 182:    */     throws Exception
/* 183:    */   {
/* 184:475 */     return getAllValuesInEnumFieldAsList(getEnumField(field).getFieldDefinition());
/* 185:    */   }
/* 186:    */   
/* 187:    */   public List<String> getActiveValuesInEnumFieldAsList(IGRCObject object, String fieldInfo)
/* 188:    */     throws Exception
/* 189:    */   {
/* 190:495 */     return getAllValuesInEnumFieldAsList(getEnumField(object, fieldInfo));
/* 191:    */   }
/* 192:    */   
/* 193:    */   public List<String> getHiddenValuesInEnumFieldAsList(IField field)
/* 194:    */     throws Exception
/* 195:    */   {
/* 196:514 */     return getAllValuesInEnumFieldAsList(getEnumField(field).getFieldDefinition());
/* 197:    */   }
/* 198:    */   
/* 199:    */   public List<String> getHiddenValuesInEnumFieldAsList(IGRCObject object, String fieldInfo)
/* 200:    */     throws Exception
/* 201:    */   {
/* 202:534 */     return getAllValuesInEnumFieldAsList(getEnumField(object, fieldInfo));
/* 203:    */   }
/* 204:    */   
/* 205:    */   public boolean isEnumFieldValueMatchExpectedValue(IField field, String expectedFieldValue, CheckFor checkFor)
/* 206:    */     throws Exception
/* 207:    */   {
/* 208:557 */     boolean isMatch = false;
/* 209:558 */     List<String> exptedValues = null;
/* 210:559 */     List<String> enumFieldValues = null;
/* 211:    */     
/* 212:561 */     enumFieldValues = getEnumFieldSelectedValue(field);
/* 213:562 */     exptedValues = CommonUtil.parseDelimitedValues(expectedFieldValue, ",");
/* 214:564 */     if ((CommonUtil.isListNotNullOrEmpty(enumFieldValues)) && (CommonUtil.isListNotNullOrEmpty(exptedValues))) {
/* 215:566 */       isMatch = CommonUtil.isSelectedValuesMatchActualValues(getEnumFieldSelectedValue(field), exptedValues, checkFor);
/* 216:    */     }
/* 217:569 */     return isMatch;
/* 218:    */   }
/* 219:    */   
/* 220:    */   public boolean isEnumFieldValueMatchExpectedValue(IGRCObject object, String fieldInfo, String expectedFieldValue, CheckFor checkFor)
/* 221:    */     throws Exception
/* 222:    */   {
/* 223:592 */     return isEnumFieldValueMatchExpectedValue(getEnumField(object, fieldInfo), expectedFieldValue, checkFor);
/* 224:    */   }
/* 225:    */   
/* 226:    */   public void setEnumFieldValue(IField field, String setValue)
/* 227:    */     throws Exception
/* 228:    */   {
/* 229:611 */     List<IEnumValue> setValues = null;
/* 230:612 */     List<String> setValueList = null;
/* 231:613 */     List<IEnumValue> enumValues = null;
/* 232:    */     
/* 233:615 */     IMultiEnumField enumField = null;
/* 234:616 */     IFieldDefinition fieldDef = null;
/* 235:    */     
/* 236:618 */     enumField = getEnumField(field);
/* 237:619 */     fieldDef = field.getFieldDefinition();
/* 238:620 */     enumValues = fieldDef.getEnumValues();
/* 239:621 */     setValueList = CommonUtil.parseDelimitedValues(setValue, ",");
/* 240:623 */     if ((CommonUtil.isListNotNullOrEmpty(setValueList)) && (CommonUtil.isListNotNullOrEmpty(enumValues)))
/* 241:    */     {
/* 242:625 */       setValues = new ArrayList();
/* 243:627 */       for (IEnumValue val : enumValues)
/* 244:    */       {
/* 245:629 */         String name = val.getName();
/* 246:630 */         this.logger.debug("Value in the Multi Enumerated field: " + name);
/* 247:631 */         this.logger.debug("Is " + name + " Equal to " + setValue + ": " + name.equals(setValue));
/* 248:633 */         if (setValueList.contains(name)) {
/* 249:635 */           setValues.add(val);
/* 250:    */         }
/* 251:    */       }
/* 252:    */     }
/* 253:640 */     setEnumFieldValue(enumField, setValues);
/* 254:    */   }
/* 255:    */   
/* 256:    */   public void setEnumFieldValue(IGRCObject object, String fieldInfo, String setValue)
/* 257:    */     throws Exception
/* 258:    */   {
/* 259:661 */     setEnumFieldValue(getEnumField(object, fieldInfo), setValue);
/* 260:    */   }
/* 261:    */   
/* 262:    */   public void setEnumFieldValue(IField field, List<IEnumValue> setValues)
/* 263:    */     throws Exception
/* 264:    */   {
/* 265:682 */     if (CommonUtil.isListNotNullOrEmpty(setValues)) {
/* 266:683 */       getEnumField(field).setEnumValues(setValues);
/* 267:    */     }
/* 268:    */   }
/* 269:    */   
/* 270:    */   public void setEnumFieldValue(IGRCObject object, String fieldInfo, List<IEnumValue> setValues)
/* 271:    */     throws Exception
/* 272:    */   {
/* 273:704 */     setEnumFieldValue(getEnumField(object, fieldInfo), setValues);
/* 274:    */   }
/* 275:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.impl.MultiEnumFieldUtil
 * JD-Core Version:    0.7.0.1
 */