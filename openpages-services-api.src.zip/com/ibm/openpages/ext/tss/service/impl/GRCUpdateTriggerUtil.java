/*   1:    */ package com.ibm.openpages.ext.tss.service.impl;
/*   2:    */ 
/*   3:    */ import com.ibm.openpages.ext.tss.service.IFieldUtil;
/*   4:    */ import com.ibm.openpages.ext.tss.service.IGRCObjectSearchUtil;
/*   5:    */ import com.ibm.openpages.ext.tss.service.IGRCUpdateTriggerUtil;
/*   6:    */ import com.ibm.openpages.ext.tss.service.ILoggerUtil;
/*   7:    */ import com.ibm.openpages.ext.tss.service.beans.IGRCObjectUpdateInformation;
/*   8:    */ import com.ibm.openpages.ext.tss.service.util.CommonUtil;
/*   9:    */ import java.util.ArrayList;
/*  10:    */ import java.util.List;
/*  11:    */ import javax.annotation.PostConstruct;
/*  12:    */ import org.apache.commons.logging.Log;
/*  13:    */ import org.springframework.beans.factory.annotation.Autowired;
/*  14:    */ import org.springframework.stereotype.Service;
/*  15:    */ 
/*  16:    */ @Service("grcUpdateTriggerUtil")
/*  17:    */ public class GRCUpdateTriggerUtil
/*  18:    */   implements IGRCUpdateTriggerUtil
/*  19:    */ {
/*  20:    */   private Log logger;
/*  21:    */   @Autowired
/*  22:    */   ILoggerUtil loggerUtil;
/*  23:    */   @Autowired
/*  24:    */   IFieldUtil fieldUtil;
/*  25:    */   @Autowired
/*  26:    */   IGRCObjectSearchUtil objectSearchUtil;
/*  27:    */   
/*  28:    */   @PostConstruct
/*  29:    */   public void initService()
/*  30:    */   {
/*  31: 64 */     this.logger = this.loggerUtil.getExtLogger();
/*  32:    */   }
/*  33:    */   
/*  34:    */   public boolean updateObject(IGRCObjectUpdateInformation objectUpdateInformation)
/*  35:    */   {
/*  36: 77 */     initService();
/*  37: 78 */     boolean isUpdate = false;
/*  38:    */     
/*  39: 80 */     this.logger.error("START: updateObject()");
/*  40: 81 */     this.logger.error("Updating Object with this information: " + objectUpdateInformation.toString());
/*  41: 83 */     if (objectUpdateInformation.isUpdateInObject()) {
/*  42: 85 */       if (objectUpdateInformation.isUpdateFieldToField()) {
/*  43: 87 */         isUpdate = processObjectFieldToFieldUpdate(objectUpdateInformation);
/*  44:    */       } else {
/*  45: 91 */         isUpdate = processObjectUpdate(objectUpdateInformation);
/*  46:    */       }
/*  47:    */     }
/*  48: 95 */     this.logger.error("Has update been successfull: " + isUpdate);
/*  49: 96 */     this.logger.error("END: updateObject()");
/*  50: 97 */     return isUpdate;
/*  51:    */   }
/*  52:    */   
/*  53:    */   private boolean processObjectUpdate(IGRCObjectUpdateInformation objectUpdateInformation)
/*  54:    */   {
/*  55:102 */     int index = 0;
/*  56:103 */     boolean isUpdate = false;
/*  57:    */     
/*  58:105 */     List<List<?>> listsInformation = null;
/*  59:    */     try
/*  60:    */     {
/*  61:109 */       this.logger.error("START: processObjectUpdate()");
/*  62:110 */       listsInformation = new ArrayList();
/*  63:111 */       listsInformation.add(objectUpdateInformation.getUpdateFieldsList());
/*  64:112 */       listsInformation.add(objectUpdateInformation.getUpdateValuesList());
/*  65:114 */       if (CommonUtil.isListsOfTheSameSize(listsInformation))
/*  66:    */       {
/*  67:117 */         for (String updateField : objectUpdateInformation.getUpdateFieldsList())
/*  68:    */         {
/*  69:119 */           this.fieldUtil.setFieldValue(objectUpdateInformation.getSourceObject(), updateField, (String)objectUpdateInformation.getUpdateValuesList().get(index));
/*  70:120 */           index++;
/*  71:    */         }
/*  72:123 */         isUpdate = true;
/*  73:    */       }
/*  74:    */     }
/*  75:    */     catch (Exception ex)
/*  76:    */     {
/*  77:128 */       isUpdate = false;
/*  78:129 */       this.logger.error("Exception!!!!!!" + CommonUtil.getStackTrace(ex));
/*  79:    */     }
/*  80:132 */     this.logger.error("Has update object been successful: " + isUpdate);
/*  81:133 */     this.logger.error("END: processObjectUpdate()");
/*  82:134 */     return isUpdate;
/*  83:    */   }
/*  84:    */   
/*  85:    */   private boolean processObjectFieldToFieldUpdate(IGRCObjectUpdateInformation objectUpdateInformation)
/*  86:    */   {
/*  87:139 */     int index = 0;
/*  88:140 */     boolean isUpdate = false;
/*  89:    */     
/*  90:142 */     List<List<?>> listsInformation = null;
/*  91:    */     try
/*  92:    */     {
/*  93:146 */       this.logger.error("START: processObjectFieldToFieldUpdate()");
/*  94:147 */       listsInformation = new ArrayList();
/*  95:148 */       listsInformation.add(objectUpdateInformation.getUpdateFieldsList());
/*  96:149 */       listsInformation.add(objectUpdateInformation.getSourceFieldsList());
/*  97:151 */       if (CommonUtil.isListsOfTheSameSize(listsInformation))
/*  98:    */       {
/*  99:153 */         for (String updateField : objectUpdateInformation.getUpdateFieldsList())
/* 100:    */         {
/* 101:155 */           String updateValue = this.fieldUtil.getFieldValueAsString(objectUpdateInformation.getSourceObject(), (String)objectUpdateInformation.getSourceFieldsList().get(index));
/* 102:156 */           this.fieldUtil.setFieldValue(objectUpdateInformation.getSourceObject(), updateField, updateValue);
/* 103:158 */           if (objectUpdateInformation.isResetSourceInObject()) {
/* 104:159 */             this.fieldUtil.setFieldValueWithNull(objectUpdateInformation.getSourceObject(), updateField);
/* 105:    */           }
/* 106:160 */           index++;
/* 107:    */         }
/* 108:163 */         isUpdate = true;
/* 109:    */       }
/* 110:    */     }
/* 111:    */     catch (Exception ex)
/* 112:    */     {
/* 113:168 */       isUpdate = false;
/* 114:169 */       this.logger.error("Exception!!!!!!" + CommonUtil.getStackTrace(ex));
/* 115:    */     }
/* 116:172 */     this.logger.error("Has update object field to field been successful: " + isUpdate);
/* 117:173 */     this.logger.error("END: processObjectFieldToFieldUpdate()");
/* 118:174 */     return isUpdate;
/* 119:    */   }
/* 120:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.impl.GRCUpdateTriggerUtil
 * JD-Core Version:    0.7.0.1
 */