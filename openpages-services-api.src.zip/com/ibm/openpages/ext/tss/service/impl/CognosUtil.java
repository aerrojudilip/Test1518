/*   1:    */ package com.ibm.openpages.ext.tss.service.impl;
/*   2:    */ 
/*   3:    */ import com.cognos.developer.schemas.bibus._3.ContentManagerService_PortType;
/*   4:    */ import com.cognos.developer.schemas.bibus._3.ParameterValue;
/*   5:    */ import com.cognos.developer.schemas.bibus._3.ReportService_PortType;
/*   6:    */ import com.ibm.openpages.ext.tss.service.ICognosUtil;
/*   7:    */ import com.ibm.openpages.ext.tss.service.ILoggerUtil;
/*   8:    */ import com.ibm.openpages.ext.tss.service.proxy.IOPSessionProxy;
/*   9:    */ import com.ibm.openpages.ext.tss.service.util.CommonUtil;
/*  10:    */ import com.openpages.aurora.cognos.CognosCSVReportOutputReader;
/*  11:    */ import com.openpages.aurora.cognos.CognosComputationHelper;
/*  12:    */ import com.openpages.aurora.cognos.CognosReportExecOptions;
/*  13:    */ import com.openpages.aurora.cognos.CognosReportsUtil;
/*  14:    */ import com.openpages.aurora.cognos.ICognosReportOutputReader;
/*  15:    */ import com.openpages.sdk.OpenpagesSession;
/*  16:    */ import com.openpages.sdk.admin.registry.Registry;
/*  17:    */ import java.io.File;
/*  18:    */ import java.io.FileInputStream;
/*  19:    */ import java.util.ArrayList;
/*  20:    */ import java.util.HashMap;
/*  21:    */ import java.util.LinkedHashMap;
/*  22:    */ import java.util.List;
/*  23:    */ import java.util.Map;
/*  24:    */ import javax.annotation.PostConstruct;
/*  25:    */ import org.apache.commons.logging.Log;
/*  26:    */ import org.jdom.Document;
/*  27:    */ import org.jdom.Element;
/*  28:    */ import org.jdom.Namespace;
/*  29:    */ import org.jdom.input.SAXBuilder;
/*  30:    */ import org.springframework.beans.factory.annotation.Autowired;
/*  31:    */ import org.springframework.stereotype.Service;
/*  32:    */ 
/*  33:    */ @Service("cognosUtil")
/*  34:    */ public class CognosUtil
/*  35:    */   implements ICognosUtil
/*  36:    */ {
/*  37:    */   private Log logger;
/*  38:    */   private static final int DEFAULT_RETRY_ATTEMPTS = 5;
/*  39:    */   private static final int DEFAULT_RETRY_WAIT_MILLISECONDS = 60000;
/*  40:    */   @Autowired
/*  41:    */   IOPSessionProxy opSessionProxy;
/*  42:    */   @Autowired
/*  43:    */   ILoggerUtil loggerUtil;
/*  44:    */   
/*  45:    */   @PostConstruct
/*  46:    */   public void initService()
/*  47:    */   {
/*  48: 64 */     this.logger = this.loggerUtil.getExtLogger();
/*  49:    */   }
/*  50:    */   
/*  51:    */   public String getReportPathForRegistry(String reportPath)
/*  52:    */     throws Exception
/*  53:    */   {
/*  54: 72 */     StringBuffer retVal = null;
/*  55: 73 */     String[] myPath = null;
/*  56:    */     
/*  57:    */ 
/*  58: 76 */     retVal = new StringBuffer("/content/");
/*  59: 77 */     myPath = reportPath.split("\\\\");
/*  60: 79 */     for (int i = 0; i < myPath.length - 1; i++) {
/*  61: 82 */       retVal.append("folder[@name='").append(myPath[i]).append("']/");
/*  62:    */     }
/*  63: 85 */     retVal.append("report[@name='").append(myPath[(myPath.length - 1)]).append("']");
/*  64:    */     
/*  65: 87 */     return retVal.toString();
/*  66:    */   }
/*  67:    */   
/*  68:    */   public String getCognosOutputPath(String reportPath, Map<String, String[]> reportParams, String outputFormat)
/*  69:    */   {
/*  70: 95 */     assert (outputFormat != null);
/*  71: 96 */     assert (reportParams != null);
/*  72: 97 */     assert (reportPath != null);
/*  73:    */     
/*  74: 99 */     assert ((outputFormat.equalsIgnoreCase("CSV")) || (outputFormat.equalsIgnoreCase("XML")));
/*  75:    */     try
/*  76:    */     {
/*  77:106 */       return invokeCognosReport(reportPath, reportParams, outputFormat);
/*  78:    */     }
/*  79:    */     catch (Exception e)
/*  80:    */     {
/*  81:110 */       this.logger.error("Error occurred while getting cognos output path" + CommonUtil.getStackTrace(e));
/*  82:    */     }
/*  83:114 */     return null;
/*  84:    */   }
/*  85:    */   
/*  86:    */   private String invokeCognosReport(String reportPath, Map<String, String[]> paramMap, String outputFormat)
/*  87:    */     throws Exception
/*  88:    */   {
/*  89:134 */     this.logger.debug("Entering invokeCognosReport");
/*  90:    */     
/*  91:136 */     CognosReportExecOptions cognosExecOptions = new CognosReportExecOptions();
/*  92:137 */     cognosExecOptions.setOutputFormat(outputFormat);
/*  93:    */     
/*  94:139 */     int maxAttemptNumber = 5;
/*  95:140 */     int sleepTimerMilliSec = 60000;
/*  96:142 */     if (paramMap == null) {
/*  97:144 */       paramMap = new HashMap();
/*  98:    */     }
/*  99:147 */     OpenpagesSession opSession = this.opSessionProxy.getOpenpagesSession();
/* 100:148 */     ReportService_PortType reportServicePortType = CognosReportsUtil.getReportPort(opSession);
/* 101:    */     
/* 102:150 */     ContentManagerService_PortType cognosPort = CognosReportsUtil.getCognosPort(opSession);
/* 103:    */     
/* 104:152 */     this.logger.debug("ParamMap is " + paramMap.toString());
/* 105:153 */     ParameterValue[] reportParams = CognosComputationHelper.createCognosParameters(paramMap);
/* 106:    */     
/* 107:155 */     this.logger.debug("Report params " + reportParams);
/* 108:156 */     boolean isSuccess = false;
/* 109:157 */     int attemptNumber = 1;
/* 110:158 */     String reportOutputPath = null;
/* 111:160 */     while (!isSuccess) {
/* 112:    */       try
/* 113:    */       {
/* 114:165 */         this.logger.debug("Attempt #: " + attemptNumber);
/* 115:166 */         reportOutputPath = CognosComputationHelper.executeReport(reportPath, cognosExecOptions, reportParams, reportServicePortType, cognosPort);
/* 116:    */         
/* 117:    */ 
/* 118:169 */         this.logger.debug("Query Output Path: " + reportOutputPath);
/* 119:170 */         isSuccess = true;
/* 120:    */       }
/* 121:    */       catch (Exception e)
/* 122:    */       {
/* 123:175 */         this.logger.error(e.getMessage());
/* 124:178 */         if (attemptNumber >= maxAttemptNumber) {
/* 125:180 */           throw e;
/* 126:    */         }
/* 127:185 */         Thread.sleep(sleepTimerMilliSec);
/* 128:    */         
/* 129:    */ 
/* 130:188 */         attemptNumber++;
/* 131:    */       }
/* 132:    */     }
/* 133:191 */     this.logger.debug("Exiting invokeCognosReport2");
/* 134:192 */     return reportOutputPath;
/* 135:    */   }
/* 136:    */   
/* 137:    */   public Map<Integer, List<String>> getCognosOutputMap(String reportPath, Map<String, String[]> reportParams)
/* 138:    */   {
/* 139:199 */     this.logger.debug("Entering getCognosOutputMap");
/* 140:    */     
/* 141:201 */     Map<Integer, List<String>> map = new LinkedHashMap();
/* 142:    */     try
/* 143:    */     {
/* 144:205 */       String pathToReport = invokeCognosReport(reportPath, reportParams, "CSV");
/* 145:    */       
/* 146:207 */       String csvDelim = Registry.getStringValue("/OpenPages/Platform/Reporting/Report Output/CSV/Field Delimiter", null);
/* 147:    */       
/* 148:    */ 
/* 149:    */ 
/* 150:211 */       ICognosReportOutputReader reportOutputReader = new CognosCSVReportOutputReader(pathToReport);
/* 151:    */       
/* 152:213 */       reportOutputReader.setDeleteOutputFileOnClose(true);
/* 153:214 */       reportOutputReader.init();
/* 154:215 */       String dataRow = reportOutputReader.getNextRow();
/* 155:216 */       int i = 0;
/* 156:217 */       while (dataRow != null)
/* 157:    */       {
/* 158:219 */         String[] values = dataRow.split(csvDelim);
/* 159:    */         
/* 160:221 */         List<String> list = new ArrayList(values.length);
/* 161:222 */         for (String s : values) {
/* 162:224 */           list.add(s);
/* 163:    */         }
/* 164:226 */         map.put(Integer.valueOf(i++), list);
/* 165:227 */         dataRow = reportOutputReader.getNextRow();
/* 166:    */       }
/* 167:231 */       reportOutputReader.close();
/* 168:    */     }
/* 169:    */     catch (Exception e)
/* 170:    */     {
/* 171:236 */       this.logger.error("An error occurred while retrieving the results from cognos report " + CommonUtil.getStackTrace(e));
/* 172:    */     }
/* 173:241 */     this.logger.debug("Exiting getMapFromCSV");
/* 174:242 */     return map;
/* 175:    */   }
/* 176:    */   
/* 177:    */   public List<Element> getCognosResultsAsXMLRows(String reportPath, Map<String, String[]> parametersMap)
/* 178:    */     throws Exception
/* 179:    */   {
/* 180:259 */     String pathToCognosResultAsXML = null;
/* 181:    */     
/* 182:261 */     List<Element> xmlRows = null;
/* 183:    */     
/* 184:263 */     Element data = null;
/* 185:264 */     File outputFile = null;
/* 186:265 */     Element dataset = null;
/* 187:266 */     Document document = null;
/* 188:267 */     SAXBuilder builder = null;
/* 189:268 */     Namespace cognosNamespace = null;
/* 190:269 */     FileInputStream inputStream = null;
/* 191:    */     
/* 192:271 */     pathToCognosResultAsXML = getCognosOutputPath(reportPath, parametersMap, "XML");
/* 193:274 */     if (!CommonUtil.isNullOrEmpty(pathToCognosResultAsXML))
/* 194:    */     {
/* 195:281 */       builder = new SAXBuilder(false);
/* 196:282 */       outputFile = new File(pathToCognosResultAsXML);
/* 197:283 */       inputStream = new FileInputStream(outputFile);
/* 198:284 */       cognosNamespace = Namespace.getNamespace("http://developer.cognos.com/schemas/xmldata/1/");
/* 199:    */       
/* 200:    */ 
/* 201:    */ 
/* 202:    */ 
/* 203:    */ 
/* 204:    */ 
/* 205:291 */       document = builder.build(inputStream);
/* 206:292 */       dataset = document.getRootElement();
/* 207:293 */       data = dataset.getChild("data", cognosNamespace);
/* 208:295 */       if (!CommonUtil.isObjectNull(data)) {
/* 209:298 */         xmlRows = data.getChildren("row", cognosNamespace);
/* 210:    */       }
/* 211:    */     }
/* 212:302 */     return xmlRows;
/* 213:    */   }
/* 214:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.impl.CognosUtil
 * JD-Core Version:    0.7.0.1
 */