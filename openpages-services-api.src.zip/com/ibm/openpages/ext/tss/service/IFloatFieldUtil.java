package com.ibm.openpages.ext.tss.service;

import com.ibm.openpages.api.resource.IField;
import com.ibm.openpages.api.resource.IFloatField;
import com.ibm.openpages.api.resource.IGRCObject;

public abstract interface IFloatFieldUtil
{
  public abstract void initService();
  
  public abstract IFloatField getFloatField(IField paramIField)
    throws Exception;
  
  public abstract IFloatField getFloatField(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract boolean isFloatFieldNull(IField paramIField)
    throws Exception;
  
  public abstract boolean isFloatFieldNull(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract boolean isFloatFieldNotNull(IField paramIField)
    throws Exception;
  
  public abstract boolean isFloatFieldNotNull(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract boolean isFloatFieldValueNull(IField paramIField)
    throws Exception;
  
  public abstract boolean isFloatFieldValueNull(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract boolean isFloatFieldValueNotNull(IField paramIField)
    throws Exception;
  
  public abstract boolean isFloatFieldValueNotNull(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract String getFloatFieldValueAsString(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract String getFloatFieldValueAsString(IField paramIField)
    throws Exception;
  
  public abstract Double getFloatFieldValue(IField paramIField)
    throws Exception;
  
  public abstract Double getFloatFieldValue(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract float getFloatFieldValueAsFloat(IField paramIField)
    throws Exception;
  
  public abstract float getFloatFieldValueAsFloat(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract double getFloatFieldValueAsDouble(IField paramIField)
    throws Exception;
  
  public abstract double getFloatFieldValueAsDouble(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract long getFloatFieldValueAsLong(IField paramIField)
    throws Exception;
  
  public abstract long getFloatFieldValueAsLong(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract long getFloatFieldValueAsInt(IField paramIField)
    throws Exception;
  
  public abstract long getFloatFieldValueAsInt(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract void setFloatField(IGRCObject paramIGRCObject, String paramString1, String paramString2)
    throws Exception;
  
  public abstract void setFloatField(IGRCObject paramIGRCObject, String paramString, Double paramDouble)
    throws Exception;
  
  public abstract void setFloatField(IFloatField paramIFloatField, String paramString)
    throws Exception;
  
  public abstract void setFloatField(IFloatField paramIFloatField, Double paramDouble)
    throws Exception;
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.IFloatFieldUtil
 * JD-Core Version:    0.7.0.1
 */