/*  1:   */ package com.ibm.openpages.ext.tss.service.logging;
/*  2:   */ 
/*  3:   */ import org.apache.commons.logging.impl.LogFactoryImpl;
/*  4:   */ 
/*  5:   */ public class EXTLoggerFactoryImpl
/*  6:   */   extends LogFactoryImpl
/*  7:   */ {
/*  8:   */   private String logClassName;
/*  9:   */   
/* 10:   */   protected String getLogClassName()
/* 11:   */   {
/* 12:17 */     if (this.logClassName != null) {
/* 13:18 */       return this.logClassName;
/* 14:   */     }
/* 15:21 */     this.logClassName = "com.ibm.openpages.ext.tss.service.logging.EXTLogger";
/* 16:   */     
/* 17:23 */     return this.logClassName;
/* 18:   */   }
/* 19:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.logging.EXTLoggerFactoryImpl
 * JD-Core Version:    0.7.0.1
 */