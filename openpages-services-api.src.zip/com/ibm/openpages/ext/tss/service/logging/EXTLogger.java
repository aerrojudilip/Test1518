/*   1:    */ package com.ibm.openpages.ext.tss.service.logging;
/*   2:    */ 
/*   3:    */ import com.openpages.aurora.common.Environment;
/*   4:    */ import com.openpages.sdk.admin.registry.Registry;
/*   5:    */ import java.io.File;
/*   6:    */ import org.apache.commons.logging.Log;
/*   7:    */ import org.apache.log4j.Level;
/*   8:    */ import org.apache.log4j.Logger;
/*   9:    */ import org.apache.log4j.PatternLayout;
/*  10:    */ import org.apache.log4j.RollingFileAppender;
/*  11:    */ 
/*  12:    */ public final class EXTLogger
/*  13:    */   implements Log
/*  14:    */ {
/*  15:    */   private static final String DEBUG_LEVEL_REGISTRY_ENTRY = "/OpenPages/Custom Deliverables/Logging/Level";
/*  16: 27 */   private static final String FILE_SEPARATOR = System.getProperty("file.separator");
/*  17: 30 */   private static final String OPENPAGES_HOME = Environment.getOpenpagesHomeDir();
/*  18: 33 */   private static final String LOG_DIR = OPENPAGES_HOME + FILE_SEPARATOR + "aurora" + FILE_SEPARATOR + "logs" + FILE_SEPARATOR + "ext";
/*  19:    */   private static final boolean APPEND = true;
/*  20:    */   private static final String DEFAULT_PATTERN = "%d{yyyy-MM-dd HH:mm:ss,SSS} %-5p [%t]:%l %n %m%n";
/*  21:    */   private static final String LOG_FILENAME = "services.log";
/*  22:    */   private static final int MAX_LOG_BACKUP_FILES = 25;
/*  23:    */   private static final String MAX_LOG_FILE_SIZE = "2048KB";
/*  24:    */   private static final int LOG_IO_BUFFER_SIZE_BYTES = 1024;
/*  25: 51 */   private String file = null;
/*  26: 56 */   private static final String FQCN = EXTLogger.class.getName();
/*  27: 59 */   private Logger logger = null;
/*  28:    */   
/*  29:    */   public EXTLogger() {}
/*  30:    */   
/*  31:    */   private void addAppenders()
/*  32:    */     throws Exception
/*  33:    */   {
/*  34: 70 */     File logDir = new File(LOG_DIR);
/*  35: 71 */     logDir.mkdirs();
/*  36:    */     
/*  37: 73 */     String logfilename = "services.log";
/*  38: 74 */     if ((this.logger.getName() != null) && (!this.logger.getName().equalsIgnoreCase("com.ibm.openpages.ext.tss.service.logging.EXTLogger"))) {
/*  39: 78 */       logfilename = this.logger.getName();
/*  40:    */     }
/*  41: 80 */     File logFile = new File(logDir, String.format("%s%s", new Object[] { FILE_SEPARATOR, logfilename }));
/*  42:    */     
/*  43:    */ 
/*  44: 83 */     this.file = logFile.getCanonicalPath();
/*  45:    */     
/*  46: 85 */     PatternLayout layout = new PatternLayout("%d{yyyy-MM-dd HH:mm:ss,SSS} %-5p [%t]:%l %n %m%n");
/*  47:    */     
/*  48: 87 */     RollingFileAppender rollingFileAppender = new RollingFileAppender(layout, this.file, true);
/*  49:    */     
/*  50:    */ 
/*  51:    */ 
/*  52: 91 */     rollingFileAppender.setName(this.logger.getName());
/*  53:    */     
/*  54:    */ 
/*  55:    */ 
/*  56:    */ 
/*  57:    */ 
/*  58: 97 */     rollingFileAppender.setImmediateFlush(true);
/*  59: 98 */     rollingFileAppender.setBufferedIO(false);
/*  60: 99 */     rollingFileAppender.setBufferSize(1024);
/*  61:    */     
/*  62:    */ 
/*  63:    */ 
/*  64:    */ 
/*  65:104 */     rollingFileAppender.setMaxBackupIndex(25);
/*  66:105 */     rollingFileAppender.setMaxFileSize("2048KB");
/*  67:    */     
/*  68:    */ 
/*  69:108 */     this.logger.addAppender(rollingFileAppender);
/*  70:    */   }
/*  71:    */   
/*  72:    */   public EXTLogger(String name)
/*  73:    */   {
/*  74:118 */     this.logger = Logger.getLogger(name);
/*  75:119 */     if (!this.logger.isAttached(this.logger.getAppender(this.logger.getName()))) {
/*  76:    */       try
/*  77:    */       {
/*  78:123 */         addAppenders();
/*  79:    */       }
/*  80:    */       catch (Exception e)
/*  81:    */       {
/*  82:128 */         e.printStackTrace();
/*  83:    */       }
/*  84:    */     }
/*  85:    */   }
/*  86:    */   
/*  87:    */   public EXTLogger(Logger logger)
/*  88:    */   {
/*  89:140 */     if (!logger.isAttached(logger.getAppender(logger.getName()))) {
/*  90:    */       try
/*  91:    */       {
/*  92:144 */         addAppenders();
/*  93:    */       }
/*  94:    */       catch (Exception e)
/*  95:    */       {
/*  96:149 */         e.printStackTrace();
/*  97:    */       }
/*  98:    */     }
/*  99:    */   }
/* 100:    */   
/* 101:    */   public void trace(Object message)
/* 102:    */   {
/* 103:163 */     this.logger.setLevel(getLogLevel());
/* 104:164 */     this.logger.log(FQCN, Level.DEBUG, message, null);
/* 105:    */   }
/* 106:    */   
/* 107:    */   public void trace(Object message, Throwable t)
/* 108:    */   {
/* 109:174 */     this.logger.setLevel(getLogLevel());
/* 110:175 */     this.logger.log(FQCN, Level.DEBUG, message, t);
/* 111:    */   }
/* 112:    */   
/* 113:    */   public void debug(Object message)
/* 114:    */   {
/* 115:185 */     this.logger.setLevel(getLogLevel());
/* 116:186 */     this.logger.log(FQCN, Level.DEBUG, message, null);
/* 117:    */   }
/* 118:    */   
/* 119:    */   public void debug(Object message, Throwable t)
/* 120:    */   {
/* 121:197 */     this.logger.setLevel(getLogLevel());
/* 122:198 */     this.logger.log(FQCN, Level.DEBUG, message, null);
/* 123:    */   }
/* 124:    */   
/* 125:    */   public void info(Object message)
/* 126:    */   {
/* 127:208 */     this.logger.setLevel(getLogLevel());
/* 128:209 */     this.logger.log(FQCN, Level.INFO, message, null);
/* 129:    */   }
/* 130:    */   
/* 131:    */   public void info(Object message, Throwable t)
/* 132:    */   {
/* 133:218 */     this.logger.setLevel(getLogLevel());
/* 134:219 */     this.logger.log(FQCN, Level.INFO, message, t);
/* 135:    */   }
/* 136:    */   
/* 137:    */   public void warn(Object message)
/* 138:    */   {
/* 139:228 */     this.logger.setLevel(getLogLevel());
/* 140:229 */     this.logger.log(FQCN, Level.WARN, message, null);
/* 141:    */   }
/* 142:    */   
/* 143:    */   public void warn(Object message, Throwable t)
/* 144:    */   {
/* 145:238 */     this.logger.setLevel(getLogLevel());
/* 146:239 */     this.logger.log(FQCN, Level.WARN, message, t);
/* 147:    */   }
/* 148:    */   
/* 149:    */   public void error(Object message)
/* 150:    */   {
/* 151:248 */     this.logger.setLevel(getLogLevel());
/* 152:249 */     this.logger.log(FQCN, Level.ERROR, message, null);
/* 153:    */   }
/* 154:    */   
/* 155:    */   public void error(Object message, Throwable t)
/* 156:    */   {
/* 157:258 */     this.logger.setLevel(getLogLevel());
/* 158:259 */     this.logger.log(FQCN, Level.ERROR, message, t);
/* 159:    */   }
/* 160:    */   
/* 161:    */   public void fatal(Object message)
/* 162:    */   {
/* 163:268 */     this.logger.setLevel(getLogLevel());
/* 164:269 */     this.logger.log(FQCN, Level.FATAL, message, null);
/* 165:    */   }
/* 166:    */   
/* 167:    */   public void fatal(Object message, Throwable t)
/* 168:    */   {
/* 169:278 */     this.logger.setLevel(getLogLevel());
/* 170:279 */     this.logger.log(FQCN, Level.FATAL, message, t);
/* 171:    */   }
/* 172:    */   
/* 173:    */   public boolean isDebugEnabled()
/* 174:    */   {
/* 175:289 */     return getLogLevel().toInt() == Level.DEBUG.toInt();
/* 176:    */   }
/* 177:    */   
/* 178:    */   public boolean isErrorEnabled()
/* 179:    */   {
/* 180:299 */     return getLogLevel().toInt() == Level.ERROR.toInt();
/* 181:    */   }
/* 182:    */   
/* 183:    */   public boolean isFatalEnabled()
/* 184:    */   {
/* 185:309 */     return getLogLevel().toInt() == Level.FATAL.toInt();
/* 186:    */   }
/* 187:    */   
/* 188:    */   public boolean isInfoEnabled()
/* 189:    */   {
/* 190:319 */     return getLogLevel().toInt() == Level.INFO.toInt();
/* 191:    */   }
/* 192:    */   
/* 193:    */   public boolean isTraceEnabled()
/* 194:    */   {
/* 195:330 */     return getLogLevel().toInt() == Level.DEBUG.toInt();
/* 196:    */   }
/* 197:    */   
/* 198:    */   public boolean isWarnEnabled()
/* 199:    */   {
/* 200:340 */     return getLogLevel().toInt() == Level.WARN.toInt();
/* 201:    */   }
/* 202:    */   
/* 203:    */   private Level getLogLevel()
/* 204:    */   {
/* 205:347 */     String level = Registry.getStringValue("/OpenPages/Custom Deliverables/Logging/Level", "");
/* 206:    */     
/* 207:    */ 
/* 208:350 */     Level logLevel = null;
/* 209:352 */     if ((level != null) && (!level.equalsIgnoreCase("")))
/* 210:    */     {
/* 211:355 */       level = level.trim();
/* 212:356 */       if (level.equalsIgnoreCase("debug")) {
/* 213:358 */         logLevel = Level.DEBUG;
/* 214:360 */       } else if (level.equalsIgnoreCase("warn")) {
/* 215:362 */         logLevel = Level.WARN;
/* 216:364 */       } else if (level.equalsIgnoreCase("info")) {
/* 217:366 */         logLevel = Level.INFO;
/* 218:368 */       } else if (level.equalsIgnoreCase("error")) {
/* 219:370 */         logLevel = Level.ERROR;
/* 220:372 */       } else if (level.equalsIgnoreCase("all")) {
/* 221:374 */         logLevel = Level.ALL;
/* 222:376 */       } else if (level.equalsIgnoreCase("fatal")) {
/* 223:378 */         logLevel = Level.FATAL;
/* 224:380 */       } else if (level.equalsIgnoreCase("off")) {
/* 225:382 */         logLevel = Level.OFF;
/* 226:    */       }
/* 227:    */     }
/* 228:387 */     if (logLevel == null) {
/* 229:388 */       logLevel = Level.ERROR;
/* 230:    */     }
/* 231:392 */     return logLevel;
/* 232:    */   }
/* 233:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.logging.EXTLogger
 * JD-Core Version:    0.7.0.1
 */