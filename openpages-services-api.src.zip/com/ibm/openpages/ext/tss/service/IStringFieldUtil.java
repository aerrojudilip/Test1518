package com.ibm.openpages.ext.tss.service;

import com.ibm.openpages.api.resource.IField;
import com.ibm.openpages.api.resource.IGRCObject;
import com.ibm.openpages.api.resource.IStringField;

public abstract interface IStringFieldUtil
{
  public abstract void initService();
  
  public abstract IStringField getStringField(IField paramIField);
  
  public abstract IStringField getStringField(IGRCObject paramIGRCObject, String paramString);
  
  public abstract boolean isStringFieldNull(IField paramIField);
  
  public abstract boolean isStringFieldNull(IGRCObject paramIGRCObject, String paramString);
  
  public abstract boolean isStringFieldNotNull(IField paramIField);
  
  public abstract boolean isStringFieldNotNull(IGRCObject paramIGRCObject, String paramString);
  
  public abstract boolean isStringFieldValueNull(IField paramIField);
  
  public abstract boolean isStringFieldValueNull(IGRCObject paramIGRCObject, String paramString);
  
  public abstract boolean isStringFieldValueNotNull(IField paramIField);
  
  public abstract boolean isStringFieldValueNotNull(IGRCObject paramIGRCObject, String paramString);
  
  public abstract boolean isStringFieldValueNullorEmpty(IField paramIField);
  
  public abstract boolean isStringFieldValueNullorEmpty(IGRCObject paramIGRCObject, String paramString);
  
  public abstract boolean isStringFieldValueNotNullorEmpty(IField paramIField);
  
  public abstract boolean isStringFieldValueNotNullorEmpty(IGRCObject paramIGRCObject, String paramString);
  
  public abstract boolean isStringFieldValueNumeric(IField paramIField);
  
  public abstract boolean isStringFieldValueNumeric(IGRCObject paramIGRCObject, String paramString);
  
  public abstract String getStringFieldValue(IField paramIField);
  
  public abstract String getStringFieldValue(IGRCObject paramIGRCObject, String paramString);
  
  public abstract int getStringFieldValueAsInt(IField paramIField);
  
  public abstract int getStringFieldValueAsInt(IGRCObject paramIGRCObject, String paramString);
  
  public abstract double getStringFieldValueAsDouble(IField paramIField);
  
  public abstract double getStringFieldValueAsDouble(IGRCObject paramIGRCObject, String paramString);
  
  public abstract float getStringFieldValueAsFloat(IField paramIField);
  
  public abstract float getStringFieldValueAsFloat(IGRCObject paramIGRCObject, String paramString);
  
  public abstract void setStringFieldValue(IStringField paramIStringField, String paramString);
  
  public abstract void setStringFieldValue(IGRCObject paramIGRCObject, String paramString1, String paramString2);
  
  public abstract boolean isStringFieldDataType(IField paramIField);
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.IStringFieldUtil
 * JD-Core Version:    0.7.0.1
 */