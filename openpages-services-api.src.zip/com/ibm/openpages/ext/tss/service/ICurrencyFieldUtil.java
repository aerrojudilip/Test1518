package com.ibm.openpages.ext.tss.service;

import com.ibm.openpages.api.configuration.ICurrency;
import com.ibm.openpages.api.resource.ICurrencyField;
import com.ibm.openpages.api.resource.IField;
import com.ibm.openpages.api.resource.IGRCObject;
import java.util.Date;

public abstract interface ICurrencyFieldUtil
{
  public abstract void initService();
  
  public abstract ICurrencyField getCurrencyField(IField paramIField)
    throws Exception;
  
  public abstract ICurrencyField getCurrencyField(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract boolean isCurrencyFieldNull(IField paramIField)
    throws Exception;
  
  public abstract boolean isCurrencyFieldNull(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract boolean isCurrencyFieldNotNull(IField paramIField)
    throws Exception;
  
  public abstract boolean isCurrencyFieldNotNull(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract boolean isCurrencyFieldBaseAmountNull(IField paramIField)
    throws Exception;
  
  public abstract boolean isCurrencyFieldBaseAmountNull(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract boolean isCurrencyFieldBaseAmountNotNull(IField paramIField)
    throws Exception;
  
  public abstract boolean isCurrencyFieldLocalAmountNull(IField paramIField)
    throws Exception;
  
  public abstract boolean isCurrencyFieldLocalAmountNull(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract boolean isCurrencyFieldLocalAmountNotNull(IField paramIField)
    throws Exception;
  
  public abstract boolean isCurrencyFieldLocalAmountNotNull(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract boolean isCurrencyFieldBaseAmountNotNull(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract Double getCurrencyFieldBaseAmount(IField paramIField)
    throws Exception;
  
  public abstract Double getCurrencyFieldBaseAmount(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract String getCurrencyFieldBaseCurrencyCode(IField paramIField)
    throws Exception;
  
  public abstract String getCurrencyFieldBaseCurrencyCode(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract Double getCurrencyFieldLocalAmount(IField paramIField)
    throws Exception;
  
  public abstract Double getCurrencyFieldLocalAmount(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract String getCurrencyFieldLocalAmountAsString(IField paramIField)
    throws Exception;
  
  public abstract String getCurrencyFieldLocalAmountAsString(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract String getCurrencyFieldLocalCurrencyCode(IField paramIField)
    throws Exception;
  
  public abstract String getCurrencyFieldLocalCurrencyCode(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract void setCurrencyFieldLocalAmount(IField paramIField, Double paramDouble)
    throws Exception;
  
  public abstract void setCurrencyFieldLocalAmount(IGRCObject paramIGRCObject, String paramString, Double paramDouble)
    throws Exception;
  
  public abstract double getCurrencyFieldExchangeRate(IGRCObject paramIGRCObject, String paramString, Date paramDate)
    throws Exception;
  
  public abstract double getCurrencyFieldExchangeRate(IField paramIField, Date paramDate)
    throws Exception;
  
  public abstract void setCurrencyFieldLocalCurrency(IField paramIField, ICurrency paramICurrency)
    throws Exception;
  
  public abstract void setCurrencyFieldLocalCurrency(IGRCObject paramIGRCObject, String paramString, ICurrency paramICurrency)
    throws Exception;
  
  public abstract void setCurrencyFieldExchangeRate(IField paramIField, Double paramDouble)
    throws Exception;
  
  public abstract void setCurrencyFieldExchangeRate(IGRCObject paramIGRCObject, String paramString, Double paramDouble)
    throws Exception;
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.ICurrencyFieldUtil
 * JD-Core Version:    0.7.0.1
 */