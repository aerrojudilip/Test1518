package com.ibm.openpages.ext.tss.service;

import com.ibm.openpages.api.resource.IGRCObject;
import com.ibm.openpages.api.trigger.events.AbstractEvent;
import com.ibm.openpages.ext.tss.service.beans.FieldValueChangeForSetTriggerAttributesInfo;
import com.ibm.openpages.ext.tss.service.beans.FieldValueChangeInfo;
import com.ibm.openpages.ext.tss.service.beans.IGRCFieldValidateInformation;
import java.util.HashMap;

public abstract interface IGRCTriggerUtil
{
  public abstract void initService();
  
  public abstract String getAttributeName(HashMap<String, String> paramHashMap, String paramString)
    throws Exception;
  
  public abstract void setAttributeInGRCTriggerDefinition(FieldValueChangeForSetTriggerAttributesInfo paramFieldValueChangeForSetTriggerAttributesInfo)
    throws Exception;
  
  public abstract String getAttributeInGRCTriggerDefinition(FieldValueChangeForSetTriggerAttributesInfo paramFieldValueChangeForSetTriggerAttributesInfo)
    throws Exception;
  
  public abstract FieldValueChangeForSetTriggerAttributesInfo populateTriggerSetAttributesP(AbstractEvent paramAbstractEvent, FieldValueChangeForSetTriggerAttributesInfo paramFieldValueChangeForSetTriggerAttributesInfo, HashMap<String, String> paramHashMap)
    throws Exception;
  
  public abstract boolean matchFieldValueToAGivenValue(IGRCObject paramIGRCObject, IGRCFieldValidateInformation paramIGRCFieldValidateInformation)
    throws Exception;
  
  public abstract boolean detectPropertyChange(FieldValueChangeInfo paramFieldValueChangeInfo)
    throws Exception;
  
  public abstract boolean detectPropertyChangeToAGivenValue(FieldValueChangeInfo paramFieldValueChangeInfo)
    throws Exception;
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.IGRCTriggerUtil
 * JD-Core Version:    0.7.0.1
 */