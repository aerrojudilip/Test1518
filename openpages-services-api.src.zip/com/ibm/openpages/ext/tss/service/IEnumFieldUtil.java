package com.ibm.openpages.ext.tss.service;

import com.ibm.openpages.api.metadata.IEnumValue;
import com.ibm.openpages.api.metadata.IFieldDefinition;
import com.ibm.openpages.api.resource.IEnumField;
import com.ibm.openpages.api.resource.IField;
import com.ibm.openpages.api.resource.IGRCObject;
import java.util.List;

public abstract interface IEnumFieldUtil
{
  public abstract void initService();
  
  public abstract IEnumField getEnumField(IField paramIField)
    throws Exception;
  
  public abstract IEnumField getEnumField(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract boolean isEnumFieldNull(IField paramIField)
    throws Exception;
  
  public abstract boolean isEnumFieldNull(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract boolean isEnumFieldNotNull(IField paramIField)
    throws Exception;
  
  public abstract boolean isEnumFieldNotNull(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract boolean isEnumFieldValueNull(IField paramIField)
    throws Exception;
  
  public abstract boolean isEnumFieldValueNull(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract boolean isEnumFieldValueNotNull(IField paramIField)
    throws Exception;
  
  public abstract boolean isEnumFieldValueNotNull(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract IEnumValue getEnumFieldValue(IField paramIField)
    throws Exception;
  
  public abstract IEnumValue getEnumFieldValue(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract String getEnumFieldSelectedValue(IField paramIField)
    throws Exception;
  
  public abstract String getEnumFieldSelectedValue(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract List<String> getAllValuesInEnumFieldAsList(IFieldDefinition paramIFieldDefinition)
    throws Exception;
  
  public abstract List<String> getActiveValuesInEnumFieldAsList(IFieldDefinition paramIFieldDefinition)
    throws Exception;
  
  public abstract List<String> getHiddenValuesInEnumFieldAsList(IFieldDefinition paramIFieldDefinition)
    throws Exception;
  
  public abstract List<String> getAllValuesInEnumFieldAsList(IField paramIField)
    throws Exception;
  
  public abstract List<String> getAllValuesInEnumFieldAsList(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract List<String> getActiveValuesInEnumFieldAsList(IField paramIField)
    throws Exception;
  
  public abstract List<String> getActiveValuesInEnumFieldAsList(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract List<String> getHiddenValuesInEnumFieldAsList(IField paramIField)
    throws Exception;
  
  public abstract List<String> getHiddenValuesInEnumFieldAsList(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract boolean isEnumFieldValueMatchExpectedValue(IField paramIField, String paramString)
    throws Exception;
  
  public abstract boolean isEnumFieldValueMatchExpectedValue(IGRCObject paramIGRCObject, String paramString1, String paramString2)
    throws Exception;
  
  public abstract boolean isEnumFieldValueMatchAnyDesiredValues(IField paramIField, List<String> paramList)
    throws Exception;
  
  public abstract boolean isEnumFieldValueMatchAnyDesiredValues(IGRCObject paramIGRCObject, String paramString, List<String> paramList)
    throws Exception;
  
  public abstract boolean isEnumFieldValueMatchAnyDesiredValues(IField paramIField, String paramString)
    throws Exception;
  
  public abstract boolean isEnumFieldValueMatchAnyDesiredValues(IGRCObject paramIGRCObject, String paramString1, String paramString2)
    throws Exception;
  
  public abstract void setEnumFieldValue(IEnumField paramIEnumField, String paramString)
    throws Exception;
  
  public abstract void setEnumFieldValue(IGRCObject paramIGRCObject, String paramString1, String paramString2)
    throws Exception;
  
  public abstract void setEnumFieldValue(IEnumField paramIEnumField, IEnumValue paramIEnumValue)
    throws Exception;
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.IEnumFieldUtil
 * JD-Core Version:    0.7.0.1
 */