package com.ibm.openpages.ext.tss.service;

import com.ibm.openpages.api.resource.IGRCObject;
import com.ibm.openpages.api.service.IServiceFactory;
import com.ibm.openpages.ext.tss.service.beans.AppServerInformation;
import com.openpages.sdk.OpenpagesSession;
import java.util.List;
import java.util.Map;

public abstract interface IApplicationUtil
{
  public abstract void initService();
  
  public abstract OpenpagesSession createNewOpenpagesSessionForUser(AppServerInformation paramAppServerInformation)
    throws Exception;
  
  public abstract IServiceFactory createServiceFactoryForUser(AppServerInformation paramAppServerInformation)
    throws Exception;
  
  public abstract boolean isRegistrySettingExists(String paramString)
    throws Exception;
  
  public abstract String getRegistrySetting(String paramString)
    throws Exception;
  
  public abstract String getRegistrySetting(String paramString1, String paramString2)
    throws Exception;
  
  public abstract Map<String, String> getRegistrySettings(List<String> paramList)
    throws Exception;
  
  public abstract void setValueForRegistrySetting(String paramString1, String paramString2)
    throws Exception;
  
  public abstract List<String> getSecurityPoints()
    throws Exception;
  
  public abstract List<String> getAllSelfContainedObjectTypes()
    throws Exception;
  
  public abstract String getAutoNamePatternForContentType(String paramString)
    throws Exception;
  
  public abstract String getObjectDetailViewLink(IGRCObject paramIGRCObject)
    throws Exception;
  
  public abstract String getObjectDetailViewLink(String paramString1, String paramString2)
    throws Exception;
  
  public abstract String getObjectDetailViewURL(String paramString)
    throws Exception;
  
  public abstract String getCommandCenterReportViewURL(String paramString)
    throws Exception;
  
  public abstract String getObjectDetailViewRelativeURL(String paramString)
    throws Exception;
  
  public abstract String getCommandCenterReportViewRelativeURL(String paramString)
    throws Exception;
  
  public abstract String getAutoName(IGRCObject paramIGRCObject)
    throws Exception;
  
  public abstract String getApplicationString(String paramString)
    throws Exception;
  
  public abstract String getApplicationString(String paramString, List<String> paramList)
    throws Exception;
  
  public abstract List<String> getApplicationStringsAsList(Map<String, List<String>> paramMap)
    throws Exception;
  
  public abstract Map<String, String> getApplicationStringsAsMap(Map<String, List<String>> paramMap)
    throws Exception;
  
  public abstract String getAutoNameBasedOnFormat(IGRCObject paramIGRCObject, String paramString, int paramInt)
    throws Exception;
  
  public abstract String getAutoNameBasedOnFormat(String paramString1, String paramString2, int paramInt)
    throws Exception;
  
  public abstract String getAuroraEnvProperty(String paramString)
    throws Exception;
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.IApplicationUtil
 * JD-Core Version:    0.7.0.1
 */