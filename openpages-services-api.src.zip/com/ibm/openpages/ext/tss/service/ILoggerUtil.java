package com.ibm.openpages.ext.tss.service;

import org.apache.commons.logging.Log;

public abstract interface ILoggerUtil
{
  public abstract Log getExtLogger();
  
  public abstract Log getExtLogger(String paramString);
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.ILoggerUtil
 * JD-Core Version:    0.7.0.1
 */