/*  1:   */ package com.ibm.openpages.ext.tss.service.constants;
/*  2:   */ 
/*  3:   */ public enum Comparators
/*  4:   */ {
/*  5:17 */   NULL,  NOT_NULL,  EMPTY,  NULL_OR_EMPTY,  NOT_NULL_OR_EMPTY,  EQUAL,  EQUAL_IGNORE_CASE,  NOT_EQUAL,  GREATER_THAN,  LESSER_THAN,  GREATER_THAN_OR_EQUAL,  LESSER_THAN_OR_EQUAL,  IN_FUTURE,  IN_THE_PAST,  WITHIN_RANGE,  WITHIN_MONTHS,  WITHIN_DAYS,  WITHIN_YEARS,  START_WITH,  END_WITH,  CONTAINS,  FIELD_MODIFIED;
/*  6:   */   
/*  7:   */   private Comparators() {}
/*  8:   */   
/*  9:   */   public static boolean contains(String value)
/* 10:   */   {
/* 11:42 */     for (Comparators comparators : ) {
/* 12:43 */       if (comparators.name().equals(value)) {
/* 13:44 */         return true;
/* 14:   */       }
/* 15:   */     }
/* 16:45 */     return false;
/* 17:   */   }
/* 18:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.constants.Comparators
 * JD-Core Version:    0.7.0.1
 */