/*  1:   */ package com.ibm.openpages.ext.tss.service.constants;
/*  2:   */ 
/*  3:   */ public enum CheckFor
/*  4:   */ {
/*  5:16 */   CHECK_ALL,  CHECK_ANY;
/*  6:   */   
/*  7:   */   private CheckFor() {}
/*  8:   */   
/*  9:   */   public static boolean contains(String value)
/* 10:   */   {
/* 11:20 */     for (CheckFor checkFor : ) {
/* 12:21 */       if (checkFor.name().equals(value)) {
/* 13:22 */         return true;
/* 14:   */       }
/* 15:   */     }
/* 16:23 */     return false;
/* 17:   */   }
/* 18:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.constants.CheckFor
 * JD-Core Version:    0.7.0.1
 */