/*  1:   */ package com.ibm.openpages.ext.tss.service.constants;
/*  2:   */ 
/*  3:   */ public class IGRCObjectConstants
/*  4:   */ {
/*  5:   */   public static final String SYS_NAME = "Name";
/*  6:   */   public static final String SYS_DESCRIPTION = "Description";
/*  7:   */   public static final String SYS_RESOURCE_ID = "Resource ID";
/*  8:   */   public static final String SYS_CREATED_BY = "Created By";
/*  9:   */   public static final String SYS_CREATION_DATE = "Creation Date";
/* 10:   */   public static final String SYS_LAST_MODIFICAION_DATE = "Last Modification Date";
/* 11:   */   public static final String SYS_LAST_MODIFIED_BY = "Last Modified By";
/* 12:   */   public static final String SYS_LOCATION = "Location";
/* 13:   */   public static final String SYS_ORPHAN = "Orphan";
/* 14:16 */   public static String SYSTEM_FIELDS_WITHOUT_NAME_AND_DESCRIPTION = "Resource ID,Created By,Creation Date,Last Modification Date,Last Modified By,Location,Orphan";
/* 15:24 */   public static String SYSTEM_FIELDS_WITHOUT_DESCRIPTION = "Name," + SYSTEM_FIELDS_WITHOUT_NAME_AND_DESCRIPTION;
/* 16:25 */   public static String ALL_SYSTEM_FIELDS = "Name,Description," + SYSTEM_FIELDS_WITHOUT_NAME_AND_DESCRIPTION;
/* 17:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.constants.IGRCObjectConstants
 * JD-Core Version:    0.7.0.1
 */