/*  1:   */ package com.ibm.openpages.ext.tss.service.constants;
/*  2:   */ 
/*  3:   */ public abstract class DateConstants
/*  4:   */ {
/*  5:   */   public static final String CURRENT_DATE = "CURRENT_DATE";
/*  6:   */   public static final String MMM_dd_YYYY = "MMM dd, yyyy";
/*  7:   */   public static final String MM_dd_YYYY = "MM/dd/yyyy";
/*  8:   */   public static final String YYYY_MM_dd = "yyyy-MM-dd";
/*  9:   */   public static final String MM_dd_YYYY_HH_mm_ss = "MM/dd/yyyy HH:mm:ss";
/* 10:   */   public static final String YYYY_MM_dd_HH_mm_ss = "yyyy-MM-dd HH:mm:ss";
/* 11:   */   public static final String YYYY_MM_DD_T_HH_MM_SS = "yyyy-MM-dd'T'HH:mm:ss";
/* 12:30 */   public static final String[] DATE_FORMATS = { "MMM dd, yyyy", "MM/dd/yyyy", "yyyy-MM-dd", "yyyy/MM/dd", "MM/dd/yyyy HH:mm:ss", "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd'T'HH:mm:ss", "EEE MMM dd, yyyy hh:mm a", "EEE MMM dd HH:mm:ss zzz yyyy" };
/* 13:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.constants.DateConstants
 * JD-Core Version:    0.7.0.1
 */