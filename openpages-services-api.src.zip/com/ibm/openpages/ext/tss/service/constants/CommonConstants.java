/*   1:    */ package com.ibm.openpages.ext.tss.service.constants;
/*   2:    */ 
/*   3:    */ import java.util.HashMap;
/*   4:    */ import java.util.Map;
/*   5:    */ 
/*   6:    */ public abstract class CommonConstants
/*   7:    */ {
/*   8:    */   public static final String DOT = "\\.";
/*   9:    */   public static final int INT_ZERO = 0;
/*  10:    */   public static final int INT_ONE = 1;
/*  11:    */   public static final String ALL = "all";
/*  12:    */   public static final String ANY = "any";
/*  13:    */   public static final String EQUAL_TO = "=";
/*  14:    */   public static final String TRUE = "true";
/*  15:    */   public static final String FALSE = "false";
/*  16:    */   public static final String YES = "Yes";
/*  17:    */   public static final String NO = "No";
/*  18:    */   public static final String NAME = "name";
/*  19:    */   public static final String START = "Start";
/*  20:    */   public static final String END = "End";
/*  21:    */   public static final String SUCCESS = "success";
/*  22:    */   public static final String INPUT = "input";
/*  23:    */   public static final String DECIMAL = "decimal";
/*  24:    */   public static final String PROFILE = "profile";
/*  25:    */   public static final String EMPTY_STRING = "";
/*  26:    */   public static final String NO_SETTING_FOUND = "No Setting Found";
/*  27:    */   public static final String EMPTY = "EMPTY";
/*  28:    */   public static final String SINGLE_SPACE = " ";
/*  29:    */   public static final String QUESTION_MARK = "?";
/*  30:    */   public static final String FOLDER_SEPARATROR = "/";
/*  31:    */   public static final String TEXT_FILE_TYPE = "txt (text/plain)";
/*  32:    */   public static final String PERCENTAGE_P = "%P;";
/*  33:    */   public static final String PERCENTAGE_N = "%N";
/*  34:    */   public static final String PLACE_HOLDER_START_CHARECTER = "{";
/*  35:    */   public static final String PLACE_HOLDER_END_CHARECTER = "}";
/*  36:    */   public static final String PLACE_HOLDER_ONE = "{0}";
/*  37:    */   public static final String PLACE_HOLDER_TWO = "{1}";
/*  38:    */   public static final String COLON = ":";
/*  39:    */   public static final String SEMI_COLON = ":";
/*  40:    */   public static final String PERIOD = "'.'";
/*  41:    */   public static final String PERIOD_CHARECTER = "\\.";
/*  42:    */   public static final String PERIOD_STRING = ".";
/*  43:    */   public static final String BACK_SLASH = "\\";
/*  44:    */   public static final String FORWARD_SLASH = "//";
/*  45:    */   public static final String TEXT_FILE_EXTENSION = ".txt";
/*  46:    */   public static final String HYPHEN = "-";
/*  47:    */   public static final String COMMA_SEPERATED_DELIMITER = ",";
/*  48:    */   public static final String PIPE_SEPERATED_DELIMITER = "\\|";
/*  49:    */   public static final String COLON_SEPERATED_DELIMITER = ":";
/*  50:    */   public static final String SEMI_COLON_DELIMITER = ";";
/*  51:    */   public static final String ATTR_SOX_PROJECT_DEFAULT_NAME = "SOX.ProjectDefault";
/*  52:    */   public static final String COMMAND_CENTER_REPORT_SUBMISSION_URL = "/openpages/report.tree.post.do?submitAction=preview&actionContext=preview&reportId=";
/*  53:    */   public static final int DEFAULT_RETRY_ATTEMPTS = 5;
/*  54:    */   public static final String JSON_IDENTIFIER = "identifier";
/*  55:    */   public static final String JSON_LABEL = "label";
/*  56:    */   public static final String JSON_ITEMS = "items";
/*  57:    */   public static final String READ_ACCESS = "Read";
/*  58:    */   public static final String WRITE_ACCESS = "Write";
/*  59:    */   public static final String ASSOCIATE_ACCESS = "Associate";
/*  60:    */   public static final String DELETE_ACCESS = "Delete";
/*  61:    */   public static final int DEFAULT_RETRY_WAIT_MILLISECONDS = 10000;
/*  62:    */   public static final String OPENPAGES_AUTO_NAMING_STRING = "/OpenPages/Applications/GRCM/Auto Naming/";
/*  63:    */   public static final String AUTO_NAMING_FORMAT = "/Format";
/*  64:    */   public static final String REGISTRY_MAIL_SERVER = "/OpenPages/Applications/Common/Email/Mail Server";
/*  65:    */   public static final String REGISTRY_LOCK_OBJECT_ROOT = "/OpenPages/Applications/GRCM/Locked Objects/Lock Child Types/";
/*  66:    */   public static final String APPLICATION_URL_PROTOCOL = "/OpenPages/Platform/Reporting Schema/Object URL Generator/Protocol";
/*  67:    */   public static final String APPLICATION_URL_HOST = "/OpenPages/Platform/Reporting Schema/Object URL Generator/Host";
/*  68:    */   public static final String APPLICATION_URL_PORT = "/OpenPages/Platform/Reporting Schema/Object URL Generator/Port";
/*  69:    */   public static final String APPLICATION_URL_DETAIL_PAGE = "/OpenPages/Platform/Reporting Schema/Object URL Generator/Detail Page";
/*  70:    */   public static final String APPLICATION_URL_OBJECT_ID_PARAM = "/OpenPages/Platform/Reporting Schema/Object URL Generator/Object ID Parameter Name";
/*  71:    */   public static final String REGISTRY_SECURITY_CONTEXT_PATH = "/OpenPages/Common/Security/Model";
/*  72:    */   public static final String REGISTRY_SELF_CONTAINED_PATH = "/OpenPages/Common/Self Contained Object Types";
/*  73:    */   public static final String AUTO_NAMING_REGISTRY_PATH = "/OpenPages/Applications/GRCM/Auto Naming/{0}/Format";
/*  74:    */   public static final String SOXDOCUMENT_NAME = "SOXDocument";
/*  75:    */   public static final String SOXSIGNATURE_NAME = "SOXSignature";
/*  76:    */   public static final String RESOURCE_VIEW_RELATIVE_URL = "/view.resource.do?fileId=";
/*  77:    */   public static final String OBJECT_DEFAULT_PATH = "/_op_sox/Project/Default/";
/*  78:    */   public static final String OBJECT_ROOT_PATH = "/_op_sox/Project/Default/ICDocumentation/";
/*  79:    */   public static final String HTML_NEW_LINE = "<br/>";
/*  80:    */   public static final String HTML_TABLE_TAG = "<table>";
/*  81:    */   public static final String HTML_TABLE_CLOSE_TAG = "</table>";
/*  82:    */   public static final String HTML_TABLE_THEAD_TAG = "<thead>";
/*  83:    */   public static final String HTML_TABLE_THEAD_CLOSE_TAG = "</thead>";
/*  84:    */   public static final String HTML_TABLE_TBODY_TAG = "<tbody>";
/*  85:    */   public static final String HTML_TABLE_TBODY_CLOSE_TAG = "</tbody>";
/*  86:    */   public static final String HTML_TABLE_TR_TAG = "<tr>";
/*  87:    */   public static final String HTML_TABLE_TR_CLOSE_TAG = "</tr>";
/*  88:    */   public static final String HTML_TABLE_TH_TAG = "<th>";
/*  89:    */   public static final String HTML_TABLE_TH_CLOSE_TAG = "</th>";
/*  90:    */   public static final String HTML_TABLE_TD_TAG = "<td>";
/*  91:    */   public static final String HTML_TABLE_TD_CLOSE_TAG = "</td>";
/*  92:    */   public static final String HTML_ANCHOR_TAG = "<a href=\"";
/*  93:    */   public static final String HTML_ANCHOR_CLOSE_TAG = "</a>";
/*  94:    */   public static final String HTML_TAG_END_CLOSE = "\">";
/*  95:    */   public static final String SYSTEM_FIELD_NAME = "System Fields:";
/*  96:    */   public static final String DESCRIPTION_FIELD_NAME = "System Fields:Description";
/*  97:    */   public static final String APPLICATION = "application";
/*  98:    */   public static final String OPENPAGES_SESSION_KEY = "OpenpagesSession";
/*  99:203 */   public static final Map<String, String> FILE_EXTENSION_TO_FILE_MIME_TYPES_MAP = new HashMap()
/* 100:    */   {
/* 101:    */     private static final long serialVersionUID = 1L;
/* 102:    */   };
/* 103:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.constants.CommonConstants
 * JD-Core Version:    0.7.0.1
 */