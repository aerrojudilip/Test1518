/*  1:   */ package com.ibm.openpages.ext.tss.service.constants;
/*  2:   */ 
/*  3:   */ public enum DateFrequency
/*  4:   */ {
/*  5: 4 */   MONTHLY,  EVERY_OTHER_MONTH,  QUARTERLY,  SEMI_ANNUALLY,  ANNUALLY,  ADD_NUMBER_OF_DAYS,  ADD_NUMBER_OF_YEARS;
/*  6:   */   
/*  7:   */   private DateFrequency() {}
/*  8:   */   
/*  9:   */   public static boolean contains(String value)
/* 10:   */   {
/* 11:14 */     for (DateFrequency dateFrequency : ) {
/* 12:15 */       if (dateFrequency.name().equals(value)) {
/* 13:16 */         return true;
/* 14:   */       }
/* 15:   */     }
/* 16:17 */     return false;
/* 17:   */   }
/* 18:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.constants.DateFrequency
 * JD-Core Version:    0.7.0.1
 */