package com.ibm.openpages.ext.tss.service;

import java.util.List;
import java.util.Map;
import org.jdom.Element;

public abstract interface ICognosUtil
{
  public abstract String getReportPathForRegistry(String paramString)
    throws Exception;
  
  public abstract String getCognosOutputPath(String paramString1, Map<String, String[]> paramMap, String paramString2)
    throws Exception;
  
  public abstract Map<Integer, List<String>> getCognosOutputMap(String paramString, Map<String, String[]> paramMap)
    throws Exception;
  
  public abstract List<Element> getCognosResultsAsXMLRows(String paramString, Map<String, String[]> paramMap)
    throws Exception;
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.ICognosUtil
 * JD-Core Version:    0.7.0.1
 */