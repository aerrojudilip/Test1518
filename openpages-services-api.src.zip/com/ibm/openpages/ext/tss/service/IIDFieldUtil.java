package com.ibm.openpages.ext.tss.service;

import com.ibm.openpages.api.metadata.Id;
import com.ibm.openpages.api.resource.IField;
import com.ibm.openpages.api.resource.IGRCObject;
import com.ibm.openpages.api.resource.IIdField;

public abstract interface IIDFieldUtil
{
  public abstract void initService();
  
  public abstract IIdField getIdField(IField paramIField)
    throws Exception;
  
  public abstract IIdField getIdField(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract boolean isIdFieldNull(IField paramIField)
    throws Exception;
  
  public abstract boolean isIdFieldNull(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract boolean isIdFieldNotNull(IField paramIField)
    throws Exception;
  
  public abstract boolean isIdFieldNotNull(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract String getIdFieldValueAsString(IField paramIField)
    throws Exception;
  
  public abstract String getIdFieldValueAsString(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract Id getIdFieldValue(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract Id getIdFieldValue(IField paramIField)
    throws Exception;
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.IIDFieldUtil
 * JD-Core Version:    0.7.0.1
 */