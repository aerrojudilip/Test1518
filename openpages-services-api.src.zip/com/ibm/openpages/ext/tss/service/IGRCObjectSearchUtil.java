package com.ibm.openpages.ext.tss.service;

import com.ibm.openpages.api.metadata.Id;
import com.ibm.openpages.api.query.ITabularResultSet;
import com.ibm.openpages.api.resource.IAssociationNode;
import com.ibm.openpages.api.resource.IGRCObject;
import com.ibm.openpages.ext.tss.service.beans.IGRCFieldInformationForQuery;
import java.util.List;

public abstract interface IGRCObjectSearchUtil
{
  public abstract void initService();
  
  public abstract ITabularResultSet executeQuery(String paramString)
    throws Exception;
  
  public abstract ITabularResultSet executeQuery(String paramString, boolean paramBoolean)
    throws Exception;
  
  public abstract int getTotalNumberOfRecordsReturned(String paramString, boolean paramBoolean)
    throws Exception;
  
  public abstract int getTotalNumberOfRecordsReturned(String paramString)
    throws Exception;
  
  public abstract IGRCObject getImmediatePrimaryParentFromId(String paramString, List<String> paramList, boolean paramBoolean)
    throws Exception;
  
  public abstract IGRCObject getImmediatePrimaryParentFromName(String paramString, List<String> paramList, boolean paramBoolean)
    throws Exception;
  
  public abstract List<IAssociationNode> getAllParentsOfGivenType(String paramString1, String paramString2, boolean paramBoolean)
    throws Exception;
  
  public abstract List<IAssociationNode> getAllParentsOfGivenType(Id paramId, String paramString, boolean paramBoolean)
    throws Exception;
  
  public abstract List<String> getAllChildObjectIdsOfGivenObject(IGRCObject paramIGRCObject, String paramString, boolean paramBoolean)
    throws Exception;
  
  public abstract List<String> getAllChildObjectIdsOfGivenObject(IGRCObject paramIGRCObject, List<String> paramList, boolean paramBoolean)
    throws Exception;
  
  public abstract String getFieldValueFromObjectBasedOnId(String paramString1, String paramString2, String paramString3)
    throws Exception;
  
  public abstract ITabularResultSet getFieldValuesFromObjectBasedOnId(String paramString1, String paramString2, List<String> paramList)
    throws Exception;
  
  public abstract ITabularResultSet getFieldValuesFromObjectBasedOnLocation(String paramString1, String paramString2, List<String> paramList, boolean paramBoolean)
    throws Exception;
  
  public abstract String getSingleValueFromQuery(String paramString)
    throws Exception;
  
  public abstract String getSingleValueFromQuery(String paramString, boolean paramBoolean)
    throws Exception;
  
  public abstract List<String> getMultipleValuesFromQueryAsList(String paramString, boolean paramBoolean)
    throws Exception;
  
  public abstract StringBuilder appendResourceIdWhereClauseToQuery(String paramString, IGRCObject paramIGRCObject)
    throws Exception;
  
  public abstract StringBuilder appendResourceIdWhereClauseToQuery(String paramString1, String paramString2)
    throws Exception;
  
  public abstract StringBuilder appendFieldsToWhereClauseInQuery(String paramString, IGRCFieldInformationForQuery paramIGRCFieldInformationForQuery)
    throws Exception;
  
  public abstract StringBuilder getBaseQueryForMultipleChildAssociation(List<String> paramList)
    throws Exception;
  
  public abstract StringBuilder getBaseQueryForMultipleParentAssociation(List<String> paramList)
    throws Exception;
  
  public abstract StringBuilder getQueryForMultipleParentAssociation(List<String> paramList1, List<String> paramList2)
    throws Exception;
  
  public abstract IGRCObject getObjectFromNameAndPath(String paramString1, String paramString2, String paramString3, boolean paramBoolean)
    throws Exception;
  
  public abstract List<IGRCObject> getImmediateParentsFromId(String paramString, List<String> paramList)
    throws Exception;
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.IGRCObjectSearchUtil
 * JD-Core Version:    0.7.0.1
 */