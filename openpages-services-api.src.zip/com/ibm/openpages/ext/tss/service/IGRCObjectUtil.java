package com.ibm.openpages.ext.tss.service;

import com.ibm.openpages.api.application.MoveObjectOptions;
import com.ibm.openpages.api.metadata.Id;
import com.ibm.openpages.api.resource.GRCObjectFilter;
import com.ibm.openpages.api.resource.IGRCObject;
import com.ibm.openpages.ext.tss.service.beans.IGRCObjectAssociationInformation;
import com.ibm.openpages.ext.tss.service.beans.SnapshotObjectInformation;
import java.util.List;
import java.util.Map;
import java.util.Set;

public abstract interface IGRCObjectUtil
{
  public abstract void initService();
  
  public abstract IGRCObject getObjectFromId(Id paramId)
    throws Exception;
  
  public abstract IGRCObject getObjectFromId(String paramString)
    throws Exception;
  
  public abstract IGRCObject getObjectFromId(String paramString, GRCObjectFilter paramGRCObjectFilter)
    throws Exception;
  
  public abstract IGRCObject getObjectFromId(Id paramId, GRCObjectFilter paramGRCObjectFilter)
    throws Exception;
  
  public abstract IGRCObject createAutoNamedObject(String paramString)
    throws Exception;
  
  public abstract void lockObjectsBasedOnId(Set<String> paramSet)
    throws Exception;
  
  public abstract void unLockChildObjects(Set<String> paramSet)
    throws Exception;
  
  public abstract IGRCObject saveResource(IGRCObject paramIGRCObject)
    throws Exception;
  
  public abstract void deleteResource(IGRCObject paramIGRCObject)
    throws Exception;
  
  public abstract void deleteResource(Id paramId)
    throws Exception;
  
  public abstract IGRCObject associateParentAndChildrentToAnObject(IGRCObject paramIGRCObject, IGRCObjectAssociationInformation paramIGRCObjectAssociationInformation)
    throws Exception;
  
  public abstract void disassociateParentAndChildrentFromAnObject(IGRCObject paramIGRCObject, IGRCObjectAssociationInformation paramIGRCObjectAssociationInformation)
    throws Exception;
  
  public abstract void moveAnIGRCObject(IGRCObject paramIGRCObject1, IGRCObject paramIGRCObject2, MoveObjectOptions paramMoveObjectOptions)
    throws Exception;
  
  public abstract void moveIGRCObjects(IGRCObject paramIGRCObject, List<Id> paramList, MoveObjectOptions paramMoveObjectOptions)
    throws Exception;
  
  public abstract IGRCObject createSnapShotForObject(IGRCObject paramIGRCObject, SnapshotObjectInformation paramSnapshotObjectInformation, IGRCObjectAssociationInformation paramIGRCObjectAssociationInformation)
    throws Exception;
  
  public abstract IGRCObject createDocument(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract boolean isChildObjectOfGivenObjectTypePresent(IGRCObject paramIGRCObject, String paramString, boolean paramBoolean)
    throws Exception;
  
  public abstract void updateFieldsInObject(String paramString, Map<String, String> paramMap)
    throws Exception;
  
  public abstract void updateFieldsInObject(IGRCObject paramIGRCObject, Map<String, String> paramMap)
    throws Exception;
  
  public abstract void updateFieldsInObjectAndSave(String paramString, Map<String, String> paramMap)
    throws Exception;
  
  public abstract void updateFieldsInObjectAndSave(IGRCObject paramIGRCObject, Map<String, String> paramMap)
    throws Exception;
  
  public abstract void updateFieldsInObject(String paramString1, String paramString2, List<String> paramList)
    throws Exception;
  
  public abstract void updateFieldsInObject(IGRCObject paramIGRCObject1, IGRCObject paramIGRCObject2, List<String> paramList)
    throws Exception;
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.IGRCObjectUtil
 * JD-Core Version:    0.7.0.1
 */