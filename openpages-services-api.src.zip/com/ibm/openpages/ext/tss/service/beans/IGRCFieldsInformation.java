/*  1:   */ package com.ibm.openpages.ext.tss.service.beans;
/*  2:   */ 
/*  3:   */ import com.ibm.openpages.api.resource.IGRCObject;
/*  4:   */ import com.ibm.openpages.ext.tss.service.util.CommonUtil;
/*  5:   */ import java.util.List;
/*  6:   */ 
/*  7:   */ public class IGRCFieldsInformation
/*  8:   */ {
/*  9:   */   private List<String> fieldsList;
/* 10:   */   private List<String> fieldValuesList;
/* 11:   */   private IGRCObject sourceObject;
/* 12:   */   
/* 13:   */   public List<String> getFieldsList()
/* 14:   */   {
/* 15:21 */     return this.fieldsList;
/* 16:   */   }
/* 17:   */   
/* 18:   */   public void setFieldsList(List<String> fieldsList)
/* 19:   */   {
/* 20:27 */     this.fieldsList = fieldsList;
/* 21:   */   }
/* 22:   */   
/* 23:   */   public List<String> getFieldValuesList()
/* 24:   */   {
/* 25:33 */     return this.fieldValuesList;
/* 26:   */   }
/* 27:   */   
/* 28:   */   public void setFieldValuesList(List<String> fieldValuesList)
/* 29:   */   {
/* 30:39 */     this.fieldValuesList = fieldValuesList;
/* 31:   */   }
/* 32:   */   
/* 33:   */   public IGRCObject getSourceObject()
/* 34:   */   {
/* 35:45 */     return this.sourceObject;
/* 36:   */   }
/* 37:   */   
/* 38:   */   public void setSourceObject(IGRCObject sourceObject)
/* 39:   */   {
/* 40:51 */     this.sourceObject = sourceObject;
/* 41:   */   }
/* 42:   */   
/* 43:   */   public String toString()
/* 44:   */   {
/* 45:62 */     StringBuilder sb = new StringBuilder();
/* 46:   */     
/* 47:64 */     sb.append("\n");
/* 48:65 */     sb.append("\n Fields Information: " + this.fieldsList);
/* 49:66 */     sb.append("\n Field values: " + this.fieldValuesList);
/* 50:   */     
/* 51:68 */     sb.append("\n Source Object: " + (CommonUtil.isObjectNotNull(this.sourceObject) ? this.sourceObject.getName() : "Null"));
/* 52:69 */     return sb.toString();
/* 53:   */   }
/* 54:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.beans.IGRCFieldsInformation
 * JD-Core Version:    0.7.0.1
 */