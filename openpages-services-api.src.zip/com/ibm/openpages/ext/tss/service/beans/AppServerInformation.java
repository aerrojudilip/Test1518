/*  1:   */ package com.ibm.openpages.ext.tss.service.beans;
/*  2:   */ 
/*  3:   */ public class AppServerInformation
/*  4:   */ {
/*  5:   */   private String userName;
/*  6:   */   private String password;
/*  7:   */   private String appServer;
/*  8:   */   private String openPagesURL;
/*  9:   */   private String openPagesPort;
/* 10:   */   private String openPagesServer;
/* 11:   */   
/* 12:   */   public String getAppServer()
/* 13:   */   {
/* 14:17 */     return this.appServer;
/* 15:   */   }
/* 16:   */   
/* 17:   */   public void setAppServer(String appServer)
/* 18:   */   {
/* 19:23 */     this.appServer = appServer;
/* 20:   */   }
/* 21:   */   
/* 22:   */   public String getOpenPagesURL()
/* 23:   */   {
/* 24:29 */     return this.openPagesURL;
/* 25:   */   }
/* 26:   */   
/* 27:   */   public void setOpenPagesURL(String openPagesURL)
/* 28:   */   {
/* 29:35 */     this.openPagesURL = openPagesURL;
/* 30:   */   }
/* 31:   */   
/* 32:   */   public String getOpenPagesServer()
/* 33:   */   {
/* 34:41 */     return this.openPagesServer;
/* 35:   */   }
/* 36:   */   
/* 37:   */   public void setOpenPagesServer(String openPagesServer)
/* 38:   */   {
/* 39:47 */     this.openPagesServer = openPagesServer;
/* 40:   */   }
/* 41:   */   
/* 42:   */   public String getOpenPagesPort()
/* 43:   */   {
/* 44:53 */     return this.openPagesPort;
/* 45:   */   }
/* 46:   */   
/* 47:   */   public void setOpenPagesPort(String openPagesPort)
/* 48:   */   {
/* 49:59 */     this.openPagesPort = openPagesPort;
/* 50:   */   }
/* 51:   */   
/* 52:   */   public String getUserName()
/* 53:   */   {
/* 54:65 */     return this.userName;
/* 55:   */   }
/* 56:   */   
/* 57:   */   public void setUserName(String userName)
/* 58:   */   {
/* 59:71 */     this.userName = userName;
/* 60:   */   }
/* 61:   */   
/* 62:   */   public String getPassword()
/* 63:   */   {
/* 64:77 */     return this.password;
/* 65:   */   }
/* 66:   */   
/* 67:   */   public void setPassword(String password)
/* 68:   */   {
/* 69:83 */     this.password = password;
/* 70:   */   }
/* 71:   */   
/* 72:   */   public String toString()
/* 73:   */   {
/* 74:89 */     StringBuilder sb = new StringBuilder();
/* 75:   */     
/* 76:91 */     sb.append("\n App Server : " + this.appServer);
/* 77:92 */     sb.append("\n OpenPages URL : " + this.openPagesURL);
/* 78:93 */     sb.append("\n OpenPages Server : " + this.openPagesServer);
/* 79:94 */     sb.append("\n OpenPages Port : " + this.openPagesPort);
/* 80:95 */     sb.append("\n User Name : " + this.userName);
/* 81:96 */     sb.append("\n");
/* 82:   */     
/* 83:98 */     return sb.toString();
/* 84:   */   }
/* 85:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.beans.AppServerInformation
 * JD-Core Version:    0.7.0.1
 */