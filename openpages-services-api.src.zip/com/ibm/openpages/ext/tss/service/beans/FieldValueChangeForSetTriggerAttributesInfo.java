/*  1:   */ package com.ibm.openpages.ext.tss.service.beans;
/*  2:   */ 
/*  3:   */ import com.ibm.openpages.api.trigger.TriggerPositionType;
/*  4:   */ import com.ibm.openpages.api.trigger.events.TriggerEventType;
/*  5:   */ 
/*  6:   */ public class FieldValueChangeForSetTriggerAttributesInfo
/*  7:   */   extends FieldValueChangeInfo
/*  8:   */ {
/*  9:   */   private TriggerEventType triggerEvent;
/* 10:   */   private TriggerPositionType triggerPosition;
/* 11:   */   private String triggerName;
/* 12:   */   private String triggerAttributeValue;
/* 13:   */   
/* 14:   */   public String getTriggerEvent()
/* 15:   */   {
/* 16:20 */     return this.triggerEvent.getName();
/* 17:   */   }
/* 18:   */   
/* 19:   */   public void setTriggerEvent(TriggerEventType triggerEvent)
/* 20:   */   {
/* 21:27 */     this.triggerEvent = triggerEvent;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public String getTriggerPosition()
/* 25:   */   {
/* 26:34 */     return this.triggerPosition.getPosition();
/* 27:   */   }
/* 28:   */   
/* 29:   */   public void setTriggerPosition(TriggerPositionType triggerPosition)
/* 30:   */   {
/* 31:40 */     this.triggerPosition = triggerPosition;
/* 32:   */   }
/* 33:   */   
/* 34:   */   public String getTriggerName()
/* 35:   */   {
/* 36:46 */     return this.triggerName;
/* 37:   */   }
/* 38:   */   
/* 39:   */   public void setTriggerName(String triggerName)
/* 40:   */   {
/* 41:52 */     this.triggerName = triggerName;
/* 42:   */   }
/* 43:   */   
/* 44:   */   public String getTriggerAttributeValue()
/* 45:   */   {
/* 46:58 */     return this.triggerAttributeValue;
/* 47:   */   }
/* 48:   */   
/* 49:   */   public void setTriggerAttributeValue(String triggerAttributeValue)
/* 50:   */   {
/* 51:64 */     this.triggerAttributeValue = triggerAttributeValue;
/* 52:   */   }
/* 53:   */   
/* 54:   */   public String getTriggerAttributeName()
/* 55:   */   {
/* 56:71 */     return getTriggerName() + "." + "modified.fields";
/* 57:   */   }
/* 58:   */   
/* 59:   */   public String toString()
/* 60:   */   {
/* 61:82 */     StringBuilder sb = new StringBuilder();
/* 62:   */     
/* 63:84 */     sb.append("\n Trigger Event: " + getTriggerEvent());
/* 64:85 */     sb.append("\n");
/* 65:86 */     sb.append("\n Trigger Position: " + getTriggerPosition());
/* 66:87 */     sb.append("\n");
/* 67:88 */     sb.append("\n Trigger Name: " + this.triggerName);
/* 68:89 */     sb.append("\n");
/* 69:90 */     sb.append("\n Trigger Attribute Name: " + getTriggerAttributeName());
/* 70:91 */     sb.append("\n");
/* 71:92 */     sb.append("\n Trigger Attribute Name: " + this.triggerAttributeValue);
/* 72:93 */     sb.append("\n");
/* 73:   */     
/* 74:95 */     return sb.toString();
/* 75:   */   }
/* 76:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.beans.FieldValueChangeForSetTriggerAttributesInfo
 * JD-Core Version:    0.7.0.1
 */