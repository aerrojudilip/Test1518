/*  1:   */ package com.ibm.openpages.ext.tss.service.beans;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ 
/*  5:   */ public class SnapshotObjectInformation
/*  6:   */   extends IGRCObjectAssociationInformation
/*  7:   */ {
/*  8:   */   private boolean isCopyDescription;
/*  9:   */   private String snapshotObjectType;
/* 10:   */   private List<String> ignoreFieldsToCopyList;
/* 11:   */   
/* 12:   */   public boolean isCopyDescription()
/* 13:   */   {
/* 14:16 */     return this.isCopyDescription;
/* 15:   */   }
/* 16:   */   
/* 17:   */   public void setCopyDescription(boolean isCopyDescription)
/* 18:   */   {
/* 19:22 */     this.isCopyDescription = isCopyDescription;
/* 20:   */   }
/* 21:   */   
/* 22:   */   public String getSnapshotObjectType()
/* 23:   */   {
/* 24:28 */     return this.snapshotObjectType;
/* 25:   */   }
/* 26:   */   
/* 27:   */   public void setSnapshotObjectType(String snapshotObjectType)
/* 28:   */   {
/* 29:34 */     this.snapshotObjectType = snapshotObjectType;
/* 30:   */   }
/* 31:   */   
/* 32:   */   public List<String> getIgnoreFieldsToCopyList()
/* 33:   */   {
/* 34:40 */     return this.ignoreFieldsToCopyList;
/* 35:   */   }
/* 36:   */   
/* 37:   */   public void setIgnoreFieldsToCopyList(List<String> ignoreFieldsToCopyList)
/* 38:   */   {
/* 39:46 */     this.ignoreFieldsToCopyList = ignoreFieldsToCopyList;
/* 40:   */   }
/* 41:   */   
/* 42:   */   public String toString()
/* 43:   */   {
/* 44:52 */     StringBuilder sb = new StringBuilder();
/* 45:   */     
/* 46:54 */     sb.append("\n");
/* 47:55 */     sb.append("\n Is copy description : " + this.isCopyDescription);
/* 48:56 */     sb.append("\n Snapshot Object Type : " + this.snapshotObjectType);
/* 49:57 */     sb.append("\n Ignore Fields to copy list : " + this.ignoreFieldsToCopyList);
/* 50:58 */     sb.append("\n");
/* 51:   */     
/* 52:60 */     return sb.toString();
/* 53:   */   }
/* 54:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.beans.SnapshotObjectInformation
 * JD-Core Version:    0.7.0.1
 */