/*  1:   */ package com.ibm.openpages.ext.tss.service.beans;
/*  2:   */ 
/*  3:   */ import com.ibm.openpages.api.metadata.Id;
/*  4:   */ import java.util.List;
/*  5:   */ 
/*  6:   */ public class IGRCObjectAssociationInformation
/*  7:   */ {
/*  8:   */   private boolean isSaveAfterAssociate;
/*  9:   */   private boolean isSetPrimaryParent;
/* 10:   */   private Id primaryParentAssociationId;
/* 11:   */   private List<Id> secondaryParentAssociationList;
/* 12:   */   private List<Id> childAssociationsList;
/* 13:   */   
/* 14:   */   public boolean isSaveAfterAssociate()
/* 15:   */   {
/* 16:20 */     return this.isSaveAfterAssociate;
/* 17:   */   }
/* 18:   */   
/* 19:   */   public void setSaveAfterAssociate(boolean isSaveAfterAssociate)
/* 20:   */   {
/* 21:26 */     this.isSaveAfterAssociate = isSaveAfterAssociate;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public boolean isSetPrimaryParent()
/* 25:   */   {
/* 26:32 */     return this.isSetPrimaryParent;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public void setSetPrimaryParent(boolean isSetPrimaryParent)
/* 30:   */   {
/* 31:38 */     this.isSetPrimaryParent = isSetPrimaryParent;
/* 32:   */   }
/* 33:   */   
/* 34:   */   public Id getPrimaryParentAssociationId()
/* 35:   */   {
/* 36:44 */     return this.primaryParentAssociationId;
/* 37:   */   }
/* 38:   */   
/* 39:   */   public void setPrimaryParentAssociationId(Id primaryParentAssociationId)
/* 40:   */   {
/* 41:50 */     this.primaryParentAssociationId = primaryParentAssociationId;
/* 42:   */   }
/* 43:   */   
/* 44:   */   public List<Id> getSecondaryParentAssociationList()
/* 45:   */   {
/* 46:56 */     return this.secondaryParentAssociationList;
/* 47:   */   }
/* 48:   */   
/* 49:   */   public void setSecondaryParentAssociationList(List<Id> secondaryParentAssociationList)
/* 50:   */   {
/* 51:62 */     this.secondaryParentAssociationList = secondaryParentAssociationList;
/* 52:   */   }
/* 53:   */   
/* 54:   */   public List<Id> getChildAssociationsList()
/* 55:   */   {
/* 56:68 */     return this.childAssociationsList;
/* 57:   */   }
/* 58:   */   
/* 59:   */   public void setChildAssociationsList(List<Id> childAssociationsList)
/* 60:   */   {
/* 61:74 */     this.childAssociationsList = childAssociationsList;
/* 62:   */   }
/* 63:   */   
/* 64:   */   public String toString()
/* 65:   */   {
/* 66:80 */     StringBuilder sb = new StringBuilder();
/* 67:   */     
/* 68:82 */     sb.append("\n Is Save Object after associate : " + this.isSaveAfterAssociate);
/* 69:83 */     sb.append("\n Is Set Primary Parent : " + this.isSetPrimaryParent);
/* 70:84 */     sb.append("\n Primary parent Object Id : " + this.primaryParentAssociationId);
/* 71:85 */     sb.append("\n Secondary Parents Id List : " + this.secondaryParentAssociationList);
/* 72:86 */     sb.append("\n Child Object Id List : " + this.childAssociationsList);
/* 73:87 */     sb.append("\n");
/* 74:   */     
/* 75:89 */     return sb.toString();
/* 76:   */   }
/* 77:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.beans.IGRCObjectAssociationInformation
 * JD-Core Version:    0.7.0.1
 */