/*  1:   */ package com.ibm.openpages.ext.tss.service.beans;
/*  2:   */ 
/*  3:   */ public class IGRCFieldInformationForQuery
/*  4:   */   extends IGRCFieldsInformation
/*  5:   */ {
/*  6:   */   private boolean includeResourceId;
/*  7:   */   private boolean isQueryOnSameObjectType;
/*  8:   */   private String objectTypeForQuery;
/*  9:   */   
/* 10:   */   public boolean isIncludeResourceId()
/* 11:   */   {
/* 12:14 */     return this.includeResourceId;
/* 13:   */   }
/* 14:   */   
/* 15:   */   public void setIncludeResourceId(boolean includeResourceId)
/* 16:   */   {
/* 17:21 */     this.includeResourceId = includeResourceId;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public boolean isQueryOnSameObjectType()
/* 21:   */   {
/* 22:28 */     return this.isQueryOnSameObjectType;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public void setQueryOnSameObjectType(boolean isQueryOnSameObjectType)
/* 26:   */   {
/* 27:35 */     this.isQueryOnSameObjectType = isQueryOnSameObjectType;
/* 28:   */   }
/* 29:   */   
/* 30:   */   public String getObjectTypeForQuery()
/* 31:   */   {
/* 32:42 */     return this.objectTypeForQuery;
/* 33:   */   }
/* 34:   */   
/* 35:   */   public void setObjectTypeForQuery(String objectTypeForQuery)
/* 36:   */   {
/* 37:49 */     this.objectTypeForQuery = objectTypeForQuery;
/* 38:   */   }
/* 39:   */   
/* 40:   */   public String toString()
/* 41:   */   {
/* 42:60 */     StringBuilder sb = new StringBuilder();
/* 43:61 */     super.toString();
/* 44:62 */     sb.append("\n");
/* 45:63 */     sb.append("\n Include Resoruce Id in query: " + this.includeResourceId);
/* 46:64 */     sb.append("\n Is Query On Same Object Type: " + this.isQueryOnSameObjectType);
/* 47:65 */     sb.append("\n Object Type for query: " + this.objectTypeForQuery);
/* 48:66 */     return sb.toString();
/* 49:   */   }
/* 50:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.beans.IGRCFieldInformationForQuery
 * JD-Core Version:    0.7.0.1
 */