/*   1:    */ package com.ibm.openpages.ext.tss.service.beans;
/*   2:    */ 
/*   3:    */ import java.io.File;
/*   4:    */ import java.util.List;
/*   5:    */ 
/*   6:    */ public class EmailInformation
/*   7:    */ {
/*   8:    */   private int emailSent;
/*   9:    */   private int emailFailed;
/*  10:    */   private boolean isTORequired;
/*  11:    */   private boolean isCCRequired;
/*  12:    */   private boolean isBCCRequired;
/*  13:    */   private boolean isAttachments;
/*  14:    */   private boolean isFormattedEmail;
/*  15:    */   private boolean isEmailNotification;
/*  16:    */   private boolean isEmailToMultipleCCAddress;
/*  17:    */   private boolean isEmailToMultipleBCCAddress;
/*  18:    */   private boolean isEmailToMultipleEmailAddresses;
/*  19:    */   private String emailBody;
/*  20:    */   private String mailServer;
/*  21:    */   private String fromName;
/*  22:    */   private String toAddress;
/*  23:    */   private String fromAddress;
/*  24:    */   private String emailSubject;
/*  25:    */   private String emailContent;
/*  26:    */   private String emailHeader;
/*  27:    */   private String emailFooter;
/*  28:    */   private String secondaryToAddress;
/*  29:    */   private String emailLayoutStyle;
/*  30:    */   private String ccAddress;
/*  31:    */   private String bccAddress;
/*  32:    */   private String invalidFromAddress;
/*  33:    */   private String toEmailSeperator;
/*  34:    */   private String ccEmailSeperator;
/*  35:    */   private String bccEmailSeperator;
/*  36:    */   private List<String> toAddresses;
/*  37:    */   private List<String> ccAddresses;
/*  38:    */   private List<String> bccAddresses;
/*  39:    */   private List<String> invalidToAddresses;
/*  40:    */   private List<String> invalidCCAddresses;
/*  41:    */   private List<String> invalidBCCAddresses;
/*  42:    */   private List<String> emailBodytableHeaderInfo;
/*  43:    */   private List<String> emailBodytableBodyInfo;
/*  44:    */   private List<String> invalidBodyRows;
/*  45:    */   private List<File> attachments;
/*  46:    */   
/*  47:    */   public String getMailServer()
/*  48:    */   {
/*  49: 56 */     return this.mailServer;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public void setMailServer(String mailServer)
/*  53:    */   {
/*  54: 62 */     this.mailServer = mailServer;
/*  55:    */   }
/*  56:    */   
/*  57:    */   public String getFromName()
/*  58:    */   {
/*  59: 68 */     return this.fromName;
/*  60:    */   }
/*  61:    */   
/*  62:    */   public void setFromName(String fromName)
/*  63:    */   {
/*  64: 74 */     this.fromName = fromName;
/*  65:    */   }
/*  66:    */   
/*  67:    */   public String getFromAddress()
/*  68:    */   {
/*  69: 80 */     return this.fromAddress;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public void setFromAddress(String fromAddress)
/*  73:    */   {
/*  74: 86 */     this.fromAddress = fromAddress;
/*  75:    */   }
/*  76:    */   
/*  77:    */   public String getEmailSubject()
/*  78:    */   {
/*  79: 92 */     return this.emailSubject;
/*  80:    */   }
/*  81:    */   
/*  82:    */   public void setEmailSubject(String emailSubject)
/*  83:    */   {
/*  84: 98 */     this.emailSubject = emailSubject;
/*  85:    */   }
/*  86:    */   
/*  87:    */   public String getEmailContent()
/*  88:    */   {
/*  89:104 */     return this.emailContent;
/*  90:    */   }
/*  91:    */   
/*  92:    */   public void setEmailContent(String emailContent)
/*  93:    */   {
/*  94:110 */     this.emailContent = emailContent;
/*  95:    */   }
/*  96:    */   
/*  97:    */   public boolean isEmailNotification()
/*  98:    */   {
/*  99:116 */     return this.isEmailNotification;
/* 100:    */   }
/* 101:    */   
/* 102:    */   public void setEmailNotification(boolean isEmailNotification)
/* 103:    */   {
/* 104:122 */     this.isEmailNotification = isEmailNotification;
/* 105:    */   }
/* 106:    */   
/* 107:    */   public String getSecondaryToAddress()
/* 108:    */   {
/* 109:128 */     return this.secondaryToAddress;
/* 110:    */   }
/* 111:    */   
/* 112:    */   public void setSecondaryToAddress(String secondaryToAddress)
/* 113:    */   {
/* 114:134 */     this.secondaryToAddress = secondaryToAddress;
/* 115:    */   }
/* 116:    */   
/* 117:    */   public List<String> getToAddresses()
/* 118:    */   {
/* 119:140 */     return this.toAddresses;
/* 120:    */   }
/* 121:    */   
/* 122:    */   public void setToAddresses(List<String> toAddresses)
/* 123:    */   {
/* 124:146 */     this.toAddresses = toAddresses;
/* 125:    */   }
/* 126:    */   
/* 127:    */   public String getToAddress()
/* 128:    */   {
/* 129:152 */     return this.toAddress;
/* 130:    */   }
/* 131:    */   
/* 132:    */   public void setToAddress(String toAddress)
/* 133:    */   {
/* 134:158 */     this.toAddress = toAddress;
/* 135:    */   }
/* 136:    */   
/* 137:    */   public int getEmailSent()
/* 138:    */   {
/* 139:164 */     return this.emailSent;
/* 140:    */   }
/* 141:    */   
/* 142:    */   public void setEmailSent(int emailSent)
/* 143:    */   {
/* 144:170 */     this.emailSent = emailSent;
/* 145:    */   }
/* 146:    */   
/* 147:    */   public int getEmailFailed()
/* 148:    */   {
/* 149:176 */     return this.emailFailed;
/* 150:    */   }
/* 151:    */   
/* 152:    */   public void setEmailFailed(int emailFailed)
/* 153:    */   {
/* 154:182 */     this.emailFailed = emailFailed;
/* 155:    */   }
/* 156:    */   
/* 157:    */   public String getEmailLayoutStyle()
/* 158:    */   {
/* 159:188 */     return this.emailLayoutStyle;
/* 160:    */   }
/* 161:    */   
/* 162:    */   public void setEmailLayoutStyle(String emailLayoutStyle)
/* 163:    */   {
/* 164:194 */     this.emailLayoutStyle = emailLayoutStyle;
/* 165:    */   }
/* 166:    */   
/* 167:    */   public String getEmailBody()
/* 168:    */   {
/* 169:201 */     StringBuilder sb = new StringBuilder();
/* 170:202 */     sb.append(this.emailLayoutStyle);
/* 171:203 */     sb.append(this.emailHeader);
/* 172:204 */     sb.append("<br/>");
/* 173:205 */     sb.append("<br/>");
/* 174:206 */     sb.append("<br/>");
/* 175:207 */     sb.append(this.emailContent);
/* 176:208 */     sb.append("<br/>");
/* 177:209 */     sb.append("<br/>");
/* 178:210 */     sb.append("<br/>");
/* 179:211 */     sb.append(this.emailFooter);
/* 180:    */     
/* 181:213 */     return sb.toString();
/* 182:    */   }
/* 183:    */   
/* 184:    */   public String getEmailHeader()
/* 185:    */   {
/* 186:220 */     return this.emailHeader;
/* 187:    */   }
/* 188:    */   
/* 189:    */   public void setEmailHeader(String emailHeader)
/* 190:    */   {
/* 191:226 */     this.emailHeader = emailHeader;
/* 192:    */   }
/* 193:    */   
/* 194:    */   public String getEmailFooter()
/* 195:    */   {
/* 196:232 */     return this.emailFooter;
/* 197:    */   }
/* 198:    */   
/* 199:    */   public void setEmailFooter(String emailFooter)
/* 200:    */   {
/* 201:238 */     this.emailFooter = emailFooter;
/* 202:    */   }
/* 203:    */   
/* 204:    */   public boolean isFormattedEmail()
/* 205:    */   {
/* 206:245 */     return this.isFormattedEmail;
/* 207:    */   }
/* 208:    */   
/* 209:    */   public void setFormattedEmail(boolean isFormattedEmail)
/* 210:    */   {
/* 211:251 */     this.isFormattedEmail = isFormattedEmail;
/* 212:    */   }
/* 213:    */   
/* 214:    */   public boolean isEmailToMultipleEmailAddresses()
/* 215:    */   {
/* 216:258 */     return this.isEmailToMultipleEmailAddresses;
/* 217:    */   }
/* 218:    */   
/* 219:    */   public void setEmailToMultipleEmailAddresses(boolean isEmailToMultipleEmailAddresses)
/* 220:    */   {
/* 221:265 */     this.isEmailToMultipleEmailAddresses = isEmailToMultipleEmailAddresses;
/* 222:    */   }
/* 223:    */   
/* 224:    */   public boolean isEmailToMultipleCCAddress()
/* 225:    */   {
/* 226:272 */     return this.isEmailToMultipleCCAddress;
/* 227:    */   }
/* 228:    */   
/* 229:    */   public void setEmailToMultipleCCAddress(boolean isEmailToMultipleCCAddress)
/* 230:    */   {
/* 231:278 */     this.isEmailToMultipleCCAddress = isEmailToMultipleCCAddress;
/* 232:    */   }
/* 233:    */   
/* 234:    */   public String getCcAddress()
/* 235:    */   {
/* 236:284 */     return this.ccAddress;
/* 237:    */   }
/* 238:    */   
/* 239:    */   public void setCcAddress(String ccAddress)
/* 240:    */   {
/* 241:290 */     this.ccAddress = ccAddress;
/* 242:    */   }
/* 243:    */   
/* 244:    */   public List<String> getCcAddresses()
/* 245:    */   {
/* 246:296 */     return this.ccAddresses;
/* 247:    */   }
/* 248:    */   
/* 249:    */   public void setCcAddresses(List<String> ccAddresses)
/* 250:    */   {
/* 251:302 */     this.ccAddresses = ccAddresses;
/* 252:    */   }
/* 253:    */   
/* 254:    */   public String getInvalidFromAddress()
/* 255:    */   {
/* 256:309 */     return this.invalidFromAddress;
/* 257:    */   }
/* 258:    */   
/* 259:    */   public void setInvalidFromAddress(String invalidFromAddress)
/* 260:    */   {
/* 261:315 */     this.invalidFromAddress = invalidFromAddress;
/* 262:    */   }
/* 263:    */   
/* 264:    */   public List<String> getInvalidToAddresses()
/* 265:    */   {
/* 266:321 */     return this.invalidToAddresses;
/* 267:    */   }
/* 268:    */   
/* 269:    */   public void setInvalidToAddresses(List<String> invalidToAddresses)
/* 270:    */   {
/* 271:327 */     this.invalidToAddresses = invalidToAddresses;
/* 272:    */   }
/* 273:    */   
/* 274:    */   public List<String> getInvalidCCAddresses()
/* 275:    */   {
/* 276:333 */     return this.invalidCCAddresses;
/* 277:    */   }
/* 278:    */   
/* 279:    */   public void setInvalidCCAddresses(List<String> invalidCCAddresses)
/* 280:    */   {
/* 281:339 */     this.invalidCCAddresses = invalidCCAddresses;
/* 282:    */   }
/* 283:    */   
/* 284:    */   public boolean isCCRequired()
/* 285:    */   {
/* 286:346 */     return this.isCCRequired;
/* 287:    */   }
/* 288:    */   
/* 289:    */   public void setCCRequired(boolean isCCRequired)
/* 290:    */   {
/* 291:352 */     this.isCCRequired = isCCRequired;
/* 292:    */   }
/* 293:    */   
/* 294:    */   public List<String> getEmailBodytableHeaderInfo()
/* 295:    */   {
/* 296:359 */     return this.emailBodytableHeaderInfo;
/* 297:    */   }
/* 298:    */   
/* 299:    */   public void setEmailBodytableHeaderInfo(List<String> emailBodytableHeaderInfo)
/* 300:    */   {
/* 301:365 */     this.emailBodytableHeaderInfo = emailBodytableHeaderInfo;
/* 302:    */   }
/* 303:    */   
/* 304:    */   public List<String> getEmailBodytableBodyInfo()
/* 305:    */   {
/* 306:371 */     return this.emailBodytableBodyInfo;
/* 307:    */   }
/* 308:    */   
/* 309:    */   public void setEmailBodytableBodyInfo(List<String> emailBodytableBodyInfo)
/* 310:    */   {
/* 311:377 */     this.emailBodytableBodyInfo = emailBodytableBodyInfo;
/* 312:    */   }
/* 313:    */   
/* 314:    */   public List<String> getInvalidBodyRows()
/* 315:    */   {
/* 316:383 */     return this.invalidBodyRows;
/* 317:    */   }
/* 318:    */   
/* 319:    */   public void setInvalidBodyRows(List<String> invalidBodyRows)
/* 320:    */   {
/* 321:389 */     this.invalidBodyRows = invalidBodyRows;
/* 322:    */   }
/* 323:    */   
/* 324:    */   public String getToEmailSeperator()
/* 325:    */   {
/* 326:396 */     return this.toEmailSeperator;
/* 327:    */   }
/* 328:    */   
/* 329:    */   public void setToEmailSeperator(String toEmailSeperator)
/* 330:    */   {
/* 331:402 */     this.toEmailSeperator = toEmailSeperator;
/* 332:    */   }
/* 333:    */   
/* 334:    */   public String getCcEmailSeperator()
/* 335:    */   {
/* 336:408 */     return this.ccEmailSeperator;
/* 337:    */   }
/* 338:    */   
/* 339:    */   public void setCcEmailSeperator(String ccEmailSeperator)
/* 340:    */   {
/* 341:414 */     this.ccEmailSeperator = ccEmailSeperator;
/* 342:    */   }
/* 343:    */   
/* 344:    */   public boolean isAttachments()
/* 345:    */   {
/* 346:420 */     return this.isAttachments;
/* 347:    */   }
/* 348:    */   
/* 349:    */   public void setAttachments(boolean isAttachments)
/* 350:    */   {
/* 351:426 */     this.isAttachments = isAttachments;
/* 352:    */   }
/* 353:    */   
/* 354:    */   public List<File> getAttachments()
/* 355:    */   {
/* 356:432 */     return this.attachments;
/* 357:    */   }
/* 358:    */   
/* 359:    */   public void setAttachments(List<File> attachments)
/* 360:    */   {
/* 361:438 */     this.attachments = attachments;
/* 362:    */   }
/* 363:    */   
/* 364:    */   public boolean isBCCRequired()
/* 365:    */   {
/* 366:445 */     return this.isBCCRequired;
/* 367:    */   }
/* 368:    */   
/* 369:    */   public void setBCCRequired(boolean isBCCRequired)
/* 370:    */   {
/* 371:451 */     this.isBCCRequired = isBCCRequired;
/* 372:    */   }
/* 373:    */   
/* 374:    */   public String getBccAddress()
/* 375:    */   {
/* 376:457 */     return this.bccAddress;
/* 377:    */   }
/* 378:    */   
/* 379:    */   public void setBccAddress(String bccAddress)
/* 380:    */   {
/* 381:463 */     this.bccAddress = bccAddress;
/* 382:    */   }
/* 383:    */   
/* 384:    */   public String getBccEmailSeperator()
/* 385:    */   {
/* 386:469 */     return this.bccEmailSeperator;
/* 387:    */   }
/* 388:    */   
/* 389:    */   public void setBccEmailSeperator(String bccEmailSeperator)
/* 390:    */   {
/* 391:475 */     this.bccEmailSeperator = bccEmailSeperator;
/* 392:    */   }
/* 393:    */   
/* 394:    */   public List<String> getBccAddresses()
/* 395:    */   {
/* 396:481 */     return this.bccAddresses;
/* 397:    */   }
/* 398:    */   
/* 399:    */   public void setBccAddresses(List<String> bccAddresses)
/* 400:    */   {
/* 401:487 */     this.bccAddresses = bccAddresses;
/* 402:    */   }
/* 403:    */   
/* 404:    */   public List<String> getInvalidBCCAddresses()
/* 405:    */   {
/* 406:493 */     return this.invalidBCCAddresses;
/* 407:    */   }
/* 408:    */   
/* 409:    */   public void setInvalidBCCAddresses(List<String> invalidBCCAddresses)
/* 410:    */   {
/* 411:499 */     this.invalidBCCAddresses = invalidBCCAddresses;
/* 412:    */   }
/* 413:    */   
/* 414:    */   public boolean isEmailToMultipleBCCAddress()
/* 415:    */   {
/* 416:506 */     return this.isEmailToMultipleBCCAddress;
/* 417:    */   }
/* 418:    */   
/* 419:    */   public void setEmailToMultipleBCCAddress(boolean isEmailToMultipleBCCAddress)
/* 420:    */   {
/* 421:512 */     this.isEmailToMultipleBCCAddress = isEmailToMultipleBCCAddress;
/* 422:    */   }
/* 423:    */   
/* 424:    */   public boolean isTORequired()
/* 425:    */   {
/* 426:519 */     return this.isTORequired;
/* 427:    */   }
/* 428:    */   
/* 429:    */   public void setTORequired(boolean isTORequired)
/* 430:    */   {
/* 431:525 */     this.isTORequired = isTORequired;
/* 432:    */   }
/* 433:    */   
/* 434:    */   public String toString()
/* 435:    */   {
/* 436:531 */     StringBuilder sb = new StringBuilder();
/* 437:    */     
/* 438:533 */     sb.append("\n Is TO Required: " + this.isTORequired);
/* 439:534 */     sb.append("\n Is CC Required: " + this.isCCRequired);
/* 440:535 */     sb.append("\n Is BCC Required: " + this.isBCCRequired);
/* 441:536 */     sb.append("\n Is Attachments: " + this.isAttachments);
/* 442:537 */     sb.append("\n Is Email Notification: " + this.isEmailNotification);
/* 443:538 */     sb.append("\n Is Formatted Email Notification: " + this.isFormattedEmail);
/* 444:539 */     sb.append("\n Is Email To Multiple Addresses: " + this.isEmailToMultipleEmailAddresses);
/* 445:540 */     sb.append("\n Is Email To Multiple CC Addresses: " + this.isEmailToMultipleCCAddress);
/* 446:541 */     sb.append("\n Is Email To Multiple BCC Addresses: " + this.isEmailToMultipleBCCAddress);
/* 447:    */     
/* 448:543 */     sb.append("\nTotal Email Sentr: " + this.emailSent);
/* 449:544 */     sb.append("\nTotal Email Failed: " + this.emailFailed);
/* 450:    */     
/* 451:546 */     sb.append("Mail Server: " + this.mailServer);
/* 452:547 */     sb.append("\n From Name: " + this.fromName);
/* 453:548 */     sb.append("\n From Address: " + this.fromAddress);
/* 454:549 */     sb.append("\n To Address: " + this.toAddress);
/* 455:550 */     sb.append("\n To Addresses: " + this.toAddresses);
/* 456:551 */     sb.append("\n To Email Seperator: " + this.toEmailSeperator);
/* 457:552 */     sb.append("\n CC Addresses: " + this.ccAddress);
/* 458:553 */     sb.append("\n CC Addresses: " + this.ccAddresses);
/* 459:554 */     sb.append("\n CC Email Seperator: " + this.ccEmailSeperator);
/* 460:555 */     sb.append("\n BCC Addresses: " + this.bccAddress);
/* 461:556 */     sb.append("\n BCC Addresses: " + this.bccAddresses);
/* 462:557 */     sb.append("\n BCC Email Seperator: " + this.bccEmailSeperator);
/* 463:558 */     sb.append("\n Secondary To Address: " + this.secondaryToAddress);
/* 464:559 */     sb.append("\n Attachments: " + this.attachments);
/* 465:560 */     sb.append("\n Email Subject: " + this.emailSubject);
/* 466:561 */     sb.append("\n Email Header: " + this.emailHeader);
/* 467:562 */     sb.append("\n Email Body: " + this.emailBody);
/* 468:563 */     sb.append("\n Email Body Table Header: " + this.emailBodytableHeaderInfo);
/* 469:564 */     sb.append("\n Email Body Table Body: " + this.emailBodytableBodyInfo);
/* 470:565 */     sb.append("\n Email Footer: " + this.emailFooter);
/* 471:566 */     sb.append("\n Email Content: " + this.emailContent);
/* 472:567 */     sb.append("\n Email Layout Style: " + this.emailLayoutStyle);
/* 473:    */     
/* 474:569 */     sb.append("\n Invalid From Address: " + this.invalidFromAddress);
/* 475:570 */     sb.append("\n Invalid To Addresses: " + this.invalidToAddresses);
/* 476:571 */     sb.append("\n Invalid CC Addresses: " + this.invalidCCAddresses);
/* 477:572 */     sb.append("\n Invalid CC Addresses: " + this.invalidBCCAddresses);
/* 478:573 */     sb.append("\n Invalid Body Rows: " + this.invalidBodyRows);
/* 479:574 */     sb.append("\n");
/* 480:    */     
/* 481:576 */     return sb.toString();
/* 482:    */   }
/* 483:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.beans.EmailInformation
 * JD-Core Version:    0.7.0.1
 */