/*   1:    */ package com.ibm.openpages.ext.tss.service.beans;
/*   2:    */ 
/*   3:    */ import com.ibm.openpages.api.resource.IGRCObject;
/*   4:    */ import com.ibm.openpages.ext.tss.service.util.CommonUtil;
/*   5:    */ import java.util.List;
/*   6:    */ 
/*   7:    */ public class IGRCObjectUpdateInformation
/*   8:    */ {
/*   9:    */   private boolean isUpdateInChild;
/*  10:    */   private boolean isUpdateInObject;
/*  11:    */   private boolean isUpdateInParent;
/*  12:    */   private boolean isUpdateInManyParent;
/*  13:    */   private boolean isUpdateManyChildren;
/*  14:    */   private boolean isUpdateFieldToField;
/*  15:    */   private boolean isResetSourceInChild;
/*  16:    */   private boolean isResetSourceInParent;
/*  17:    */   private boolean isResetSourceInObject;
/*  18:    */   private boolean isSourceFieldInChild;
/*  19:    */   private boolean isSourceFieldInParent;
/*  20:    */   private boolean isSourceFieldInObject;
/*  21:    */   private List<String> sourceFieldsList;
/*  22:    */   private List<String> updateValuesList;
/*  23:    */   private List<String> updateFieldsList;
/*  24:    */   private IGRCObject sourceObject;
/*  25:    */   private IGRCObject destinationObject;
/*  26:    */   
/*  27:    */   public boolean isUpdateInChild()
/*  28:    */   {
/*  29: 37 */     return this.isUpdateInChild;
/*  30:    */   }
/*  31:    */   
/*  32:    */   public void setUpdateInChild(boolean isUpdateInChild)
/*  33:    */   {
/*  34: 43 */     this.isUpdateInChild = isUpdateInChild;
/*  35:    */   }
/*  36:    */   
/*  37:    */   public boolean isUpdateInObject()
/*  38:    */   {
/*  39: 49 */     return this.isUpdateInObject;
/*  40:    */   }
/*  41:    */   
/*  42:    */   public void setUpdateInObject(boolean isUpdateInObject)
/*  43:    */   {
/*  44: 55 */     this.isUpdateInObject = isUpdateInObject;
/*  45:    */   }
/*  46:    */   
/*  47:    */   public boolean isUpdateInParent()
/*  48:    */   {
/*  49: 61 */     return this.isUpdateInParent;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public void setUpdateInParent(boolean isUpdateInParent)
/*  53:    */   {
/*  54: 67 */     this.isUpdateInParent = isUpdateInParent;
/*  55:    */   }
/*  56:    */   
/*  57:    */   public boolean isUpdateInManyParent()
/*  58:    */   {
/*  59: 73 */     return this.isUpdateInManyParent;
/*  60:    */   }
/*  61:    */   
/*  62:    */   public void setUpdateInManyParent(boolean isUpdateInManyParent)
/*  63:    */   {
/*  64: 79 */     this.isUpdateInManyParent = isUpdateInManyParent;
/*  65:    */   }
/*  66:    */   
/*  67:    */   public boolean isUpdateManyChildren()
/*  68:    */   {
/*  69: 85 */     return this.isUpdateManyChildren;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public void setUpdateManyChildren(boolean isUpdateManyChildren)
/*  73:    */   {
/*  74: 91 */     this.isUpdateManyChildren = isUpdateManyChildren;
/*  75:    */   }
/*  76:    */   
/*  77:    */   public boolean isUpdateFieldToField()
/*  78:    */   {
/*  79: 97 */     return this.isUpdateFieldToField;
/*  80:    */   }
/*  81:    */   
/*  82:    */   public void setUpdateFieldToField(boolean isUpdateFieldToField)
/*  83:    */   {
/*  84:103 */     this.isUpdateFieldToField = isUpdateFieldToField;
/*  85:    */   }
/*  86:    */   
/*  87:    */   public boolean isResetSourceInChild()
/*  88:    */   {
/*  89:109 */     return this.isResetSourceInChild;
/*  90:    */   }
/*  91:    */   
/*  92:    */   public void setResetSourceInChild(boolean isResetSourceInChild)
/*  93:    */   {
/*  94:115 */     this.isResetSourceInChild = isResetSourceInChild;
/*  95:    */   }
/*  96:    */   
/*  97:    */   public boolean isResetSourceInParent()
/*  98:    */   {
/*  99:121 */     return this.isResetSourceInParent;
/* 100:    */   }
/* 101:    */   
/* 102:    */   public void setResetSourceInParent(boolean isResetSourceInParent)
/* 103:    */   {
/* 104:127 */     this.isResetSourceInParent = isResetSourceInParent;
/* 105:    */   }
/* 106:    */   
/* 107:    */   public boolean isResetSourceInObject()
/* 108:    */   {
/* 109:133 */     return this.isResetSourceInObject;
/* 110:    */   }
/* 111:    */   
/* 112:    */   public void setResetSourceInObject(boolean isResetSourceInObject)
/* 113:    */   {
/* 114:139 */     this.isResetSourceInObject = isResetSourceInObject;
/* 115:    */   }
/* 116:    */   
/* 117:    */   public boolean isSourceFieldInChild()
/* 118:    */   {
/* 119:145 */     return this.isSourceFieldInChild;
/* 120:    */   }
/* 121:    */   
/* 122:    */   public void setSourceFieldInChild(boolean isSourceFieldInChild)
/* 123:    */   {
/* 124:151 */     this.isSourceFieldInChild = isSourceFieldInChild;
/* 125:    */   }
/* 126:    */   
/* 127:    */   public boolean isSourceFieldInParent()
/* 128:    */   {
/* 129:157 */     return this.isSourceFieldInParent;
/* 130:    */   }
/* 131:    */   
/* 132:    */   public void setSourceFieldInParent(boolean isSourceFieldInParent)
/* 133:    */   {
/* 134:163 */     this.isSourceFieldInParent = isSourceFieldInParent;
/* 135:    */   }
/* 136:    */   
/* 137:    */   public boolean isSourceFieldInObject()
/* 138:    */   {
/* 139:169 */     return this.isSourceFieldInObject;
/* 140:    */   }
/* 141:    */   
/* 142:    */   public void setSourceFieldInObject(boolean isSourceFieldInObject)
/* 143:    */   {
/* 144:175 */     this.isSourceFieldInObject = isSourceFieldInObject;
/* 145:    */   }
/* 146:    */   
/* 147:    */   public List<String> getSourceFieldsList()
/* 148:    */   {
/* 149:181 */     return this.sourceFieldsList;
/* 150:    */   }
/* 151:    */   
/* 152:    */   public void setSourceFieldsList(List<String> sourceFieldsList)
/* 153:    */   {
/* 154:187 */     this.sourceFieldsList = sourceFieldsList;
/* 155:    */   }
/* 156:    */   
/* 157:    */   public List<String> getUpdateValuesList()
/* 158:    */   {
/* 159:193 */     return this.updateValuesList;
/* 160:    */   }
/* 161:    */   
/* 162:    */   public void setUpdateValuesList(List<String> updateValuesList)
/* 163:    */   {
/* 164:199 */     this.updateValuesList = updateValuesList;
/* 165:    */   }
/* 166:    */   
/* 167:    */   public List<String> getUpdateFieldsList()
/* 168:    */   {
/* 169:205 */     return this.updateFieldsList;
/* 170:    */   }
/* 171:    */   
/* 172:    */   public void setUpdateFieldsList(List<String> updateFieldsList)
/* 173:    */   {
/* 174:211 */     this.updateFieldsList = updateFieldsList;
/* 175:    */   }
/* 176:    */   
/* 177:    */   public IGRCObject getSourceObject()
/* 178:    */   {
/* 179:217 */     return this.sourceObject;
/* 180:    */   }
/* 181:    */   
/* 182:    */   public void setSourceObject(IGRCObject sourceObject)
/* 183:    */   {
/* 184:223 */     this.sourceObject = sourceObject;
/* 185:    */   }
/* 186:    */   
/* 187:    */   public IGRCObject getDestinationObject()
/* 188:    */   {
/* 189:229 */     return this.destinationObject;
/* 190:    */   }
/* 191:    */   
/* 192:    */   public void setDestinationObject(IGRCObject destinationObject)
/* 193:    */   {
/* 194:235 */     this.destinationObject = destinationObject;
/* 195:    */   }
/* 196:    */   
/* 197:    */   public String toString()
/* 198:    */   {
/* 199:246 */     StringBuilder sb = new StringBuilder();
/* 200:    */     
/* 201:248 */     sb.append("\n");
/* 202:249 */     sb.append("\n Is Update In Child: " + this.isUpdateInChild);
/* 203:250 */     sb.append("\n Is Update In Object: " + this.isUpdateInObject);
/* 204:251 */     sb.append("\n Is Update In Parent: " + this.isUpdateInParent);
/* 205:252 */     sb.append("\n Is Update In Many Children: " + this.isUpdateManyChildren);
/* 206:253 */     sb.append("\n Is Update In Many Parent: " + this.isUpdateInManyParent);
/* 207:254 */     sb.append("\n Is Update Field To Field: " + this.isUpdateFieldToField);
/* 208:    */     
/* 209:256 */     sb.append("\n Is Reset Source In Child: " + this.isResetSourceInObject);
/* 210:257 */     sb.append("\n Is Reset Source In Object: " + this.isResetSourceInChild);
/* 211:258 */     sb.append("\n Is Reset Source In Parent: " + this.isResetSourceInParent);
/* 212:    */     
/* 213:260 */     sb.append("\n Is Source Field In Child: " + this.isSourceFieldInChild);
/* 214:261 */     sb.append("\n Is Source Field In Parent: " + this.isSourceFieldInParent);
/* 215:262 */     sb.append("\n Is Source Field In Object: " + this.isSourceFieldInObject);
/* 216:    */     
/* 217:264 */     sb.append("\n Source Fields List: " + this.sourceFieldsList);
/* 218:265 */     sb.append("\n Update Fields List: " + this.updateFieldsList);
/* 219:266 */     sb.append("\n Update Values List: " + this.updateValuesList);
/* 220:    */     
/* 221:268 */     sb.append("\n Source Object: " + (CommonUtil.isObjectNotNull(this.sourceObject) ? this.sourceObject.getName() : "Null"));
/* 222:269 */     sb.append("\n Destination Object: " + (CommonUtil.isObjectNotNull(this.destinationObject) ? this.destinationObject.getName() : "Null"));
/* 223:    */     
/* 224:271 */     return sb.toString();
/* 225:    */   }
/* 226:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.beans.IGRCObjectUpdateInformation
 * JD-Core Version:    0.7.0.1
 */