/*   1:    */ package com.ibm.openpages.ext.tss.service.beans;
/*   2:    */ 
/*   3:    */ import com.ibm.openpages.api.resource.IField;
/*   4:    */ import com.ibm.openpages.ext.tss.service.IFieldUtil;
/*   5:    */ import com.ibm.openpages.ext.tss.service.config.OPSServiceFactory;
/*   6:    */ import com.ibm.openpages.ext.tss.service.constants.CheckFor;
/*   7:    */ import com.ibm.openpages.ext.tss.service.util.CommonUtil;
/*   8:    */ import java.util.List;
/*   9:    */ import org.springframework.beans.factory.annotation.Autowired;
/*  10:    */ 
/*  11:    */ public class FieldValueChangeInfo
/*  12:    */ {
/*  13:    */   @Autowired
/*  14:    */   IFieldUtil fieldUtil;
/*  15:    */   private String fields;
/*  16:    */   private String values;
/*  17:    */   private CheckFor checkFor;
/*  18:    */   private List<IField> modifiedFields;
/*  19:    */   
/*  20:    */   public String getFields()
/*  21:    */   {
/*  22: 44 */     return this.fields;
/*  23:    */   }
/*  24:    */   
/*  25:    */   public void setFields(String fields)
/*  26:    */   {
/*  27: 52 */     this.fields = fields;
/*  28:    */   }
/*  29:    */   
/*  30:    */   public String getValues()
/*  31:    */   {
/*  32: 59 */     return this.values;
/*  33:    */   }
/*  34:    */   
/*  35:    */   public void setValues(String values)
/*  36:    */   {
/*  37: 67 */     this.values = values;
/*  38:    */   }
/*  39:    */   
/*  40:    */   public CheckFor getCheckFor()
/*  41:    */   {
/*  42: 74 */     return this.checkFor;
/*  43:    */   }
/*  44:    */   
/*  45:    */   public void setCheckFor(CheckFor checkFor)
/*  46:    */   {
/*  47: 82 */     this.checkFor = checkFor;
/*  48:    */   }
/*  49:    */   
/*  50:    */   public List<IField> getModifiedFields()
/*  51:    */   {
/*  52: 89 */     return this.modifiedFields;
/*  53:    */   }
/*  54:    */   
/*  55:    */   public void setModifiedFields(List<IField> modifiedFields)
/*  56:    */   {
/*  57: 97 */     this.modifiedFields = modifiedFields;
/*  58:    */   }
/*  59:    */   
/*  60:    */   public List<String> getValuesList()
/*  61:    */   {
/*  62:104 */     return CommonUtil.parseDelimitedValues(this.values, ",");
/*  63:    */   }
/*  64:    */   
/*  65:    */   public List<String> getFieldNamesList()
/*  66:    */   {
/*  67:112 */     return CommonUtil.parseDelimitedValues(this.fields, ",");
/*  68:    */   }
/*  69:    */   
/*  70:    */   public String toString()
/*  71:    */   {
/*  72:123 */     initFieldUtilServices();
/*  73:124 */     StringBuilder sb = new StringBuilder();
/*  74:    */     
/*  75:126 */     sb.append("\n Fields: " + this.fields);
/*  76:127 */     sb.append("\n");
/*  77:128 */     sb.append("\n Values: " + this.values);
/*  78:129 */     sb.append("\n");
/*  79:130 */     sb.append("\n Check For: " + this.checkFor);
/*  80:131 */     sb.append("\n");
/*  81:132 */     sb.append("\n Modifield Fields: " + this.fieldUtil.getFieldNamesAsList(this.modifiedFields));
/*  82:133 */     sb.append("\n");
/*  83:134 */     sb.append("\n Expected Fields: " + getFieldNamesList());
/*  84:135 */     sb.append("\n");
/*  85:136 */     sb.append("\n Expected Field Values: " + getValuesList());
/*  86:137 */     sb.append("\n");
/*  87:    */     
/*  88:139 */     return sb.toString();
/*  89:    */   }
/*  90:    */   
/*  91:    */   private void initFieldUtilServices()
/*  92:    */   {
/*  93:144 */     this.fieldUtil = OPSServiceFactory.getFieldUtil();
/*  94:    */   }
/*  95:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.beans.FieldValueChangeInfo
 * JD-Core Version:    0.7.0.1
 */