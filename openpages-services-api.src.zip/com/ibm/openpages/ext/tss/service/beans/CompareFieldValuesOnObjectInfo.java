/*   1:    */ package com.ibm.openpages.ext.tss.service.beans;
/*   2:    */ 
/*   3:    */ import com.ibm.openpages.api.resource.IGRCObject;
/*   4:    */ import com.ibm.openpages.ext.tss.service.ILoggerUtil;
/*   5:    */ import com.ibm.openpages.ext.tss.service.config.OPSServiceFactory;
/*   6:    */ import com.ibm.openpages.ext.tss.service.util.CommonUtil;
/*   7:    */ import java.util.List;
/*   8:    */ import org.apache.commons.logging.Log;
/*   9:    */ 
/*  10:    */ public class CompareFieldValuesOnObjectInfo
/*  11:    */ {
/*  12:    */   private boolean isCompareOnObject;
/*  13:    */   private boolean isCompareOnParent;
/*  14:    */   private boolean isCompareParentChild;
/*  15:    */   private boolean isCompareFieldToField;
/*  16:    */   private boolean isPlaceHolderValueFromParent;
/*  17:    */   private boolean isParentValuesFromCognosReport;
/*  18:    */   private boolean isCompareHeirarchyParentToChild;
/*  19:    */   private String checkForInObject;
/*  20:    */   private String exceptionToThrow;
/*  21:    */   private String compareExceptionInObjectForAny;
/*  22:    */   private String compareExceptionInObjectForAll;
/*  23:    */   private IGRCObject object;
/*  24:    */   private List<String> comparatorList;
/*  25:    */   private List<Object> exceptionArgumentsList;
/*  26:    */   private List<String> fieldsInObjectForCompareList;
/*  27:    */   private List<String> fieldsToBeComparedInObjectList;
/*  28:    */   private List<String> fieldValuesToBeComparedInObjectList;
/*  29:    */   private List<String> compareExceptionPlaceHolderValuesForAny;
/*  30:    */   private List<String> compareExceptionPlaceHolderValuesForAll;
/*  31:    */   private List<String> fieldValuesFromCognosToBeComparedInObjectList;
/*  32:    */   private CompareFieldValuesOnObjectInfo childFieldValuesOnObjectDTO;
/*  33:    */   Log logger;
/*  34:    */   
/*  35:    */   public CompareFieldValuesOnObjectInfo()
/*  36:    */   {
/*  37: 48 */     this.logger = OPSServiceFactory.getLoggerUtil().getExtLogger();
/*  38:    */   }
/*  39:    */   
/*  40:    */   public boolean isCompareOnObject()
/*  41:    */   {
/*  42: 55 */     return this.isCompareOnObject;
/*  43:    */   }
/*  44:    */   
/*  45:    */   public void setCompareOnObject(boolean isCompareOnObject)
/*  46:    */   {
/*  47: 63 */     this.isCompareOnObject = isCompareOnObject;
/*  48:    */   }
/*  49:    */   
/*  50:    */   public boolean isCompareOnParent()
/*  51:    */   {
/*  52: 70 */     return this.isCompareOnParent;
/*  53:    */   }
/*  54:    */   
/*  55:    */   public void setCompareOnParent(boolean isCompareOnParent)
/*  56:    */   {
/*  57: 78 */     this.isCompareOnParent = isCompareOnParent;
/*  58:    */   }
/*  59:    */   
/*  60:    */   public boolean isCompareParentChild()
/*  61:    */   {
/*  62: 85 */     return this.isCompareParentChild;
/*  63:    */   }
/*  64:    */   
/*  65:    */   public void setCompareParentChild(boolean isCompareParentChild)
/*  66:    */   {
/*  67: 93 */     this.isCompareParentChild = isCompareParentChild;
/*  68:    */   }
/*  69:    */   
/*  70:    */   public boolean isCompareFieldToField()
/*  71:    */   {
/*  72:100 */     return this.isCompareFieldToField;
/*  73:    */   }
/*  74:    */   
/*  75:    */   public void setCompareFieldToField(boolean isCompareFieldToField)
/*  76:    */   {
/*  77:108 */     this.isCompareFieldToField = isCompareFieldToField;
/*  78:    */   }
/*  79:    */   
/*  80:    */   public boolean isPlaceHolderValueFromParent()
/*  81:    */   {
/*  82:115 */     return this.isPlaceHolderValueFromParent;
/*  83:    */   }
/*  84:    */   
/*  85:    */   public void setPlaceHolderValueFromParent(boolean isPlaceHolderValueFromParent)
/*  86:    */   {
/*  87:123 */     this.isPlaceHolderValueFromParent = isPlaceHolderValueFromParent;
/*  88:    */   }
/*  89:    */   
/*  90:    */   public boolean isParentValuesFromCognosReport()
/*  91:    */   {
/*  92:130 */     return this.isParentValuesFromCognosReport;
/*  93:    */   }
/*  94:    */   
/*  95:    */   public void setParentValuesFromCognosReport(boolean isParentValuesFromCognosReport)
/*  96:    */   {
/*  97:138 */     this.isParentValuesFromCognosReport = isParentValuesFromCognosReport;
/*  98:    */   }
/*  99:    */   
/* 100:    */   public boolean isCompareHeirarchyParentToChild()
/* 101:    */   {
/* 102:145 */     return this.isCompareHeirarchyParentToChild;
/* 103:    */   }
/* 104:    */   
/* 105:    */   public void setCompareHeirarchyParentToChild(boolean isCompareHeirarchyParentToChild)
/* 106:    */   {
/* 107:153 */     this.isCompareHeirarchyParentToChild = isCompareHeirarchyParentToChild;
/* 108:    */   }
/* 109:    */   
/* 110:    */   public String getCheckForInObject()
/* 111:    */   {
/* 112:160 */     return this.checkForInObject;
/* 113:    */   }
/* 114:    */   
/* 115:    */   public void setCheckForInObject(String checkForInObject)
/* 116:    */   {
/* 117:168 */     this.checkForInObject = checkForInObject;
/* 118:    */   }
/* 119:    */   
/* 120:    */   public String getExceptionToThrow()
/* 121:    */   {
/* 122:175 */     return this.exceptionToThrow;
/* 123:    */   }
/* 124:    */   
/* 125:    */   public void setExceptionToThrow(String exceptionToThrow)
/* 126:    */   {
/* 127:183 */     this.exceptionToThrow = exceptionToThrow;
/* 128:    */   }
/* 129:    */   
/* 130:    */   public String getCompareExceptionInObjectForAny()
/* 131:    */   {
/* 132:190 */     return this.compareExceptionInObjectForAny;
/* 133:    */   }
/* 134:    */   
/* 135:    */   public void setCompareExceptionInObjectForAny(String compareExceptionInObjectForAny)
/* 136:    */   {
/* 137:198 */     this.compareExceptionInObjectForAny = compareExceptionInObjectForAny;
/* 138:    */   }
/* 139:    */   
/* 140:    */   public String getCompareExceptionInObjectForAll()
/* 141:    */   {
/* 142:205 */     return this.compareExceptionInObjectForAll;
/* 143:    */   }
/* 144:    */   
/* 145:    */   public void setCompareExceptionInObjectForAll(String compareExceptionInObjectForAll)
/* 146:    */   {
/* 147:213 */     this.compareExceptionInObjectForAll = compareExceptionInObjectForAll;
/* 148:    */   }
/* 149:    */   
/* 150:    */   public IGRCObject getObject()
/* 151:    */   {
/* 152:220 */     return this.object;
/* 153:    */   }
/* 154:    */   
/* 155:    */   public void setObject(IGRCObject object)
/* 156:    */   {
/* 157:228 */     this.object = object;
/* 158:    */   }
/* 159:    */   
/* 160:    */   public List<String> getComparatorList()
/* 161:    */   {
/* 162:235 */     return this.comparatorList;
/* 163:    */   }
/* 164:    */   
/* 165:    */   public void setComparatorList(List<String> comparatorList)
/* 166:    */   {
/* 167:243 */     this.comparatorList = comparatorList;
/* 168:    */   }
/* 169:    */   
/* 170:    */   public List<Object> getExceptionArgumentsList()
/* 171:    */   {
/* 172:250 */     return this.exceptionArgumentsList;
/* 173:    */   }
/* 174:    */   
/* 175:    */   public void setExceptionArgumentsList(List<Object> exceptionArgumentsList)
/* 176:    */   {
/* 177:258 */     this.exceptionArgumentsList = exceptionArgumentsList;
/* 178:    */   }
/* 179:    */   
/* 180:    */   public List<String> getFieldsInObjectForCompareList()
/* 181:    */   {
/* 182:265 */     return this.fieldsInObjectForCompareList;
/* 183:    */   }
/* 184:    */   
/* 185:    */   public void setFieldsInObjectForCompareList(List<String> fieldsInObjectForCompareList)
/* 186:    */   {
/* 187:273 */     this.fieldsInObjectForCompareList = fieldsInObjectForCompareList;
/* 188:    */   }
/* 189:    */   
/* 190:    */   public List<String> getFieldsToBeComparedInObjectList()
/* 191:    */   {
/* 192:280 */     return this.fieldsToBeComparedInObjectList;
/* 193:    */   }
/* 194:    */   
/* 195:    */   public void setFieldsToBeComparedInObjectList(List<String> fieldsToBeComparedInObjectList)
/* 196:    */   {
/* 197:288 */     this.fieldsToBeComparedInObjectList = fieldsToBeComparedInObjectList;
/* 198:    */   }
/* 199:    */   
/* 200:    */   public List<String> getFieldValuesToBeComparedInObjectList()
/* 201:    */   {
/* 202:295 */     return this.fieldValuesToBeComparedInObjectList;
/* 203:    */   }
/* 204:    */   
/* 205:    */   public void setFieldValuesToBeComparedInObjectList(List<String> fieldValuesToBeComparedInObjectList)
/* 206:    */   {
/* 207:303 */     this.fieldValuesToBeComparedInObjectList = fieldValuesToBeComparedInObjectList;
/* 208:    */   }
/* 209:    */   
/* 210:    */   public List<String> getCompareExceptionPlaceHolderValuesForAny()
/* 211:    */   {
/* 212:310 */     return this.compareExceptionPlaceHolderValuesForAny;
/* 213:    */   }
/* 214:    */   
/* 215:    */   public void setCompareExceptionPlaceHolderValuesForAny(List<String> compareExceptionPlaceHolderValuesForAny)
/* 216:    */   {
/* 217:318 */     this.compareExceptionPlaceHolderValuesForAny = compareExceptionPlaceHolderValuesForAny;
/* 218:    */   }
/* 219:    */   
/* 220:    */   public List<String> getCompareExceptionPlaceHolderValuesForAll()
/* 221:    */   {
/* 222:325 */     return this.compareExceptionPlaceHolderValuesForAll;
/* 223:    */   }
/* 224:    */   
/* 225:    */   public void setCompareExceptionPlaceHolderValuesForAll(List<String> compareExceptionPlaceHolderValuesForAll)
/* 226:    */   {
/* 227:333 */     this.compareExceptionPlaceHolderValuesForAll = compareExceptionPlaceHolderValuesForAll;
/* 228:    */   }
/* 229:    */   
/* 230:    */   public List<String> getFieldValuesFromCognosToBeComparedInObjectList()
/* 231:    */   {
/* 232:340 */     return this.fieldValuesFromCognosToBeComparedInObjectList;
/* 233:    */   }
/* 234:    */   
/* 235:    */   public void setFieldValuesFromCognosToBeComparedInObjectList(List<String> fieldValuesFromCognosToBeComparedInObjectList)
/* 236:    */   {
/* 237:349 */     this.fieldValuesFromCognosToBeComparedInObjectList = fieldValuesFromCognosToBeComparedInObjectList;
/* 238:    */   }
/* 239:    */   
/* 240:    */   public CompareFieldValuesOnObjectInfo getChildFieldValuesOnObjectDTO()
/* 241:    */   {
/* 242:356 */     return this.childFieldValuesOnObjectDTO;
/* 243:    */   }
/* 244:    */   
/* 245:    */   public void setChildFieldValuesOnObjectDTO(CompareFieldValuesOnObjectInfo childFieldValuesOnObjectDTO)
/* 246:    */   {
/* 247:364 */     this.childFieldValuesOnObjectDTO = childFieldValuesOnObjectDTO;
/* 248:    */   }
/* 249:    */   
/* 250:    */   public List<String> getCompareObjectList()
/* 251:    */   {
/* 252:370 */     return this.isCompareFieldToField ? this.fieldsToBeComparedInObjectList : this.isCompareParentChild ? this.childFieldValuesOnObjectDTO.getFieldsInObjectForCompareList() : this.fieldValuesToBeComparedInObjectList;
/* 253:    */   }
/* 254:    */   
/* 255:    */   public List<String> getFieldsInObjectListInParent()
/* 256:    */   {
/* 257:376 */     this.logger.debug("isParentValuesFromCognosReport: " + isParentValuesFromCognosReport());
/* 258:    */     
/* 259:378 */     return this.isParentValuesFromCognosReport ? this.fieldValuesFromCognosToBeComparedInObjectList : this.fieldsInObjectForCompareList;
/* 260:    */   }
/* 261:    */   
/* 262:    */   private boolean isListValuesNotNull()
/* 263:    */   {
/* 264:384 */     return (CommonUtil.isListNotNullOrEmpty(this.fieldsInObjectForCompareList)) && (CommonUtil.isListNotNullOrEmpty(getCompareObjectList())) && (CommonUtil.isListNotNullOrEmpty(getCompartorList()));
/* 265:    */   }
/* 266:    */   
/* 267:    */   private List<String> getCompartorList()
/* 268:    */   {
/* 269:390 */     return this.isCompareParentChild ? this.childFieldValuesOnObjectDTO.getComparatorList() : this.comparatorList;
/* 270:    */   }
/* 271:    */   
/* 272:    */   private boolean isListValuesForParentChildCompareNotNull()
/* 273:    */   {
/* 274:395 */     this.logger.debug("getFieldsInObjectListInParent: " + getFieldsInObjectListInParent());
/* 275:396 */     this.logger.debug("getCompareObjectList: " + getCompareObjectList());
/* 276:397 */     this.logger.debug("comparator list in child null or empty: " + CommonUtil.isListNotNullOrEmpty(getCompartorList()));
/* 277:    */     
/* 278:    */ 
/* 279:400 */     return (CommonUtil.isListNotNullOrEmpty(getFieldsInObjectListInParent())) && (CommonUtil.isObjectNotNull(this.childFieldValuesOnObjectDTO)) && (CommonUtil.isListNotNullOrEmpty(getCompareObjectList())) && (CommonUtil.isListNotNullOrEmpty(getCompartorList()));
/* 280:    */   }
/* 281:    */   
/* 282:    */   private boolean isListValuesSizeSame()
/* 283:    */   {
/* 284:406 */     return (isListValuesNotNull()) && (this.fieldsInObjectForCompareList.size() == getCompareObjectList().size()) && (getCompareObjectList().size() == getCompartorList().size());
/* 285:    */   }
/* 286:    */   
/* 287:    */   private boolean isListValuesForParentChildCompareSizeSame()
/* 288:    */   {
/* 289:411 */     this.logger.debug("isListValuesForParentChildCompareNotNull: " + isListValuesForParentChildCompareNotNull());
/* 290:    */     
/* 291:413 */     this.logger.debug("getFieldsInObjectListInParent: " + getFieldsInObjectListInParent().size());
/* 292:414 */     this.logger.debug("getCompareObjectList: " + getCompareObjectList().size());
/* 293:415 */     this.logger.debug("comparatorList: " + getCompartorList().size());
/* 294:    */     
/* 295:417 */     return (isListValuesForParentChildCompareNotNull()) && (getFieldsInObjectListInParent().size() == getCompareObjectList().size()) && (getCompareObjectList().size() == getCompartorList().size());
/* 296:    */   }
/* 297:    */   
/* 298:    */   private boolean isCheckForAndException()
/* 299:    */   {
/* 300:423 */     return (isListValuesNotNull()) && (((CommonUtil.isEqual(this.checkForInObject, "any")) && (CommonUtil.isNotNullOrEmpty(this.compareExceptionInObjectForAny))) || ((CommonUtil.isEqual(this.checkForInObject, "all")) && (CommonUtil.isNotNullOrEmpty(this.compareExceptionInObjectForAll))));
/* 301:    */   }
/* 302:    */   
/* 303:    */   private boolean isCheckForAndExceptionInParent()
/* 304:    */   {
/* 305:430 */     boolean flag = false;
/* 306:431 */     if (this.isCompareHeirarchyParentToChild) {
/* 307:432 */       flag = ((CommonUtil.isEqual(this.checkForInObject, "any")) && (CommonUtil.isNotNullOrEmpty(this.compareExceptionInObjectForAny))) || ((CommonUtil.isEqual(this.checkForInObject, "all")) && (CommonUtil.isNotNullOrEmpty(this.compareExceptionInObjectForAll)));
/* 308:    */     } else {
/* 309:435 */       flag = ((CommonUtil.isEqual(this.childFieldValuesOnObjectDTO.getCheckForInObject(), "any")) && (CommonUtil.isNotNullOrEmpty(this.childFieldValuesOnObjectDTO.getCompareExceptionInObjectForAny()))) || ((CommonUtil.isEqual(this.childFieldValuesOnObjectDTO.getCheckForInObject(), "all")) && (CommonUtil.isNotNullOrEmpty(this.childFieldValuesOnObjectDTO.getCompareExceptionInObjectForAll())));
/* 310:    */     }
/* 311:441 */     this.logger.debug("Flag calculated: " + flag);
/* 312:    */     
/* 313:443 */     return (isListValuesForParentChildCompareNotNull()) && (flag);
/* 314:    */   }
/* 315:    */   
/* 316:    */   public boolean isInfoAvailableForCompare()
/* 317:    */   {
/* 318:448 */     this.logger.debug("Is List Valeus size same: " + isListValuesSizeSame());
/* 319:449 */     this.logger.debug("Is Check For And Exception: " + isCheckForAndException());
/* 320:450 */     return (isListValuesSizeSame()) && (isCheckForAndException());
/* 321:    */   }
/* 322:    */   
/* 323:    */   public boolean isInfoAvailableForParentChildCompare()
/* 324:    */   {
/* 325:455 */     this.logger.debug("Is List Values For Parent Child: " + isListValuesForParentChildCompareSizeSame());
/* 326:456 */     this.logger.debug("Is Check For and Exception: " + isCheckForAndExceptionInParent());
/* 327:457 */     return (isListValuesForParentChildCompareSizeSame()) && (isCheckForAndExceptionInParent());
/* 328:    */   }
/* 329:    */   
/* 330:    */   public String toString()
/* 331:    */   {
/* 332:461 */     StringBuffer sb = new StringBuffer();
/* 333:462 */     sb.append("\n");
/* 334:463 */     sb.append("Is Compare On Object: " + this.isCompareOnObject);
/* 335:464 */     sb.append("\n");
/* 336:465 */     sb.append("Is Compare On Parent: " + this.isCompareOnParent);
/* 337:466 */     sb.append("\n");
/* 338:467 */     sb.append("Is Compare Parent Child: " + this.isCompareParentChild);
/* 339:468 */     sb.append("\n");
/* 340:469 */     sb.append("Is Compare Field to Field: " + this.isCompareFieldToField);
/* 341:470 */     sb.append("\n");
/* 342:471 */     sb.append("Is Compare Heirarcghy Parent To Child: " + this.isCompareHeirarchyParentToChild);
/* 343:472 */     sb.append("\n");
/* 344:473 */     sb.append("Is Compare Parent Values From Cognos report: " + this.isParentValuesFromCognosReport);
/* 345:474 */     sb.append("\n");
/* 346:475 */     sb.append("Is Place holder Value from Parent: " + this.isPlaceHolderValueFromParent);
/* 347:476 */     sb.append("\n");
/* 348:477 */     sb.append("Exception Identified: " + this.exceptionToThrow);
/* 349:478 */     sb.append("\n");
/* 350:479 */     sb.append("Exception Aguments List: " + this.exceptionArgumentsList);
/* 351:480 */     sb.append("\n");
/* 352:481 */     sb.append("Object Name: " + (CommonUtil.isObjectNotNull(this.object) ? this.object.getName() : "Null"));
/* 353:482 */     sb.append("\n");
/* 354:483 */     sb.append("Check For In Object" + this.checkForInObject);
/* 355:484 */     sb.append("\n");
/* 356:485 */     sb.append("Fields In Object For Compare List: " + this.fieldsInObjectForCompareList);
/* 357:486 */     sb.append("\n");
/* 358:487 */     sb.append("Fields To be Compared In Objects List: " + this.fieldsToBeComparedInObjectList);
/* 359:488 */     sb.append("\n");
/* 360:489 */     sb.append("Field Values To Be Compared In Objectst List: " + this.fieldValuesToBeComparedInObjectList);
/* 361:490 */     sb.append("\n");
/* 362:491 */     sb.append("Comparator List: " + this.comparatorList);
/* 363:492 */     sb.append("\n");
/* 364:493 */     sb.append("Compare Exception In Object For Any: " + this.compareExceptionInObjectForAny);
/* 365:494 */     sb.append("\n");
/* 366:495 */     sb.append("Compare Exception Place Holder For Any: " + this.compareExceptionPlaceHolderValuesForAny);
/* 367:496 */     sb.append("\n");
/* 368:497 */     sb.append("Compare Exception In Object For All: " + this.compareExceptionInObjectForAll);
/* 369:498 */     sb.append("\n");
/* 370:499 */     sb.append("Compare Exception Place Holder For Any: " + this.compareExceptionPlaceHolderValuesForAll);
/* 371:500 */     sb.append("\n");
/* 372:501 */     sb.append("Compare Values From Cognos Report: " + this.fieldValuesFromCognosToBeComparedInObjectList);
/* 373:502 */     sb.append("\n");
/* 374:503 */     sb.append("Child Object Information: " + (CommonUtil.isObjectNotNull(this.childFieldValuesOnObjectDTO) ? this.childFieldValuesOnObjectDTO.toString() : "Null"));
/* 375:    */     
/* 376:    */ 
/* 377:506 */     return sb.toString();
/* 378:    */   }
/* 379:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.beans.CompareFieldValuesOnObjectInfo
 * JD-Core Version:    0.7.0.1
 */