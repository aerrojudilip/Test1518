/*   1:    */ package com.ibm.openpages.ext.tss.service.beans;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ 
/*   5:    */ public class IGRCObjectValidateInformation
/*   6:    */   extends IGRCFieldValidateInformation
/*   7:    */ {
/*   8:    */   private boolean isEventOnChild;
/*   9:    */   private boolean isEventOnParent;
/*  10:    */   private boolean isEventOnObject;
/*  11:    */   private boolean isEventOnAllChild;
/*  12:    */   private boolean isEventOnAllParent;
/*  13:    */   private boolean isEventOnPrimaryParent;
/*  14:    */   private List<String> heirarchyList;
/*  15:    */   
/*  16:    */   public boolean isEventOnChild()
/*  17:    */   {
/*  18: 20 */     return this.isEventOnChild;
/*  19:    */   }
/*  20:    */   
/*  21:    */   public void setEventOnChild(boolean isEventOnChild)
/*  22:    */   {
/*  23: 26 */     this.isEventOnChild = isEventOnChild;
/*  24:    */   }
/*  25:    */   
/*  26:    */   public boolean isEventOnParent()
/*  27:    */   {
/*  28: 32 */     return this.isEventOnParent;
/*  29:    */   }
/*  30:    */   
/*  31:    */   public void setEventOnParent(boolean isEventOnParent)
/*  32:    */   {
/*  33: 38 */     this.isEventOnParent = isEventOnParent;
/*  34:    */   }
/*  35:    */   
/*  36:    */   public boolean isEventOnObject()
/*  37:    */   {
/*  38: 44 */     return this.isEventOnObject;
/*  39:    */   }
/*  40:    */   
/*  41:    */   public void setEventOnObject(boolean isEventOnObject)
/*  42:    */   {
/*  43: 50 */     this.isEventOnObject = isEventOnObject;
/*  44:    */   }
/*  45:    */   
/*  46:    */   public boolean isEventOnAllChild()
/*  47:    */   {
/*  48: 56 */     return this.isEventOnAllChild;
/*  49:    */   }
/*  50:    */   
/*  51:    */   public void setEventOnAllChild(boolean isEventOnAllChild)
/*  52:    */   {
/*  53: 62 */     this.isEventOnAllChild = isEventOnAllChild;
/*  54:    */   }
/*  55:    */   
/*  56:    */   public boolean isEventOnAllParent()
/*  57:    */   {
/*  58: 68 */     return this.isEventOnAllParent;
/*  59:    */   }
/*  60:    */   
/*  61:    */   public void setEventOnAllParent(boolean isEventOnAllParent)
/*  62:    */   {
/*  63: 74 */     this.isEventOnAllParent = isEventOnAllParent;
/*  64:    */   }
/*  65:    */   
/*  66:    */   public boolean isEventOnPrimaryParent()
/*  67:    */   {
/*  68: 80 */     return this.isEventOnPrimaryParent;
/*  69:    */   }
/*  70:    */   
/*  71:    */   public void setEventOnPrimaryParent(boolean isEventOnPrimaryParent)
/*  72:    */   {
/*  73: 86 */     this.isEventOnPrimaryParent = isEventOnPrimaryParent;
/*  74:    */   }
/*  75:    */   
/*  76:    */   public List<String> getHeirarchyList()
/*  77:    */   {
/*  78: 92 */     return this.heirarchyList;
/*  79:    */   }
/*  80:    */   
/*  81:    */   public void setHeirarchyList(List<String> heirarchyList)
/*  82:    */   {
/*  83: 98 */     this.heirarchyList = heirarchyList;
/*  84:    */   }
/*  85:    */   
/*  86:    */   public String toString()
/*  87:    */   {
/*  88:109 */     StringBuilder sb = new StringBuilder();
/*  89:    */     
/*  90:111 */     sb.append("\n");
/*  91:112 */     sb.append("\n Is Event On Child: " + this.isEventOnChild);
/*  92:113 */     sb.append("\n Is Event On Parent: " + this.isEventOnParent);
/*  93:114 */     sb.append("\n Is Event On Object: " + this.isEventOnObject);
/*  94:115 */     sb.append("\n Is Event On All Child: " + this.isEventOnAllChild);
/*  95:116 */     sb.append("\n Is Event On All Parent: " + this.isEventOnAllParent);
/*  96:117 */     sb.append("\n Is Event On Primary Parent: " + this.isEventOnPrimaryParent);
/*  97:    */     
/*  98:119 */     sb.append("\n Heirarchy List: " + this.heirarchyList);
/*  99:120 */     sb.append("\n" + super.toString());
/* 100:    */     
/* 101:122 */     return sb.toString();
/* 102:    */   }
/* 103:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.beans.IGRCObjectValidateInformation
 * JD-Core Version:    0.7.0.1
 */