/*   1:    */ package com.ibm.openpages.ext.tss.service.beans;
/*   2:    */ 
/*   3:    */ import com.ibm.openpages.ext.tss.service.util.CommonUtil;
/*   4:    */ import java.util.List;
/*   5:    */ 
/*   6:    */ public class IGRCFieldValidateInformation
/*   7:    */   extends IGRCFieldsInformation
/*   8:    */ {
/*   9:    */   private boolean isValid;
/*  10:    */   private boolean isException;
/*  11:    */   private boolean isPerformValidation;
/*  12:    */   private boolean isCompareFieldToField;
/*  13:    */   private String checkFor;
/*  14:    */   private String exceptionMessage;
/*  15:    */   private String checkAllExceptionMessage;
/*  16:    */   private List<Object> checkAllExceptionPlaceHolderValues;
/*  17:    */   private List<String> comparatorsList;
/*  18:    */   private List<String> checkAnyExceptionMessageList;
/*  19:    */   
/*  20:    */   public boolean isValid()
/*  21:    */   {
/*  22: 28 */     return this.isValid;
/*  23:    */   }
/*  24:    */   
/*  25:    */   public void setValid(boolean isValid)
/*  26:    */   {
/*  27: 34 */     this.isValid = isValid;
/*  28:    */   }
/*  29:    */   
/*  30:    */   public boolean isException()
/*  31:    */   {
/*  32: 40 */     return this.isException;
/*  33:    */   }
/*  34:    */   
/*  35:    */   public void setException(boolean isException)
/*  36:    */   {
/*  37: 46 */     this.isException = isException;
/*  38:    */   }
/*  39:    */   
/*  40:    */   public boolean isPerformValidation()
/*  41:    */   {
/*  42: 54 */     this.isPerformValidation = ((CommonUtil.isNotNullOrEmpty(this.checkAllExceptionMessage)) || (CommonUtil.isListNotNullOrEmpty(this.checkAnyExceptionMessageList)));
/*  43:    */     
/*  44: 56 */     return this.isPerformValidation;
/*  45:    */   }
/*  46:    */   
/*  47:    */   public void setPerformValidation(boolean isPerformValidation)
/*  48:    */   {
/*  49: 62 */     this.isPerformValidation = isPerformValidation;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public boolean isCompareFieldToField()
/*  53:    */   {
/*  54: 68 */     return this.isCompareFieldToField;
/*  55:    */   }
/*  56:    */   
/*  57:    */   public void setCompareFieldToField(boolean isCompareFieldToField)
/*  58:    */   {
/*  59: 74 */     this.isCompareFieldToField = isCompareFieldToField;
/*  60:    */   }
/*  61:    */   
/*  62:    */   public String getCheckFor()
/*  63:    */   {
/*  64: 80 */     return this.checkFor;
/*  65:    */   }
/*  66:    */   
/*  67:    */   public void setCheckFor(String checkFor)
/*  68:    */   {
/*  69: 86 */     this.checkFor = checkFor;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public String getExceptionMessage()
/*  73:    */   {
/*  74: 92 */     return this.exceptionMessage;
/*  75:    */   }
/*  76:    */   
/*  77:    */   public void setExceptionMessage(String exceptionMessage)
/*  78:    */   {
/*  79: 98 */     this.exceptionMessage = exceptionMessage;
/*  80:    */   }
/*  81:    */   
/*  82:    */   public String getCheckAllExceptionMessage()
/*  83:    */   {
/*  84:104 */     return this.checkAllExceptionMessage;
/*  85:    */   }
/*  86:    */   
/*  87:    */   public void setCheckAllExceptionMessage(String checkAllExceptionMessage)
/*  88:    */   {
/*  89:110 */     this.checkAllExceptionMessage = checkAllExceptionMessage;
/*  90:    */   }
/*  91:    */   
/*  92:    */   public List<Object> getCheckAllExceptionPlaceHolderValues()
/*  93:    */   {
/*  94:116 */     return this.checkAllExceptionPlaceHolderValues;
/*  95:    */   }
/*  96:    */   
/*  97:    */   public void setCheckAllExceptionPlaceHolderValues(List<Object> checkAllExceptionPlaceHolderValues)
/*  98:    */   {
/*  99:122 */     this.checkAllExceptionPlaceHolderValues = checkAllExceptionPlaceHolderValues;
/* 100:    */   }
/* 101:    */   
/* 102:    */   public List<String> getComparatorsList()
/* 103:    */   {
/* 104:128 */     return this.comparatorsList;
/* 105:    */   }
/* 106:    */   
/* 107:    */   public void setComparatorsList(List<String> comparatorsList)
/* 108:    */   {
/* 109:134 */     this.comparatorsList = comparatorsList;
/* 110:    */   }
/* 111:    */   
/* 112:    */   public List<String> getCheckAnyExceptionMessageList()
/* 113:    */   {
/* 114:140 */     return this.checkAnyExceptionMessageList;
/* 115:    */   }
/* 116:    */   
/* 117:    */   public void setCheckAnyExceptionMessageList(List<String> checkAnyExceptionMessageList)
/* 118:    */   {
/* 119:146 */     this.checkAnyExceptionMessageList = checkAnyExceptionMessageList;
/* 120:    */   }
/* 121:    */   
/* 122:    */   public String toString()
/* 123:    */   {
/* 124:157 */     StringBuilder sb = new StringBuilder();
/* 125:    */     
/* 126:159 */     sb.append("\n");
/* 127:160 */     sb.append("\n Is Check Valid: " + this.isValid);
/* 128:161 */     sb.append("\n Is Exception: " + this.isException);
/* 129:162 */     sb.append("\n Exception Message: " + this.exceptionMessage);
/* 130:163 */     sb.append("\n Is Compare Field To Field: " + this.isCompareFieldToField);
/* 131:    */     
/* 132:165 */     sb.append("\n Check For: " + this.checkFor);
/* 133:166 */     sb.append("\n Comparators: " + this.comparatorsList);
/* 134:167 */     sb.append(super.toString());
/* 135:    */     
/* 136:169 */     sb.append("\n Exception Message for CHECK_ALL: " + this.checkAnyExceptionMessageList);
/* 137:170 */     sb.append("\n Exception Messages for CHECK_ANY: " + this.checkAllExceptionMessage);
/* 138:171 */     sb.append("\n Place Holder Values for CHECK_ALL Exception: " + this.checkAllExceptionPlaceHolderValues);
/* 139:    */     
/* 140:173 */     return sb.toString();
/* 141:    */   }
/* 142:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.beans.IGRCFieldValidateInformation
 * JD-Core Version:    0.7.0.1
 */