/*  1:   */ package com.ibm.openpages.ext.tss.service.beans;
/*  2:   */ 
/*  3:   */ import com.ibm.openpages.api.metadata.Id;
/*  4:   */ import java.util.List;
/*  5:   */ 
/*  6:   */ public class IGRCObjectSearchInformation
/*  7:   */   extends IGRCFieldValidateInformation
/*  8:   */ {
/*  9: 9 */   private boolean includeObjectId = false;
/* 10:11 */   private Id objectId = null;
/* 11:13 */   private List<String> heirarchyList = null;
/* 12:   */   
/* 13:   */   public boolean isIncludeObjectId()
/* 14:   */   {
/* 15:19 */     return this.includeObjectId;
/* 16:   */   }
/* 17:   */   
/* 18:   */   public void setIncludeObjectId(boolean includeObjectId)
/* 19:   */   {
/* 20:25 */     this.includeObjectId = includeObjectId;
/* 21:   */   }
/* 22:   */   
/* 23:   */   public Id getObjectId()
/* 24:   */   {
/* 25:31 */     return this.objectId;
/* 26:   */   }
/* 27:   */   
/* 28:   */   public void setObjectId(Id objectId)
/* 29:   */   {
/* 30:37 */     this.objectId = objectId;
/* 31:   */   }
/* 32:   */   
/* 33:   */   public List<String> getHeirarchyList()
/* 34:   */   {
/* 35:43 */     return this.heirarchyList;
/* 36:   */   }
/* 37:   */   
/* 38:   */   public void setHeirarchyList(List<String> heirarchyList)
/* 39:   */   {
/* 40:49 */     this.heirarchyList = heirarchyList;
/* 41:   */   }
/* 42:   */   
/* 43:   */   public String toString()
/* 44:   */   {
/* 45:55 */     StringBuilder sb = new StringBuilder();
/* 46:   */     
/* 47:57 */     sb.append("\n Include Object Id in query : " + this.includeObjectId);
/* 48:58 */     sb.append("\n Object Id : " + this.objectId.toString());
/* 49:59 */     sb.append("\n Heirarchy List : " + this.heirarchyList);
/* 50:60 */     sb.append("\n");
/* 51:   */     
/* 52:62 */     return sb.toString();
/* 53:   */   }
/* 54:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.beans.IGRCObjectSearchInformation
 * JD-Core Version:    0.7.0.1
 */