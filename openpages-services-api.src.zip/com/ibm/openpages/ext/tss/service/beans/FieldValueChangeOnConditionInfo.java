/*  1:   */ package com.ibm.openpages.ext.tss.service.beans;
/*  2:   */ 
/*  3:   */ import com.ibm.openpages.api.resource.IGRCObject;
/*  4:   */ import com.ibm.openpages.ext.tss.service.constants.CheckFor;
/*  5:   */ import com.ibm.openpages.ext.tss.service.constants.Comparators;
/*  6:   */ import java.util.List;
/*  7:   */ 
/*  8:   */ public class FieldValueChangeOnConditionInfo
/*  9:   */ {
/* 10:   */   private CheckFor checkFor;
/* 11:   */   private IGRCObject object;
/* 12:   */   private List<String> fieldsInfoList;
/* 13:   */   private List<String> fieldValuesList;
/* 14:   */   private List<Comparators> conditionsList;
/* 15:   */   
/* 16:   */   public CheckFor getCheckFor()
/* 17:   */   {
/* 18:20 */     return this.checkFor;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public void setCheckFor(CheckFor checkFor)
/* 22:   */   {
/* 23:26 */     this.checkFor = checkFor;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public IGRCObject getObject()
/* 27:   */   {
/* 28:32 */     return this.object;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public void setObject(IGRCObject object)
/* 32:   */   {
/* 33:38 */     this.object = object;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public List<String> getFieldsInfoList()
/* 37:   */   {
/* 38:44 */     return this.fieldsInfoList;
/* 39:   */   }
/* 40:   */   
/* 41:   */   public void setFieldsInfoList(List<String> fieldsInfoList)
/* 42:   */   {
/* 43:50 */     this.fieldsInfoList = fieldsInfoList;
/* 44:   */   }
/* 45:   */   
/* 46:   */   public List<String> getFieldValuesList()
/* 47:   */   {
/* 48:56 */     return this.fieldValuesList;
/* 49:   */   }
/* 50:   */   
/* 51:   */   public void setFieldValuesList(List<String> fieldValuesList)
/* 52:   */   {
/* 53:62 */     this.fieldValuesList = fieldValuesList;
/* 54:   */   }
/* 55:   */   
/* 56:   */   public List<Comparators> getConditionsList()
/* 57:   */   {
/* 58:68 */     return this.conditionsList;
/* 59:   */   }
/* 60:   */   
/* 61:   */   public void setConditionsList(List<Comparators> conditionsList)
/* 62:   */   {
/* 63:74 */     this.conditionsList = conditionsList;
/* 64:   */   }
/* 65:   */   
/* 66:   */   public String toString()
/* 67:   */   {
/* 68:85 */     StringBuilder sb = new StringBuilder();
/* 69:   */     
/* 70:87 */     sb.append("\n Object Name: " + this.object.getName());
/* 71:88 */     sb.append("\n");
/* 72:89 */     sb.append("\n Check For: " + this.checkFor);
/* 73:90 */     sb.append("\n");
/* 74:91 */     sb.append("\n Fields Info List: " + this.fieldsInfoList);
/* 75:92 */     sb.append("\n");
/* 76:93 */     sb.append("\n Fields Values List: " + this.fieldValuesList);
/* 77:94 */     sb.append("\n");
/* 78:95 */     sb.append("\n Conditions List: " + this.conditionsList);
/* 79:96 */     sb.append("\n");
/* 80:   */     
/* 81:98 */     return sb.toString();
/* 82:   */   }
/* 83:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.beans.FieldValueChangeOnConditionInfo
 * JD-Core Version:    0.7.0.1
 */