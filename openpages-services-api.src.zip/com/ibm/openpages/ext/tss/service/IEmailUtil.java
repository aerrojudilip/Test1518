package com.ibm.openpages.ext.tss.service;

import com.ibm.openpages.ext.tss.service.beans.EmailInformation;
import java.util.List;

public abstract interface IEmailUtil
{
  public abstract void initService();
  
  public abstract void sendEmail(EmailInformation paramEmailInformation)
    throws Exception;
  
  public abstract void getEmailBodyInHTMLFormat(EmailInformation paramEmailInformation)
    throws Exception;
  
  public abstract boolean isSendEmail(EmailInformation paramEmailInformation)
    throws Exception;
  
  public abstract List<String> validateListOfEmailAddresses(List<String> paramList);
  
  public abstract boolean validateEmailAddress(String paramString);
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.IEmailUtil
 * JD-Core Version:    0.7.0.1
 */