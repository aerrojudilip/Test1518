package com.ibm.openpages.ext.tss.service;

import com.ibm.openpages.api.resource.IField;
import com.ibm.openpages.api.resource.IGRCObject;
import com.ibm.openpages.api.resource.IIntegerField;

public abstract interface IIntegerFieldUtil
{
  public abstract void initService();
  
  public abstract IIntegerField getIntegerField(IField paramIField)
    throws Exception;
  
  public abstract IIntegerField getIntegerField(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract boolean isIntegerFieldNull(IField paramIField)
    throws Exception;
  
  public abstract boolean isIntegerFieldNull(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract boolean isIntegerFieldNotNull(IField paramIField)
    throws Exception;
  
  public abstract boolean isIntegerFieldNotNull(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract boolean isIntegerFieldValueNull(IField paramIField)
    throws Exception;
  
  public abstract boolean isIntegerFieldValueNull(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract boolean isIntegerFieldValueNotNull(IField paramIField)
    throws Exception;
  
  public abstract boolean isIntegerFieldValueNotNull(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract String getIntegerFieldValueAsString(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract String getIntegerFieldValueAsString(IField paramIField)
    throws Exception;
  
  public abstract Integer getIntegerFieldValue(IField paramIField)
    throws Exception;
  
  public abstract Integer getIntegerFieldValue(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract float getIntegerFieldValueAsFloat(IField paramIField)
    throws Exception;
  
  public abstract float getIntegerFieldValueAsFloat(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract double getIntegerFieldValueAsDouble(IField paramIField)
    throws Exception;
  
  public abstract double getIntegerFieldValueAsDouble(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract long getIntegerFieldValueAsLong(IField paramIField)
    throws Exception;
  
  public abstract long getIntegerFieldValueAsLong(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract int getIntegerFieldValueAsInt(IField paramIField)
    throws Exception;
  
  public abstract long getIntegerFieldValueAsInt(IGRCObject paramIGRCObject, String paramString)
    throws Exception;
  
  public abstract void setIntegerField(IGRCObject paramIGRCObject, String paramString1, String paramString2)
    throws Exception;
  
  public abstract void setIntegerField(IGRCObject paramIGRCObject, String paramString, Integer paramInteger)
    throws Exception;
  
  public abstract void setIntegerField(IIntegerField paramIIntegerField, String paramString)
    throws Exception;
  
  public abstract void setIntegerField(IIntegerField paramIIntegerField, Integer paramInteger)
    throws Exception;
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.IIntegerFieldUtil
 * JD-Core Version:    0.7.0.1
 */