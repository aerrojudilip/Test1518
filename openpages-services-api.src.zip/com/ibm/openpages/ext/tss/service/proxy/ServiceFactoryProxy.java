/*  1:   */ package com.ibm.openpages.ext.tss.service.proxy;
/*  2:   */ 
/*  3:   */ import com.ibm.openpages.api.Context;
/*  4:   */ import com.ibm.openpages.api.service.IServiceFactory;
/*  5:   */ import com.ibm.openpages.api.service.ServiceFactory;
/*  6:   */ import com.ibm.openpages.ext.tss.service.config.ContextWrapper;
/*  7:   */ import com.ibm.openpages.ext.tss.service.util.CommonUtil;
/*  8:   */ import com.openpages.sdk.OpenpagesSession;
/*  9:   */ import java.io.PrintStream;
/* 10:   */ import org.springframework.beans.factory.BeanCreationException;
/* 11:   */ import org.springframework.beans.factory.annotation.Autowired;
/* 12:   */ import org.springframework.stereotype.Service;
/* 13:   */ 
/* 14:   */ @Service("serviceFactoryProxy")
/* 15:   */ public class ServiceFactoryProxy
/* 16:   */   implements IServiceFactoryProxy
/* 17:   */ {
/* 18:   */   @Autowired
/* 19:   */   IOPSessionProxy opSessionProxy;
/* 20:   */   private ContextWrapper contextWrapper;
/* 21:   */   
/* 22:   */   public IServiceFactory getServiceFactory()
/* 23:   */   {
/* 24:27 */     Context context = null;
/* 25:28 */     IServiceFactory sf = null;
/* 26:29 */     OpenpagesSession opSession = null;
/* 27:30 */     System.out.println("In Get Service Factory Start");
/* 28:   */     try
/* 29:   */     {
/* 30:34 */       context = new Context();
/* 31:35 */       opSession = this.opSessionProxy.getOpenpagesSession();
/* 32:36 */       context.put("com.ibm.openpages.sdk.service.session", opSession);
/* 33:37 */       sf = ServiceFactory.getServiceFactory(context);
/* 34:   */     }
/* 35:   */     catch (BeanCreationException bce)
/* 36:   */     {
/* 37:42 */       System.out.println("Bean Creation Exception: ");
/* 38:   */     }
/* 39:   */     catch (Exception ex)
/* 40:   */     {
/* 41:46 */       System.err.println("Generic Exception: " + ex.getMessage());
/* 42:   */     }
/* 43:52 */     if (CommonUtil.isObjectNull(opSession))
/* 44:   */     {
/* 45:54 */       System.out.println("Openapges Session is null creating new Service Factory with the Context Wrapper");
/* 46:   */       try
/* 47:   */       {
/* 48:58 */         sf = ServiceFactory.getServiceFactory(this.contextWrapper.getContext());
/* 49:   */       }
/* 50:   */       catch (Exception e)
/* 51:   */       {
/* 52:62 */         System.err.println("Error getting session from Trigger" + CommonUtil.getStackTrace(e));
/* 53:   */       }
/* 54:   */     }
/* 55:66 */     System.err.println("In Get Service Factory End");
/* 56:67 */     return sf;
/* 57:   */   }
/* 58:   */   
/* 59:   */   public void setContextWrapper(ContextWrapper contextwrapper)
/* 60:   */   {
/* 61:75 */     this.contextWrapper = contextwrapper;
/* 62:   */   }
/* 63:   */   
/* 64:   */   public ContextWrapper getContextWrapper()
/* 65:   */   {
/* 66:83 */     return this.contextWrapper;
/* 67:   */   }
/* 68:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.proxy.ServiceFactoryProxy
 * JD-Core Version:    0.7.0.1
 */