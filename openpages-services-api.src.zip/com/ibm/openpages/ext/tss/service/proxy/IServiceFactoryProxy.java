package com.ibm.openpages.ext.tss.service.proxy;

import com.ibm.openpages.api.service.IServiceFactory;
import com.ibm.openpages.ext.tss.service.config.ContextWrapper;

public abstract interface IServiceFactoryProxy
{
  public abstract IServiceFactory getServiceFactory();
  
  public abstract ContextWrapper getContextWrapper();
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.proxy.IServiceFactoryProxy
 * JD-Core Version:    0.7.0.1
 */