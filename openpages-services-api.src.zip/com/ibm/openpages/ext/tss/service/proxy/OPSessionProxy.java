/*  1:   */ package com.ibm.openpages.ext.tss.service.proxy;
/*  2:   */ 
/*  3:   */ import com.ibm.openpages.ext.tss.service.util.CommonUtil;
/*  4:   */ import com.openpages.apps.common.util.HttpContext;
/*  5:   */ import com.openpages.sdk.OpenpagesSession;
/*  6:   */ import java.io.PrintStream;
/*  7:   */ import java.util.Enumeration;
/*  8:   */ import javax.servlet.http.HttpSession;
/*  9:   */ import org.springframework.beans.factory.annotation.Autowired;
/* 10:   */ import org.springframework.context.annotation.Scope;
/* 11:   */ import org.springframework.context.annotation.ScopedProxyMode;
/* 12:   */ import org.springframework.stereotype.Service;
/* 13:   */ 
/* 14:   */ @Service("opSessionProxy")
/* 15:   */ @Scope(value="session", proxyMode=ScopedProxyMode.TARGET_CLASS)
/* 16:   */ public class OPSessionProxy
/* 17:   */   implements IOPSessionProxy
/* 18:   */ {
/* 19:   */   @Autowired
/* 20:   */   private HttpSession httpSession;
/* 21:   */   private OpenpagesSession opSession;
/* 22:   */   
/* 23:   */   public OpenpagesSession getOpenpagesSession()
/* 24:   */   {
/* 25:34 */     OpenpagesSession openpagesSession = null;
/* 26:   */     
/* 27:   */ 
/* 28:   */ 
/* 29:   */ 
/* 30:39 */     openpagesSession = CommonUtil.isObjectNull(HttpContext.getAttribute(this.httpSession, "application", "OpenpagesSession")) ? null : (OpenpagesSession)HttpContext.getAttribute(this.httpSession, "application", "OpenpagesSession");
/* 31:   */     
/* 32:   */ 
/* 33:42 */     System.out.println("OPSession proxy : Openpages session " + openpagesSession);
/* 34:43 */     return openpagesSession;
/* 35:   */   }
/* 36:   */   
/* 37:   */   private void logHttpSessionParams(HttpSession httpSession)
/* 38:   */   {
/* 39:53 */     Enumeration<?> enums = null;
/* 40:   */     try
/* 41:   */     {
/* 42:57 */       System.out.println("OPSesion proxy : Http session is " + httpSession);
/* 43:59 */       if (CommonUtil.isObjectNotNull(httpSession))
/* 44:   */       {
/* 45:61 */         System.out.println("Session attribtues " + httpSession.getAttributeNames());
/* 46:62 */         enums = httpSession.getAttributeNames();
/* 47:64 */         while (enums.hasMoreElements()) {
/* 48:65 */           System.out.println(enums.nextElement());
/* 49:   */         }
/* 50:   */       }
/* 51:   */     }
/* 52:   */     catch (Exception ex)
/* 53:   */     {
/* 54:71 */       System.err.println("Exception in getOpenpagesSession() + " + CommonUtil.getStackTrace(ex));
/* 55:   */     }
/* 56:   */   }
/* 57:   */   
/* 58:   */   public OpenpagesSession getOpSession()
/* 59:   */   {
/* 60:79 */     return this.opSession;
/* 61:   */   }
/* 62:   */   
/* 63:   */   public void setOpSession(OpenpagesSession opSession)
/* 64:   */   {
/* 65:86 */     this.opSession = opSession;
/* 66:   */   }
/* 67:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.proxy.OPSessionProxy
 * JD-Core Version:    0.7.0.1
 */