/*  1:   */ package com.ibm.openpages.ext.tss.service.config;
/*  2:   */ 
/*  3:   */ import org.springframework.beans.BeansException;
/*  4:   */ import org.springframework.context.ApplicationContext;
/*  5:   */ import org.springframework.context.ApplicationContextAware;
/*  6:   */ import org.springframework.stereotype.Component;
/*  7:   */ 
/*  8:   */ @Component("appContext")
/*  9:   */ public class ApplicationContextUtils
/* 10:   */   implements ApplicationContextAware
/* 11:   */ {
/* 12:   */   private static ApplicationContext CONTEXT;
/* 13:   */   
/* 14:   */   public void setApplicationContext(ApplicationContext context)
/* 15:   */     throws BeansException
/* 16:   */   {
/* 17:38 */     CONTEXT = context;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public static Object getBean(String beanName)
/* 21:   */   {
/* 22:57 */     return CONTEXT.getBean(beanName);
/* 23:   */   }
/* 24:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.config.ApplicationContextUtils
 * JD-Core Version:    0.7.0.1
 */