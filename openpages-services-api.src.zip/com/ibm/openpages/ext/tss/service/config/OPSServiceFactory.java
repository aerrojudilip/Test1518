/*   1:    */ package com.ibm.openpages.ext.tss.service.config;
/*   2:    */ 
/*   3:    */ import com.ibm.openpages.ext.tss.helpers.dao.IHelperAppBaseDAO;
/*   4:    */ import com.ibm.openpages.ext.tss.service.IApplicationUtil;
/*   5:    */ import com.ibm.openpages.ext.tss.service.ICognosUtil;
/*   6:    */ import com.ibm.openpages.ext.tss.service.ICurrencyFieldUtil;
/*   7:    */ import com.ibm.openpages.ext.tss.service.IDateFieldUtil;
/*   8:    */ import com.ibm.openpages.ext.tss.service.IEmailUtil;
/*   9:    */ import com.ibm.openpages.ext.tss.service.IEnumFieldUtil;
/*  10:    */ import com.ibm.openpages.ext.tss.service.IFieldUtil;
/*  11:    */ import com.ibm.openpages.ext.tss.service.IFileUtil;
/*  12:    */ import com.ibm.openpages.ext.tss.service.IFloatFieldUtil;
/*  13:    */ import com.ibm.openpages.ext.tss.service.IGRCObjectSearchUtil;
/*  14:    */ import com.ibm.openpages.ext.tss.service.IGRCObjectUtil;
/*  15:    */ import com.ibm.openpages.ext.tss.service.IGRCTriggerUtil;
/*  16:    */ import com.ibm.openpages.ext.tss.service.IGRCUpdateTriggerUtil;
/*  17:    */ import com.ibm.openpages.ext.tss.service.IGRCValidationTriggerUtil;
/*  18:    */ import com.ibm.openpages.ext.tss.service.IIDFieldUtil;
/*  19:    */ import com.ibm.openpages.ext.tss.service.IIntegerFieldUtil;
/*  20:    */ import com.ibm.openpages.ext.tss.service.ILoggerUtil;
/*  21:    */ import com.ibm.openpages.ext.tss.service.IMultiEnumFieldUtil;
/*  22:    */ import com.ibm.openpages.ext.tss.service.IStringFieldUtil;
/*  23:    */ import com.ibm.openpages.ext.tss.service.IUserUtil;
/*  24:    */ import com.ibm.openpages.ext.tss.service.proxy.IOPSessionProxy;
/*  25:    */ import com.ibm.openpages.ext.tss.service.proxy.IServiceFactoryProxy;
/*  26:    */ 
/*  27:    */ public class OPSServiceFactory
/*  28:    */ {
/*  29:    */   public static IApplicationUtil getApplicationUtil()
/*  30:    */   {
/*  31: 57 */     return (IApplicationUtil)ApplicationContextUtils.getBean("applicationUtil");
/*  32:    */   }
/*  33:    */   
/*  34:    */   public static IOPSessionProxy getOPSessionProxy()
/*  35:    */   {
/*  36: 73 */     return (IOPSessionProxy)ApplicationContextUtils.getBean("opSessionProxy");
/*  37:    */   }
/*  38:    */   
/*  39:    */   public static ILoggerUtil getLoggerUtil()
/*  40:    */   {
/*  41: 87 */     return (ILoggerUtil)ApplicationContextUtils.getBean("loggerUtil");
/*  42:    */   }
/*  43:    */   
/*  44:    */   public static IEmailUtil getEmailUtil()
/*  45:    */   {
/*  46:100 */     return (IEmailUtil)ApplicationContextUtils.getBean("emailUtil");
/*  47:    */   }
/*  48:    */   
/*  49:    */   public static IServiceFactoryProxy getServiceFactoryProxy()
/*  50:    */   {
/*  51:114 */     return (IServiceFactoryProxy)ApplicationContextUtils.getBean("serviceFactoryProxy");
/*  52:    */   }
/*  53:    */   
/*  54:    */   public static ICognosUtil getCognosUtil()
/*  55:    */   {
/*  56:128 */     return (ICognosUtil)ApplicationContextUtils.getBean("cognosUtil");
/*  57:    */   }
/*  58:    */   
/*  59:    */   public static IUserUtil getUserUtil()
/*  60:    */   {
/*  61:141 */     return (IUserUtil)ApplicationContextUtils.getBean("userUtil");
/*  62:    */   }
/*  63:    */   
/*  64:    */   public static IGRCTriggerUtil getGRCTriggerUtil()
/*  65:    */   {
/*  66:154 */     return (IGRCTriggerUtil)ApplicationContextUtils.getBean("grcTriggerUtil");
/*  67:    */   }
/*  68:    */   
/*  69:    */   public static IGRCValidationTriggerUtil getGRCValidationTriggerUtil()
/*  70:    */   {
/*  71:169 */     return (IGRCValidationTriggerUtil)ApplicationContextUtils.getBean("grcValidationTriggerUtil");
/*  72:    */   }
/*  73:    */   
/*  74:    */   public static IGRCUpdateTriggerUtil getGRCUpdateTriggerUtil()
/*  75:    */   {
/*  76:184 */     return (IGRCUpdateTriggerUtil)ApplicationContextUtils.getBean("grcUpdateTriggerUtil");
/*  77:    */   }
/*  78:    */   
/*  79:    */   public static IGRCObjectUtil getGRCObjectUtil()
/*  80:    */   {
/*  81:198 */     return (IGRCObjectUtil)ApplicationContextUtils.getBean("grcObjectUtil");
/*  82:    */   }
/*  83:    */   
/*  84:    */   public static IGRCObjectSearchUtil getGRCObjectSearchUtil()
/*  85:    */   {
/*  86:213 */     return (IGRCObjectSearchUtil)ApplicationContextUtils.getBean("grcObjectSearchUtil");
/*  87:    */   }
/*  88:    */   
/*  89:    */   public static IFieldUtil getFieldUtil()
/*  90:    */   {
/*  91:227 */     return (IFieldUtil)ApplicationContextUtils.getBean("fieldUtil");
/*  92:    */   }
/*  93:    */   
/*  94:    */   public static IFloatFieldUtil getFloatFieldUtil()
/*  95:    */   {
/*  96:240 */     return (IFloatFieldUtil)ApplicationContextUtils.getBean("floatFieldUtil");
/*  97:    */   }
/*  98:    */   
/*  99:    */   public static IEnumFieldUtil getEnumFieldUtil()
/* 100:    */   {
/* 101:254 */     return (IEnumFieldUtil)ApplicationContextUtils.getBean("enumFieldUtil");
/* 102:    */   }
/* 103:    */   
/* 104:    */   public static IMultiEnumFieldUtil getMultiEnumFieldUtil()
/* 105:    */   {
/* 106:268 */     return (IMultiEnumFieldUtil)ApplicationContextUtils.getBean("multiEnumFieldUtil");
/* 107:    */   }
/* 108:    */   
/* 109:    */   public static IDateFieldUtil getDateFieldUtil()
/* 110:    */   {
/* 111:282 */     return (IDateFieldUtil)ApplicationContextUtils.getBean("dateFieldUtil");
/* 112:    */   }
/* 113:    */   
/* 114:    */   public static IStringFieldUtil getStringFieldUtil()
/* 115:    */   {
/* 116:296 */     return (IStringFieldUtil)ApplicationContextUtils.getBean("stringFieldUtil");
/* 117:    */   }
/* 118:    */   
/* 119:    */   public static IIntegerFieldUtil getIntegerFieldUtil()
/* 120:    */   {
/* 121:310 */     return (IIntegerFieldUtil)ApplicationContextUtils.getBean("integerFieldUtil");
/* 122:    */   }
/* 123:    */   
/* 124:    */   public static IIDFieldUtil getIDFieldUtil()
/* 125:    */   {
/* 126:324 */     return (IIDFieldUtil)ApplicationContextUtils.getBean("idFieldUtil");
/* 127:    */   }
/* 128:    */   
/* 129:    */   public static ICurrencyFieldUtil getICurrencyFieldUtil()
/* 130:    */   {
/* 131:337 */     return (ICurrencyFieldUtil)ApplicationContextUtils.getBean("currencyFieldUtil");
/* 132:    */   }
/* 133:    */   
/* 134:    */   public static IFileUtil getIFileUtil()
/* 135:    */   {
/* 136:351 */     return (IFileUtil)ApplicationContextUtils.getBean("fileUtil");
/* 137:    */   }
/* 138:    */   
/* 139:    */   public static IHelperAppBaseDAO getHelperAppBaseDAO()
/* 140:    */   {
/* 141:364 */     return (IHelperAppBaseDAO)ApplicationContextUtils.getBean("helperAppBaseDAO");
/* 142:    */   }
/* 143:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.config.OPSServiceFactory
 * JD-Core Version:    0.7.0.1
 */