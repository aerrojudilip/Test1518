/*   1:    */ package com.ibm.openpages.ext.tss.service.config;
/*   2:    */ 
/*   3:    */ import com.ibm.openpages.ext.tss.helpers.dao.IHelperAppBaseDAO;
/*   4:    */ import com.ibm.openpages.ext.tss.helpers.dao.impl.HelperAppBaseDAOImpl;
/*   5:    */ import com.ibm.openpages.ext.tss.service.IApplicationUtil;
/*   6:    */ import com.ibm.openpages.ext.tss.service.ICognosUtil;
/*   7:    */ import com.ibm.openpages.ext.tss.service.IDateFieldUtil;
/*   8:    */ import com.ibm.openpages.ext.tss.service.IEmailUtil;
/*   9:    */ import com.ibm.openpages.ext.tss.service.IEnumFieldUtil;
/*  10:    */ import com.ibm.openpages.ext.tss.service.IFieldUtil;
/*  11:    */ import com.ibm.openpages.ext.tss.service.IFileUtil;
/*  12:    */ import com.ibm.openpages.ext.tss.service.IFloatFieldUtil;
/*  13:    */ import com.ibm.openpages.ext.tss.service.IGRCObjectSearchUtil;
/*  14:    */ import com.ibm.openpages.ext.tss.service.IGRCObjectUtil;
/*  15:    */ import com.ibm.openpages.ext.tss.service.IGRCTriggerUtil;
/*  16:    */ import com.ibm.openpages.ext.tss.service.IGRCUpdateTriggerUtil;
/*  17:    */ import com.ibm.openpages.ext.tss.service.IGRCValidationTriggerUtil;
/*  18:    */ import com.ibm.openpages.ext.tss.service.IIDFieldUtil;
/*  19:    */ import com.ibm.openpages.ext.tss.service.IIntegerFieldUtil;
/*  20:    */ import com.ibm.openpages.ext.tss.service.ILoggerUtil;
/*  21:    */ import com.ibm.openpages.ext.tss.service.IMultiEnumFieldUtil;
/*  22:    */ import com.ibm.openpages.ext.tss.service.IStringFieldUtil;
/*  23:    */ import com.ibm.openpages.ext.tss.service.IUserUtil;
/*  24:    */ import com.ibm.openpages.ext.tss.service.impl.ApplicationUtil;
/*  25:    */ import com.ibm.openpages.ext.tss.service.impl.CognosUtil;
/*  26:    */ import com.ibm.openpages.ext.tss.service.impl.DateFieldUtil;
/*  27:    */ import com.ibm.openpages.ext.tss.service.impl.EmailUtil;
/*  28:    */ import com.ibm.openpages.ext.tss.service.impl.EnumFieldUtil;
/*  29:    */ import com.ibm.openpages.ext.tss.service.impl.FieldUtil;
/*  30:    */ import com.ibm.openpages.ext.tss.service.impl.FileUtil;
/*  31:    */ import com.ibm.openpages.ext.tss.service.impl.FloatFieldUtil;
/*  32:    */ import com.ibm.openpages.ext.tss.service.impl.GRCObjectSearchUtil;
/*  33:    */ import com.ibm.openpages.ext.tss.service.impl.GRCObjectUtil;
/*  34:    */ import com.ibm.openpages.ext.tss.service.impl.GRCTriggerUtil;
/*  35:    */ import com.ibm.openpages.ext.tss.service.impl.GRCUpdateTriggerUtil;
/*  36:    */ import com.ibm.openpages.ext.tss.service.impl.GRCValidationTriggerUtil;
/*  37:    */ import com.ibm.openpages.ext.tss.service.impl.IDFieldUtil;
/*  38:    */ import com.ibm.openpages.ext.tss.service.impl.IntegerFieldUtil;
/*  39:    */ import com.ibm.openpages.ext.tss.service.impl.LoggerUtil;
/*  40:    */ import com.ibm.openpages.ext.tss.service.impl.MultiEnumFieldUtil;
/*  41:    */ import com.ibm.openpages.ext.tss.service.impl.StringFieldUtil;
/*  42:    */ import com.ibm.openpages.ext.tss.service.impl.UserUtil;
/*  43:    */ import com.ibm.openpages.ext.tss.service.proxy.IOPSessionProxy;
/*  44:    */ import com.ibm.openpages.ext.tss.service.proxy.IServiceFactoryProxy;
/*  45:    */ import com.ibm.openpages.ext.tss.service.proxy.OPSessionProxy;
/*  46:    */ import com.ibm.openpages.ext.tss.service.proxy.ServiceFactoryProxy;
/*  47:    */ import org.springframework.context.annotation.Bean;
/*  48:    */ import org.springframework.context.annotation.Configuration;
/*  49:    */ import org.springframework.context.annotation.Profile;
/*  50:    */ import org.springframework.web.multipart.commons.CommonsMultipartResolver;
/*  51:    */ 
/*  52:    */ @Configuration
/*  53:    */ @Profile({"production"})
/*  54:    */ public class OPSConfig
/*  55:    */ {
/*  56:    */   @Bean
/*  57:    */   public ICognosUtil cognosUtil()
/*  58:    */   {
/*  59: 86 */     return new CognosUtil();
/*  60:    */   }
/*  61:    */   
/*  62:    */   @Bean
/*  63:    */   public IOPSessionProxy opSessionProxy()
/*  64:    */   {
/*  65:102 */     return new OPSessionProxy();
/*  66:    */   }
/*  67:    */   
/*  68:    */   @Bean
/*  69:    */   public IServiceFactoryProxy serviceFactoryProxy()
/*  70:    */   {
/*  71:116 */     return new ServiceFactoryProxy();
/*  72:    */   }
/*  73:    */   
/*  74:    */   @Bean
/*  75:    */   public IUserUtil userUtil()
/*  76:    */   {
/*  77:130 */     return new UserUtil();
/*  78:    */   }
/*  79:    */   
/*  80:    */   @Bean
/*  81:    */   IApplicationUtil applicationUtil()
/*  82:    */   {
/*  83:144 */     return new ApplicationUtil();
/*  84:    */   }
/*  85:    */   
/*  86:    */   @Bean
/*  87:    */   ApplicationContextUtils appContextUtils()
/*  88:    */   {
/*  89:158 */     return new ApplicationContextUtils();
/*  90:    */   }
/*  91:    */   
/*  92:    */   @Bean
/*  93:    */   ILoggerUtil loggerUtil()
/*  94:    */   {
/*  95:172 */     return new LoggerUtil();
/*  96:    */   }
/*  97:    */   
/*  98:    */   @Bean
/*  99:    */   IEmailUtil emailUtil()
/* 100:    */   {
/* 101:187 */     return new EmailUtil();
/* 102:    */   }
/* 103:    */   
/* 104:    */   @Bean
/* 105:    */   public IGRCObjectUtil getGRCObjectUtil()
/* 106:    */   {
/* 107:201 */     return new GRCObjectUtil();
/* 108:    */   }
/* 109:    */   
/* 110:    */   @Bean
/* 111:    */   public IGRCObjectSearchUtil getGRCObjectSearchUtil()
/* 112:    */   {
/* 113:215 */     return new GRCObjectSearchUtil();
/* 114:    */   }
/* 115:    */   
/* 116:    */   @Bean
/* 117:    */   public IFieldUtil getFieldUtil()
/* 118:    */   {
/* 119:229 */     return new FieldUtil();
/* 120:    */   }
/* 121:    */   
/* 122:    */   @Bean
/* 123:    */   public IFloatFieldUtil getFloatFieldUtil()
/* 124:    */   {
/* 125:243 */     return new FloatFieldUtil();
/* 126:    */   }
/* 127:    */   
/* 128:    */   @Bean
/* 129:    */   public IEnumFieldUtil getEnumFieldUtil()
/* 130:    */   {
/* 131:257 */     return new EnumFieldUtil();
/* 132:    */   }
/* 133:    */   
/* 134:    */   @Bean
/* 135:    */   public IMultiEnumFieldUtil getMultiEnumFieldUtil()
/* 136:    */   {
/* 137:271 */     return new MultiEnumFieldUtil();
/* 138:    */   }
/* 139:    */   
/* 140:    */   @Bean
/* 141:    */   public IDateFieldUtil getDateFieldUtil()
/* 142:    */   {
/* 143:285 */     return new DateFieldUtil();
/* 144:    */   }
/* 145:    */   
/* 146:    */   @Bean
/* 147:    */   public IStringFieldUtil getStringFieldUtil()
/* 148:    */   {
/* 149:299 */     return new StringFieldUtil();
/* 150:    */   }
/* 151:    */   
/* 152:    */   @Bean
/* 153:    */   public IIntegerFieldUtil getIntegerFieldUtil()
/* 154:    */   {
/* 155:313 */     return new IntegerFieldUtil();
/* 156:    */   }
/* 157:    */   
/* 158:    */   @Bean
/* 159:    */   public IIDFieldUtil getIDFieldUtil()
/* 160:    */   {
/* 161:327 */     return new IDFieldUtil();
/* 162:    */   }
/* 163:    */   
/* 164:    */   @Bean
/* 165:    */   public IFileUtil getIFileUtil()
/* 166:    */   {
/* 167:354 */     return new FileUtil();
/* 168:    */   }
/* 169:    */   
/* 170:    */   @Bean
/* 171:    */   public IGRCTriggerUtil getIGRCTriggerUtil()
/* 172:    */   {
/* 173:368 */     return new GRCTriggerUtil();
/* 174:    */   }
/* 175:    */   
/* 176:    */   @Bean
/* 177:    */   public IGRCValidationTriggerUtil getIGRCValidationTriggerUtil()
/* 178:    */   {
/* 179:382 */     return new GRCValidationTriggerUtil();
/* 180:    */   }
/* 181:    */   
/* 182:    */   @Bean
/* 183:    */   public IGRCUpdateTriggerUtil getIGRCUpdateTriggerUtil()
/* 184:    */   {
/* 185:396 */     return new GRCUpdateTriggerUtil();
/* 186:    */   }
/* 187:    */   
/* 188:    */   @Bean
/* 189:    */   public IHelperAppBaseDAO getIHelperAppBaseDAO()
/* 190:    */   {
/* 191:410 */     return new HelperAppBaseDAOImpl();
/* 192:    */   }
/* 193:    */   
/* 194:    */   @Bean
/* 195:    */   public CommonsMultipartResolver multipartResolver()
/* 196:    */   {
/* 197:424 */     CommonsMultipartResolver resolver = new CommonsMultipartResolver();
/* 198:425 */     resolver.setDefaultEncoding("utf-8");
/* 199:426 */     return resolver;
/* 200:    */   }
/* 201:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.config.OPSConfig
 * JD-Core Version:    0.7.0.1
 */