/*  1:   */ package com.ibm.openpages.ext.tss.service.config;
/*  2:   */ 
/*  3:   */ import com.ibm.openpages.api.Context;
/*  4:   */ import org.springframework.beans.factory.annotation.Configurable;
/*  5:   */ 
/*  6:   */ @Configurable
/*  7:   */ public class ContextWrapper
/*  8:   */ {
/*  9:   */   private Context context;
/* 10:   */   
/* 11:   */   public Context getContext()
/* 12:   */   {
/* 13:16 */     return this.context;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public void setContext(Context context)
/* 17:   */   {
/* 18:23 */     this.context = context;
/* 19:   */   }
/* 20:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.config.ContextWrapper
 * JD-Core Version:    0.7.0.1
 */