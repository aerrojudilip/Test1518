package com.ibm.openpages.ext.tss.service;

import com.ibm.openpages.api.metadata.Id;
import com.ibm.openpages.api.resource.IGRCObject;
import com.ibm.openpages.api.security.IGroup;
import com.ibm.openpages.api.security.IRoleAssignment;
import com.ibm.openpages.api.security.IUser;
import com.ibm.openpages.ext.tss.service.constants.CheckFor;
import java.util.Iterator;
import java.util.List;

public abstract interface IUserUtil
{
  public abstract void initService();
  
  public abstract IUser getLoggedInUser()
    throws Exception;
  
  public abstract String getLoggedInUserName()
    throws Exception;
  
  public abstract Id getLoggedInUserId()
    throws Exception;
  
  public abstract String getUserIdAsString()
    throws Exception;
  
  public abstract String getLoggedInUsersFirstName()
    throws Exception;
  
  public abstract String getLoggedInUsersLastName()
    throws Exception;
  
  public abstract String getLoggedInUsersMiddleName()
    throws Exception;
  
  public abstract String getLoggedInUsersFulleName()
    throws Exception;
  
  public abstract String getLoggedInUsersEmailAddress()
    throws Exception;
  
  public abstract IUser getUser(Id paramId)
    throws Exception;
  
  public abstract List<IUser> getUsersListFromUserNameList(List<String> paramList)
    throws Exception;
  
  public abstract String getUserName(Id paramId)
    throws Exception;
  
  public abstract IUser getUser(String paramString)
    throws Exception;
  
  public abstract boolean isLoggedInUserSameUser(String paramString)
    throws Exception;
  
  public abstract boolean isUserSameAsGivenUser(IUser paramIUser1, IUser paramIUser2)
    throws Exception;
  
  public abstract boolean isUserSameAsGivenUser(IUser paramIUser, String paramString)
    throws Exception;
  
  public abstract boolean isUserSameAsLoggedInUser(String paramString)
    throws Exception;
  
  public abstract String getUsersFirstName(Id paramId)
    throws Exception;
  
  public abstract String getUsersFirstName(String paramString)
    throws Exception;
  
  public abstract String getUsersLastName(Id paramId)
    throws Exception;
  
  public abstract String getUsersLastName(String paramString)
    throws Exception;
  
  public abstract String getUsersMiddleName(Id paramId)
    throws Exception;
  
  public abstract String getUsersMiddleName(String paramString)
    throws Exception;
  
  public abstract String getUsersFullName(Id paramId)
    throws Exception;
  
  public abstract String getUsersFullName(String paramString)
    throws Exception;
  
  public abstract String getEmailAddressesOfUser(Id paramId)
    throws Exception;
  
  public abstract String getEmailAddressesOfUser(String paramString)
    throws Exception;
  
  public abstract List<String> getEmailAddressesOfUsers(String paramString)
    throws Exception;
  
  public abstract List<String> getEmailAddressesOfUsers(List<String> paramList)
    throws Exception;
  
  public abstract List<String> getEmailAddressesOfUsersFromFields(IGRCObject paramIGRCObject, List<String> paramList)
    throws Exception;
  
  public abstract Iterator<IRoleAssignment> getRoleAssignmentsForLoggedInUser()
    throws Exception;
  
  public abstract Iterator<IRoleAssignment> getRoleAssignmentsForUser(Id paramId)
    throws Exception;
  
  public abstract Iterator<IRoleAssignment> getRoleAssignmentsForUser(String paramString)
    throws Exception;
  
  public abstract boolean isLoggedInUserHasRoleAssignments(Iterator<IRoleAssignment> paramIterator, CheckFor paramCheckFor)
    throws Exception;
  
  public abstract boolean isUserHasRoleAssignments(IUser paramIUser, Iterator<IRoleAssignment> paramIterator, CheckFor paramCheckFor)
    throws Exception;
  
  public abstract List<String> getRoleAssignmentNamesAsList(Iterator<IRoleAssignment> paramIterator)
    throws Exception;
  
  public abstract boolean isLoggedInUserPartOfGivenGroups(String paramString, CheckFor paramCheckFor)
    throws Exception;
  
  public abstract boolean isLoggedInUserPartOfGivenGroups(List<String> paramList, CheckFor paramCheckFor)
    throws Exception;
  
  public abstract IGroup getGroup(Id paramId)
    throws Exception;
  
  public abstract IGroup getGroup(String paramString)
    throws Exception;
  
  public abstract List<IGroup> getGroupFromGroupNameList(List<String> paramList)
    throws Exception;
  
  public abstract boolean isLoggedInUserMemberOfAGroup(IGroup paramIGroup)
    throws Exception;
  
  public abstract boolean isLoggedInUserMemberOfAGroup(String paramString)
    throws Exception;
  
  public abstract boolean isGivenUserMemberOfAGroup(IUser paramIUser, String paramString)
    throws Exception;
  
  public abstract boolean isGivenUserMemberOfAGroup(String paramString, IGroup paramIGroup)
    throws Exception;
  
  public abstract boolean isGivenUserMemberOfAGroup(String paramString1, String paramString2)
    throws Exception;
  
  public abstract boolean isGivenUserMemberOfAGroup(IUser paramIUser, IGroup paramIGroup)
    throws Exception;
  
  public abstract boolean isUserMemberOfGivenGroups(IUser paramIUser, List<IGroup> paramList, CheckFor paramCheckFor)
    throws Exception;
  
  public abstract String getUserDisplayNameLastFirst(String paramString)
    throws Exception;
  
  public abstract String getUserDisplayNameLastFirst(IUser paramIUser)
    throws Exception;
  
  public abstract String getUserDisplayNameFirstLast(String paramString)
    throws Exception;
  
  public abstract String getUserDisplayNameFirstLast(IUser paramIUser)
    throws Exception;
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.service.IUserUtil
 * JD-Core Version:    0.7.0.1
 */