/*   1:    */ package com.ibm.openpages.ext.tss.notification.controller;
/*   2:    */ 
/*   3:    */ import com.ibm.openpages.api.Context;
/*   4:    */ import com.ibm.openpages.ext.tss.service.ILoggerUtil;
/*   5:    */ import com.ibm.openpages.ext.tss.service.config.ApplicationContextUtils;
/*   6:    */ import com.ibm.openpages.ext.tss.service.config.ContextWrapper;
/*   7:    */ import com.ibm.openpages.ext.tss.service.proxy.ServiceFactoryProxy;
/*   8:    */ import com.ibm.openpages.ext.tss.service.util.CommonUtil;
/*   9:    */ import com.openpages.apps.common.util.HttpContext;
/*  10:    */ import com.openpages.sdk.OpenpagesSession;
/*  11:    */ import java.io.PrintStream;
/*  12:    */ import javax.servlet.http.HttpServletRequest;
/*  13:    */ import org.apache.commons.logging.Log;
/*  14:    */ import org.springframework.context.ApplicationContext;
/*  15:    */ 
/*  16:    */ public class NotificationManagerBaseController
/*  17:    */ {
/*  18:    */   private static Log logger;
/*  19:    */   
/*  20:    */   public void prepareContextForNotification(HttpServletRequest request)
/*  21:    */     throws Exception
/*  22:    */   {
/*  23: 44 */     getLogger();
/*  24:    */     
/*  25: 46 */     logger.debug("Prepare Context for Trigger START");
/*  26:    */     
/*  27:    */ 
/*  28: 49 */     boolean isNotificationManager = false;
/*  29:    */     
/*  30: 51 */     Context context = null;
/*  31: 52 */     ContextWrapper contextWrapper = null;
/*  32: 53 */     OpenpagesSession openpagesSession = null;
/*  33: 54 */     ServiceFactoryProxy serviceFactoryProxy = null;
/*  34: 55 */     ApplicationContext applicationContextProvider = null;
/*  35:    */     
/*  36:    */ 
/*  37:    */ 
/*  38: 59 */     context = new Context();
/*  39: 60 */     isNotificationManager = CommonUtil.parseBoolean(request.getParameter("isNotificationManager"));
/*  40:    */     
/*  41:    */ 
/*  42: 63 */     System.out.println("isNotificationManager request parameter: " + request.getParameter("isNotificationManager"));
/*  43:    */     
/*  44: 65 */     System.out.println("isNotificationManager : " + isNotificationManager);
/*  45: 71 */     if (isNotificationManager)
/*  46:    */     {
/*  47: 74 */       System.out.println("Notification Manager Base Controller UserName : " + request.getParameter("sdk.login.username"));
/*  48:    */       
/*  49:    */ 
/*  50: 77 */       System.out.println("Notification Manager Base Controller Password : " + request.getParameter("sdk.login.password"));
/*  51:    */       
/*  52:    */ 
/*  53:    */ 
/*  54: 81 */       context.put("com.ibm.openpages.sdk.service.username", request.getParameter("sdk.login.username"));
/*  55:    */       
/*  56: 83 */       context.put("com.ibm.openpages.sdk.service.password", request.getParameter("sdk.login.password"));
/*  57:    */     }
/*  58:    */     else
/*  59:    */     {
/*  60: 93 */       openpagesSession = HttpContext.getOpenpagesSession(request);
/*  61: 94 */       context.put("com.ibm.openpages.sdk.service.session", openpagesSession);
/*  62:    */     }
/*  63:101 */     contextWrapper = new ContextWrapper();
/*  64:102 */     contextWrapper.setContext(context);
/*  65:    */     
/*  66:104 */     serviceFactoryProxy = (ServiceFactoryProxy)ApplicationContextUtils.getBean("serviceFactoryProxy");
/*  67:    */     
/*  68:106 */     serviceFactoryProxy.setContextWrapper(contextWrapper);
/*  69:    */     
/*  70:108 */     logger.debug("Prepare Context for Trigger END");
/*  71:    */   }
/*  72:    */   
/*  73:    */   private void getLogger()
/*  74:    */   {
/*  75:121 */     System.out.println("Entering get logger util");
/*  76:    */     
/*  77:123 */     ILoggerUtil loggerUtil = null;
/*  78:    */     try
/*  79:    */     {
/*  80:128 */       loggerUtil = (ILoggerUtil)ApplicationContextUtils.getBean("loggerUtil");
/*  81:    */       
/*  82:130 */       logger = loggerUtil.getExtLogger();
/*  83:    */     }
/*  84:    */     catch (Exception ex)
/*  85:    */     {
/*  86:135 */       System.out.println(CommonUtil.getStackTrace(ex));
/*  87:    */     }
/*  88:138 */     System.out.println("Exiting get logger util");
/*  89:    */   }
/*  90:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.notification.controller.NotificationManagerBaseController
 * JD-Core Version:    0.7.0.1
 */