/*   1:    */ package com.ibm.openpages.ext.tss.notification.controller;
/*   2:    */ 
/*   3:    */ import com.ibm.openpages.ext.tss.notification.bean.NotificationManagerInfo;
/*   4:    */ import com.ibm.openpages.ext.tss.service.ILoggerUtil;
/*   5:    */ import com.ibm.openpages.ext.tss.service.config.ApplicationContextUtils;
/*   6:    */ import com.ibm.openpages.ext.tss.service.util.CommonUtil;
/*   7:    */ import com.openpages.tool.encrypt.CryptUtil;
/*   8:    */ import java.io.FileInputStream;
/*   9:    */ import java.io.PrintStream;
/*  10:    */ import java.util.Properties;
/*  11:    */ import org.apache.commons.logging.Log;
/*  12:    */ 
/*  13:    */ public class NotificationManagerLauncher
/*  14:    */ {
/*  15:    */   private static Log logger;
/*  16:    */   
/*  17:    */   public static void main(String[] args)
/*  18:    */   {
/*  19: 31 */     getLogger();
/*  20:    */     
/*  21: 33 */     logger.debug("Notification Manager - START");
/*  22: 34 */     NotificationManagerInfo notificationManagerInfo = null;
/*  23: 35 */     notificationManagerInfo = processInputInformation(args);
/*  24: 36 */     notificationManagerInfo = processUserInformation(notificationManagerInfo);
/*  25: 38 */     if ((CommonUtil.isEqual("AIX", notificationManagerInfo.getPlatformOS())) || (CommonUtil.isEqual("Linux", notificationManagerInfo.getPlatformOS()))) {
/*  26: 40 */       callNotificationManagerForLinux(notificationManagerInfo);
/*  27: 42 */     } else if (CommonUtil.isEqual("Windows", notificationManagerInfo.getPlatformOS())) {
/*  28: 44 */       callNotificationManagerForWindows(notificationManagerInfo);
/*  29:    */     } else {
/*  30: 48 */       logger.debug("Not a supported OS: " + notificationManagerInfo.getPlatformOS());
/*  31:    */     }
/*  32: 51 */     logger.debug("Notification Manager - END");
/*  33:    */   }
/*  34:    */   
/*  35:    */   private static NotificationManagerInfo processInputInformation(String[] args)
/*  36:    */   {
/*  37: 56 */     logger.debug("Notification Manager processInputInformation() - START");
/*  38:    */     
/*  39: 58 */     String inputParameters = "";
/*  40: 59 */     NotificationManagerInfo notificationManagerInfo = null;
/*  41:    */     try
/*  42:    */     {
/*  43: 63 */       notificationManagerInfo = new NotificationManagerInfo();
/*  44: 64 */       logArguments(args);
/*  45: 66 */       if (args.length < 5)
/*  46:    */       {
/*  47: 68 */         System.out.println("Invalid command line.");
/*  48: 69 */         System.out.println("USAGE:  JAVA -cp %CLASSPATH% com.openpages.ext.rbc.utilities.Launcher <pathToCredentialsFileGoesHere> <helperFullPathInOPXGoesHere> -heleperSpecificParam1 value1 -heleperSpecificParam2 value2 .... -heleperSpecificParamN valueN");
/*  49:    */         
/*  50: 71 */         logger.debug("Invalid command line.");
/*  51: 72 */         logger.debug("USAGE:  JAVA -cp %CLASSPATH% com.openpages.ext.rbc.utilities.Launcher <pathToCredentialsFileGoesHere> <helperFullPathInOPXGoesHere> -heleperSpecificParam1 value1 -heleperSpecificParam2 value2 .... -heleperSpecificParamN valueN");
/*  52: 73 */         notificationManagerInfo.setPreviousStepComplete(false);
/*  53:    */       }
/*  54:    */       else
/*  55:    */       {
/*  56: 77 */         notificationManagerInfo.setPlatformOS(args[0]);
/*  57: 78 */         notificationManagerInfo.setPropertyFile(args[1]);
/*  58: 79 */         notificationManagerInfo.setHelperLaunchPath(args[2]);
/*  59: 80 */         notificationManagerInfo.setLogSession(CommonUtil.isEqual(args[3], "true"));
/*  60: 81 */         notificationManagerInfo.setSaveOutput(CommonUtil.isEqual(args[4], "true"));
/*  61: 82 */         notificationManagerInfo.setPreviousStepComplete(true);
/*  62: 84 */         if (args.length > 5)
/*  63:    */         {
/*  64: 86 */           for (int i = 5; i < args.length; i++) {
/*  65: 88 */             inputParameters = inputParameters + " " + args[i];
/*  66:    */           }
/*  67: 91 */           notificationManagerInfo.setInputParameters(inputParameters);
/*  68:    */         }
/*  69:    */       }
/*  70:    */     }
/*  71:    */     catch (Exception ex)
/*  72:    */     {
/*  73: 97 */       notificationManagerInfo.setPreviousStepComplete(false);
/*  74: 98 */       logger.debug("EXCEPTION !!!!!!!!!!!!!! " + CommonUtil.getStackTrace(ex));
/*  75:    */     }
/*  76:101 */     logger.debug("Input Information Processed: " + notificationManagerInfo.toString());
/*  77:102 */     logger.debug("Notification Manager processInputInformation() - END");
/*  78:103 */     return notificationManagerInfo;
/*  79:    */   }
/*  80:    */   
/*  81:    */   private static NotificationManagerInfo processUserInformation(NotificationManagerInfo notificationManagerInfo)
/*  82:    */   {
/*  83:108 */     logger.debug("Notification Manager processUserInformation() - START");
/*  84:    */     
/*  85:110 */     Properties properties = null;
/*  86:    */     try
/*  87:    */     {
/*  88:114 */       if (notificationManagerInfo.isPreviousStepComplete())
/*  89:    */       {
/*  90:116 */         properties = new Properties();
/*  91:117 */         properties.load(new FileInputStream(notificationManagerInfo.getPropertyFile()));
/*  92:118 */         notificationManagerInfo.setSuperUserName(properties.getProperty("sdk.login.username"));
/*  93:119 */         notificationManagerInfo.setSuperUserEncPassword(properties.getProperty("sdk.login.password"));
/*  94:121 */         if (CommonUtil.isNullOrEmpty(notificationManagerInfo.getSuperUserName()))
/*  95:    */         {
/*  96:123 */           notificationManagerInfo.setPreviousStepComplete(false);
/*  97:124 */           System.out.println("User name in credentials file " + notificationManagerInfo.getPropertyFile() + " is empty");
/*  98:    */         }
/*  99:126 */         if (CommonUtil.isNullOrEmpty(notificationManagerInfo.getSuperUserEncPassword()))
/* 100:    */         {
/* 101:128 */           notificationManagerInfo.setPreviousStepComplete(false);
/* 102:129 */           System.out.println("Password in configuration file " + notificationManagerInfo.getPropertyFile() + " is empty");
/* 103:    */         }
/* 104:    */       }
/* 105:    */     }
/* 106:    */     catch (Exception ex)
/* 107:    */     {
/* 108:135 */       notificationManagerInfo.setPreviousStepComplete(false);
/* 109:136 */       logger.debug("Error reading the credentials file: " + (notificationManagerInfo != null ? notificationManagerInfo.getPropertyFile() : "Null"));
/* 110:137 */       logger.debug(CommonUtil.getStackTrace(ex));
/* 111:    */     }
/* 112:140 */     logger.debug("User Information Populated: " + notificationManagerInfo.toString());
/* 113:141 */     logger.debug("Notification Manager processUserInformation() - END");
/* 114:142 */     return notificationManagerInfo;
/* 115:    */   }
/* 116:    */   
/* 117:    */   private static NotificationManagerInfo callNotificationManagerForLinux(NotificationManagerInfo notificationManagerInfo)
/* 118:    */   {
/* 119:147 */     logger.debug("Notification Manager callNotificationManagerForLinux() - START");
/* 120:    */     try
/* 121:    */     {
/* 122:151 */       if (notificationManagerInfo.isPreviousStepComplete())
/* 123:    */       {
/* 124:153 */         notificationManagerInfo.setSuperUserDecPassword(CryptUtil.decrypt(notificationManagerInfo.getSuperUserEncPassword()));
/* 125:154 */         String sCmmdL = "./NotificationManager.sh -Username " + notificationManagerInfo.getSuperUserName() + " -Password " + notificationManagerInfo.getSuperUserDecPassword() + " -NotificationProgram \"" + notificationManagerInfo.getHelperLaunchPath() + "\"" + " -SaveOutput " + notificationManagerInfo.isSaveOutput() + " -LogSession " + notificationManagerInfo.isLogSession() + " " + notificationManagerInfo.getInputParameters();
/* 126:    */         
/* 127:    */ 
/* 128:    */ 
/* 129:    */ 
/* 130:    */ 
/* 131:    */ 
/* 132:    */ 
/* 133:162 */         logger.debug("COMMAND LINE : " + sCmmdL);
/* 134:163 */         Runtime.getRuntime().exec(new String[] { "/bin/sh", "-c", sCmmdL });
/* 135:    */       }
/* 136:    */     }
/* 137:    */     catch (Exception ex)
/* 138:    */     {
/* 139:170 */       notificationManagerInfo.setPreviousStepComplete(false);
/* 140:171 */       logger.debug("EXCEPTION !!!!!!!!!!!!!!!!!!!!!!!!! " + CommonUtil.getStackTrace(ex));
/* 141:    */     }
/* 142:174 */     logger.debug("Notification Manager callNotificationManagerForLinux() - END");
/* 143:175 */     return notificationManagerInfo;
/* 144:    */   }
/* 145:    */   
/* 146:    */   private static NotificationManagerInfo callNotificationManagerForWindows(NotificationManagerInfo notificationManagerInfo)
/* 147:    */   {
/* 148:180 */     logger.debug("Notification Manager callNotificationManagerForWindows() - START");
/* 149:    */     try
/* 150:    */     {
/* 151:184 */       notificationManagerInfo.setSuperUserDecPassword(CryptUtil.decrypt(notificationManagerInfo.getSuperUserEncPassword()));
/* 152:185 */       String sCmmd = "NotificationManager.cmd -Username " + notificationManagerInfo.getSuperUserName() + " -Password " + notificationManagerInfo.getSuperUserDecPassword() + " -NotificationProgram \"" + notificationManagerInfo.getHelperLaunchPath() + "\"" + " -SaveOutput " + notificationManagerInfo.isSaveOutput() + " -LogSession " + notificationManagerInfo.isLogSession() + " " + notificationManagerInfo.getInputParameters();
/* 153:    */       
/* 154:    */ 
/* 155:    */ 
/* 156:    */ 
/* 157:    */ 
/* 158:    */ 
/* 159:    */ 
/* 160:193 */       logger.debug("COMMAND LINE : " + sCmmd);
/* 161:    */       
/* 162:195 */       Runtime.getRuntime().exec(new String[] { "cmd /c ", "-c", sCmmd });
/* 163:    */     }
/* 164:    */     catch (Exception localException) {}
/* 165:201 */     logger.debug("Notification Manager callNotificationManagerForWindows() - END");
/* 166:202 */     return notificationManagerInfo;
/* 167:    */   }
/* 168:    */   
/* 169:    */   private static void logArguments(String[] args)
/* 170:    */   {
/* 171:207 */     for (int i = 2; i < args.length; i++) {
/* 172:208 */       logger.debug("Passed in argument value (" + i + ") = " + args[i]);
/* 173:    */     }
/* 174:    */   }
/* 175:    */   
/* 176:    */   public static void getLogger()
/* 177:    */   {
/* 178:220 */     System.out.println("Entering get logger util");
/* 179:    */     
/* 180:222 */     ILoggerUtil loggerUtil = null;
/* 181:    */     try
/* 182:    */     {
/* 183:226 */       loggerUtil = (ILoggerUtil)ApplicationContextUtils.getBean("loggerUtil");
/* 184:227 */       logger = loggerUtil.getExtLogger();
/* 185:    */     }
/* 186:    */     catch (Exception ex)
/* 187:    */     {
/* 188:231 */       System.out.println(CommonUtil.getStackTrace(ex));
/* 189:    */     }
/* 190:234 */     System.out.println("Exiting get logger util");
/* 191:    */   }
/* 192:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.notification.controller.NotificationManagerLauncher
 * JD-Core Version:    0.7.0.1
 */