package com.ibm.openpages.ext.tss.notification.constants;

public class NotificationManagerConstants
{
  public static final String AIX_OS = "AIX";
  public static final String LINUX_OS = "Linux";
  public static final String WINDOWS_OS = "Windows";
  public static final String SDK_LOGIN_USERNAME = "sdk.login.username";
  public static final String SDK_LOGIN_PASSWORD = "sdk.login.password";
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.notification.constants.NotificationManagerConstants
 * JD-Core Version:    0.7.0.1
 */