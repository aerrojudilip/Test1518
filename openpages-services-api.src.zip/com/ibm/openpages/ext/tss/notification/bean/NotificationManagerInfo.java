/*   1:    */ package com.ibm.openpages.ext.tss.notification.bean;
/*   2:    */ 
/*   3:    */ import java.io.Serializable;
/*   4:    */ 
/*   5:    */ public class NotificationManagerInfo
/*   6:    */   implements Serializable
/*   7:    */ {
/*   8:    */   private static final long serialVersionUID = 6895721311165919493L;
/*   9:    */   private boolean saveOutput;
/*  10:    */   private boolean logSession;
/*  11:    */   private boolean isPreviousStepComplete;
/*  12:    */   private String platformOS;
/*  13:    */   private String propertyFile;
/*  14:    */   private String superUserName;
/*  15:    */   private String superUserEncPassword;
/*  16:    */   private String superUserDecPassword;
/*  17:    */   private String helperLaunchPath;
/*  18:    */   private String inputParameters;
/*  19:    */   
/*  20:    */   public boolean isSaveOutput()
/*  21:    */   {
/*  22: 56 */     return this.saveOutput;
/*  23:    */   }
/*  24:    */   
/*  25:    */   public void setSaveOutput(boolean saveOutput)
/*  26:    */   {
/*  27: 62 */     this.saveOutput = saveOutput;
/*  28:    */   }
/*  29:    */   
/*  30:    */   public boolean isLogSession()
/*  31:    */   {
/*  32: 68 */     return this.logSession;
/*  33:    */   }
/*  34:    */   
/*  35:    */   public void setLogSession(boolean logSession)
/*  36:    */   {
/*  37: 74 */     this.logSession = logSession;
/*  38:    */   }
/*  39:    */   
/*  40:    */   public boolean isPreviousStepComplete()
/*  41:    */   {
/*  42: 80 */     return this.isPreviousStepComplete;
/*  43:    */   }
/*  44:    */   
/*  45:    */   public void setPreviousStepComplete(boolean isPreviousStepComplete)
/*  46:    */   {
/*  47: 86 */     this.isPreviousStepComplete = isPreviousStepComplete;
/*  48:    */   }
/*  49:    */   
/*  50:    */   public String getPlatformOS()
/*  51:    */   {
/*  52: 92 */     return this.platformOS;
/*  53:    */   }
/*  54:    */   
/*  55:    */   public void setPlatformOS(String platformOS)
/*  56:    */   {
/*  57: 98 */     this.platformOS = platformOS;
/*  58:    */   }
/*  59:    */   
/*  60:    */   public String getPropertyFile()
/*  61:    */   {
/*  62:104 */     return this.propertyFile;
/*  63:    */   }
/*  64:    */   
/*  65:    */   public void setPropertyFile(String propertyFile)
/*  66:    */   {
/*  67:110 */     this.propertyFile = propertyFile;
/*  68:    */   }
/*  69:    */   
/*  70:    */   public String getSuperUserName()
/*  71:    */   {
/*  72:116 */     return this.superUserName;
/*  73:    */   }
/*  74:    */   
/*  75:    */   public void setSuperUserName(String superUserName)
/*  76:    */   {
/*  77:122 */     this.superUserName = superUserName;
/*  78:    */   }
/*  79:    */   
/*  80:    */   public String getSuperUserEncPassword()
/*  81:    */   {
/*  82:128 */     return this.superUserEncPassword;
/*  83:    */   }
/*  84:    */   
/*  85:    */   public void setSuperUserEncPassword(String superUserEncPassword)
/*  86:    */   {
/*  87:134 */     this.superUserEncPassword = superUserEncPassword;
/*  88:    */   }
/*  89:    */   
/*  90:    */   public String getSuperUserDecPassword()
/*  91:    */   {
/*  92:140 */     return this.superUserDecPassword;
/*  93:    */   }
/*  94:    */   
/*  95:    */   public void setSuperUserDecPassword(String superUserDecPassword)
/*  96:    */   {
/*  97:146 */     this.superUserDecPassword = superUserDecPassword;
/*  98:    */   }
/*  99:    */   
/* 100:    */   public String getHelperLaunchPath()
/* 101:    */   {
/* 102:152 */     return this.helperLaunchPath;
/* 103:    */   }
/* 104:    */   
/* 105:    */   public void setHelperLaunchPath(String helperLaunchPath)
/* 106:    */   {
/* 107:158 */     this.helperLaunchPath = helperLaunchPath;
/* 108:    */   }
/* 109:    */   
/* 110:    */   public String getInputParameters()
/* 111:    */   {
/* 112:164 */     return this.inputParameters;
/* 113:    */   }
/* 114:    */   
/* 115:    */   public void setInputParameters(String inputParameters)
/* 116:    */   {
/* 117:170 */     this.inputParameters = inputParameters;
/* 118:    */   }
/* 119:    */   
/* 120:    */   public String toString()
/* 121:    */   {
/* 122:176 */     StringBuilder sb = new StringBuilder();
/* 123:    */     
/* 124:178 */     sb.append("\n Display Name : " + this.saveOutput);
/* 125:179 */     sb.append("\n Display Image : " + this.logSession);
/* 126:180 */     sb.append("\n Display Image : " + this.isPreviousStepComplete);
/* 127:    */     
/* 128:182 */     sb.append("\n Display Image : " + this.propertyFile);
/* 129:183 */     sb.append("\n Display Image : " + this.platformOS);
/* 130:184 */     sb.append("\n Display Image : " + this.superUserName);
/* 131:185 */     sb.append("\n Display Image : " + this.superUserEncPassword);
/* 132:186 */     sb.append("\n Display Image : " + this.superUserDecPassword);
/* 133:187 */     sb.append("\n Display Image : " + this.helperLaunchPath);
/* 134:188 */     sb.append("\n Display Image : " + this.inputParameters);
/* 135:189 */     sb.append("\n");
/* 136:    */     
/* 137:191 */     return sb.toString();
/* 138:    */   }
/* 139:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.notification.bean.NotificationManagerInfo
 * JD-Core Version:    0.7.0.1
 */