package com.ibm.openpages.ext.tss.triggers.constants;

import com.ibm.openpages.ext.tss.service.constants.CommonConstants;

public class TriggerCommonConstants
  extends CommonConstants
{
  public static final String TRIGGER_PRE_POSITION = "pre";
  public static final String TRIGGER_POST_POSITION = "post";
  public static final String TRIGGER_OPERATION_UPDATE_OBJECT = "update.object";
  public static final String TRIGGER_OPERATION_ASSOCIATE_OBJECT = "associate.objects";
  public static final String TRIGGER_NAME = "trigger.name";
  public static final String MODIFIED_FIELD_NAME = "modified.fields";
  public static final String RUN_TRIGGER_CONFIG = "run.trigger.registry.setting";
  public static final String OBJECT_RESOURC_ID = "resourceId";
  public static final String OBJECT_NAME_FIELD = "System:Name";
  public static final String IS_FORWARDED_FROM_CREATE = "isForwardedFromCreate";
  public static final String TRIGGER_ROOT_REGISTRY_SETTING = "trigger.root.registry.setting";
  public static final String TRIGGER_COMMON_ERROR = "com.openpages.trigger.common.exception";
  public static final String DEFAULT_TRIGGER_EXCEPTION = "com.trigggers.default.exception.message";
  public static final String RUN_ALL_TRIGGERS = "/OpenPages/Custom Deliverables/Triggers/All Triggers/Run All Triggers";
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.triggers.constants.TriggerCommonConstants
 * JD-Core Version:    0.7.0.1
 */