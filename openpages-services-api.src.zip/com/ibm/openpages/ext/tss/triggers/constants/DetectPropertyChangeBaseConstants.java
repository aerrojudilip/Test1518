package com.ibm.openpages.ext.tss.triggers.constants;

public abstract class DetectPropertyChangeBaseConstants
  extends ContentTypeMatchConstants
{
  public static final String FIELD_VALUES_TO_CHECK_ATTR = "field.values.to.check";
  public static final String FIELD_NAMES_TO_CHECK_ATTR = "field.names.to.check";
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.triggers.constants.DetectPropertyChangeBaseConstants
 * JD-Core Version:    0.7.0.1
 */