package com.ibm.openpages.ext.tss.triggers.constants;

public abstract class ValidatePrimaryParentFieldsConstants
  extends TriggerCommonConstants
{
  public static final String COGNOS_PARAMETER_ACITON_ID = "action_id";
  public static final String ATTR_IS_COMPARE_ON_OBJECT = "is.compare.on.object";
  public static final String ATTR_IS_COMPARE_PARENT_CHILD = "is.compare.parent.child";
  public static final String ATTR_IS_COMPARE_FIELD_TO_FIELD = "is.compare.field.to.field";
  public static final String ATTR_IS_COMPARE_ON_OBJECT_PARENT = "is.compare.on.object.parent";
  public static final String ATTR_IS_PLACE_HOLDER_VALUES_FROM_PARENT = "is.get.place.holder.values.from.parent";
  public static final String ATTR_IS_COMPARE_HEIRARCHY_PARENT_TO_CHILD = "is.compare.heirarchy.parent.to.child";
  public static final String ATTR_IS_GET_PARENT_VALUES_FROM_COGNOS_REPORT = "is.get.parent.values.from.cognos.report";
  public static final String ATTR_CHECK_FOR_IN_OBJECT = "check.for.in.object";
  public static final String ATTR_COMPARATOR_IN_OBJECT = "comparator.in.object";
  public static final String ATTR_FIELDS_IN_OBJECT_FOR_COMPARE = "fields.in.object.for.compare";
  public static final String ATTR_FIELDS_TO_BE_COMPARED_IN_OBJECT = "fields.to.be.compared.in.object";
  public static final String ATTR_FIELD_VALUES_TO_BE_COMPARED_IN_OBJECT = "field.values.to.be.compared.in.object";
  public static final String ATTR_CHECK_FOR_IN_PARENT_OBJECT = "check.for.in.parent.object";
  public static final String COGNOS_REPORT_PATH_FOR_PARENT_INFORMATION = "parent.information.cognos.report.path";
  public static final String ATTR_COMPARATOR_IN_PARENT_OBJECT = "comparator.in.parent.object";
  public static final String ATTR_FIELDS_TO_BE_COMPARED_IN_PARENT = "fields.to.be.compared.in.parent.object";
  public static final String ATTR_FIELDS_IN_PARENT_OBJECT_FOR_COMPARE = "fields.in.parent.object.for.compare";
  public static final String IS_PARENT_GET_VALUES_FROM_COGNOS_REPORTS = "is.get.parent.values.from.cognos.reports";
  public static final String ATTR_FIELD_VALUES_TO_BE_COMPARED_IN_PARENT_OBJECT = "field.values.to.be.compared.in.parent.object";
  public static final String ATTR_PARENT_INFORMATION_COGNOS_REPORT_PATH = "parent.information.cognos.report.path";
  public static final String ATTR_POSITIONS_OF_FIELD_VALUES_TO_BE_COMPARED_IN_PARENT_OBJECT = "positions.of.field.values.to.be.compared.in.parent.object";
  public static final String ATTR_COMPARE_EXCEPTIONS_FOR_ANY = "compare.exceptions.for.any";
  public static final String ATTR_COMPARE_EXCEPTIONS_FOR_ALL = "compare.exception.for.all";
  public static final String ATTR_COMPARE_EXCEPTIONS_PLACE_HOLDER_FOR_ANY = "compare.exceptions.place.holder.for.any";
  public static final String ATTR_COMPARE_EXCEPTIONS_PLACE_HOLDER_FOR_ALL = "compare.exceptions.place.holder.for.all";
  public static final String ATTR_COMPARE_FIELD_VALUE_IN_OBJECT_OR_PARENT_OBJECT_RUN_CREATE_TRIGGER_REGISTRY_SETTING = "compare.field.value.in.object.or.parent.object.run.create.trigger.registry.setting";
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.triggers.constants.ValidatePrimaryParentFieldsConstants
 * JD-Core Version:    0.7.0.1
 */