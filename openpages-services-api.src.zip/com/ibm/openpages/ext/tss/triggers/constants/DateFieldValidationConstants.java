package com.ibm.openpages.ext.tss.triggers.constants;

public abstract class DateFieldValidationConstants
  extends TriggerCommonConstants
{
  public static final String ATTR_CHECK_FOR = "check.for";
  public static final String ATTR_DATE_COMPARATORS = "compare.date.fields";
  public static final String ATTR_SOURCE_DATE_FIELD = "source.date.fields";
  public static final String ATTR_COMPARE_DATE_FIELD = "compare.date.fields";
  public static final String ATTR_DATE_VALIDATION_ERROR_MESSAGES = "date.validation.error.messages";
  public static final String ATTR_DATE_VALIDATION_ERROR_MESSAGES_PLACE_HOLDER_VALUE = "date.validation.error.messages.place.holder.values";
  public static final String ATTR_DATE_VALIDATION_ERROR_MESSAGE_PLACE_HOLDER_VALUES_INFO = "date.validation.error.message.place.holder.values.info";
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.triggers.constants.DateFieldValidationConstants
 * JD-Core Version:    0.7.0.1
 */