package com.ibm.openpages.ext.tss.triggers.constants;

public abstract class DetectPropertyChangeConstants
  extends DetectPropertyChangeBaseConstants
{}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.triggers.constants.DetectPropertyChangeConstants
 * JD-Core Version:    0.7.0.1
 */