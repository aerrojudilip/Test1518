package com.ibm.openpages.ext.tss.triggers.constants;

public abstract class ContentTypeMatchBaseConstants
  extends TriggerCommonConstants
{
  public static final String CHECK_ALL = "ALL";
  public static final String CHECK_ANY = "ANY";
  public static final String ATTR_CHILD = "child";
  public static final String ATTR_PARENT = "parent";
  public static final String ATTR_SOURCE = "source";
  public static final String ATTR_TARGET = "target";
  public static final String ATTR_CHECK_ON = "check.on";
  public static final String CHECK_FOR_ALL_OR_ANY_ATTR = "check.for.all.or.any";
  public static final String CONTENT_TYPE_NAME_ATTR = "content.type.name";
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.triggers.constants.ContentTypeMatchBaseConstants
 * JD-Core Version:    0.7.0.1
 */