package com.ibm.openpages.ext.tss.triggers.constants;

public abstract class ParentChildContentTypeMatchConstants
  extends TriggerCommonConstants
{
  public static final String PARENT_CONTENT_TYPE_NAME_ATTR = "parent.content.type.names";
  public static final String CHILD_CONTENT_TYPE_NAME_ATTR = "child.content.type.names";
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.triggers.constants.ParentChildContentTypeMatchConstants
 * JD-Core Version:    0.7.0.1
 */