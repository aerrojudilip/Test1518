package com.ibm.openpages.ext.tss.triggers.constants;

public abstract class UpdateFieldValueConstants
  extends TriggerCommonConstants
{
  public static final String ATTR_FIELD_TO_BE_UPDATED = "field.to.be.updated";
  public static final String ATTR_CHECK_FIELD_IS_EMPTY = "check.field.is.empty";
  public static final String ATTR_FIELD_VALUE_TO_BE_UPDATED = "field.value.to.be.updated";
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.triggers.constants.UpdateFieldValueConstants
 * JD-Core Version:    0.7.0.1
 */