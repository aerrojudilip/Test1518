package com.ibm.openpages.ext.tss.triggers.constants;

public abstract class FolderMatchConstants
  extends TriggerCommonConstants
{
  public static final String SCOPE_SELF = "self";
  public static final String ATTR_SCOPE = "scope";
  public static final String ATTR_CHILD = "child";
  public static final String ATTR_PARENT = "parent";
  public static final String ATTR_SOURCE = "source";
  public static final String ATTR_CHECK_ON = "check.on";
  public static final String SCOPE_RECURSIVE = "recursive";
  public static final String ATTR_FOLDER_PATH = "folder.path";
  public static final String ATTR_DESTINATION = "destination";
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.triggers.constants.FolderMatchConstants
 * JD-Core Version:    0.7.0.1
 */