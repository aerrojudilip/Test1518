package com.ibm.openpages.ext.tss.triggers.backingbean;

public class UpdateTargetValueFromSourceBackingBean
  extends BaseTriggerBackingBean
{}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.triggers.backingbean.UpdateTargetValueFromSourceBackingBean
 * JD-Core Version:    0.7.0.1
 */