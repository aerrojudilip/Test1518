/*   1:    */ package com.ibm.openpages.ext.tss.triggers.backingbean;
/*   2:    */ 
/*   3:    */ import com.ibm.openpages.api.metadata.Id;
/*   4:    */ import com.ibm.openpages.api.resource.IGRCObject;
/*   5:    */ import com.ibm.openpages.api.service.IResourceService;
/*   6:    */ import com.ibm.openpages.api.service.IServiceFactory;
/*   7:    */ import com.ibm.openpages.ext.tss.service.IApplicationUtil;
/*   8:    */ import com.ibm.openpages.ext.tss.service.ICognosUtil;
/*   9:    */ import com.ibm.openpages.ext.tss.service.IDateFieldUtil;
/*  10:    */ import com.ibm.openpages.ext.tss.service.IEmailUtil;
/*  11:    */ import com.ibm.openpages.ext.tss.service.IEnumFieldUtil;
/*  12:    */ import com.ibm.openpages.ext.tss.service.IFieldUtil;
/*  13:    */ import com.ibm.openpages.ext.tss.service.IGRCObjectSearchUtil;
/*  14:    */ import com.ibm.openpages.ext.tss.service.IGRCObjectUtil;
/*  15:    */ import com.ibm.openpages.ext.tss.service.IGRCTriggerUtil;
/*  16:    */ import com.ibm.openpages.ext.tss.service.IIntegerFieldUtil;
/*  17:    */ import com.ibm.openpages.ext.tss.service.ILoggerUtil;
/*  18:    */ import com.ibm.openpages.ext.tss.service.IMultiEnumFieldUtil;
/*  19:    */ import com.ibm.openpages.ext.tss.service.IStringFieldUtil;
/*  20:    */ import com.ibm.openpages.ext.tss.service.IUserUtil;
/*  21:    */ import com.ibm.openpages.ext.tss.service.config.OPSServiceFactory;
/*  22:    */ import com.ibm.openpages.ext.tss.service.proxy.IServiceFactoryProxy;
/*  23:    */ import com.ibm.openpages.ext.tss.service.util.CommonUtil;
/*  24:    */ import com.openpages.sdk.repository.Resource;
/*  25:    */ import com.openpages.sdk.repository.ResourceId;
/*  26:    */ import com.openpages.sdk.trigger.TriggerContext;
/*  27:    */ import com.openpages.sdk.trigger.object.TriggerConstants.ResourceTriggerConstants;
/*  28:    */ import org.apache.commons.logging.Log;
/*  29:    */ 
/*  30:    */ public class BaseTriggerBackingBean
/*  31:    */ {
/*  32: 34 */   public Log logger = null;
/*  33: 35 */   public IEmailUtil emailUtil = null;
/*  34: 36 */   public IFieldUtil fieldUtil = null;
/*  35: 37 */   public ICognosUtil cognosUtil = null;
/*  36: 38 */   public IDateFieldUtil datefieldUtil = null;
/*  37: 39 */   public IEnumFieldUtil enumFieldUtil = null;
/*  38: 40 */   public IIntegerFieldUtil integerFieldUtil = null;
/*  39: 41 */   public IMultiEnumFieldUtil multiEnumFieldUtil = null;
/*  40: 42 */   public IStringFieldUtil stringFieldUtil = null;
/*  41: 43 */   public IUserUtil userUtil = null;
/*  42: 44 */   public IGRCObjectUtil grcObjectUtil = null;
/*  43: 45 */   public IGRCTriggerUtil grcTriggerUtil = null;
/*  44: 46 */   public IServiceFactory serviceFactory = null;
/*  45: 47 */   public IApplicationUtil applicationUtil = null;
/*  46: 48 */   public IGRCObjectSearchUtil grcObjectSearchUtil = null;
/*  47:    */   
/*  48:    */   public IGRCObject getImmediateParentObjectForCreate()
/*  49:    */     throws Exception
/*  50:    */   {
/*  51: 60 */     initLogServices();
/*  52: 61 */     this.logger.debug("getImmediateParentIssueForCreate()Start");
/*  53:    */     
/*  54:    */ 
/*  55: 64 */     long resourceId = 0L;
/*  56:    */     
/*  57: 66 */     IGRCObject parentIssue = null;
/*  58: 67 */     Resource primaryParentResource = null;
/*  59:    */     
/*  60: 69 */     initServiceFactory();
/*  61: 70 */     primaryParentResource = (Resource)TriggerContext.get().getContextAttribute(TriggerConstants.ResourceTriggerConstants.CONTEXT_ATTR_PRIMARY_PARENT);
/*  62:    */     
/*  63: 72 */     this.logger.debug("Is Primary Parent Resource null: " + CommonUtil.isObjectNotNull(primaryParentResource));
/*  64: 73 */     this.logger.debug("Primary Parent Resource name: " + (CommonUtil.isObjectNotNull(primaryParentResource) ? primaryParentResource.getName() : "null"));
/*  65: 74 */     resourceId = primaryParentResource.getResourceId().getId();
/*  66: 75 */     parentIssue = this.serviceFactory.createResourceService().getGRCObject(new Id(Long.toString(resourceId)));
/*  67:    */     
/*  68: 77 */     this.logger.debug("Parent Issue: " + parentIssue.getName());
/*  69: 78 */     this.logger.debug("getImmediateParentIssueForCreate()End");
/*  70: 79 */     return parentIssue;
/*  71:    */   }
/*  72:    */   
/*  73:    */   public void initLogServices()
/*  74:    */   {
/*  75: 91 */     this.logger = (CommonUtil.isObjectNotNull(this.logger) ? this.logger : OPSServiceFactory.getLoggerUtil().getExtLogger());
/*  76:    */   }
/*  77:    */   
/*  78:    */   public void initServiceFactory()
/*  79:    */   {
/*  80:103 */     this.serviceFactory = (CommonUtil.isObjectNotNull(this.serviceFactory) ? this.serviceFactory : OPSServiceFactory.getServiceFactoryProxy().getServiceFactory());
/*  81:    */   }
/*  82:    */   
/*  83:    */   public void initCognosUtilServices()
/*  84:    */   {
/*  85:115 */     this.cognosUtil = (CommonUtil.isObjectNotNull(this.cognosUtil) ? this.cognosUtil : OPSServiceFactory.getCognosUtil());
/*  86:    */   }
/*  87:    */   
/*  88:    */   public void initDateFieldUtilServices()
/*  89:    */   {
/*  90:127 */     this.datefieldUtil = (CommonUtil.isObjectNotNull(this.datefieldUtil) ? this.datefieldUtil : OPSServiceFactory.getDateFieldUtil());
/*  91:    */   }
/*  92:    */   
/*  93:    */   public void initEnumFieldUtilServices()
/*  94:    */   {
/*  95:139 */     this.enumFieldUtil = (CommonUtil.isObjectNotNull(this.enumFieldUtil) ? this.enumFieldUtil : OPSServiceFactory.getEnumFieldUtil());
/*  96:    */   }
/*  97:    */   
/*  98:    */   public void initMultiEnumFieldUtilServices()
/*  99:    */   {
/* 100:151 */     this.multiEnumFieldUtil = (CommonUtil.isObjectNotNull(this.multiEnumFieldUtil) ? this.multiEnumFieldUtil : OPSServiceFactory.getMultiEnumFieldUtil());
/* 101:    */   }
/* 102:    */   
/* 103:    */   public void initStringFieldUtilServices()
/* 104:    */   {
/* 105:163 */     this.stringFieldUtil = (CommonUtil.isObjectNotNull(this.stringFieldUtil) ? this.stringFieldUtil : OPSServiceFactory.getStringFieldUtil());
/* 106:    */   }
/* 107:    */   
/* 108:    */   public void initEmailUtilServices()
/* 109:    */   {
/* 110:175 */     this.emailUtil = (CommonUtil.isObjectNotNull(this.emailUtil) ? this.emailUtil : OPSServiceFactory.getEmailUtil());
/* 111:    */   }
/* 112:    */   
/* 113:    */   public void initUserUtilServices()
/* 114:    */   {
/* 115:187 */     this.userUtil = (CommonUtil.isObjectNotNull(this.userUtil) ? this.userUtil : OPSServiceFactory.getUserUtil());
/* 116:    */   }
/* 117:    */   
/* 118:    */   public void initGRCTriggerUtilServices()
/* 119:    */   {
/* 120:199 */     this.grcTriggerUtil = (CommonUtil.isObjectNotNull(this.grcTriggerUtil) ? this.grcTriggerUtil : OPSServiceFactory.getGRCTriggerUtil());
/* 121:    */   }
/* 122:    */   
/* 123:    */   public void initGRCObjectUtilServices()
/* 124:    */   {
/* 125:211 */     this.grcObjectUtil = (CommonUtil.isObjectNotNull(this.grcObjectUtil) ? this.grcObjectUtil : OPSServiceFactory.getGRCObjectUtil());
/* 126:    */   }
/* 127:    */   
/* 128:    */   public void initGRCObjectSearchUtilServices()
/* 129:    */   {
/* 130:223 */     this.grcObjectSearchUtil = (CommonUtil.isObjectNotNull(this.grcObjectSearchUtil) ? this.grcObjectSearchUtil : OPSServiceFactory.getGRCObjectSearchUtil());
/* 131:    */   }
/* 132:    */   
/* 133:    */   public void initFieldUtilServices()
/* 134:    */   {
/* 135:235 */     this.fieldUtil = (CommonUtil.isObjectNotNull(this.fieldUtil) ? this.fieldUtil : OPSServiceFactory.getFieldUtil());
/* 136:    */   }
/* 137:    */   
/* 138:    */   public void initApplicationUtilServices()
/* 139:    */   {
/* 140:247 */     this.applicationUtil = (CommonUtil.isObjectNotNull(this.applicationUtil) ? this.applicationUtil : OPSServiceFactory.getApplicationUtil());
/* 141:    */   }
/* 142:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.triggers.backingbean.BaseTriggerBackingBean
 * JD-Core Version:    0.7.0.1
 */