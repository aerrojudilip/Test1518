/*   1:    */ package com.ibm.openpages.ext.tss.triggers.rule;
/*   2:    */ 
/*   3:    */ import com.ibm.openpages.api.metadata.ITypeDefinition;
/*   4:    */ import com.ibm.openpages.api.resource.IGRCObject;
/*   5:    */ import com.ibm.openpages.api.resource.IResource;
/*   6:    */ import com.ibm.openpages.api.trigger.events.AssociateResourceEvent;
/*   7:    */ import com.ibm.openpages.api.trigger.events.CopyResourceEvent;
/*   8:    */ import com.ibm.openpages.api.trigger.events.CreateResourceEvent;
/*   9:    */ import com.ibm.openpages.api.trigger.events.DeleteResourceEvent;
/*  10:    */ import com.ibm.openpages.api.trigger.events.DisassociateResourceEvent;
/*  11:    */ import com.ibm.openpages.api.trigger.events.QueryEvent;
/*  12:    */ import com.ibm.openpages.api.trigger.events.SearchEvent;
/*  13:    */ import com.ibm.openpages.api.trigger.events.UpdateResourceEvent;
/*  14:    */ import com.ibm.openpages.ext.tss.service.IFieldUtil;
/*  15:    */ import com.ibm.openpages.ext.tss.service.beans.FieldValueChangeInfo;
/*  16:    */ import com.ibm.openpages.ext.tss.service.constants.CheckFor;
/*  17:    */ import com.ibm.openpages.ext.tss.service.util.CommonUtil;
/*  18:    */ import org.apache.commons.logging.Log;
/*  19:    */ 
/*  20:    */ public class DetectPropertyChangeRule
/*  21:    */   extends DetectPropertyChangeBaseRule
/*  22:    */ {
/*  23:    */   public boolean isApplicable(CreateResourceEvent createResourceEvent)
/*  24:    */   {
/*  25: 75 */     boolean isApplicable = false;
/*  26: 76 */     IResource resource = null;
/*  27: 79 */     if (super.isApplicable(createResourceEvent))
/*  28:    */     {
/*  29: 81 */       this.logger.debug("isApplicable(CreateResourceEvent)Start");
/*  30:    */       try
/*  31:    */       {
/*  32: 85 */         prepareContextForTrigger(createResourceEvent);
/*  33: 87 */         if (isRunTrigger())
/*  34:    */         {
/*  35: 89 */           resource = createResourceEvent.getResource();
/*  36: 95 */           if (super.isApplicable(createResourceEvent)) {
/*  37: 97 */             isApplicable = resource.isFolder() ? false : evaluate((IGRCObject)resource);
/*  38:    */           }
/*  39:    */         }
/*  40:    */       }
/*  41:    */       catch (Exception ex)
/*  42:    */       {
/*  43:102 */         this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(CreateResourceEvent)" + CommonUtil.getStackTrace(ex));
/*  44:103 */         isApplicable = false;
/*  45:    */       }
/*  46:106 */       this.logger.debug("Is trigger Applicable: " + isApplicable);
/*  47:107 */       this.logger.debug("isApplicable(CreateResourceEvent)End");
/*  48:    */     }
/*  49:110 */     return isApplicable;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public boolean isApplicable(UpdateResourceEvent updateResourceEvent)
/*  53:    */   {
/*  54:128 */     boolean isApplicable = false;
/*  55:129 */     IResource resource = null;
/*  56:132 */     if (super.isApplicable(updateResourceEvent))
/*  57:    */     {
/*  58:134 */       this.logger.debug("isApplicable(UpdateResourceEvent)Start");
/*  59:    */       try
/*  60:    */       {
/*  61:138 */         prepareContextForTrigger(updateResourceEvent);
/*  62:140 */         if (isRunTrigger())
/*  63:    */         {
/*  64:142 */           resource = updateResourceEvent.getResource();
/*  65:148 */           if (super.isApplicable(updateResourceEvent)) {
/*  66:150 */             isApplicable = resource.isFolder() ? false : evaluate((IGRCObject)resource);
/*  67:    */           }
/*  68:    */         }
/*  69:    */       }
/*  70:    */       catch (Exception ex)
/*  71:    */       {
/*  72:155 */         this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(UpdateResourceEvent)" + CommonUtil.getStackTrace(ex));
/*  73:156 */         isApplicable = false;
/*  74:    */       }
/*  75:159 */       this.logger.debug("Is trigger Applicable: " + isApplicable);
/*  76:160 */       this.logger.debug("isApplicable(UpdateResourceEvent)End");
/*  77:    */     }
/*  78:163 */     return isApplicable;
/*  79:    */   }
/*  80:    */   
/*  81:    */   public boolean isApplicable(AssociateResourceEvent associateResourceEvent)
/*  82:    */   {
/*  83:179 */     boolean isApplicable = false;
/*  84:182 */     if (super.isApplicable(associateResourceEvent))
/*  85:    */     {
/*  86:184 */       this.logger.debug("isApplicable(AssociateResourceEvent)Start");
/*  87:    */       try
/*  88:    */       {
/*  89:188 */         prepareContextForTrigger(associateResourceEvent);
/*  90:191 */         if (isRunTrigger()) {
/*  91:193 */           isApplicable = super.isApplicable(associateResourceEvent);
/*  92:    */         }
/*  93:    */       }
/*  94:    */       catch (Exception ex)
/*  95:    */       {
/*  96:197 */         this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(AssociateResourceEvent)" + CommonUtil.getStackTrace(ex));
/*  97:198 */         isApplicable = false;
/*  98:    */       }
/*  99:201 */       this.logger.debug("Is Applicable: " + isApplicable);
/* 100:202 */       this.logger.debug("isApplicable(AssociateResourceEvent)End");
/* 101:    */     }
/* 102:205 */     return isApplicable;
/* 103:    */   }
/* 104:    */   
/* 105:    */   public boolean isApplicable(DisassociateResourceEvent disassociateResourceEvent)
/* 106:    */   {
/* 107:221 */     boolean isApplicable = false;
/* 108:224 */     if (super.isApplicable(disassociateResourceEvent))
/* 109:    */     {
/* 110:226 */       this.logger.debug("isApplicable(DisassociateResourceEvent)Start");
/* 111:    */       try
/* 112:    */       {
/* 113:230 */         prepareContextForTrigger(disassociateResourceEvent);
/* 114:233 */         if (isRunTrigger()) {
/* 115:235 */           isApplicable = super.isApplicable(disassociateResourceEvent);
/* 116:    */         }
/* 117:    */       }
/* 118:    */       catch (Exception ex)
/* 119:    */       {
/* 120:239 */         this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(DisassociateResourceEvent)" + CommonUtil.getStackTrace(ex));
/* 121:240 */         isApplicable = false;
/* 122:    */       }
/* 123:243 */       this.logger.debug("Is Applicable: " + isApplicable);
/* 124:244 */       this.logger.debug("isApplicable(DisassociateResourceEvent)End");
/* 125:    */     }
/* 126:247 */     return isApplicable;
/* 127:    */   }
/* 128:    */   
/* 129:    */   public boolean isApplicable(CopyResourceEvent copyResourceEvent)
/* 130:    */   {
/* 131:263 */     boolean isApplicable = false;
/* 132:266 */     if (super.isApplicable(copyResourceEvent))
/* 133:    */     {
/* 134:268 */       this.logger.debug("isApplicable(CopyResourceEvent)Start");
/* 135:    */       try
/* 136:    */       {
/* 137:272 */         prepareContextForTrigger(copyResourceEvent);
/* 138:275 */         if (isRunTrigger()) {
/* 139:277 */           isApplicable = super.isApplicable(copyResourceEvent);
/* 140:    */         }
/* 141:    */       }
/* 142:    */       catch (Exception ex)
/* 143:    */       {
/* 144:281 */         this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(CopyResourceEvent)" + CommonUtil.getStackTrace(ex));
/* 145:282 */         isApplicable = false;
/* 146:    */       }
/* 147:285 */       this.logger.debug("Is Applicable: " + isApplicable);
/* 148:286 */       this.logger.debug("isApplicable(CopyResourceEvent)End");
/* 149:    */     }
/* 150:289 */     return isApplicable;
/* 151:    */   }
/* 152:    */   
/* 153:    */   public boolean isApplicable(DeleteResourceEvent deleteResourceEvent)
/* 154:    */   {
/* 155:305 */     boolean isApplicable = false;
/* 156:308 */     if (super.isApplicable(deleteResourceEvent))
/* 157:    */     {
/* 158:310 */       this.logger.debug("isApplicable(DeleteResourceEvent)Start");
/* 159:    */       try
/* 160:    */       {
/* 161:314 */         prepareContextForTrigger(deleteResourceEvent);
/* 162:317 */         if (isRunTrigger()) {
/* 163:319 */           isApplicable = super.isApplicable(deleteResourceEvent);
/* 164:    */         }
/* 165:    */       }
/* 166:    */       catch (Exception ex)
/* 167:    */       {
/* 168:323 */         this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(DeleteResourceEvent)" + CommonUtil.getStackTrace(ex));
/* 169:324 */         isApplicable = false;
/* 170:    */       }
/* 171:327 */       this.logger.debug("Is Applicable: " + isApplicable);
/* 172:328 */       this.logger.debug("isApplicable(DeleteResourceEvent)End");
/* 173:    */     }
/* 174:331 */     return isApplicable;
/* 175:    */   }
/* 176:    */   
/* 177:    */   public boolean isApplicable(QueryEvent queryEvent)
/* 178:    */   {
/* 179:346 */     this.logger.debug("isApplicable(QueryEvent)Start");
/* 180:    */     
/* 181:    */ 
/* 182:349 */     boolean isApplicable = false;
/* 183:    */     try
/* 184:    */     {
/* 185:354 */       prepareContextForTrigger(queryEvent);
/* 186:357 */       if (isRunTrigger()) {
/* 187:359 */         isApplicable = super.isApplicable(queryEvent);
/* 188:    */       }
/* 189:    */     }
/* 190:    */     catch (Exception ex)
/* 191:    */     {
/* 192:363 */       this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(QueryEvent)" + CommonUtil.getStackTrace(ex));
/* 193:364 */       isApplicable = false;
/* 194:    */     }
/* 195:367 */     this.logger.debug("Is Applicable: " + isApplicable);
/* 196:368 */     this.logger.debug("isApplicable(QueryEvent)End");
/* 197:369 */     return isApplicable;
/* 198:    */   }
/* 199:    */   
/* 200:    */   public boolean isApplicable(SearchEvent searchEvent)
/* 201:    */   {
/* 202:384 */     this.logger.debug("isApplicable(SearchEvent)Start");
/* 203:    */     
/* 204:    */ 
/* 205:387 */     boolean isApplicable = false;
/* 206:    */     try
/* 207:    */     {
/* 208:392 */       prepareContextForTrigger(searchEvent);
/* 209:395 */       if (isRunTrigger()) {
/* 210:397 */         isApplicable = super.isApplicable(searchEvent);
/* 211:    */       }
/* 212:    */     }
/* 213:    */     catch (Exception ex)
/* 214:    */     {
/* 215:401 */       this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(SearchEvent)" + CommonUtil.getStackTrace(ex));
/* 216:402 */       isApplicable = false;
/* 217:    */     }
/* 218:405 */     this.logger.debug("Is Applicable: " + isApplicable);
/* 219:406 */     this.logger.debug("isApplicable(SearchEvent)End");
/* 220:407 */     return isApplicable;
/* 221:    */   }
/* 222:    */   
/* 223:    */   private boolean evaluate(IGRCObject object)
/* 224:    */     throws Exception
/* 225:    */   {
/* 226:424 */     this.logger.debug("evaluate()Start");
/* 227:    */     
/* 228:    */ 
/* 229:427 */     boolean isApplicable = false;
/* 230:    */     
/* 231:429 */     String fields = "";
/* 232:430 */     String contentType = "";
/* 233:431 */     CheckFor checkFor = null;
/* 234:    */     
/* 235:433 */     FieldValueChangeInfo detectPropertyChangeInfoDTO = null;
/* 236:    */     
/* 237:    */ 
/* 238:    */ 
/* 239:437 */     initFieldUtilServices();
/* 240:438 */     detectPropertyChangeInfoDTO = new FieldValueChangeInfo();
/* 241:439 */     fields = getTriggerAttrbuteValue("field.names.to.check");
/* 242:440 */     checkFor = CommonUtil.getCheckFor(getTriggerAttrbuteValue("check.for.all.or.any"));
/* 243:441 */     contentType = getTriggerAttrbuteValue("content.type.name");
/* 244:    */     
/* 245:    */ 
/* 246:444 */     this.logger.debug("Content Type for check: " + contentType);
/* 247:445 */     this.logger.debug("Content Type in the current Event: " + object.getType().getName());
/* 248:446 */     this.logger.debug("Is Content Type same as required Content Type: " + CommonUtil.isEqualIgnoreCase(object.getType().getName(), contentType));
/* 249:    */     
/* 250:    */ 
/* 251:449 */     this.logger.debug("Fields that needs to be checked: " + fields);
/* 252:450 */     this.logger.debug("Check For: " + getTriggerAttrbuteValue("check.for.all.or.any"));
/* 253:    */     
/* 254:452 */     detectPropertyChangeInfoDTO.setFields(fields);
/* 255:453 */     detectPropertyChangeInfoDTO.setCheckFor(checkFor);
/* 256:454 */     detectPropertyChangeInfoDTO.setModifiedFields(this.fieldUtil.getModifiedFields(object));
/* 257:    */     
/* 258:456 */     this.logger.debug("Detect Property Change Info DTO: " + detectPropertyChangeInfoDTO.toString());
/* 259:    */     
/* 260:458 */     detectPropertyChangeValidation(detectPropertyChangeInfoDTO);
/* 261:459 */     isApplicable = detectPropertyChange(detectPropertyChangeInfoDTO);
/* 262:    */     
/* 263:461 */     this.logger.debug("Is Applicable: " + isApplicable);
/* 264:462 */     return isApplicable;
/* 265:    */   }
/* 266:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.triggers.rule.DetectPropertyChangeRule
 * JD-Core Version:    0.7.0.1
 */