/*   1:    */ package com.ibm.openpages.ext.tss.triggers.rule;
/*   2:    */ 
/*   3:    */ import com.ibm.openpages.api.metadata.ITypeDefinition;
/*   4:    */ import com.ibm.openpages.api.resource.IField;
/*   5:    */ import com.ibm.openpages.api.resource.IGRCObject;
/*   6:    */ import com.ibm.openpages.api.resource.IResource;
/*   7:    */ import com.ibm.openpages.api.trigger.events.AssociateResourceEvent;
/*   8:    */ import com.ibm.openpages.api.trigger.events.CopyResourceEvent;
/*   9:    */ import com.ibm.openpages.api.trigger.events.CreateResourceEvent;
/*  10:    */ import com.ibm.openpages.api.trigger.events.DeleteResourceEvent;
/*  11:    */ import com.ibm.openpages.api.trigger.events.DisassociateResourceEvent;
/*  12:    */ import com.ibm.openpages.api.trigger.events.QueryEvent;
/*  13:    */ import com.ibm.openpages.api.trigger.events.SearchEvent;
/*  14:    */ import com.ibm.openpages.api.trigger.events.UpdateResourceEvent;
/*  15:    */ import com.ibm.openpages.ext.tss.service.IFieldUtil;
/*  16:    */ import com.ibm.openpages.ext.tss.service.IGRCObjectUtil;
/*  17:    */ import com.ibm.openpages.ext.tss.service.beans.FieldValueChangeInfo;
/*  18:    */ import com.ibm.openpages.ext.tss.service.constants.CheckFor;
/*  19:    */ import com.ibm.openpages.ext.tss.service.util.CommonUtil;
/*  20:    */ import java.io.PrintStream;
/*  21:    */ import java.util.ArrayList;
/*  22:    */ import java.util.List;
/*  23:    */ import org.apache.commons.logging.Log;
/*  24:    */ 
/*  25:    */ public class DetectPropertyChangeToGivenValueRule
/*  26:    */   extends DetectPropertyChangeBaseRule
/*  27:    */ {
/*  28:    */   public boolean isApplicable(CreateResourceEvent createResourceEvent)
/*  29:    */   {
/*  30:    */     try
/*  31:    */     {
/*  32: 84 */       prepareContextForTrigger(createResourceEvent);
/*  33:    */     }
/*  34:    */     catch (Exception e)
/*  35:    */     {
/*  36: 87 */       System.out.println(CommonUtil.getStackTrace(e));
/*  37:    */     }
/*  38: 91 */     boolean isApplicable = false;
/*  39: 92 */     IResource resource = null;
/*  40: 94 */     if (super.isApplicable(createResourceEvent))
/*  41:    */     {
/*  42: 96 */       this.logger.debug("isApplicable(CreateResourceEvent)Start");
/*  43:    */       try
/*  44:    */       {
/*  45:101 */         prepareContextForTrigger(createResourceEvent);
/*  46:103 */         if (isRunTrigger())
/*  47:    */         {
/*  48:105 */           resource = createResourceEvent.getResource();
/*  49:108 */           if (super.isApplicable(createResourceEvent)) {
/*  50:110 */             isApplicable = resource.isFolder() ? false : evaluateOnCreate((IGRCObject)resource);
/*  51:    */           }
/*  52:    */         }
/*  53:    */       }
/*  54:    */       catch (Exception ex)
/*  55:    */       {
/*  56:116 */         this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(CreateResourceEvent)" + CommonUtil.getStackTrace(ex));
/*  57:117 */         isApplicable = false;
/*  58:    */       }
/*  59:120 */       this.logger.debug("Is trigger Applicable: " + isApplicable);
/*  60:121 */       this.logger.debug("isApplicable(CreateResourceEvent)End");
/*  61:    */     }
/*  62:124 */     return isApplicable;
/*  63:    */   }
/*  64:    */   
/*  65:    */   public boolean isApplicable(UpdateResourceEvent updateResourceEvent)
/*  66:    */   {
/*  67:139 */     boolean isApplicable = false;
/*  68:140 */     IResource resource = null;
/*  69:142 */     if (super.isApplicable(updateResourceEvent))
/*  70:    */     {
/*  71:144 */       this.logger.debug("isApplicable(UpdateResourceEvent)Start");
/*  72:    */       try
/*  73:    */       {
/*  74:148 */         prepareContextForTrigger(updateResourceEvent);
/*  75:150 */         if (isRunTrigger())
/*  76:    */         {
/*  77:152 */           resource = updateResourceEvent.getResource();
/*  78:155 */           if (super.isApplicable(updateResourceEvent)) {
/*  79:157 */             isApplicable = resource.isFolder() ? false : evaluate((IGRCObject)resource);
/*  80:    */           }
/*  81:    */         }
/*  82:    */       }
/*  83:    */       catch (Exception ex)
/*  84:    */       {
/*  85:163 */         this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(UpdateResourceEvent)" + CommonUtil.getStackTrace(ex));
/*  86:164 */         isApplicable = false;
/*  87:    */       }
/*  88:167 */       this.logger.debug("Is trigger applicable: " + isApplicable);
/*  89:168 */       this.logger.debug("isApplicable(UpdateResourceEvent)End");
/*  90:    */     }
/*  91:171 */     return isApplicable;
/*  92:    */   }
/*  93:    */   
/*  94:    */   public boolean isApplicable(AssociateResourceEvent associateResourceEvent)
/*  95:    */   {
/*  96:187 */     boolean isApplicable = false;
/*  97:188 */     IResource resource = null;
/*  98:190 */     if (super.isApplicable(associateResourceEvent))
/*  99:    */     {
/* 100:192 */       this.logger.debug("isApplicable(AssociateResourceEvent)Start");
/* 101:    */       
/* 102:194 */       initGRCObjectUtilServices();
/* 103:    */       try
/* 104:    */       {
/* 105:199 */         prepareContextForTrigger(associateResourceEvent);
/* 106:202 */         if (isRunTrigger())
/* 107:    */         {
/* 108:204 */           resource = this.grcObjectUtil.getObjectFromId(associateResourceEvent.getChild());
/* 109:207 */           if (super.isApplicable(associateResourceEvent)) {
/* 110:209 */             isApplicable = resource.isFolder() ? false : evaluate((IGRCObject)resource);
/* 111:    */           }
/* 112:    */         }
/* 113:    */       }
/* 114:    */       catch (Exception ex)
/* 115:    */       {
/* 116:214 */         this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(AssociateResourceEvent)" + CommonUtil.getStackTrace(ex));
/* 117:215 */         isApplicable = false;
/* 118:    */       }
/* 119:218 */       this.logger.debug("Is Applicable: " + isApplicable);
/* 120:219 */       this.logger.debug("isApplicable(AssociateResourceEvent)End");
/* 121:    */     }
/* 122:222 */     return isApplicable;
/* 123:    */   }
/* 124:    */   
/* 125:    */   public boolean isApplicable(DisassociateResourceEvent disassociateResourceEvent)
/* 126:    */   {
/* 127:238 */     boolean isApplicable = false;
/* 128:240 */     if (super.isApplicable(disassociateResourceEvent))
/* 129:    */     {
/* 130:242 */       this.logger.debug("isApplicable(DisassociateResourceEvent)Start");
/* 131:    */       try
/* 132:    */       {
/* 133:248 */         prepareContextForTrigger(disassociateResourceEvent);
/* 134:251 */         if (isRunTrigger()) {
/* 135:253 */           isApplicable = super.isApplicable(disassociateResourceEvent);
/* 136:    */         }
/* 137:    */       }
/* 138:    */       catch (Exception ex)
/* 139:    */       {
/* 140:257 */         this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(DisassociateResourceEvent)" + CommonUtil.getStackTrace(ex));
/* 141:258 */         isApplicable = false;
/* 142:    */       }
/* 143:261 */       this.logger.debug("Is Applicable: " + isApplicable);
/* 144:262 */       this.logger.debug("isApplicable(DisassociateResourceEvent)End");
/* 145:    */     }
/* 146:265 */     return isApplicable;
/* 147:    */   }
/* 148:    */   
/* 149:    */   public boolean isApplicable(CopyResourceEvent copyResourceEvent)
/* 150:    */   {
/* 151:280 */     this.logger.debug("isApplicable(CopyResourceEvent)Start");
/* 152:    */     
/* 153:    */ 
/* 154:283 */     boolean isApplicable = false;
/* 155:    */     try
/* 156:    */     {
/* 157:288 */       prepareContextForTrigger(copyResourceEvent);
/* 158:291 */       if (isRunTrigger()) {
/* 159:293 */         isApplicable = super.isApplicable(copyResourceEvent);
/* 160:    */       }
/* 161:    */     }
/* 162:    */     catch (Exception ex)
/* 163:    */     {
/* 164:297 */       this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(CopyResourceEvent)" + CommonUtil.getStackTrace(ex));
/* 165:298 */       isApplicable = false;
/* 166:    */     }
/* 167:301 */     this.logger.debug("Is Applicable: " + isApplicable);
/* 168:302 */     this.logger.debug("isApplicable(CopyResourceEvent)End");
/* 169:303 */     return isApplicable;
/* 170:    */   }
/* 171:    */   
/* 172:    */   public boolean isApplicable(DeleteResourceEvent deleteResourceEvent)
/* 173:    */   {
/* 174:318 */     this.logger.debug("isApplicable(DeleteResourceEvent)Start");
/* 175:    */     
/* 176:    */ 
/* 177:321 */     boolean isApplicable = false;
/* 178:    */     try
/* 179:    */     {
/* 180:326 */       prepareContextForTrigger(deleteResourceEvent);
/* 181:329 */       if (isRunTrigger()) {
/* 182:331 */         isApplicable = super.isApplicable(deleteResourceEvent);
/* 183:    */       }
/* 184:    */     }
/* 185:    */     catch (Exception ex)
/* 186:    */     {
/* 187:335 */       this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(DeleteResourceEvent)" + CommonUtil.getStackTrace(ex));
/* 188:336 */       isApplicable = false;
/* 189:    */     }
/* 190:339 */     this.logger.debug("Is Applicable: " + isApplicable);
/* 191:340 */     this.logger.debug("isApplicable(DeleteResourceEvent)End");
/* 192:341 */     return isApplicable;
/* 193:    */   }
/* 194:    */   
/* 195:    */   public boolean isApplicable(QueryEvent queryEvent)
/* 196:    */   {
/* 197:357 */     boolean isApplicable = false;
/* 198:360 */     if (super.isApplicable(queryEvent))
/* 199:    */     {
/* 200:362 */       this.logger.debug("isApplicable(QueryEvent)Start");
/* 201:    */       try
/* 202:    */       {
/* 203:366 */         prepareContextForTrigger(queryEvent);
/* 204:369 */         if (isRunTrigger()) {
/* 205:371 */           isApplicable = super.isApplicable(queryEvent);
/* 206:    */         }
/* 207:    */       }
/* 208:    */       catch (Exception ex)
/* 209:    */       {
/* 210:375 */         this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(QueryEvent)" + CommonUtil.getStackTrace(ex));
/* 211:376 */         isApplicable = false;
/* 212:    */       }
/* 213:379 */       this.logger.debug("Is Applicable: " + isApplicable);
/* 214:380 */       this.logger.debug("isApplicable(QueryEvent)End");
/* 215:    */     }
/* 216:383 */     return isApplicable;
/* 217:    */   }
/* 218:    */   
/* 219:    */   public boolean isApplicable(SearchEvent searchEvent)
/* 220:    */   {
/* 221:399 */     boolean isApplicable = false;
/* 222:402 */     if (super.isApplicable(searchEvent))
/* 223:    */     {
/* 224:404 */       this.logger.debug("isApplicable(SearchEvent)Start");
/* 225:    */       try
/* 226:    */       {
/* 227:408 */         prepareContextForTrigger(searchEvent);
/* 228:411 */         if (isRunTrigger()) {
/* 229:413 */           isApplicable = super.isApplicable(searchEvent);
/* 230:    */         }
/* 231:    */       }
/* 232:    */       catch (Exception ex)
/* 233:    */       {
/* 234:417 */         this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(SearchEvent)" + CommonUtil.getStackTrace(ex));
/* 235:418 */         isApplicable = false;
/* 236:    */       }
/* 237:421 */       this.logger.debug("Is Applicable: " + isApplicable);
/* 238:422 */       this.logger.debug("isApplicable(SearchEvent)End");
/* 239:    */     }
/* 240:425 */     return isApplicable;
/* 241:    */   }
/* 242:    */   
/* 243:    */   private boolean evaluateOnCreate(IGRCObject object)
/* 244:    */     throws Exception
/* 245:    */   {
/* 246:441 */     this.logger.debug("evaluateOnCreate()Start");
/* 247:    */     
/* 248:    */ 
/* 249:444 */     boolean isApplicable = false;
/* 250:    */     
/* 251:446 */     String values = "";
/* 252:447 */     String fields = "";
/* 253:448 */     String contentType = "";
/* 254:    */     
/* 255:450 */     CheckFor checkFor = null;
/* 256:451 */     List<String> valuesList = null;
/* 257:452 */     List<String> fieldNamesList = null;
/* 258:453 */     List<IField> modifiedFields = null;
/* 259:454 */     FieldValueChangeInfo detectPropertyChangeInfoDTO = null;
/* 260:    */     
/* 261:    */ 
/* 262:    */ 
/* 263:458 */     initFieldUtilServices();
/* 264:459 */     modifiedFields = new ArrayList();
/* 265:460 */     detectPropertyChangeInfoDTO = new FieldValueChangeInfo();
/* 266:461 */     values = getTriggerAttrbuteValue("field.values.to.check");
/* 267:462 */     fields = getTriggerAttrbuteValue("field.names.to.check");
/* 268:463 */     checkFor = CommonUtil.getCheckFor(getTriggerAttrbuteValue("check.for.all.or.any"));
/* 269:464 */     contentType = getTriggerAttrbuteValue("content.type.name");
/* 270:465 */     valuesList = CommonUtil.parseDelimitedValues(values, ",");
/* 271:466 */     fieldNamesList = CommonUtil.parseDelimitedValues(fields, ",");
/* 272:    */     
/* 273:    */ 
/* 274:469 */     this.logger.debug("Content Type for check: " + contentType);
/* 275:470 */     this.logger.debug("Content Type in the current Event: " + object.getType().getName());
/* 276:471 */     this.logger.debug("Is Content Type same as required Content Type: " + CommonUtil.isEqualIgnoreCase(object.getType().getName(), contentType));
/* 277:    */     
/* 278:473 */     this.logger.debug("Fields that needs to be checked: " + fields);
/* 279:474 */     this.logger.debug("Field Values that needs to be checked: " + values);
/* 280:475 */     this.logger.debug("Check For: " + getTriggerAttrbuteValue("check.for.all.or.any"));
/* 281:476 */     this.logger.debug("Field Names List: " + fieldNamesList);
/* 282:477 */     this.logger.debug("Field Values List: " + valuesList);
/* 283:478 */     this.logger.debug("Field Names List Size = : " + fieldNamesList.size());
/* 284:479 */     this.logger.debug("Field Values List Size = : " + valuesList.size());
/* 285:    */     
/* 286:481 */     detectPropertyChangeInfoDTO.setValues(values);
/* 287:482 */     detectPropertyChangeInfoDTO.setFields(fields);
/* 288:483 */     detectPropertyChangeInfoDTO.setCheckFor(checkFor);
/* 289:    */     
/* 290:485 */     detectPropertyChangeToAGivenValueValidation(detectPropertyChangeInfoDTO);
/* 291:487 */     for (String fieldInfo : fieldNamesList)
/* 292:    */     {
/* 293:489 */       this.logger.debug("Field Info: " + fieldInfo);
/* 294:    */       
/* 295:491 */       IField modifiedField = this.fieldUtil.getField(object, fieldInfo);
/* 296:492 */       this.logger.debug("Modified Field not null: " + CommonUtil.isObjectNotNull(modifiedField));
/* 297:493 */       this.logger.debug("Modified Field Name: " + (CommonUtil.isObjectNotNull(modifiedField) ? modifiedField.getName() : "null"));
/* 298:495 */       if (CommonUtil.isObjectNotNull(modifiedField)) {
/* 299:496 */         modifiedFields.add(modifiedField);
/* 300:    */       }
/* 301:    */     }
/* 302:500 */     this.logger.debug("Modified Field not null: " + (CommonUtil.isListNotNullOrEmpty(modifiedFields) ? modifiedFields.toString() : "null"));
/* 303:501 */     detectPropertyChangeInfoDTO.setModifiedFields(modifiedFields);
/* 304:502 */     this.logger.debug("Detect Property Change Info DTO: " + detectPropertyChangeInfoDTO.toString());
/* 305:    */     
/* 306:504 */     isApplicable = detectPropertyChangeToAGivenValue(detectPropertyChangeInfoDTO);
/* 307:    */     
/* 308:506 */     this.logger.debug("Is Applicable: " + isApplicable);
/* 309:507 */     this.logger.debug("evaluateOnCreate()End");
/* 310:508 */     return isApplicable;
/* 311:    */   }
/* 312:    */   
/* 313:    */   private boolean evaluate(IGRCObject object)
/* 314:    */     throws Exception
/* 315:    */   {
/* 316:526 */     this.logger.debug("evaluate()Start");
/* 317:    */     
/* 318:    */ 
/* 319:529 */     boolean isApplicable = false;
/* 320:    */     
/* 321:531 */     String values = "";
/* 322:532 */     String fields = "";
/* 323:533 */     String contentType = "";
/* 324:    */     
/* 325:535 */     CheckFor checkFor = null;
/* 326:536 */     List<String> valuesList = null;
/* 327:537 */     List<String> fieldNamesList = null;
/* 328:538 */     FieldValueChangeInfo detectPropertyChangeInfoDTO = null;
/* 329:    */     
/* 330:    */ 
/* 331:    */ 
/* 332:542 */     initFieldUtilServices();
/* 333:543 */     detectPropertyChangeInfoDTO = new FieldValueChangeInfo();
/* 334:544 */     values = getTriggerAttrbuteValue("field.values.to.check");
/* 335:545 */     fields = getTriggerAttrbuteValue("field.names.to.check");
/* 336:546 */     checkFor = CommonUtil.getCheckFor(getTriggerAttrbuteValue("check.for.all.or.any"));
/* 337:547 */     contentType = getTriggerAttrbuteValue("content.type.name");
/* 338:548 */     valuesList = CommonUtil.parseDelimitedValues(values, ",");
/* 339:549 */     fieldNamesList = CommonUtil.parseDelimitedValues(fields, ",");
/* 340:    */     
/* 341:    */ 
/* 342:552 */     this.logger.debug("Content Type for check: " + contentType);
/* 343:553 */     this.logger.debug("Content Type in the current Event: " + object.getType().getName());
/* 344:554 */     this.logger.debug("Is Content Type same as required Content Type: " + CommonUtil.isEqualIgnoreCase(object.getType().getName(), contentType));
/* 345:    */     
/* 346:556 */     this.logger.debug("Fields that needs to be checked: " + fields);
/* 347:557 */     this.logger.debug("Field Values that needs to be checked: " + values);
/* 348:558 */     this.logger.debug("Check For: " + getTriggerAttrbuteValue("check.for.all.or.any"));
/* 349:559 */     this.logger.debug("Field Names List: " + fieldNamesList);
/* 350:560 */     this.logger.debug("Field Values List: " + valuesList);
/* 351:561 */     this.logger.debug("Field Names List Size = : " + fieldNamesList.size());
/* 352:562 */     this.logger.debug("Field Values List Size = : " + valuesList.size());
/* 353:    */     
/* 354:564 */     detectPropertyChangeInfoDTO.setValues(values);
/* 355:565 */     detectPropertyChangeInfoDTO.setFields(fields);
/* 356:566 */     detectPropertyChangeInfoDTO.setCheckFor(checkFor);
/* 357:567 */     detectPropertyChangeInfoDTO.setModifiedFields(this.fieldUtil.getModifiedFields(object));
/* 358:    */     
/* 359:569 */     detectPropertyChangeToAGivenValueValidation(detectPropertyChangeInfoDTO);
/* 360:570 */     isApplicable = detectPropertyChangeToAGivenValue(detectPropertyChangeInfoDTO);
/* 361:    */     
/* 362:572 */     this.logger.debug("Is Applicable: " + isApplicable);
/* 363:573 */     return isApplicable;
/* 364:    */   }
/* 365:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.triggers.rule.DetectPropertyChangeToGivenValueRule
 * JD-Core Version:    0.7.0.1
 */