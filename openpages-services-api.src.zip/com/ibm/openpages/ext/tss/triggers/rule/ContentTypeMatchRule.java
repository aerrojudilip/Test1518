/*   1:    */ package com.ibm.openpages.ext.tss.triggers.rule;
/*   2:    */ 
/*   3:    */ import com.ibm.openpages.api.resource.IGRCObject;
/*   4:    */ import com.ibm.openpages.api.resource.IResource;
/*   5:    */ import com.ibm.openpages.api.trigger.events.AssociateResourceEvent;
/*   6:    */ import com.ibm.openpages.api.trigger.events.CopyResourceEvent;
/*   7:    */ import com.ibm.openpages.api.trigger.events.CreateResourceEvent;
/*   8:    */ import com.ibm.openpages.api.trigger.events.DeleteResourceEvent;
/*   9:    */ import com.ibm.openpages.api.trigger.events.DisassociateResourceEvent;
/*  10:    */ import com.ibm.openpages.api.trigger.events.QueryEvent;
/*  11:    */ import com.ibm.openpages.api.trigger.events.SearchEvent;
/*  12:    */ import com.ibm.openpages.api.trigger.events.UpdateResourceEvent;
/*  13:    */ import com.ibm.openpages.ext.tss.service.IGRCObjectUtil;
/*  14:    */ import com.ibm.openpages.ext.tss.service.util.CommonUtil;
/*  15:    */ import org.apache.commons.logging.Log;
/*  16:    */ 
/*  17:    */ public class ContentTypeMatchRule
/*  18:    */   extends ContentTypeMatchBaseRule
/*  19:    */ {
/*  20:    */   public boolean isApplicable(CreateResourceEvent createResourceEvent)
/*  21:    */   {
/*  22: 64 */     boolean isApplicable = false;
/*  23: 65 */     IResource resource = null;
/*  24: 68 */     if (super.isApplicable(createResourceEvent))
/*  25:    */     {
/*  26: 70 */       this.logger.debug("isApplicable(CreateResourceEvent)Start");
/*  27:    */       try
/*  28:    */       {
/*  29: 74 */         prepareContextForTrigger(createResourceEvent);
/*  30: 76 */         if (isRunTrigger())
/*  31:    */         {
/*  32: 78 */           resource = createResourceEvent.getResource();
/*  33: 79 */           isApplicable = resource.isFolder() ? false : evaluate((IGRCObject)resource);
/*  34:    */         }
/*  35:    */       }
/*  36:    */       catch (Exception ex)
/*  37:    */       {
/*  38: 83 */         this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(CreateResourceEvent)" + CommonUtil.getStackTrace(ex));
/*  39: 84 */         isApplicable = false;
/*  40:    */       }
/*  41: 87 */       this.logger.debug("Is Applicable: " + isApplicable);
/*  42: 88 */       this.logger.debug("isApplicable(CreateResourceEvent)End");
/*  43:    */     }
/*  44: 91 */     return isApplicable;
/*  45:    */   }
/*  46:    */   
/*  47:    */   public boolean isApplicable(UpdateResourceEvent updateResourceEvent)
/*  48:    */   {
/*  49:108 */     boolean isApplicable = false;
/*  50:109 */     IResource resource = null;
/*  51:112 */     if (super.isApplicable(updateResourceEvent))
/*  52:    */     {
/*  53:114 */       this.logger.debug("isApplicable(UpdateResourceEvent)Start");
/*  54:    */       try
/*  55:    */       {
/*  56:118 */         prepareContextForTrigger(updateResourceEvent);
/*  57:121 */         if (isRunTrigger())
/*  58:    */         {
/*  59:123 */           resource = updateResourceEvent.getResource();
/*  60:124 */           isApplicable = resource.isFolder() ? false : evaluate((IGRCObject)resource);
/*  61:    */         }
/*  62:    */       }
/*  63:    */       catch (Exception ex)
/*  64:    */       {
/*  65:128 */         this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(UpdateResourceEvent)" + CommonUtil.getStackTrace(ex));
/*  66:129 */         isApplicable = false;
/*  67:    */       }
/*  68:132 */       this.logger.debug("Is Applicable: " + isApplicable);
/*  69:133 */       this.logger.debug("isApplicable(UpdateResourceEvent)End");
/*  70:    */     }
/*  71:136 */     return isApplicable;
/*  72:    */   }
/*  73:    */   
/*  74:    */   public boolean isApplicable(AssociateResourceEvent associateResourceEvent)
/*  75:    */   {
/*  76:153 */     boolean isApplicable = false;
/*  77:154 */     String checkOn = "";
/*  78:155 */     IResource resource = null;
/*  79:158 */     if (super.isApplicable(associateResourceEvent))
/*  80:    */     {
/*  81:160 */       this.logger.debug("isApplicable(AssociateResourceEvent)Start");
/*  82:    */       try
/*  83:    */       {
/*  84:163 */         prepareContextForTrigger(associateResourceEvent);
/*  85:166 */         if (isRunTrigger())
/*  86:    */         {
/*  87:168 */           initGRCObjectUtilServices();
/*  88:169 */           contentTypeValidationForAssociate();
/*  89:170 */           checkOn = getTriggerAttrbuteValue("check.on");
/*  90:    */           
/*  91:172 */           this.logger.debug("Check On: " + checkOn);
/*  92:174 */           if (CommonUtil.isEqualIgnoreCase(checkOn, "child")) {
/*  93:175 */             resource = this.grcObjectUtil.getObjectFromId(associateResourceEvent.getChild());
/*  94:176 */           } else if (CommonUtil.isEqualIgnoreCase(checkOn, "parent")) {
/*  95:177 */             resource = this.grcObjectUtil.getObjectFromId(associateResourceEvent.getParent());
/*  96:    */           }
/*  97:179 */           this.logger.debug("Is Object Not null: " + CommonUtil.isObjectNotNull(resource));
/*  98:180 */           this.logger.debug("Is Object a Folder" + (CommonUtil.isObjectNotNull(resource) ? Boolean.valueOf(resource.isFolder()) : "Null"));
/*  99:181 */           this.logger.debug("Object name: " + (CommonUtil.isObjectNotNull(resource) ? resource.getName() : "Null"));
/* 100:183 */           if (CommonUtil.isObjectNotNull(resource)) {
/* 101:184 */             isApplicable = resource.isFolder() ? false : evaluate((IGRCObject)resource);
/* 102:    */           }
/* 103:    */         }
/* 104:    */       }
/* 105:    */       catch (Exception ex)
/* 106:    */       {
/* 107:188 */         this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(AssociateResourceEvent)" + CommonUtil.getStackTrace(ex));
/* 108:189 */         isApplicable = false;
/* 109:    */       }
/* 110:192 */       this.logger.debug("Is Applicable: " + isApplicable);
/* 111:193 */       this.logger.debug("isApplicable(AssociateResourceEvent)End");
/* 112:    */     }
/* 113:197 */     return isApplicable;
/* 114:    */   }
/* 115:    */   
/* 116:    */   public boolean isApplicable(DisassociateResourceEvent disassociateResourceEvent)
/* 117:    */   {
/* 118:213 */     boolean isApplicable = false;
/* 119:214 */     String checkOn = "";
/* 120:215 */     IResource resource = null;
/* 121:218 */     if (super.isApplicable(disassociateResourceEvent))
/* 122:    */     {
/* 123:220 */       this.logger.debug("isApplicable(DisassociateResourceEvent)Start");
/* 124:    */       try
/* 125:    */       {
/* 126:224 */         prepareContextForTrigger(disassociateResourceEvent);
/* 127:227 */         if (isRunTrigger())
/* 128:    */         {
/* 129:229 */           initGRCObjectUtilServices();
/* 130:230 */           contentTypeValidationForAssociate();
/* 131:231 */           checkOn = getTriggerAttrbuteValue("check.on");
/* 132:    */           
/* 133:233 */           this.logger.debug("Check On: " + checkOn);
/* 134:235 */           if (CommonUtil.isEqualIgnoreCase(checkOn, "child")) {
/* 135:236 */             resource = this.grcObjectUtil.getObjectFromId(disassociateResourceEvent.getChild());
/* 136:237 */           } else if (CommonUtil.isEqualIgnoreCase(checkOn, "parent")) {
/* 137:238 */             resource = this.grcObjectUtil.getObjectFromId(disassociateResourceEvent.getParent());
/* 138:    */           }
/* 139:240 */           this.logger.debug("Is Object Not null: " + CommonUtil.isObjectNotNull(resource));
/* 140:241 */           this.logger.debug("Is Object a Folder" + (CommonUtil.isObjectNotNull(resource) ? Boolean.valueOf(resource.isFolder()) : "Null"));
/* 141:242 */           this.logger.debug("Object name: " + (CommonUtil.isObjectNotNull(resource) ? resource.getName() : "Null"));
/* 142:244 */           if (CommonUtil.isObjectNotNull(resource)) {
/* 143:245 */             isApplicable = resource.isFolder() ? false : evaluate((IGRCObject)resource);
/* 144:    */           }
/* 145:    */         }
/* 146:    */       }
/* 147:    */       catch (Exception ex)
/* 148:    */       {
/* 149:249 */         this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(DisassociateResourceEvent)" + CommonUtil.getStackTrace(ex));
/* 150:250 */         isApplicable = false;
/* 151:    */       }
/* 152:253 */       this.logger.debug("Is Applicable: " + isApplicable);
/* 153:254 */       this.logger.debug("isApplicable(DisassociateResourceEvent)End");
/* 154:    */     }
/* 155:256 */     return isApplicable;
/* 156:    */   }
/* 157:    */   
/* 158:    */   public boolean isApplicable(CopyResourceEvent copyResourceEvent)
/* 159:    */   {
/* 160:272 */     boolean isApplicable = false;
/* 161:273 */     String checkOn = "";
/* 162:274 */     IResource resource = null;
/* 163:277 */     if (super.isApplicable(copyResourceEvent))
/* 164:    */     {
/* 165:279 */       this.logger.debug("isApplicable(CopyResourceEvent)Start");
/* 166:    */       try
/* 167:    */       {
/* 168:283 */         prepareContextForTrigger(copyResourceEvent);
/* 169:286 */         if (isRunTrigger())
/* 170:    */         {
/* 171:288 */           initGRCObjectUtilServices();
/* 172:289 */           contentTypeValidationForAssociate();
/* 173:290 */           checkOn = getTriggerAttrbuteValue("check.on");
/* 174:    */           
/* 175:292 */           this.logger.debug("Check On: " + checkOn);
/* 176:294 */           if (CommonUtil.isEqualIgnoreCase(checkOn, "source")) {
/* 177:295 */             resource = this.grcObjectUtil.getObjectFromId(copyResourceEvent.getSourceResouceId());
/* 178:296 */           } else if (CommonUtil.isEqualIgnoreCase(checkOn, "target")) {
/* 179:297 */             resource = this.grcObjectUtil.getObjectFromId(copyResourceEvent.getTargetResourceId());
/* 180:    */           }
/* 181:299 */           if (CommonUtil.isObjectNotNull(resource)) {
/* 182:300 */             isApplicable = resource.isFolder() ? false : evaluate((IGRCObject)resource);
/* 183:    */           }
/* 184:    */         }
/* 185:    */       }
/* 186:    */       catch (Exception ex)
/* 187:    */       {
/* 188:304 */         this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(CopyResourceEvent)" + CommonUtil.getStackTrace(ex));
/* 189:305 */         isApplicable = false;
/* 190:    */       }
/* 191:308 */       this.logger.debug("Is Applicable: " + isApplicable);
/* 192:309 */       this.logger.debug("isApplicable(CopyResourceEvent)End");
/* 193:    */     }
/* 194:312 */     return isApplicable;
/* 195:    */   }
/* 196:    */   
/* 197:    */   public boolean isApplicable(DeleteResourceEvent deleteResourceEvent)
/* 198:    */   {
/* 199:328 */     boolean isApplicable = false;
/* 200:329 */     IResource resource = null;
/* 201:334 */     if (super.isApplicable(deleteResourceEvent))
/* 202:    */     {
/* 203:336 */       this.logger.debug("isApplicable(DeleteResourceEvent)Start");
/* 204:    */       try
/* 205:    */       {
/* 206:340 */         prepareContextForTrigger(deleteResourceEvent);
/* 207:343 */         if (isRunTrigger())
/* 208:    */         {
/* 209:345 */           initGRCObjectUtilServices();
/* 210:346 */           resource = this.grcObjectUtil.getObjectFromId(deleteResourceEvent.getResourceId());
/* 211:347 */           isApplicable = resource.isFolder() ? false : evaluate((IGRCObject)resource);
/* 212:    */         }
/* 213:    */       }
/* 214:    */       catch (Exception ex)
/* 215:    */       {
/* 216:351 */         this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(DeleteResourceEvent)" + CommonUtil.getStackTrace(ex));
/* 217:352 */         isApplicable = false;
/* 218:    */       }
/* 219:355 */       this.logger.debug("Is Applicable: " + isApplicable);
/* 220:356 */       this.logger.debug("isApplicable(DeleteResourceEvent)End");
/* 221:    */     }
/* 222:359 */     return isApplicable;
/* 223:    */   }
/* 224:    */   
/* 225:    */   public boolean isApplicable(QueryEvent queryEvent)
/* 226:    */   {
/* 227:374 */     this.logger.debug("isApplicable(QueryEvent)Start");
/* 228:    */     
/* 229:    */ 
/* 230:377 */     boolean isApplicable = false;
/* 231:    */     try
/* 232:    */     {
/* 233:382 */       prepareContextForTrigger(queryEvent);
/* 234:385 */       if (isRunTrigger()) {
/* 235:387 */         isApplicable = super.isApplicable(queryEvent);
/* 236:    */       }
/* 237:    */     }
/* 238:    */     catch (Exception ex)
/* 239:    */     {
/* 240:391 */       this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(QueryEvent)" + CommonUtil.getStackTrace(ex));
/* 241:392 */       isApplicable = false;
/* 242:    */     }
/* 243:395 */     this.logger.debug("Is Applicable: " + isApplicable);
/* 244:396 */     this.logger.debug("isApplicable(QueryEvent)End");
/* 245:397 */     return isApplicable;
/* 246:    */   }
/* 247:    */   
/* 248:    */   public boolean isApplicable(SearchEvent searchEvent)
/* 249:    */   {
/* 250:412 */     this.logger.debug("isApplicable(SearchEvent)Start");
/* 251:    */     
/* 252:    */ 
/* 253:415 */     boolean isApplicable = false;
/* 254:    */     try
/* 255:    */     {
/* 256:421 */       if (isRunTrigger()) {
/* 257:423 */         isApplicable = super.isApplicable(searchEvent);
/* 258:    */       }
/* 259:    */     }
/* 260:    */     catch (Exception ex)
/* 261:    */     {
/* 262:427 */       this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(SearchEvent)" + CommonUtil.getStackTrace(ex));
/* 263:428 */       isApplicable = false;
/* 264:    */     }
/* 265:431 */     this.logger.debug("Is Applicable: " + isApplicable);
/* 266:432 */     this.logger.debug("isApplicable(SearchEvent)End");
/* 267:433 */     return isApplicable;
/* 268:    */   }
/* 269:    */   
/* 270:    */   private boolean evaluate(IGRCObject object)
/* 271:    */     throws Exception
/* 272:    */   {
/* 273:447 */     this.logger.debug("evaluate()Start");
/* 274:    */     
/* 275:    */ 
/* 276:450 */     boolean isApplicable = false;
/* 277:    */     
/* 278:    */ 
/* 279:453 */     contentTypeValidation();
/* 280:454 */     isApplicable = contentTypeMatch(object);
/* 281:    */     
/* 282:456 */     this.logger.debug("Is Applicable: " + isApplicable);
/* 283:457 */     this.logger.debug("evaluate()End");
/* 284:458 */     return isApplicable;
/* 285:    */   }
/* 286:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.triggers.rule.ContentTypeMatchRule
 * JD-Core Version:    0.7.0.1
 */