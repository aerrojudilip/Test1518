/*   1:    */ package com.ibm.openpages.ext.tss.triggers.rule;
/*   2:    */ 
/*   3:    */ import com.ibm.openpages.api.metadata.ITypeDefinition;
/*   4:    */ import com.ibm.openpages.api.resource.IGRCObject;
/*   5:    */ import com.ibm.openpages.api.resource.IResource;
/*   6:    */ import com.ibm.openpages.api.trigger.TriggerPositionType;
/*   7:    */ import com.ibm.openpages.api.trigger.events.AbstractEvent;
/*   8:    */ import com.ibm.openpages.api.trigger.events.AssociateResourceEvent;
/*   9:    */ import com.ibm.openpages.api.trigger.events.CopyResourceEvent;
/*  10:    */ import com.ibm.openpages.api.trigger.events.CreateResourceEvent;
/*  11:    */ import com.ibm.openpages.api.trigger.events.DeleteResourceEvent;
/*  12:    */ import com.ibm.openpages.api.trigger.events.DisassociateResourceEvent;
/*  13:    */ import com.ibm.openpages.api.trigger.events.QueryEvent;
/*  14:    */ import com.ibm.openpages.api.trigger.events.SearchEvent;
/*  15:    */ import com.ibm.openpages.api.trigger.events.TriggerEventType;
/*  16:    */ import com.ibm.openpages.api.trigger.events.UpdateResourceEvent;
/*  17:    */ import com.ibm.openpages.ext.tss.service.IFieldUtil;
/*  18:    */ import com.ibm.openpages.ext.tss.service.IGRCTriggerUtil;
/*  19:    */ import com.ibm.openpages.ext.tss.service.beans.FieldValueChangeForSetTriggerAttributesInfo;
/*  20:    */ import com.ibm.openpages.ext.tss.service.constants.CheckFor;
/*  21:    */ import com.ibm.openpages.ext.tss.service.util.CommonUtil;
/*  22:    */ import org.apache.commons.logging.Log;
/*  23:    */ 
/*  24:    */ public class DetectPropertyChangeAndSetInTriggerAttributesRule
/*  25:    */   extends DetectPropertyChangeBaseRule
/*  26:    */ {
/*  27:    */   public boolean isApplicable(CreateResourceEvent createResourceEvent)
/*  28:    */   {
/*  29: 70 */     this.logger.debug("isApplicable(CreateResourceEvent)Start");
/*  30:    */     
/*  31:    */ 
/*  32: 73 */     boolean isApplicable = false;
/*  33: 74 */     IResource resource = null;
/*  34:    */     try
/*  35:    */     {
/*  36: 79 */       prepareContextForTrigger(createResourceEvent);
/*  37: 81 */       if (isRunTrigger())
/*  38:    */       {
/*  39: 83 */         resource = createResourceEvent.getResource();
/*  40: 89 */         if (super.isApplicable(createResourceEvent)) {
/*  41: 91 */           isApplicable = resource.isFolder() ? false : evaluate((IGRCObject)resource, createResourceEvent);
/*  42:    */         }
/*  43:    */       }
/*  44:    */     }
/*  45:    */     catch (Exception ex)
/*  46:    */     {
/*  47: 96 */       this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(CreateResourceEvent)" + CommonUtil.getStackTrace(ex));
/*  48: 97 */       isApplicable = false;
/*  49:    */     }
/*  50:100 */     this.logger.debug("Is trigger Applicable: " + isApplicable);
/*  51:101 */     this.logger.debug("isApplicable(CreateResourceEvent)End");
/*  52:102 */     return isApplicable;
/*  53:    */   }
/*  54:    */   
/*  55:    */   public boolean isApplicable(UpdateResourceEvent updateResourceEvent)
/*  56:    */   {
/*  57:119 */     this.logger.debug("isApplicable(UpdateResourceEvent)Start");
/*  58:    */     
/*  59:    */ 
/*  60:122 */     boolean isApplicable = false;
/*  61:123 */     IResource resource = null;
/*  62:    */     try
/*  63:    */     {
/*  64:128 */       prepareContextForTrigger(updateResourceEvent);
/*  65:130 */       if (isRunTrigger())
/*  66:    */       {
/*  67:132 */         resource = updateResourceEvent.getResource();
/*  68:    */         
/*  69:134 */         this.logger.debug("Trigger Event Type" + updateResourceEvent.getTriggerEventType().getName());
/*  70:135 */         this.logger.debug("Trigger Position" + updateResourceEvent.getPosition().getPosition());
/*  71:141 */         if (super.isApplicable(updateResourceEvent)) {
/*  72:143 */           isApplicable = resource.isFolder() ? false : evaluate((IGRCObject)resource, updateResourceEvent);
/*  73:    */         }
/*  74:    */       }
/*  75:    */     }
/*  76:    */     catch (Exception ex)
/*  77:    */     {
/*  78:148 */       this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(UpdateResourceEvent)" + CommonUtil.getStackTrace(ex));
/*  79:149 */       isApplicable = false;
/*  80:    */     }
/*  81:152 */     this.logger.debug("Is trigger Applicable: " + isApplicable);
/*  82:153 */     this.logger.debug("isApplicable(UpdateResourceEvent)End");
/*  83:154 */     return isApplicable;
/*  84:    */   }
/*  85:    */   
/*  86:    */   public boolean isApplicable(AssociateResourceEvent associateResourceEvent)
/*  87:    */   {
/*  88:169 */     this.logger.debug("isApplicable(AssociateResourceEvent)Start");
/*  89:    */     
/*  90:    */ 
/*  91:172 */     boolean isApplicable = false;
/*  92:    */     try
/*  93:    */     {
/*  94:177 */       prepareContextForTrigger(associateResourceEvent);
/*  95:180 */       if (isRunTrigger()) {
/*  96:182 */         isApplicable = super.isApplicable(associateResourceEvent);
/*  97:    */       }
/*  98:    */     }
/*  99:    */     catch (Exception ex)
/* 100:    */     {
/* 101:186 */       this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(AssociateResourceEvent)" + CommonUtil.getStackTrace(ex));
/* 102:187 */       isApplicable = false;
/* 103:    */     }
/* 104:190 */     this.logger.debug("Is Applicable: " + isApplicable);
/* 105:191 */     this.logger.debug("isApplicable(AssociateResourceEvent)End");
/* 106:192 */     return isApplicable;
/* 107:    */   }
/* 108:    */   
/* 109:    */   public boolean isApplicable(DisassociateResourceEvent disassociateResourceEvent)
/* 110:    */   {
/* 111:207 */     this.logger.debug("isApplicable(DisassociateResourceEvent)Start");
/* 112:    */     
/* 113:    */ 
/* 114:210 */     boolean isApplicable = false;
/* 115:    */     try
/* 116:    */     {
/* 117:215 */       prepareContextForTrigger(disassociateResourceEvent);
/* 118:218 */       if (isRunTrigger()) {
/* 119:220 */         isApplicable = super.isApplicable(disassociateResourceEvent);
/* 120:    */       }
/* 121:    */     }
/* 122:    */     catch (Exception ex)
/* 123:    */     {
/* 124:224 */       this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(DisassociateResourceEvent)" + CommonUtil.getStackTrace(ex));
/* 125:225 */       isApplicable = false;
/* 126:    */     }
/* 127:228 */     this.logger.debug("Is Applicable: " + isApplicable);
/* 128:229 */     this.logger.debug("isApplicable(DisassociateResourceEvent)End");
/* 129:230 */     return isApplicable;
/* 130:    */   }
/* 131:    */   
/* 132:    */   public boolean isApplicable(CopyResourceEvent copyResourceEvent)
/* 133:    */   {
/* 134:245 */     this.logger.debug("isApplicable(CopyResourceEvent)Start");
/* 135:    */     
/* 136:    */ 
/* 137:248 */     boolean isApplicable = false;
/* 138:    */     try
/* 139:    */     {
/* 140:253 */       prepareContextForTrigger(copyResourceEvent);
/* 141:256 */       if (isRunTrigger()) {
/* 142:258 */         isApplicable = super.isApplicable(copyResourceEvent);
/* 143:    */       }
/* 144:    */     }
/* 145:    */     catch (Exception ex)
/* 146:    */     {
/* 147:262 */       this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(CopyResourceEvent)" + CommonUtil.getStackTrace(ex));
/* 148:263 */       isApplicable = false;
/* 149:    */     }
/* 150:266 */     this.logger.debug("Is Applicable: " + isApplicable);
/* 151:267 */     this.logger.debug("isApplicable(CopyResourceEvent)End");
/* 152:268 */     return isApplicable;
/* 153:    */   }
/* 154:    */   
/* 155:    */   public boolean isApplicable(DeleteResourceEvent deleteResourceEvent)
/* 156:    */   {
/* 157:283 */     this.logger.debug("isApplicable(DeleteResourceEvent)Start");
/* 158:    */     
/* 159:    */ 
/* 160:286 */     boolean isApplicable = false;
/* 161:    */     try
/* 162:    */     {
/* 163:291 */       prepareContextForTrigger(deleteResourceEvent);
/* 164:294 */       if (isRunTrigger()) {
/* 165:296 */         isApplicable = super.isApplicable(deleteResourceEvent);
/* 166:    */       }
/* 167:    */     }
/* 168:    */     catch (Exception ex)
/* 169:    */     {
/* 170:300 */       this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(DeleteResourceEvent)" + CommonUtil.getStackTrace(ex));
/* 171:301 */       isApplicable = false;
/* 172:    */     }
/* 173:304 */     this.logger.debug("Is Applicable: " + isApplicable);
/* 174:305 */     this.logger.debug("isApplicable(DeleteResourceEvent)End");
/* 175:306 */     return isApplicable;
/* 176:    */   }
/* 177:    */   
/* 178:    */   public boolean isApplicable(QueryEvent queryEvent)
/* 179:    */   {
/* 180:321 */     this.logger.debug("isApplicable(QueryEvent)Start");
/* 181:    */     
/* 182:    */ 
/* 183:324 */     boolean isApplicable = false;
/* 184:    */     try
/* 185:    */     {
/* 186:329 */       prepareContextForTrigger(queryEvent);
/* 187:332 */       if (isRunTrigger()) {
/* 188:334 */         isApplicable = super.isApplicable(queryEvent);
/* 189:    */       }
/* 190:    */     }
/* 191:    */     catch (Exception ex)
/* 192:    */     {
/* 193:338 */       this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(QueryEvent)" + CommonUtil.getStackTrace(ex));
/* 194:339 */       isApplicable = false;
/* 195:    */     }
/* 196:342 */     this.logger.debug("Is Applicable: " + isApplicable);
/* 197:343 */     this.logger.debug("isApplicable(QueryEvent)End");
/* 198:344 */     return isApplicable;
/* 199:    */   }
/* 200:    */   
/* 201:    */   public boolean isApplicable(SearchEvent searchEvent)
/* 202:    */   {
/* 203:359 */     this.logger.debug("isApplicable(SearchEvent)Start");
/* 204:    */     
/* 205:    */ 
/* 206:362 */     boolean isApplicable = false;
/* 207:    */     try
/* 208:    */     {
/* 209:367 */       prepareContextForTrigger(searchEvent);
/* 210:370 */       if (isRunTrigger()) {
/* 211:372 */         isApplicable = super.isApplicable(searchEvent);
/* 212:    */       }
/* 213:    */     }
/* 214:    */     catch (Exception ex)
/* 215:    */     {
/* 216:376 */       this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(SearchEvent)" + CommonUtil.getStackTrace(ex));
/* 217:377 */       isApplicable = false;
/* 218:    */     }
/* 219:380 */     this.logger.debug("Is Applicable: " + isApplicable);
/* 220:381 */     this.logger.debug("isApplicable(SearchEvent)End");
/* 221:382 */     return isApplicable;
/* 222:    */   }
/* 223:    */   
/* 224:    */   private boolean evaluate(IGRCObject object, AbstractEvent event)
/* 225:    */     throws Exception
/* 226:    */   {
/* 227:399 */     this.logger.debug("evaluate()Start");
/* 228:    */     
/* 229:    */ 
/* 230:402 */     boolean isApplicable = false;
/* 231:    */     
/* 232:404 */     String fields = "";
/* 233:405 */     String contentType = "";
/* 234:406 */     CheckFor checkFor = null;
/* 235:    */     
/* 236:408 */     FieldValueChangeForSetTriggerAttributesInfo detectPropertyChangeInfoDTO = null;
/* 237:    */     
/* 238:    */ 
/* 239:    */ 
/* 240:412 */     initFieldUtilServices();
/* 241:413 */     detectPropertyChangeInfoDTO = new FieldValueChangeForSetTriggerAttributesInfo();
/* 242:414 */     fields = getTriggerAttrbuteValue("field.names.to.check");
/* 243:415 */     checkFor = CommonUtil.getCheckFor(getTriggerAttrbuteValue("check.for.all.or.any"));
/* 244:416 */     contentType = getTriggerAttrbuteValue("content.type.name");
/* 245:    */     
/* 246:    */ 
/* 247:419 */     this.logger.debug("Content Type for check: " + contentType);
/* 248:420 */     this.logger.debug("Content Type in the current Event: " + object.getType().getName());
/* 249:421 */     this.logger.debug("Is Content Type same as required Content Type: " + CommonUtil.isEqualIgnoreCase(object.getType().getName(), contentType));
/* 250:    */     
/* 251:    */ 
/* 252:424 */     this.logger.debug("Fields that needs to be checked: " + fields);
/* 253:425 */     this.logger.debug("Check For: " + getTriggerAttrbuteValue("check.for.all.or.any"));
/* 254:    */     
/* 255:427 */     detectPropertyChangeInfoDTO.setFields(fields);
/* 256:428 */     detectPropertyChangeInfoDTO.setCheckFor(checkFor);
/* 257:429 */     detectPropertyChangeInfoDTO.setModifiedFields(this.fieldUtil.getModifiedFields(object));
/* 258:430 */     detectPropertyChangeInfoDTO = this.grcTriggerUtil.populateTriggerSetAttributesP(event, detectPropertyChangeInfoDTO, getAttributes());
/* 259:    */     
/* 260:432 */     this.logger.debug("Detect Property Change Info DTO: " + detectPropertyChangeInfoDTO.toString());
/* 261:    */     
/* 262:434 */     detectPropertyChangeValidation(detectPropertyChangeInfoDTO);
/* 263:435 */     isApplicable = detectPropertyChangeAndSetModifiedFieldsInTriggerAttributes(detectPropertyChangeInfoDTO);
/* 264:    */     
/* 265:437 */     this.logger.debug("Is Applicable: " + isApplicable);
/* 266:438 */     return isApplicable;
/* 267:    */   }
/* 268:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.triggers.rule.DetectPropertyChangeAndSetInTriggerAttributesRule
 * JD-Core Version:    0.7.0.1
 */