/*   1:    */ package com.ibm.openpages.ext.tss.triggers.rule;
/*   2:    */ 
/*   3:    */ import com.ibm.openpages.api.resource.IResource;
/*   4:    */ import com.ibm.openpages.api.trigger.events.AssociateResourceEvent;
/*   5:    */ import com.ibm.openpages.api.trigger.events.CopyResourceEvent;
/*   6:    */ import com.ibm.openpages.api.trigger.events.CreateResourceEvent;
/*   7:    */ import com.ibm.openpages.api.trigger.events.DeleteResourceEvent;
/*   8:    */ import com.ibm.openpages.api.trigger.events.DisassociateResourceEvent;
/*   9:    */ import com.ibm.openpages.api.trigger.events.QueryEvent;
/*  10:    */ import com.ibm.openpages.api.trigger.events.SearchEvent;
/*  11:    */ import com.ibm.openpages.api.trigger.events.UpdateResourceEvent;
/*  12:    */ import com.ibm.openpages.ext.tss.service.IGRCObjectUtil;
/*  13:    */ import com.ibm.openpages.ext.tss.service.util.CommonUtil;
/*  14:    */ import org.apache.commons.logging.Log;
/*  15:    */ 
/*  16:    */ public class ExecuteAllContentTypeRule
/*  17:    */   extends ContentTypeMatchBaseRule
/*  18:    */ {
/*  19:    */   public boolean isApplicable(CreateResourceEvent createResourceEvent)
/*  20:    */   {
/*  21: 38 */     boolean isApplicable = false;
/*  22: 39 */     IResource resource = null;
/*  23: 42 */     if (super.isApplicable(createResourceEvent))
/*  24:    */     {
/*  25: 44 */       this.logger.debug("isApplicable(CreateResourceEvent)Start");
/*  26:    */       try
/*  27:    */       {
/*  28: 48 */         prepareContextForTrigger(createResourceEvent);
/*  29: 51 */         if (isRunTrigger())
/*  30:    */         {
/*  31: 53 */           resource = createResourceEvent.getResource();
/*  32: 54 */           isApplicable = !resource.isFolder();
/*  33:    */         }
/*  34:    */       }
/*  35:    */       catch (Exception ex)
/*  36:    */       {
/*  37: 58 */         this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(CreateResourceEvent)" + CommonUtil.getStackTrace(ex));
/*  38: 59 */         isApplicable = false;
/*  39:    */       }
/*  40: 62 */       this.logger.debug("Is Applicable: " + isApplicable);
/*  41: 63 */       this.logger.debug("isApplicable(CreateResourceEvent)End");
/*  42:    */     }
/*  43: 66 */     return isApplicable;
/*  44:    */   }
/*  45:    */   
/*  46:    */   public boolean isApplicable(UpdateResourceEvent updateResourceEvent)
/*  47:    */   {
/*  48: 83 */     boolean isApplicable = false;
/*  49: 84 */     IResource resource = null;
/*  50: 87 */     if (super.isApplicable(updateResourceEvent))
/*  51:    */     {
/*  52: 89 */       this.logger.debug("isApplicable(UpdateResourceEvent)Start");
/*  53:    */       try
/*  54:    */       {
/*  55: 94 */         if (isRunTrigger())
/*  56:    */         {
/*  57: 96 */           prepareContextForTrigger(updateResourceEvent);
/*  58:    */           
/*  59: 98 */           resource = updateResourceEvent.getResource();
/*  60: 99 */           isApplicable = !resource.isFolder();
/*  61:    */         }
/*  62:    */       }
/*  63:    */       catch (Exception ex)
/*  64:    */       {
/*  65:103 */         this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(UpdateResourceEvent)" + CommonUtil.getStackTrace(ex));
/*  66:104 */         isApplicable = false;
/*  67:    */       }
/*  68:107 */       this.logger.debug("Is Applicable: " + isApplicable);
/*  69:108 */       this.logger.debug("isApplicable(UpdateResourceEvent)End");
/*  70:    */     }
/*  71:111 */     return isApplicable;
/*  72:    */   }
/*  73:    */   
/*  74:    */   public boolean isApplicable(AssociateResourceEvent associateReourceEvent)
/*  75:    */   {
/*  76:128 */     boolean isApplicable = false;
/*  77:129 */     String checkOn = "";
/*  78:130 */     IResource resource = null;
/*  79:133 */     if (super.isApplicable(associateReourceEvent))
/*  80:    */     {
/*  81:135 */       this.logger.debug("isApplicable(AssociateResourceEvent)Start");
/*  82:    */       try
/*  83:    */       {
/*  84:139 */         prepareContextForTrigger(associateReourceEvent);
/*  85:142 */         if (isRunTrigger())
/*  86:    */         {
/*  87:144 */           initGRCObjectUtilServices();
/*  88:145 */           contentTypeValidationForAssociate();
/*  89:146 */           checkOn = getTriggerAttrbuteValue("check.on");
/*  90:    */           
/*  91:148 */           this.logger.debug("Check On: " + checkOn);
/*  92:150 */           if (CommonUtil.isEqualIgnoreCase(checkOn, "child")) {
/*  93:151 */             resource = this.grcObjectUtil.getObjectFromId(associateReourceEvent.getChild());
/*  94:152 */           } else if (CommonUtil.isEqualIgnoreCase(checkOn, "parent")) {
/*  95:153 */             resource = this.grcObjectUtil.getObjectFromId(associateReourceEvent.getParent());
/*  96:    */           }
/*  97:155 */           this.logger.debug("Is Object Not null: " + CommonUtil.isObjectNotNull(resource));
/*  98:156 */           this.logger.debug("Is Object a Folder" + (CommonUtil.isObjectNotNull(resource) ? Boolean.valueOf(resource.isFolder()) : "Null"));
/*  99:157 */           this.logger.debug("Object name: " + (CommonUtil.isObjectNotNull(resource) ? resource.getName() : "Null"));
/* 100:159 */           if (CommonUtil.isObjectNotNull(resource)) {
/* 101:160 */             isApplicable = !resource.isFolder();
/* 102:    */           }
/* 103:    */         }
/* 104:    */       }
/* 105:    */       catch (Exception ex)
/* 106:    */       {
/* 107:164 */         this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(AssociateResourceEvent)" + CommonUtil.getStackTrace(ex));
/* 108:165 */         isApplicable = false;
/* 109:    */       }
/* 110:168 */       this.logger.debug("Is Applicable: " + isApplicable);
/* 111:169 */       this.logger.debug("isApplicable(AssociateResourceEvent)End");
/* 112:    */     }
/* 113:172 */     return isApplicable;
/* 114:    */   }
/* 115:    */   
/* 116:    */   public boolean isApplicable(DisassociateResourceEvent disassociateResourceEvent)
/* 117:    */   {
/* 118:188 */     boolean isApplicable = false;
/* 119:191 */     if (super.isApplicable(disassociateResourceEvent))
/* 120:    */     {
/* 121:193 */       this.logger.debug("isApplicable(DisassociateResourceEvent)Start");
/* 122:    */       try
/* 123:    */       {
/* 124:197 */         prepareContextForTrigger(disassociateResourceEvent);
/* 125:200 */         if (isRunTrigger()) {
/* 126:202 */           isApplicable = true;
/* 127:    */         }
/* 128:    */       }
/* 129:    */       catch (Exception ex)
/* 130:    */       {
/* 131:206 */         this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(DisassociateResourceEvent)" + CommonUtil.getStackTrace(ex));
/* 132:207 */         isApplicable = false;
/* 133:    */       }
/* 134:210 */       this.logger.debug("Is Applicable: " + isApplicable);
/* 135:211 */       this.logger.debug("isApplicable(DisassociateResourceEvent)End");
/* 136:    */     }
/* 137:214 */     return isApplicable;
/* 138:    */   }
/* 139:    */   
/* 140:    */   public boolean isApplicable(CopyResourceEvent copyResourceEvent)
/* 141:    */   {
/* 142:230 */     boolean isApplicable = false;
/* 143:233 */     if (super.isApplicable(copyResourceEvent))
/* 144:    */     {
/* 145:235 */       this.logger.debug("isApplicable(CopyResourceEvent)Start");
/* 146:    */       try
/* 147:    */       {
/* 148:239 */         prepareContextForTrigger(copyResourceEvent);
/* 149:242 */         if (isRunTrigger()) {
/* 150:244 */           isApplicable = true;
/* 151:    */         }
/* 152:    */       }
/* 153:    */       catch (Exception ex)
/* 154:    */       {
/* 155:248 */         this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(CopyResourceEvent)" + CommonUtil.getStackTrace(ex));
/* 156:249 */         isApplicable = false;
/* 157:    */       }
/* 158:252 */       this.logger.debug("Is Applicable: " + isApplicable);
/* 159:253 */       this.logger.debug("isApplicable(CopyResourceEvent)End");
/* 160:    */     }
/* 161:256 */     return isApplicable;
/* 162:    */   }
/* 163:    */   
/* 164:    */   public boolean isApplicable(DeleteResourceEvent deleteResourceEvent)
/* 165:    */   {
/* 166:272 */     boolean isApplicable = false;
/* 167:275 */     if (super.isApplicable(deleteResourceEvent))
/* 168:    */     {
/* 169:277 */       this.logger.debug("isApplicable(DeleteResourceEvent)Start");
/* 170:    */       try
/* 171:    */       {
/* 172:281 */         prepareContextForTrigger(deleteResourceEvent);
/* 173:284 */         if (isRunTrigger()) {
/* 174:286 */           isApplicable = true;
/* 175:    */         }
/* 176:    */       }
/* 177:    */       catch (Exception ex)
/* 178:    */       {
/* 179:290 */         this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(DeleteResourceEvent)" + CommonUtil.getStackTrace(ex));
/* 180:291 */         isApplicable = false;
/* 181:    */       }
/* 182:294 */       this.logger.debug("Is Applicable: " + isApplicable);
/* 183:295 */       this.logger.debug("isApplicable(DeleteResourceEvent)End");
/* 184:    */     }
/* 185:298 */     return isApplicable;
/* 186:    */   }
/* 187:    */   
/* 188:    */   public boolean isApplicable(QueryEvent queryEvent)
/* 189:    */   {
/* 190:313 */     this.logger.debug("isApplicable(QueryEvent)Start");
/* 191:    */     
/* 192:    */ 
/* 193:316 */     boolean isApplicable = false;
/* 194:    */     try
/* 195:    */     {
/* 196:321 */       prepareContextForTrigger(queryEvent);
/* 197:324 */       if (isRunTrigger()) {
/* 198:326 */         isApplicable = true;
/* 199:    */       }
/* 200:    */     }
/* 201:    */     catch (Exception ex)
/* 202:    */     {
/* 203:330 */       this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(QueryEvent)" + CommonUtil.getStackTrace(ex));
/* 204:331 */       isApplicable = false;
/* 205:    */     }
/* 206:334 */     this.logger.debug("Is Applicable: " + isApplicable);
/* 207:335 */     this.logger.debug("isApplicable(QueryEvent)End");
/* 208:336 */     return isApplicable;
/* 209:    */   }
/* 210:    */   
/* 211:    */   public boolean isApplicable(SearchEvent searchEvent)
/* 212:    */   {
/* 213:351 */     this.logger.debug("isApplicable(SearchEvent)Start");
/* 214:    */     
/* 215:    */ 
/* 216:354 */     boolean isApplicable = false;
/* 217:    */     try
/* 218:    */     {
/* 219:359 */       prepareContextForTrigger(searchEvent);
/* 220:362 */       if (isRunTrigger()) {
/* 221:364 */         isApplicable = true;
/* 222:    */       }
/* 223:    */     }
/* 224:    */     catch (Exception ex)
/* 225:    */     {
/* 226:368 */       this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(SearchEvent)" + CommonUtil.getStackTrace(ex));
/* 227:369 */       isApplicable = false;
/* 228:    */     }
/* 229:372 */     this.logger.debug("Is Applicable: " + isApplicable);
/* 230:373 */     this.logger.debug("isApplicable(SearchEvent)End");
/* 231:374 */     return isApplicable;
/* 232:    */   }
/* 233:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.triggers.rule.ExecuteAllContentTypeRule
 * JD-Core Version:    0.7.0.1
 */