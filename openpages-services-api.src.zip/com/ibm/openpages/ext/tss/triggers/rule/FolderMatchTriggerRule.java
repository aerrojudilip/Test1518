/*   1:    */ package com.ibm.openpages.ext.tss.triggers.rule;
/*   2:    */ 
/*   3:    */ import com.ibm.openpages.api.Context;
/*   4:    */ import com.ibm.openpages.api.metadata.Id;
/*   5:    */ import com.ibm.openpages.api.resource.IFolder;
/*   6:    */ import com.ibm.openpages.api.resource.IGRCObject;
/*   7:    */ import com.ibm.openpages.api.resource.IResource;
/*   8:    */ import com.ibm.openpages.api.service.IResourceService;
/*   9:    */ import com.ibm.openpages.api.service.IServiceFactory;
/*  10:    */ import com.ibm.openpages.api.service.ServiceFactory;
/*  11:    */ import com.ibm.openpages.api.trigger.events.AssociateResourceEvent;
/*  12:    */ import com.ibm.openpages.api.trigger.events.CopyResourceEvent;
/*  13:    */ import com.ibm.openpages.api.trigger.events.CreateResourceEvent;
/*  14:    */ import com.ibm.openpages.api.trigger.events.DeleteResourceEvent;
/*  15:    */ import com.ibm.openpages.api.trigger.events.DisassociateResourceEvent;
/*  16:    */ import com.ibm.openpages.api.trigger.events.QueryEvent;
/*  17:    */ import com.ibm.openpages.api.trigger.events.SearchEvent;
/*  18:    */ import com.ibm.openpages.api.trigger.events.UpdateResourceEvent;
/*  19:    */ import com.ibm.openpages.ext.tss.service.util.CommonUtil;
/*  20:    */ import java.util.List;
/*  21:    */ import org.apache.commons.logging.Log;
/*  22:    */ 
/*  23:    */ public class FolderMatchTriggerRule
/*  24:    */   extends BaseTriggerRule
/*  25:    */ {
/*  26:    */   public boolean isApplicable(CreateResourceEvent createResourceEvent)
/*  27:    */   {
/*  28: 75 */     this.logger.debug("isApplicable(CreateResourceEvent)Start");
/*  29:    */     
/*  30:    */ 
/*  31: 78 */     boolean isApplicable = false;
/*  32: 79 */     IResource resource = null;
/*  33: 80 */     String scope = "";
/*  34: 81 */     String folderPath = "";
/*  35:    */     try
/*  36:    */     {
/*  37: 86 */       prepareContextForTrigger(createResourceEvent);
/*  38: 89 */       if (isRunTrigger())
/*  39:    */       {
/*  40: 91 */         scope = getTriggerAttrbuteValue("scope");
/*  41: 92 */         resource = createResourceEvent.getResource();
/*  42: 93 */         folderPath = getTriggerAttrbuteValue("folder.path");
/*  43:    */         
/*  44: 95 */         isApplicable = evaluate((IGRCObject)resource, folderPath, scope);
/*  45:    */       }
/*  46:    */     }
/*  47:    */     catch (Exception ex)
/*  48:    */     {
/*  49: 99 */       this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(CreateResourceEvent)" + CommonUtil.getStackTrace(ex));
/*  50:100 */       isApplicable = false;
/*  51:    */     }
/*  52:103 */     this.logger.debug("Is trigger Applicable: " + isApplicable);
/*  53:104 */     this.logger.debug("isApplicable(CreateResourceEvent)End");
/*  54:105 */     return isApplicable;
/*  55:    */   }
/*  56:    */   
/*  57:    */   public boolean isApplicable(UpdateResourceEvent updateResourceEvent)
/*  58:    */   {
/*  59:120 */     this.logger.debug("isApplicable(UpdateResourceEvent)Start");
/*  60:    */     
/*  61:    */ 
/*  62:123 */     boolean isApplicable = false;
/*  63:124 */     IResource resource = null;
/*  64:125 */     String scope = "";
/*  65:126 */     String folderPath = "";
/*  66:    */     try
/*  67:    */     {
/*  68:131 */       prepareContextForTrigger(updateResourceEvent);
/*  69:134 */       if (isRunTrigger())
/*  70:    */       {
/*  71:136 */         scope = getTriggerAttrbuteValue("scope");
/*  72:137 */         resource = updateResourceEvent.getResource();
/*  73:138 */         folderPath = getTriggerAttrbuteValue("folder.path");
/*  74:    */         
/*  75:140 */         isApplicable = evaluate((IGRCObject)resource, folderPath, scope);
/*  76:    */       }
/*  77:    */     }
/*  78:    */     catch (Exception ex)
/*  79:    */     {
/*  80:144 */       this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(UpdateResourceEvent)" + CommonUtil.getStackTrace(ex));
/*  81:145 */       isApplicable = false;
/*  82:    */     }
/*  83:148 */     this.logger.debug("Is trigger Applicable: " + isApplicable);
/*  84:149 */     this.logger.debug("isApplicable(UpdateResourceEvent)End");
/*  85:150 */     return isApplicable;
/*  86:    */   }
/*  87:    */   
/*  88:    */   public boolean isApplicable(AssociateResourceEvent associateResourceEvent)
/*  89:    */   {
/*  90:165 */     this.logger.debug("isApplicable(AssociateResourceEvent)Start");
/*  91:    */     
/*  92:    */ 
/*  93:168 */     boolean isApplicable = false;
/*  94:169 */     String scope = "";
/*  95:170 */     String checkOn = "";
/*  96:171 */     String folderPath = "";
/*  97:    */     
/*  98:173 */     Context context = null;
/*  99:174 */     List<Id> parents = null;
/* 100:175 */     List<Id> children = null;
/* 101:176 */     IServiceFactory serviceFactory = null;
/* 102:177 */     IResourceService resourceService = null;
/* 103:    */     try
/* 104:    */     {
/* 105:182 */       prepareContextForTrigger(associateResourceEvent);
/* 106:185 */       if (isRunTrigger())
/* 107:    */       {
/* 108:187 */         context = associateResourceEvent.getContext();
/* 109:188 */         serviceFactory = ServiceFactory.getServiceFactory(context);
/* 110:189 */         resourceService = serviceFactory.createResourceService();
/* 111:    */         
/* 112:191 */         folderPath = getTriggerAttrbuteValue("folder.path");
/* 113:192 */         scope = getTriggerAttrbuteValue("scope");
/* 114:193 */         checkOn = getTriggerAttrbuteValue("check.on");
/* 115:195 */         if ((CommonUtil.isNotNullOrEmpty(checkOn)) && (CommonUtil.isEqualIgnoreCase(checkOn, "parent")))
/* 116:    */         {
/* 117:197 */           parents = associateResourceEvent.getParents();
/* 118:199 */           for (Id parentId : parents)
/* 119:    */           {
/* 120:201 */             IGRCObject parentObject = resourceService.getGRCObject(parentId);
/* 121:    */             
/* 122:203 */             isApplicable = evaluate(parentObject, folderPath, scope);
/* 123:205 */             if (!isApplicable)
/* 124:    */             {
/* 125:206 */               isApplicable = false;
/* 126:207 */               break;
/* 127:    */             }
/* 128:    */           }
/* 129:    */         }
/* 130:210 */         else if ((CommonUtil.isNotNullOrEmpty(checkOn)) && (CommonUtil.isEqualIgnoreCase(checkOn, "child")))
/* 131:    */         {
/* 132:212 */           children = associateResourceEvent.getChildren();
/* 133:214 */           for (Id childId : children)
/* 134:    */           {
/* 135:216 */             IGRCObject childObject = resourceService.getGRCObject(childId);
/* 136:217 */             isApplicable = evaluate(childObject, folderPath, scope);
/* 137:219 */             if (!isApplicable)
/* 138:    */             {
/* 139:220 */               isApplicable = false;
/* 140:221 */               break;
/* 141:    */             }
/* 142:    */           }
/* 143:    */         }
/* 144:    */       }
/* 145:    */     }
/* 146:    */     catch (Exception ex)
/* 147:    */     {
/* 148:228 */       this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(AssociateResourceEvent)" + CommonUtil.getStackTrace(ex));
/* 149:229 */       isApplicable = false;
/* 150:    */     }
/* 151:232 */     return isApplicable;
/* 152:    */   }
/* 153:    */   
/* 154:    */   public boolean isApplicable(DisassociateResourceEvent disassociateResourceEvent)
/* 155:    */   {
/* 156:247 */     this.logger.debug("isApplicable(DisassociateResourceEvent)Start");
/* 157:    */     
/* 158:    */ 
/* 159:250 */     boolean isApplicable = false;
/* 160:251 */     String scope = "";
/* 161:252 */     String checkOn = "";
/* 162:253 */     String folderPath = "";
/* 163:    */     
/* 164:255 */     Context context = null;
/* 165:256 */     List<Id> parents = null;
/* 166:257 */     List<Id> children = null;
/* 167:258 */     IServiceFactory serviceFactory = null;
/* 168:259 */     IResourceService resourceService = null;
/* 169:    */     try
/* 170:    */     {
/* 171:264 */       prepareContextForTrigger(disassociateResourceEvent);
/* 172:267 */       if (isRunTrigger())
/* 173:    */       {
/* 174:269 */         context = disassociateResourceEvent.getContext();
/* 175:270 */         serviceFactory = ServiceFactory.getServiceFactory(context);
/* 176:271 */         resourceService = serviceFactory.createResourceService();
/* 177:    */         
/* 178:273 */         folderPath = getTriggerAttrbuteValue("folder.path");
/* 179:274 */         scope = getTriggerAttrbuteValue("scope");
/* 180:275 */         checkOn = getTriggerAttrbuteValue("check.on");
/* 181:277 */         if ((CommonUtil.isNotNullOrEmpty(checkOn)) && (CommonUtil.isEqualIgnoreCase(checkOn, "parent")))
/* 182:    */         {
/* 183:279 */           parents = disassociateResourceEvent.getParents();
/* 184:281 */           for (Id parentId : parents)
/* 185:    */           {
/* 186:283 */             IGRCObject parentObject = resourceService.getGRCObject(parentId);
/* 187:    */             
/* 188:285 */             isApplicable = evaluate(parentObject, folderPath, scope);
/* 189:287 */             if (!isApplicable)
/* 190:    */             {
/* 191:288 */               isApplicable = false;
/* 192:289 */               break;
/* 193:    */             }
/* 194:    */           }
/* 195:    */         }
/* 196:292 */         else if ((CommonUtil.isNotNullOrEmpty(checkOn)) && (CommonUtil.isEqualIgnoreCase(checkOn, "child")))
/* 197:    */         {
/* 198:294 */           children = disassociateResourceEvent.getChildren();
/* 199:296 */           for (Id childId : children)
/* 200:    */           {
/* 201:298 */             IGRCObject childObject = resourceService.getGRCObject(childId);
/* 202:299 */             isApplicable = evaluate(childObject, folderPath, scope);
/* 203:301 */             if (!isApplicable)
/* 204:    */             {
/* 205:303 */               isApplicable = false;
/* 206:304 */               break;
/* 207:    */             }
/* 208:    */           }
/* 209:    */         }
/* 210:    */       }
/* 211:    */     }
/* 212:    */     catch (Exception ex)
/* 213:    */     {
/* 214:311 */       this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(DisassociateResourceEvent)" + CommonUtil.getStackTrace(ex));
/* 215:312 */       isApplicable = false;
/* 216:    */     }
/* 217:315 */     return isApplicable;
/* 218:    */   }
/* 219:    */   
/* 220:    */   public boolean isApplicable(CopyResourceEvent copyResourceEvent)
/* 221:    */   {
/* 222:330 */     this.logger.debug("isApplicable(DeleteResourceEvent)Start");
/* 223:    */     
/* 224:    */ 
/* 225:333 */     boolean isApplicable = false;
/* 226:    */     
/* 227:335 */     Id objectId = null;
/* 228:336 */     Context context = null;
/* 229:337 */     IGRCObject object = null;
/* 230:338 */     IServiceFactory serviceFactory = null;
/* 231:339 */     IResourceService resourceService = null;
/* 232:    */     
/* 233:341 */     String scope = "";
/* 234:342 */     String checkOn = "";
/* 235:343 */     String folderPath = "";
/* 236:    */     try
/* 237:    */     {
/* 238:348 */       prepareContextForTrigger(copyResourceEvent);
/* 239:351 */       if (isRunTrigger())
/* 240:    */       {
/* 241:353 */         context = copyResourceEvent.getContext();
/* 242:354 */         serviceFactory = ServiceFactory.getServiceFactory(context);
/* 243:355 */         resourceService = serviceFactory.createResourceService();
/* 244:    */         
/* 245:357 */         scope = getTriggerAttrbuteValue("scope");
/* 246:358 */         checkOn = getTriggerAttrbuteValue("check.on");
/* 247:359 */         folderPath = getTriggerAttrbuteValue("folder.path");
/* 248:361 */         if ((CommonUtil.isNotNullOrEmpty(checkOn)) && (CommonUtil.isEqual(checkOn, "source")))
/* 249:    */         {
/* 250:363 */           objectId = copyResourceEvent.getSourceResouceId();
/* 251:364 */           object = resourceService.getGRCObject(objectId);
/* 252:365 */           isApplicable = evaluate(object, folderPath, scope);
/* 253:    */         }
/* 254:366 */         else if ((CommonUtil.isNotNullOrEmpty(checkOn)) && (CommonUtil.isEqual(checkOn, "destination")))
/* 255:    */         {
/* 256:368 */           objectId = copyResourceEvent.getTargetResourceId();
/* 257:369 */           object = resourceService.getGRCObject(objectId);
/* 258:370 */           isApplicable = evaluate(object, folderPath, scope);
/* 259:    */         }
/* 260:    */       }
/* 261:    */     }
/* 262:    */     catch (Exception ex)
/* 263:    */     {
/* 264:375 */       this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(DeleteResourceEvent)" + CommonUtil.getStackTrace(ex));
/* 265:376 */       isApplicable = false;
/* 266:    */     }
/* 267:379 */     return isApplicable;
/* 268:    */   }
/* 269:    */   
/* 270:    */   public boolean isApplicable(DeleteResourceEvent deleteResourceEvent)
/* 271:    */   {
/* 272:394 */     this.logger.debug("isApplicable(DeleteResourceEvent)Start");
/* 273:    */     
/* 274:    */ 
/* 275:397 */     boolean isApplicable = false;
/* 276:398 */     String scope = "";
/* 277:399 */     String folderPath = "";
/* 278:    */     
/* 279:401 */     Context context = null;
/* 280:402 */     List<Id> resourceIDS = null;
/* 281:403 */     IServiceFactory serviceFactory = null;
/* 282:404 */     IResourceService resourceService = null;
/* 283:    */     try
/* 284:    */     {
/* 285:409 */       prepareContextForTrigger(deleteResourceEvent);
/* 286:412 */       if (isRunTrigger())
/* 287:    */       {
/* 288:414 */         context = deleteResourceEvent.getContext();
/* 289:415 */         serviceFactory = ServiceFactory.getServiceFactory(context);
/* 290:416 */         resourceService = serviceFactory.createResourceService();
/* 291:    */         
/* 292:418 */         resourceIDS = deleteResourceEvent.getResourceIds();
/* 293:419 */         scope = getTriggerAttrbuteValue("scope");
/* 294:420 */         folderPath = getTriggerAttrbuteValue("folder.path");
/* 295:422 */         for (Id resId : resourceIDS)
/* 296:    */         {
/* 297:424 */           IGRCObject object = resourceService.getGRCObject(resId);
/* 298:425 */           isApplicable = evaluate(object, folderPath, scope);
/* 299:427 */           if (!isApplicable)
/* 300:    */           {
/* 301:429 */             isApplicable = false;
/* 302:430 */             break;
/* 303:    */           }
/* 304:    */         }
/* 305:    */       }
/* 306:    */     }
/* 307:    */     catch (Exception ex)
/* 308:    */     {
/* 309:436 */       this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(DeleteResourceEvent)" + CommonUtil.getStackTrace(ex));
/* 310:437 */       isApplicable = false;
/* 311:    */     }
/* 312:440 */     return isApplicable;
/* 313:    */   }
/* 314:    */   
/* 315:    */   public boolean isApplicable(QueryEvent queryEvent)
/* 316:    */   {
/* 317:455 */     this.logger.debug("isApplicable(QueryEvent)Start");
/* 318:    */     
/* 319:    */ 
/* 320:458 */     boolean isApplicable = false;
/* 321:    */     try
/* 322:    */     {
/* 323:463 */       prepareContextForTrigger(queryEvent);
/* 324:466 */       if (isRunTrigger()) {
/* 325:468 */         isApplicable = super.isApplicable(queryEvent);
/* 326:    */       }
/* 327:    */     }
/* 328:    */     catch (Exception ex)
/* 329:    */     {
/* 330:472 */       this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(QueryEvent)" + CommonUtil.getStackTrace(ex));
/* 331:473 */       isApplicable = false;
/* 332:    */     }
/* 333:476 */     this.logger.debug("Is Applicable: " + isApplicable);
/* 334:477 */     this.logger.debug("isApplicable(QueryEvent)End");
/* 335:478 */     return isApplicable;
/* 336:    */   }
/* 337:    */   
/* 338:    */   public boolean isApplicable(SearchEvent searchEvent)
/* 339:    */   {
/* 340:493 */     this.logger.debug("isApplicable(SearchEvent)Start");
/* 341:    */     
/* 342:    */ 
/* 343:496 */     boolean isApplicable = false;
/* 344:    */     try
/* 345:    */     {
/* 346:501 */       prepareContextForTrigger(searchEvent);
/* 347:504 */       if (isRunTrigger()) {
/* 348:506 */         isApplicable = super.isApplicable(searchEvent);
/* 349:    */       }
/* 350:    */     }
/* 351:    */     catch (Exception ex)
/* 352:    */     {
/* 353:510 */       this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(SearchEvent)" + CommonUtil.getStackTrace(ex));
/* 354:511 */       isApplicable = false;
/* 355:    */     }
/* 356:514 */     this.logger.debug("Is Applicable: " + isApplicable);
/* 357:515 */     this.logger.debug("isApplicable(SearchEvent)End");
/* 358:516 */     return isApplicable;
/* 359:    */   }
/* 360:    */   
/* 361:    */   private boolean evaluate(IGRCObject grcObject, String folderPath, String scope)
/* 362:    */   {
/* 363:535 */     String parentFolder = grcObject.getParentFolder().getPath();
/* 364:538 */     if (scope.equalsIgnoreCase("self")) {
/* 365:539 */       return parentFolder.equals(folderPath);
/* 366:    */     }
/* 367:541 */     if (scope.equalsIgnoreCase("recursive")) {
/* 368:542 */       return parentFolder.startsWith(folderPath);
/* 369:    */     }
/* 370:545 */     return false;
/* 371:    */   }
/* 372:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.triggers.rule.FolderMatchTriggerRule
 * JD-Core Version:    0.7.0.1
 */