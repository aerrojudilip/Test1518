/*   1:    */ package com.ibm.openpages.ext.tss.triggers.rule;
/*   2:    */ 
/*   3:    */ import com.ibm.openpages.api.resource.IGRCObject;
/*   4:    */ import com.ibm.openpages.api.resource.IResource;
/*   5:    */ import com.ibm.openpages.api.trigger.events.AssociateResourceEvent;
/*   6:    */ import com.ibm.openpages.api.trigger.events.CopyResourceEvent;
/*   7:    */ import com.ibm.openpages.api.trigger.events.CreateResourceEvent;
/*   8:    */ import com.ibm.openpages.api.trigger.events.DeleteResourceEvent;
/*   9:    */ import com.ibm.openpages.api.trigger.events.DisassociateResourceEvent;
/*  10:    */ import com.ibm.openpages.api.trigger.events.QueryEvent;
/*  11:    */ import com.ibm.openpages.api.trigger.events.SearchEvent;
/*  12:    */ import com.ibm.openpages.api.trigger.events.UpdateResourceEvent;
/*  13:    */ import com.ibm.openpages.ext.tss.service.IFieldUtil;
/*  14:    */ import com.ibm.openpages.ext.tss.service.IGRCObjectUtil;
/*  15:    */ import com.ibm.openpages.ext.tss.service.IGRCTriggerUtil;
/*  16:    */ import com.ibm.openpages.ext.tss.service.beans.FieldValueChangeForSetTriggerAttributesInfo;
/*  17:    */ import com.ibm.openpages.ext.tss.service.beans.FieldValueChangeInfo;
/*  18:    */ import com.ibm.openpages.ext.tss.service.constants.CheckFor;
/*  19:    */ import com.ibm.openpages.ext.tss.service.util.CommonUtil;
/*  20:    */ import java.util.ArrayList;
/*  21:    */ import java.util.List;
/*  22:    */ import org.apache.commons.logging.Log;
/*  23:    */ 
/*  24:    */ public class DetectPropertyChangeBaseRule
/*  25:    */   extends ContentTypeMatchBaseRule
/*  26:    */ {
/*  27:    */   public boolean isApplicable(CreateResourceEvent createResourceEvent)
/*  28:    */   {
/*  29: 67 */     boolean isApplicable = false;
/*  30: 68 */     IResource resource = createResourceEvent.getResource();
/*  31: 71 */     if (super.isApplicable(createResourceEvent))
/*  32:    */     {
/*  33: 73 */       this.logger.debug("isApplicable(CreateResourceEvent)");
/*  34:    */       try
/*  35:    */       {
/*  36: 77 */         isApplicable = resource.isFolder() ? false : evaluate((IGRCObject)resource);
/*  37:    */       }
/*  38:    */       catch (Exception ex)
/*  39:    */       {
/*  40: 80 */         this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(CreateResourceEvent)" + CommonUtil.getStackTrace(ex));
/*  41: 81 */         isApplicable = false;
/*  42:    */       }
/*  43: 84 */       this.logger.debug("Is Applicable: " + isApplicable);
/*  44: 85 */       this.logger.debug("isApplicable(CreateResourceEvent)");
/*  45:    */     }
/*  46: 88 */     return isApplicable;
/*  47:    */   }
/*  48:    */   
/*  49:    */   public boolean isApplicable(UpdateResourceEvent updateResourceEvent)
/*  50:    */   {
/*  51:107 */     boolean isApplicable = false;
/*  52:108 */     IResource resource = updateResourceEvent.getResource();
/*  53:111 */     if (super.isApplicable(updateResourceEvent))
/*  54:    */     {
/*  55:113 */       this.logger.debug("isApplicable(UpdateResourceEvent)");
/*  56:    */       try
/*  57:    */       {
/*  58:117 */         isApplicable = resource.isFolder() ? false : evaluate((IGRCObject)resource);
/*  59:    */       }
/*  60:    */       catch (Exception ex)
/*  61:    */       {
/*  62:120 */         this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(UpdateResourceEvent)" + CommonUtil.getStackTrace(ex));
/*  63:121 */         isApplicable = false;
/*  64:    */       }
/*  65:124 */       this.logger.debug("Is Applicable: " + isApplicable);
/*  66:125 */       this.logger.debug("isApplicable(UpdateResourceEvent)");
/*  67:    */     }
/*  68:128 */     return isApplicable;
/*  69:    */   }
/*  70:    */   
/*  71:    */   public boolean isApplicable(AssociateResourceEvent associateResourceEvent)
/*  72:    */   {
/*  73:147 */     boolean isApplicable = false;
/*  74:148 */     IGRCObject resource = null;
/*  75:151 */     if (super.isApplicable(associateResourceEvent))
/*  76:    */     {
/*  77:153 */       this.logger.debug("isApplicable(AssociateResourceEvent)");
/*  78:    */       try
/*  79:    */       {
/*  80:157 */         resource = this.grcObjectUtil.getObjectFromId(associateResourceEvent.getChild());
/*  81:158 */         isApplicable = resource.isFolder() ? false : evaluate(resource);
/*  82:    */       }
/*  83:    */       catch (Exception ex)
/*  84:    */       {
/*  85:161 */         this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(AssociateResourceEvent)" + CommonUtil.getStackTrace(ex));
/*  86:162 */         isApplicable = false;
/*  87:    */       }
/*  88:165 */       this.logger.debug("Is Applicable: " + isApplicable);
/*  89:166 */       this.logger.debug("isApplicable(AssociateResourceEvent)");
/*  90:    */     }
/*  91:169 */     return isApplicable;
/*  92:    */   }
/*  93:    */   
/*  94:    */   public boolean isApplicable(DisassociateResourceEvent disassociateResourceEvent)
/*  95:    */   {
/*  96:188 */     boolean isApplicable = false;
/*  97:189 */     IGRCObject resource = null;
/*  98:192 */     if (super.isApplicable(disassociateResourceEvent))
/*  99:    */     {
/* 100:194 */       this.logger.debug("isApplicable(DisassociateResourceEvent)");
/* 101:    */       try
/* 102:    */       {
/* 103:198 */         resource = this.grcObjectUtil.getObjectFromId(disassociateResourceEvent.getChild());
/* 104:199 */         isApplicable = resource.isFolder() ? false : evaluate(resource);
/* 105:    */       }
/* 106:    */       catch (Exception ex)
/* 107:    */       {
/* 108:202 */         this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(DisassociateResourceEvent)" + CommonUtil.getStackTrace(ex));
/* 109:203 */         isApplicable = false;
/* 110:    */       }
/* 111:206 */       this.logger.debug("Is Applicable: " + isApplicable);
/* 112:207 */       this.logger.debug("isApplicable(DisassociateResourceEvent)");
/* 113:    */     }
/* 114:210 */     return isApplicable;
/* 115:    */   }
/* 116:    */   
/* 117:    */   public boolean isApplicable(CopyResourceEvent copyResourceEvent)
/* 118:    */   {
/* 119:228 */     this.logger.debug("isApplicable(CopyResourceEvent)Start");
/* 120:    */     
/* 121:    */ 
/* 122:231 */     boolean isApplicable = false;
/* 123:234 */     if (super.isApplicable(copyResourceEvent))
/* 124:    */     {
/* 125:    */       try
/* 126:    */       {
/* 127:238 */         prepareContextForTrigger(copyResourceEvent);
/* 128:241 */         if (isRunTrigger()) {
/* 129:243 */           isApplicable = super.isApplicable(copyResourceEvent);
/* 130:    */         }
/* 131:    */       }
/* 132:    */       catch (Exception ex)
/* 133:    */       {
/* 134:247 */         this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(CopyResourceEvent)" + CommonUtil.getStackTrace(ex));
/* 135:248 */         isApplicable = false;
/* 136:    */       }
/* 137:251 */       this.logger.debug("Is Applicable: " + isApplicable);
/* 138:252 */       this.logger.debug("isApplicable(CopyResourceEvent)End");
/* 139:    */     }
/* 140:255 */     return isApplicable;
/* 141:    */   }
/* 142:    */   
/* 143:    */   public boolean isApplicable(DeleteResourceEvent deleteResourceEvent)
/* 144:    */   {
/* 145:272 */     return super.isApplicable(deleteResourceEvent);
/* 146:    */   }
/* 147:    */   
/* 148:    */   public boolean isApplicable(QueryEvent queryEvent)
/* 149:    */   {
/* 150:289 */     return super.isApplicable(queryEvent);
/* 151:    */   }
/* 152:    */   
/* 153:    */   public boolean isApplicable(SearchEvent searchEvent)
/* 154:    */   {
/* 155:306 */     return super.isApplicable(searchEvent);
/* 156:    */   }
/* 157:    */   
/* 158:    */   protected void detectPropertyChangeValidation(FieldValueChangeInfo fieldValueChangeInfo)
/* 159:    */   {
/* 160:320 */     this.logger.debug("detectPropertyChangeValidation()");
/* 161:323 */     if (CommonUtil.isNullOrEmpty(fieldValueChangeInfo.getFields())) {
/* 162:324 */       throw new IllegalStateException("Null field names in attribute");
/* 163:    */     }
/* 164:326 */     if ((!CheckFor.CHECK_ALL.equals(fieldValueChangeInfo.getCheckFor())) && (!CheckFor.CHECK_ANY.equals(fieldValueChangeInfo.getCheckFor()))) {
/* 165:328 */       throw new IllegalStateException("Incorrect value in check.for attribute");
/* 166:    */     }
/* 167:331 */     this.logger.debug("detectPropertyChangeValidation()");
/* 168:    */   }
/* 169:    */   
/* 170:    */   protected void detectPropertyChangeToAGivenValueValidation(FieldValueChangeInfo fieldValueChangeInfo)
/* 171:    */     throws Exception
/* 172:    */   {
/* 173:344 */     this.logger.debug("detectPropertyChangeToAGivenValueValidation()");
/* 174:347 */     if (CommonUtil.isNullOrEmpty(fieldValueChangeInfo.getFields())) {
/* 175:348 */       throw new IllegalStateException("Null field names in attribute");
/* 176:    */     }
/* 177:350 */     if (CommonUtil.isNullOrEmpty(fieldValueChangeInfo.getValues())) {
/* 178:351 */       throw new IllegalStateException("Null field values in attribute");
/* 179:    */     }
/* 180:353 */     if ((CommonUtil.isListNullOrEmpty(fieldValueChangeInfo.getFieldNamesList())) && (CommonUtil.isListNullOrEmpty(fieldValueChangeInfo.getValuesList())) && (fieldValueChangeInfo.getFieldNamesList().size() != fieldValueChangeInfo.getValuesList().size())) {
/* 181:356 */       throw new IllegalStateException("The number of field names attribute and field values attribute do not match");
/* 182:    */     }
/* 183:359 */     if ((!CheckFor.CHECK_ALL.equals(fieldValueChangeInfo.getCheckFor())) && (!CheckFor.CHECK_ANY.equals(fieldValueChangeInfo.getCheckFor()))) {
/* 184:361 */       throw new IllegalStateException("Incorrect value in check.for attribute");
/* 185:    */     }
/* 186:364 */     this.logger.debug("detectPropertyChangeToAGivenValueValidation()");
/* 187:    */   }
/* 188:    */   
/* 189:    */   private boolean evaluate(IGRCObject object)
/* 190:    */     throws Exception
/* 191:    */   {
/* 192:382 */     this.logger.debug("evaluate()");
/* 193:    */     
/* 194:    */ 
/* 195:385 */     boolean isApplicable = false;
/* 196:    */     
/* 197:    */ 
/* 198:388 */     contentTypeValidation();
/* 199:389 */     isApplicable = contentTypeMatch(object);
/* 200:    */     
/* 201:391 */     this.logger.debug("Is Applicable: " + isApplicable);
/* 202:392 */     this.logger.debug("evaluate()");
/* 203:393 */     return isApplicable;
/* 204:    */   }
/* 205:    */   
/* 206:    */   protected boolean detectPropertyChange(FieldValueChangeInfo fieldValueChangeInfo)
/* 207:    */     throws Exception
/* 208:    */   {
/* 209:409 */     return this.grcTriggerUtil.detectPropertyChange(fieldValueChangeInfo);
/* 210:    */   }
/* 211:    */   
/* 212:    */   protected boolean detectPropertyChangeAndSetModifiedFieldsInTriggerAttributes(FieldValueChangeForSetTriggerAttributesInfo fieldValueChangeInfo)
/* 213:    */     throws Exception
/* 214:    */   {
/* 215:425 */     boolean isPropertyChange = false;
/* 216:426 */     List<String> modifiedFieldsList = null;
/* 217:    */     
/* 218:428 */     isPropertyChange = this.grcTriggerUtil.detectPropertyChange(fieldValueChangeInfo);
/* 219:430 */     if (isPropertyChange)
/* 220:    */     {
/* 221:431 */       initFieldUtilServices();
/* 222:    */       
/* 223:433 */       modifiedFieldsList = new ArrayList();
/* 224:434 */       modifiedFieldsList = this.fieldUtil.getModifiedFieldsInfoMatchingGivenFields(fieldValueChangeInfo);
/* 225:    */       
/* 226:436 */       String modifieldFields = modifiedFieldsList.toString();
/* 227:437 */       modifieldFields = modifieldFields.replace("[", "");
/* 228:438 */       modifieldFields = modifieldFields.replace("]", "");
/* 229:439 */       modifieldFields = modifieldFields.replace(" ", "");
/* 230:    */       
/* 231:441 */       fieldValueChangeInfo.setTriggerAttributeValue(modifieldFields);
/* 232:442 */       this.grcTriggerUtil.setAttributeInGRCTriggerDefinition(fieldValueChangeInfo);
/* 233:    */     }
/* 234:446 */     return isPropertyChange;
/* 235:    */   }
/* 236:    */   
/* 237:    */   protected boolean detectPropertyChangeToAGivenValue(FieldValueChangeInfo fieldValueChangeInfo)
/* 238:    */     throws Exception
/* 239:    */   {
/* 240:463 */     return this.grcTriggerUtil.detectPropertyChangeToAGivenValue(fieldValueChangeInfo);
/* 241:    */   }
/* 242:    */   
/* 243:    */   protected boolean detectPropertyChangeToAnyGivenValue(FieldValueChangeInfo fieldValueChangeInfo)
/* 244:    */     throws Exception
/* 245:    */   {
/* 246:480 */     return this.grcTriggerUtil.detectPropertyChangeToAGivenValue(fieldValueChangeInfo);
/* 247:    */   }
/* 248:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.triggers.rule.DetectPropertyChangeBaseRule
 * JD-Core Version:    0.7.0.1
 */