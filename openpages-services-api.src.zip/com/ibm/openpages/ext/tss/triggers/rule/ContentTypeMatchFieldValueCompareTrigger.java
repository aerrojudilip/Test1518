/*   1:    */ package com.ibm.openpages.ext.tss.triggers.rule;
/*   2:    */ 
/*   3:    */ import com.ibm.openpages.api.resource.IGRCObject;
/*   4:    */ import com.ibm.openpages.api.resource.IResource;
/*   5:    */ import com.ibm.openpages.api.trigger.events.AssociateResourceEvent;
/*   6:    */ import com.ibm.openpages.api.trigger.events.CopyResourceEvent;
/*   7:    */ import com.ibm.openpages.api.trigger.events.CreateResourceEvent;
/*   8:    */ import com.ibm.openpages.api.trigger.events.DeleteResourceEvent;
/*   9:    */ import com.ibm.openpages.api.trigger.events.DisassociateResourceEvent;
/*  10:    */ import com.ibm.openpages.api.trigger.events.QueryEvent;
/*  11:    */ import com.ibm.openpages.api.trigger.events.SearchEvent;
/*  12:    */ import com.ibm.openpages.api.trigger.events.UpdateResourceEvent;
/*  13:    */ import com.ibm.openpages.ext.tss.service.IGRCObjectUtil;
/*  14:    */ import com.ibm.openpages.ext.tss.service.IGRCTriggerUtil;
/*  15:    */ import com.ibm.openpages.ext.tss.service.beans.IGRCFieldValidateInformation;
/*  16:    */ import com.ibm.openpages.ext.tss.service.util.CommonUtil;
/*  17:    */ import java.util.List;
/*  18:    */ import org.apache.commons.logging.Log;
/*  19:    */ 
/*  20:    */ public class ContentTypeMatchFieldValueCompareTrigger
/*  21:    */   extends ContentTypeMatchBaseRule
/*  22:    */ {
/*  23:    */   public boolean isApplicable(CreateResourceEvent createResourceEvent)
/*  24:    */   {
/*  25: 57 */     this.logger.debug("isApplicable(CreateResourceEvent)Start");
/*  26:    */     
/*  27:    */ 
/*  28: 60 */     boolean isApplicable = false;
/*  29: 61 */     IResource resource = null;
/*  30:    */     try
/*  31:    */     {
/*  32: 66 */       prepareContextForTrigger(createResourceEvent);
/*  33: 69 */       if (isRunTrigger())
/*  34:    */       {
/*  35: 71 */         resource = createResourceEvent.getResource();
/*  36: 72 */         isApplicable = resource.isFolder() ? false : evaluate((IGRCObject)resource);
/*  37:    */       }
/*  38:    */     }
/*  39:    */     catch (Exception ex)
/*  40:    */     {
/*  41: 76 */       this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(CreateResourceEvent)" + CommonUtil.getStackTrace(ex));
/*  42: 77 */       isApplicable = false;
/*  43:    */     }
/*  44: 80 */     this.logger.debug("Is Applicable: " + isApplicable);
/*  45: 81 */     this.logger.debug("isApplicable(CreateResourceEvent)End");
/*  46: 82 */     return isApplicable;
/*  47:    */   }
/*  48:    */   
/*  49:    */   public boolean isApplicable(UpdateResourceEvent updateResourceEvent)
/*  50:    */   {
/*  51: 98 */     this.logger.debug("isApplicable(UpdateResourceEvent)Start");
/*  52:    */     
/*  53:    */ 
/*  54:101 */     boolean isApplicable = false;
/*  55:102 */     IResource resource = null;
/*  56:    */     try
/*  57:    */     {
/*  58:107 */       prepareContextForTrigger(updateResourceEvent);
/*  59:110 */       if (isRunTrigger())
/*  60:    */       {
/*  61:112 */         resource = updateResourceEvent.getResource();
/*  62:113 */         isApplicable = resource.isFolder() ? false : evaluate((IGRCObject)resource);
/*  63:    */       }
/*  64:    */     }
/*  65:    */     catch (Exception ex)
/*  66:    */     {
/*  67:117 */       this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(UpdateResourceEvent)" + CommonUtil.getStackTrace(ex));
/*  68:118 */       isApplicable = false;
/*  69:    */     }
/*  70:121 */     this.logger.debug("Is Applicable: " + isApplicable);
/*  71:122 */     this.logger.debug("isApplicable(UpdateResourceEvent)End");
/*  72:123 */     return isApplicable;
/*  73:    */   }
/*  74:    */   
/*  75:    */   public boolean isApplicable(AssociateResourceEvent associateReourceEvent)
/*  76:    */   {
/*  77:139 */     this.logger.debug("isApplicable(UpdateResourceEvent)Start");
/*  78:    */     
/*  79:    */ 
/*  80:142 */     boolean isApplicable = false;
/*  81:143 */     String checkOn = "";
/*  82:144 */     IResource resource = null;
/*  83:    */     try
/*  84:    */     {
/*  85:149 */       prepareContextForTrigger(associateReourceEvent);
/*  86:152 */       if (isRunTrigger())
/*  87:    */       {
/*  88:154 */         initGRCObjectUtilServices();
/*  89:155 */         contentTypeValidationForAssociate();
/*  90:156 */         checkOn = getTriggerAttrbuteValue("check.on");
/*  91:    */         
/*  92:158 */         this.logger.debug("Check On: " + checkOn);
/*  93:160 */         if (CommonUtil.isEqualIgnoreCase(checkOn, "child")) {
/*  94:161 */           resource = this.grcObjectUtil.getObjectFromId(associateReourceEvent.getChild());
/*  95:162 */         } else if (CommonUtil.isEqualIgnoreCase(checkOn, "parent")) {
/*  96:163 */           resource = this.grcObjectUtil.getObjectFromId(associateReourceEvent.getParent());
/*  97:    */         }
/*  98:165 */         this.logger.debug("Is Object Not null: " + CommonUtil.isObjectNotNull(resource));
/*  99:166 */         this.logger.debug("Is Object a Folder" + (CommonUtil.isObjectNotNull(resource) ? Boolean.valueOf(resource.isFolder()) : "Null"));
/* 100:167 */         this.logger.debug("Object name: " + (CommonUtil.isObjectNotNull(resource) ? resource.getName() : "Null"));
/* 101:169 */         if (CommonUtil.isObjectNotNull(resource)) {
/* 102:170 */           isApplicable = resource.isFolder() ? false : evaluate((IGRCObject)resource);
/* 103:    */         }
/* 104:    */       }
/* 105:    */     }
/* 106:    */     catch (Exception ex)
/* 107:    */     {
/* 108:174 */       this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(UpdateResourceEvent)" + CommonUtil.getStackTrace(ex));
/* 109:175 */       isApplicable = false;
/* 110:    */     }
/* 111:178 */     this.logger.debug("Is Applicable: " + isApplicable);
/* 112:179 */     this.logger.debug("isApplicable(UpdateResourceEvent)End");
/* 113:180 */     return isApplicable;
/* 114:    */   }
/* 115:    */   
/* 116:    */   public boolean isApplicable(DisassociateResourceEvent disassociateResourceEvent)
/* 117:    */   {
/* 118:196 */     this.logger.debug("isApplicable(DisassociateResourceEvent)Start");
/* 119:    */     
/* 120:    */ 
/* 121:199 */     boolean isApplicable = false;
/* 122:    */     try
/* 123:    */     {
/* 124:204 */       prepareContextForTrigger(disassociateResourceEvent);
/* 125:207 */       if (isRunTrigger()) {
/* 126:209 */         isApplicable = super.isApplicable(disassociateResourceEvent);
/* 127:    */       }
/* 128:    */     }
/* 129:    */     catch (Exception ex)
/* 130:    */     {
/* 131:213 */       this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(DisassociateResourceEvent)" + CommonUtil.getStackTrace(ex));
/* 132:214 */       isApplicable = false;
/* 133:    */     }
/* 134:217 */     this.logger.debug("Is Applicable: " + isApplicable);
/* 135:218 */     this.logger.debug("isApplicable(DisassociateResourceEvent)End");
/* 136:219 */     return isApplicable;
/* 137:    */   }
/* 138:    */   
/* 139:    */   public boolean isApplicable(CopyResourceEvent copyResourceEvent)
/* 140:    */   {
/* 141:234 */     this.logger.debug("isApplicable(CopyResourceEvent)Start");
/* 142:    */     
/* 143:    */ 
/* 144:237 */     boolean isApplicable = false;
/* 145:    */     try
/* 146:    */     {
/* 147:242 */       prepareContextForTrigger(copyResourceEvent);
/* 148:245 */       if (isRunTrigger()) {
/* 149:247 */         isApplicable = super.isApplicable(copyResourceEvent);
/* 150:    */       }
/* 151:    */     }
/* 152:    */     catch (Exception ex)
/* 153:    */     {
/* 154:251 */       this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(CopyResourceEvent)" + CommonUtil.getStackTrace(ex));
/* 155:252 */       isApplicable = false;
/* 156:    */     }
/* 157:255 */     this.logger.debug("Is Applicable: " + isApplicable);
/* 158:256 */     this.logger.debug("isApplicable(CopyResourceEvent)End");
/* 159:257 */     return isApplicable;
/* 160:    */   }
/* 161:    */   
/* 162:    */   public boolean isApplicable(DeleteResourceEvent deleteResourceEvent)
/* 163:    */   {
/* 164:272 */     this.logger.debug("isApplicable(DeleteResourceEvent)Start");
/* 165:    */     
/* 166:    */ 
/* 167:275 */     boolean isApplicable = false;
/* 168:    */     try
/* 169:    */     {
/* 170:280 */       prepareContextForTrigger(deleteResourceEvent);
/* 171:283 */       if (isRunTrigger()) {
/* 172:285 */         isApplicable = super.isApplicable(deleteResourceEvent);
/* 173:    */       }
/* 174:    */     }
/* 175:    */     catch (Exception ex)
/* 176:    */     {
/* 177:289 */       this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(DeleteResourceEvent)" + CommonUtil.getStackTrace(ex));
/* 178:290 */       isApplicable = false;
/* 179:    */     }
/* 180:293 */     this.logger.debug("Is Applicable: " + isApplicable);
/* 181:294 */     this.logger.debug("isApplicable(DeleteResourceEvent)End");
/* 182:295 */     return isApplicable;
/* 183:    */   }
/* 184:    */   
/* 185:    */   public boolean isApplicable(QueryEvent queryEvent)
/* 186:    */   {
/* 187:310 */     this.logger.debug("isApplicable(QueryEvent)Start");
/* 188:    */     
/* 189:    */ 
/* 190:313 */     boolean isApplicable = false;
/* 191:    */     try
/* 192:    */     {
/* 193:318 */       prepareContextForTrigger(queryEvent);
/* 194:321 */       if (isRunTrigger()) {
/* 195:323 */         isApplicable = super.isApplicable(queryEvent);
/* 196:    */       }
/* 197:    */     }
/* 198:    */     catch (Exception ex)
/* 199:    */     {
/* 200:327 */       this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(QueryEvent)" + CommonUtil.getStackTrace(ex));
/* 201:328 */       isApplicable = false;
/* 202:    */     }
/* 203:331 */     this.logger.debug("Is Applicable: " + isApplicable);
/* 204:332 */     this.logger.debug("isApplicable(QueryEvent)End");
/* 205:333 */     return isApplicable;
/* 206:    */   }
/* 207:    */   
/* 208:    */   public boolean isApplicable(SearchEvent searchEvent)
/* 209:    */   {
/* 210:348 */     this.logger.debug("isApplicable(SearchEvent)Start");
/* 211:    */     
/* 212:    */ 
/* 213:351 */     boolean isApplicable = false;
/* 214:    */     try
/* 215:    */     {
/* 216:356 */       prepareContextForTrigger(searchEvent);
/* 217:359 */       if (isRunTrigger()) {
/* 218:361 */         isApplicable = super.isApplicable(searchEvent);
/* 219:    */       }
/* 220:    */     }
/* 221:    */     catch (Exception ex)
/* 222:    */     {
/* 223:365 */       this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(SearchEvent)" + CommonUtil.getStackTrace(ex));
/* 224:366 */       isApplicable = false;
/* 225:    */     }
/* 226:369 */     this.logger.debug("Is Applicable: " + isApplicable);
/* 227:370 */     this.logger.debug("isApplicable(SearchEvent)End");
/* 228:371 */     return isApplicable;
/* 229:    */   }
/* 230:    */   
/* 231:    */   private boolean evaluate(IGRCObject object)
/* 232:    */     throws Exception
/* 233:    */   {
/* 234:385 */     this.logger.debug("evaluate()Start");
/* 235:    */     
/* 236:    */ 
/* 237:388 */     boolean isApplicable = false;
/* 238:389 */     boolean isContentTypeMatch = false;
/* 239:    */     
/* 240:391 */     String checkFor = null;
/* 241:392 */     List<String> valuesList = null;
/* 242:393 */     List<String> fieldNamesList = null;
/* 243:394 */     List<String> comparatorsList = null;
/* 244:395 */     IGRCFieldValidateInformation fieldValidateInformation = null;
/* 245:    */     
/* 246:    */ 
/* 247:398 */     checkFor = getTriggerAttrbuteValue("check.for.all.or.any");
/* 248:399 */     fieldNamesList = getParsedTriggerAttrbuteValue("field.names.to.check");
/* 249:400 */     valuesList = getParsedTriggerAttrbuteValue("field.values.to.check");
/* 250:401 */     comparatorsList = getParsedTriggerAttrbuteValue("field.value.comparators");
/* 251:    */     
/* 252:    */ 
/* 253:404 */     fieldValidateInformation = new IGRCFieldValidateInformation();
/* 254:405 */     fieldValidateInformation.setCheckFor(checkFor);
/* 255:406 */     fieldValidateInformation.setFieldValuesList(valuesList);
/* 256:407 */     fieldValidateInformation.setFieldsList(fieldNamesList);
/* 257:408 */     fieldValidateInformation.setComparatorsList(comparatorsList);
/* 258:409 */     contentTypeValidationForFieldCompare(fieldValidateInformation);
/* 259:    */     
/* 260:411 */     isContentTypeMatch = contentTypeMatch(object);
/* 261:412 */     isApplicable = (isContentTypeMatch) && (this.grcTriggerUtil.matchFieldValueToAGivenValue(object, fieldValidateInformation));
/* 262:    */     
/* 263:414 */     this.logger.debug("Is Applicable: " + isContentTypeMatch);
/* 264:416 */     if (isContentTypeMatch) {
/* 265:417 */       this.logger.debug("Is Applicable: " + this.grcTriggerUtil.matchFieldValueToAGivenValue(object, fieldValidateInformation));
/* 266:    */     }
/* 267:419 */     this.logger.debug("Is Applicable: " + isApplicable);
/* 268:420 */     this.logger.debug("evaluate()End");
/* 269:421 */     return isApplicable;
/* 270:    */   }
/* 271:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.triggers.rule.ContentTypeMatchFieldValueCompareTrigger
 * JD-Core Version:    0.7.0.1
 */