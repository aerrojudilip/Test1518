/*   1:    */ package com.ibm.openpages.ext.tss.triggers.rule;
/*   2:    */ 
/*   3:    */ import com.ibm.openpages.api.metadata.ITypeDefinition;
/*   4:    */ import com.ibm.openpages.api.resource.IGRCObject;
/*   5:    */ import com.ibm.openpages.ext.tss.service.beans.IGRCFieldValidateInformation;
/*   6:    */ import com.ibm.openpages.ext.tss.service.util.CommonUtil;
/*   7:    */ import java.util.ArrayList;
/*   8:    */ import java.util.List;
/*   9:    */ import org.apache.commons.logging.Log;
/*  10:    */ 
/*  11:    */ public class ContentTypeMatchBaseRule
/*  12:    */   extends BaseTriggerRule
/*  13:    */ {
/*  14:    */   protected void contentTypeValidation()
/*  15:    */     throws Exception
/*  16:    */   {
/*  17: 51 */     this.logger.debug("contentTypeValidation() Start");
/*  18:    */     
/*  19:    */ 
/*  20: 54 */     String contentType = "";
/*  21:    */     
/*  22:    */ 
/*  23: 57 */     contentType = getTriggerAttrbuteValue("content.type.name");
/*  24: 59 */     if (CommonUtil.isNullOrEmpty(contentType)) {
/*  25: 60 */       throw new IllegalStateException("Null content type name attribute");
/*  26:    */     }
/*  27: 63 */     this.logger.debug("contentTypeValidation()End");
/*  28:    */   }
/*  29:    */   
/*  30:    */   protected void contentTypeValidationForFieldCompare(IGRCFieldValidateInformation fieldValidateInformation)
/*  31:    */     throws Exception
/*  32:    */   {
/*  33: 77 */     this.logger.debug("contentTypeValidation() Start");
/*  34:    */     
/*  35:    */ 
/*  36: 80 */     List<List<?>> compareList = null;
/*  37:    */     
/*  38:    */ 
/*  39: 83 */     contentTypeValidation();
/*  40: 85 */     if (CommonUtil.isNullOrEmpty(fieldValidateInformation.getCheckFor())) {
/*  41: 86 */       throw new IllegalStateException("Check for Attribute Not Present");
/*  42:    */     }
/*  43: 89 */     if (CommonUtil.isListNullOrEmpty(fieldValidateInformation.getFieldsList())) {
/*  44: 90 */       throw new IllegalStateException("Fields Information Not Present");
/*  45:    */     }
/*  46: 93 */     if (CommonUtil.isListNullOrEmpty(fieldValidateInformation.getFieldValuesList())) {
/*  47: 94 */       throw new IllegalStateException("Fields Values Information Not Present");
/*  48:    */     }
/*  49: 97 */     if (CommonUtil.isListNullOrEmpty(fieldValidateInformation.getComparatorsList())) {
/*  50: 98 */       throw new IllegalStateException("Fields Values Comparator Information Not Present");
/*  51:    */     }
/*  52:101 */     compareList = new ArrayList();
/*  53:102 */     compareList.add(fieldValidateInformation.getFieldsList());
/*  54:103 */     compareList.add(fieldValidateInformation.getFieldValuesList());
/*  55:104 */     compareList.add(fieldValidateInformation.getComparatorsList());
/*  56:106 */     if (CommonUtil.isListsNotOfTheSameSize(compareList)) {
/*  57:107 */       throw new IllegalStateException("The Fields Information, Field Values Information and the Comparators should be of the same size");
/*  58:    */     }
/*  59:110 */     this.logger.debug("contentTypeValidation()End");
/*  60:    */   }
/*  61:    */   
/*  62:    */   protected void contentTypeValidationForAssociate()
/*  63:    */     throws Exception
/*  64:    */   {
/*  65:126 */     this.logger.debug("contentTypeValidationForAssociate()Start");
/*  66:    */     
/*  67:    */ 
/*  68:129 */     String checkOn = "";
/*  69:    */     
/*  70:    */ 
/*  71:132 */     contentTypeValidation();
/*  72:133 */     checkOn = getTriggerAttrbuteValue("check.on");
/*  73:135 */     if (CommonUtil.isNullOrEmpty(checkOn)) {
/*  74:136 */       throw new IllegalStateException("Null Check On attribute");
/*  75:    */     }
/*  76:139 */     this.logger.debug("contentTypeValidationForAssociate()End");
/*  77:    */   }
/*  78:    */   
/*  79:    */   protected boolean contentTypeMatch(IGRCObject object)
/*  80:    */     throws Exception
/*  81:    */   {
/*  82:153 */     this.logger.debug("contentTypeMatch()Start");
/*  83:    */     
/*  84:    */ 
/*  85:156 */     boolean isApplicable = false;
/*  86:    */     
/*  87:158 */     ITypeDefinition def = null;
/*  88:159 */     String contentType = "";
/*  89:    */     
/*  90:    */ 
/*  91:162 */     def = object.getType();
/*  92:163 */     contentType = getTriggerAttrbuteValue("content.type.name");
/*  93:164 */     isApplicable = def.getName().equals(contentType);
/*  94:    */     
/*  95:    */ 
/*  96:167 */     this.logger.debug("Actual Content Type: " + def.getName());
/*  97:168 */     this.logger.debug("Expected Content Type: " + contentType);
/*  98:    */     
/*  99:170 */     this.logger.debug("Is Applicable: " + isApplicable);
/* 100:171 */     this.logger.debug("contentTypeMatch()End");
/* 101:172 */     return isApplicable;
/* 102:    */   }
/* 103:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.triggers.rule.ContentTypeMatchBaseRule
 * JD-Core Version:    0.7.0.1
 */