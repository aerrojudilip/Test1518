/*   1:    */ package com.ibm.openpages.ext.tss.triggers.rule;
/*   2:    */ 
/*   3:    */ import com.ibm.openpages.api.resource.IFolder;
/*   4:    */ import com.ibm.openpages.api.resource.IGRCObject;
/*   5:    */ import com.ibm.openpages.api.resource.IResource;
/*   6:    */ import com.ibm.openpages.api.service.IResourceService;
/*   7:    */ import com.ibm.openpages.api.service.IServiceFactory;
/*   8:    */ import com.ibm.openpages.api.service.ServiceFactory;
/*   9:    */ import com.ibm.openpages.api.trigger.events.AbstractEvent;
/*  10:    */ import com.ibm.openpages.api.trigger.events.AssociateResourceEvent;
/*  11:    */ import com.ibm.openpages.api.trigger.events.CopyResourceEvent;
/*  12:    */ import com.ibm.openpages.api.trigger.events.CreateResourceEvent;
/*  13:    */ import com.ibm.openpages.api.trigger.events.DeleteResourceEvent;
/*  14:    */ import com.ibm.openpages.api.trigger.events.DisassociateResourceEvent;
/*  15:    */ import com.ibm.openpages.api.trigger.events.UpdateResourceEvent;
/*  16:    */ import com.ibm.openpages.api.trigger.ext.DefaultRule;
/*  17:    */ import com.ibm.openpages.ext.tss.service.IApplicationUtil;
/*  18:    */ import com.ibm.openpages.ext.tss.service.IFieldUtil;
/*  19:    */ import com.ibm.openpages.ext.tss.service.IGRCObjectUtil;
/*  20:    */ import com.ibm.openpages.ext.tss.service.IGRCTriggerUtil;
/*  21:    */ import com.ibm.openpages.ext.tss.service.IGRCValidationTriggerUtil;
/*  22:    */ import com.ibm.openpages.ext.tss.service.ILoggerUtil;
/*  23:    */ import com.ibm.openpages.ext.tss.service.config.ApplicationContextUtils;
/*  24:    */ import com.ibm.openpages.ext.tss.service.config.ContextWrapper;
/*  25:    */ import com.ibm.openpages.ext.tss.service.config.OPSServiceFactory;
/*  26:    */ import com.ibm.openpages.ext.tss.service.proxy.ServiceFactoryProxy;
/*  27:    */ import com.ibm.openpages.ext.tss.service.util.CommonUtil;
/*  28:    */ import com.ibm.openpages.ext.tss.service.util.LoggerUtil;
/*  29:    */ import java.io.PrintStream;
/*  30:    */ import java.util.ArrayList;
/*  31:    */ import java.util.HashMap;
/*  32:    */ import java.util.List;
/*  33:    */ import org.apache.commons.logging.Log;
/*  34:    */ import org.springframework.context.ApplicationContext;
/*  35:    */ 
/*  36:    */ public class BaseTriggerRule
/*  37:    */   extends DefaultRule
/*  38:    */ {
/*  39: 70 */   public Log logger = null;
/*  40: 72 */   public IFieldUtil fieldUtil = null;
/*  41: 74 */   public IGRCObjectUtil grcObjectUtil = null;
/*  42: 76 */   public IGRCTriggerUtil grcTriggerUtil = null;
/*  43: 78 */   public IApplicationUtil applicationUtil = null;
/*  44: 80 */   public IGRCValidationTriggerUtil grcValidationTriggerUtil = null;
/*  45:    */   
/*  46:    */   public BaseTriggerRule()
/*  47:    */   {
/*  48: 92 */     initLogServices();
/*  49: 93 */     initGRCTriggerUtilServices();
/*  50:    */   }
/*  51:    */   
/*  52:    */   public boolean isApplicable(CreateResourceEvent createResourceEvent)
/*  53:    */   {
/*  54:113 */     boolean isApplicable = false;
/*  55:114 */     IResource resource = createResourceEvent.getResource();
/*  56:    */     
/*  57:116 */     LoggerUtil.debugEXTLog("BaseTriggerRule", "isApplicable()", "CreateResourceEvent", Boolean.valueOf(resource.isFolder()));
/*  58:    */     
/*  59:118 */     LoggerUtil.debugEXTLog("BaseTriggerRule", "isApplicable()", "path: ", resource.getPath());
/*  60:    */     
/*  61:120 */     LoggerUtil.debugEXTLog("BaseTriggerRule", "isApplicable()", "path: ", resource.getParentFolder().getName());
/*  62:    */     
/*  63:122 */     LoggerUtil.debugEXTLog("BaseTriggerRule", "isApplicable()", "path: ", resource.getParentFolder().getPath());
/*  64:    */     
/*  65:124 */     System.out.println("CreateResourceEvent In Base Trigger Rule - Is Resource Folder: " + resource.isFolder());
/*  66:    */     
/*  67:    */ 
/*  68:127 */     System.out.println("CreateResourceEvent In Base Trigger Rule - Is Resource Folder: " + resource.isFolder());
/*  69:131 */     if (!resource.isFolder())
/*  70:    */     {
/*  71:134 */       isApplicable = true;
/*  72:135 */       initServcies();
/*  73:    */     }
/*  74:138 */     return isApplicable;
/*  75:    */   }
/*  76:    */   
/*  77:    */   public boolean isApplicable(UpdateResourceEvent updateResourceEvent)
/*  78:    */   {
/*  79:158 */     boolean isApplicable = false;
/*  80:159 */     IResource resource = updateResourceEvent.getResource();
/*  81:    */     
/*  82:161 */     LoggerUtil.debugEXTLog("BaseTriggerRule", "isApplicable()", "CREATE_CONTROL", Boolean.valueOf(resource.isFolder()));
/*  83:    */     
/*  84:163 */     System.out.println("UpdateResourceEvent In Base Trigger Rule - Is Resource Folder: " + resource.isFolder());
/*  85:167 */     if (!resource.isFolder())
/*  86:    */     {
/*  87:170 */       isApplicable = true;
/*  88:171 */       initServcies();
/*  89:    */     }
/*  90:174 */     return isApplicable;
/*  91:    */   }
/*  92:    */   
/*  93:    */   public boolean isApplicable(AssociateResourceEvent associateResourceEvent)
/*  94:    */   {
/*  95:194 */     boolean isApplicable = false;
/*  96:    */     try
/*  97:    */     {
/*  98:200 */       IServiceFactory serviceFactory = ServiceFactory.getServiceFactory(associateResourceEvent.getContext());
/*  99:    */       
/* 100:202 */       IGRCObject resource = serviceFactory.createResourceService().getGRCObject(associateResourceEvent.getChild());
/* 101:    */       
/* 102:    */ 
/* 103:205 */       System.out.println("AssociateResourceEvent In Base Trigger Rule - Is Resource Folder: " + resource.isFolder());
/* 104:209 */       if (!resource.isFolder())
/* 105:    */       {
/* 106:212 */         isApplicable = true;
/* 107:213 */         initServcies();
/* 108:    */       }
/* 109:    */     }
/* 110:    */     catch (Exception e)
/* 111:    */     {
/* 112:219 */       System.out.println(CommonUtil.getStackTrace(e));
/* 113:    */     }
/* 114:222 */     return isApplicable;
/* 115:    */   }
/* 116:    */   
/* 117:    */   public boolean isApplicable(DisassociateResourceEvent disassociateResourceEvent)
/* 118:    */   {
/* 119:243 */     boolean isApplicable = false;
/* 120:    */     try
/* 121:    */     {
/* 122:249 */       IServiceFactory serviceFactory = ServiceFactory.getServiceFactory(disassociateResourceEvent.getContext());
/* 123:    */       
/* 124:251 */       IGRCObject resource = serviceFactory.createResourceService().getGRCObject(disassociateResourceEvent.getChild());
/* 125:    */       
/* 126:    */ 
/* 127:254 */       System.out.println("AssociateResourceEvent In Base Trigger Rule - Is Resource Folder: " + resource.isFolder());
/* 128:258 */       if (!resource.isFolder())
/* 129:    */       {
/* 130:261 */         isApplicable = true;
/* 131:262 */         initServcies();
/* 132:    */       }
/* 133:    */     }
/* 134:    */     catch (Exception e)
/* 135:    */     {
/* 136:268 */       System.out.println(CommonUtil.getStackTrace(e));
/* 137:    */     }
/* 138:271 */     return isApplicable;
/* 139:    */   }
/* 140:    */   
/* 141:    */   public boolean isApplicable(CopyResourceEvent copyResourceEvent)
/* 142:    */   {
/* 143:289 */     boolean isApplicable = false;
/* 144:    */     try
/* 145:    */     {
/* 146:295 */       IServiceFactory serviceFactory = ServiceFactory.getServiceFactory(copyResourceEvent.getContext());
/* 147:    */       
/* 148:297 */       IGRCObject resource = serviceFactory.createResourceService().getGRCObject(copyResourceEvent.getSourceResouceId());
/* 149:    */       
/* 150:    */ 
/* 151:300 */       System.out.println("CopyResourceEvent In Base Trigger Rule - Is Resource Folder: " + resource.isFolder());
/* 152:    */       
/* 153:    */ 
/* 154:303 */       System.err.println("CopyResourceEvent In Base Trigger Rule - Is Resource Folder: " + resource.isFolder());
/* 155:307 */       if (!resource.isFolder())
/* 156:    */       {
/* 157:310 */         isApplicable = true;
/* 158:311 */         initServcies();
/* 159:    */       }
/* 160:    */     }
/* 161:    */     catch (Exception e)
/* 162:    */     {
/* 163:317 */       System.out.println(CommonUtil.getStackTrace(e));
/* 164:    */     }
/* 165:320 */     return isApplicable;
/* 166:    */   }
/* 167:    */   
/* 168:    */   public boolean isApplicable(DeleteResourceEvent deleteResourceEvent)
/* 169:    */   {
/* 170:338 */     boolean isApplicable = false;
/* 171:    */     try
/* 172:    */     {
/* 173:344 */       IServiceFactory serviceFactory = ServiceFactory.getServiceFactory(deleteResourceEvent.getContext());
/* 174:    */       
/* 175:346 */       IGRCObject resource = serviceFactory.createResourceService().getGRCObject(deleteResourceEvent.getResourceId());
/* 176:    */       
/* 177:    */ 
/* 178:349 */       System.out.println("DeleteResourceEvent In Base Trigger Rule - Is Resource Folder: " + resource.isFolder());
/* 179:353 */       if (!resource.isFolder())
/* 180:    */       {
/* 181:356 */         isApplicable = true;
/* 182:357 */         initServcies();
/* 183:    */       }
/* 184:    */     }
/* 185:    */     catch (Exception e)
/* 186:    */     {
/* 187:363 */       System.out.println(CommonUtil.getStackTrace(e));
/* 188:    */     }
/* 189:366 */     return isApplicable;
/* 190:    */   }
/* 191:    */   
/* 192:    */   public boolean isRunTrigger()
/* 193:    */     throws Exception
/* 194:    */   {
/* 195:382 */     return (isRunAllTriggers()) && (isRunCurrentTrigger());
/* 196:    */   }
/* 197:    */   
/* 198:    */   public boolean isRunAllTriggers()
/* 199:    */     throws Exception
/* 200:    */   {
/* 201:399 */     this.logger.debug("isRunAllTriggers()Start");
/* 202:    */     
/* 203:    */ 
/* 204:402 */     boolean isRunAllTriggers = false;
/* 205:403 */     String runAllTriggersRegistrySetting = "";
/* 206:    */     
/* 207:    */ 
/* 208:    */ 
/* 209:    */ 
/* 210:    */ 
/* 211:    */ 
/* 212:410 */     initApplicationUtilServices();
/* 213:411 */     runAllTriggersRegistrySetting = this.applicationUtil.getRegistrySetting("/OpenPages/Custom Deliverables/Triggers/All Triggers/Run All Triggers");
/* 214:    */     
/* 215:413 */     isRunAllTriggers = CommonUtil.isEqualIgnoreCase(runAllTriggersRegistrySetting, "true");
/* 216:    */     
/* 217:    */ 
/* 218:    */ 
/* 219:417 */     this.logger.debug("Run All Triggers Registry Setting: " + runAllTriggersRegistrySetting);
/* 220:    */     
/* 221:419 */     this.logger.debug("Is Run All Triggers: " + isRunAllTriggers);
/* 222:    */     
/* 223:421 */     this.logger.debug("isRunAllTriggers()End");
/* 224:422 */     return isRunAllTriggers;
/* 225:    */   }
/* 226:    */   
/* 227:    */   public boolean isRunCurrentTrigger()
/* 228:    */     throws Exception
/* 229:    */   {
/* 230:439 */     this.logger.debug("isRunCurrentTrigger()Start");
/* 231:    */     
/* 232:    */ 
/* 233:442 */     boolean isRunTrigger = false;
/* 234:    */     
/* 235:444 */     String triggerName = "";
/* 236:445 */     String triggerRunRegistrySetting = "";
/* 237:    */     
/* 238:    */ 
/* 239:    */ 
/* 240:    */ 
/* 241:    */ 
/* 242:451 */     triggerName = getTriggerAttrbuteValue("trigger.name");
/* 243:452 */     triggerRunRegistrySetting = this.applicationUtil.getRegistrySetting(getTriggerAttrbuteValue("run.trigger.registry.setting"), "false");
/* 244:    */     
/* 245:454 */     isRunTrigger = CommonUtil.isEqualIgnoreCase(triggerRunRegistrySetting, "true");
/* 246:    */     
/* 247:    */ 
/* 248:457 */     this.logger.debug("Trigger Run Registry Setting: " + triggerRunRegistrySetting);
/* 249:    */     
/* 250:459 */     this.logger.debug("The trigger " + triggerName + " will be executed: " + isRunTrigger);
/* 251:    */     
/* 252:    */ 
/* 253:462 */     this.logger.debug("isRunCurrentTrigger()End");
/* 254:    */     
/* 255:464 */     return isRunTrigger;
/* 256:    */   }
/* 257:    */   
/* 258:    */   public String getTriggerAttrbuteValue(String propertyName)
/* 259:    */     throws Exception
/* 260:    */   {
/* 261:485 */     String attributeValue = this.grcTriggerUtil.getAttributeName(getAttributes(), propertyName);
/* 262:    */     
/* 263:    */ 
/* 264:488 */     return CommonUtil.isNotNullOrEmpty(attributeValue) ? attributeValue.trim() : attributeValue;
/* 265:    */   }
/* 266:    */   
/* 267:    */   public void setTriggerAttrbuteValue(String triggerAttrName, String propertyValue)
/* 268:    */     throws Exception
/* 269:    */   {
/* 270:511 */     String triggerAttr = getTriggerAttrbuteValue("trigger.name");
/* 271:512 */     triggerAttr = triggerAttr + "." + triggerAttrName;
/* 272:    */     
/* 273:514 */     this.logger.debug("Setting Trigger Attribute as: " + getTriggerAttrbuteValue(new StringBuilder().append("trigger.name.").append(triggerAttrName).toString()));
/* 274:    */     
/* 275:516 */     this.logger.debug("Setting Trigger Attribute value as: " + propertyValue);
/* 276:517 */     getAttributes().put(triggerAttr, propertyValue);
/* 277:518 */     this.logger.debug("Trigger Attribute Name: " + triggerAttr);
/* 278:519 */     this.logger.debug("Getting the set Trigger Attribute as: " + getTriggerAttrbuteValue(triggerAttr));
/* 279:    */   }
/* 280:    */   
/* 281:    */   public List<String> getParsedTriggerAttrbuteValue(String propertyName)
/* 282:    */     throws Exception
/* 283:    */   {
/* 284:543 */     String attributeValue = getTriggerAttrbuteValue(propertyName);
/* 285:    */     
/* 286:545 */     return CommonUtil.isNotNullOrEmpty(attributeValue) ? CommonUtil.parseCommaDelimitedValues(attributeValue) : new ArrayList();
/* 287:    */   }
/* 288:    */   
/* 289:    */   public void initServcies()
/* 290:    */   {
/* 291:553 */     initLogServices();
/* 292:554 */     initGRCTriggerUtilServices();
/* 293:    */   }
/* 294:    */   
/* 295:    */   public void initLogServices()
/* 296:    */   {
/* 297:567 */     this.logger = OPSServiceFactory.getLoggerUtil().getExtLogger();
/* 298:    */   }
/* 299:    */   
/* 300:    */   public void initGRCTriggerUtilServices()
/* 301:    */   {
/* 302:580 */     this.grcTriggerUtil = OPSServiceFactory.getGRCTriggerUtil();
/* 303:    */   }
/* 304:    */   
/* 305:    */   public void initGRCValidationTriggerUtilServices()
/* 306:    */   {
/* 307:594 */     this.grcValidationTriggerUtil = (CommonUtil.isObjectNotNull(this.grcValidationTriggerUtil) ? this.grcValidationTriggerUtil : OPSServiceFactory.getGRCValidationTriggerUtil());
/* 308:    */   }
/* 309:    */   
/* 310:    */   public void initGRCObjectUtilServices()
/* 311:    */   {
/* 312:609 */     this.grcObjectUtil = OPSServiceFactory.getGRCObjectUtil();
/* 313:    */   }
/* 314:    */   
/* 315:    */   public void initFieldUtilServices()
/* 316:    */   {
/* 317:622 */     this.fieldUtil = OPSServiceFactory.getFieldUtil();
/* 318:    */   }
/* 319:    */   
/* 320:    */   public void initApplicationUtilServices()
/* 321:    */   {
/* 322:635 */     this.applicationUtil = OPSServiceFactory.getApplicationUtil();
/* 323:    */   }
/* 324:    */   
/* 325:    */   public void prepareContextForTrigger(AbstractEvent event)
/* 326:    */     throws Exception
/* 327:    */   {
/* 328:649 */     this.logger.debug("Prepare Context for Trigger START");
/* 329:    */     
/* 330:651 */     ContextWrapper contextWrapper = null;
/* 331:652 */     ServiceFactoryProxy serviceFactoryProxy = null;
/* 332:653 */     ApplicationContext applicationContextProvider = null;
/* 333:    */     
/* 334:655 */     contextWrapper = new ContextWrapper();
/* 335:656 */     contextWrapper.setContext(event.getContext());
/* 336:    */     
/* 337:658 */     this.logger.debug("Is Application Context null: " + CommonUtil.isObjectNull(applicationContextProvider));
/* 338:    */     
/* 339:660 */     this.logger.debug("Is Context null: " + CommonUtil.isObjectNull(event.getContext()));
/* 340:661 */     serviceFactoryProxy = (ServiceFactoryProxy)ApplicationContextUtils.getBean("serviceFactoryProxy");
/* 341:    */     
/* 342:663 */     serviceFactoryProxy.setContextWrapper(contextWrapper);
/* 343:    */     
/* 344:665 */     this.logger.debug("Prepare Context for Trigger END");
/* 345:    */   }
/* 346:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.triggers.rule.BaseTriggerRule
 * JD-Core Version:    0.7.0.1
 */