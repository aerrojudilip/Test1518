/*   1:    */ package com.ibm.openpages.ext.tss.triggers.rule;
/*   2:    */ 
/*   3:    */ import com.ibm.openpages.api.metadata.ITypeDefinition;
/*   4:    */ import com.ibm.openpages.api.metadata.Id;
/*   5:    */ import com.ibm.openpages.api.resource.IGRCObject;
/*   6:    */ import com.ibm.openpages.api.trigger.events.AssociateResourceEvent;
/*   7:    */ import com.ibm.openpages.api.trigger.events.DisassociateResourceEvent;
/*   8:    */ import com.ibm.openpages.ext.tss.service.IGRCObjectUtil;
/*   9:    */ import com.ibm.openpages.ext.tss.service.util.CommonUtil;
/*  10:    */ import java.util.List;
/*  11:    */ import org.apache.commons.logging.Log;
/*  12:    */ 
/*  13:    */ public class ParentChildContentTypeMatchRule
/*  14:    */   extends BaseTriggerRule
/*  15:    */ {
/*  16:    */   public boolean isApplicable(AssociateResourceEvent associateResourceEvent)
/*  17:    */   {
/*  18: 74 */     boolean isApplicable = false;
/*  19: 75 */     Id childObjectId = null;
/*  20: 76 */     Id parentObjectId = null;
/*  21: 77 */     IGRCObject object = null;
/*  22: 78 */     IGRCObject parentObject = null;
/*  23: 81 */     if (super.isApplicable(associateResourceEvent)) {
/*  24:    */       try
/*  25:    */       {
/*  26: 85 */         prepareContextForTrigger(associateResourceEvent);
/*  27: 88 */         if (isRunTrigger())
/*  28:    */         {
/*  29: 93 */           initGRCObjectUtilServices();
/*  30: 94 */           childObjectId = associateResourceEvent.getChild();
/*  31: 95 */           parentObjectId = associateResourceEvent.getParent();
/*  32:    */           
/*  33:    */ 
/*  34: 98 */           this.logger.debug("Child Object Id: " + childObjectId);
/*  35: 99 */           this.logger.debug("Parent Object Id: " + parentObjectId);
/*  36:    */           
/*  37:    */ 
/*  38:102 */           object = this.grcObjectUtil.getObjectFromId(childObjectId);
/*  39:103 */           parentObject = this.grcObjectUtil.getObjectFromId(parentObjectId);
/*  40:    */           
/*  41:    */ 
/*  42:106 */           this.logger.debug("Child Object Id: " + object.getName());
/*  43:107 */           this.logger.debug("Parent Object Id: " + parentObject.getName());
/*  44:110 */           if (parentObject.isFolder()) {
/*  45:111 */             isApplicable = false;
/*  46:    */           } else {
/*  47:115 */             isApplicable = (evaluateParent(parentObject)) && (evaluateChild(object));
/*  48:    */           }
/*  49:    */         }
/*  50:    */       }
/*  51:    */       catch (Exception ex)
/*  52:    */       {
/*  53:120 */         this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(AssociateResourceEvent)" + CommonUtil.getStackTrace(ex));
/*  54:121 */         isApplicable = false;
/*  55:    */       }
/*  56:    */     }
/*  57:125 */     return isApplicable;
/*  58:    */   }
/*  59:    */   
/*  60:    */   public boolean isApplicable(DisassociateResourceEvent disassociateResourceEvent)
/*  61:    */   {
/*  62:142 */     boolean isApplicable = false;
/*  63:143 */     Id childObjectId = null;
/*  64:144 */     Id parentObjectId = null;
/*  65:145 */     IGRCObject object = null;
/*  66:146 */     IGRCObject parentObject = null;
/*  67:149 */     if (super.isApplicable(disassociateResourceEvent)) {
/*  68:    */       try
/*  69:    */       {
/*  70:153 */         prepareContextForTrigger(disassociateResourceEvent);
/*  71:156 */         if (isRunTrigger())
/*  72:    */         {
/*  73:161 */           initGRCObjectUtilServices();
/*  74:162 */           childObjectId = disassociateResourceEvent.getChild();
/*  75:163 */           parentObjectId = disassociateResourceEvent.getParent();
/*  76:    */           
/*  77:    */ 
/*  78:166 */           this.logger.debug("Child Object Id: " + childObjectId);
/*  79:167 */           this.logger.debug("Parent Object Id: " + parentObjectId);
/*  80:    */           
/*  81:    */ 
/*  82:170 */           object = this.grcObjectUtil.getObjectFromId(childObjectId);
/*  83:171 */           parentObject = this.grcObjectUtil.getObjectFromId(parentObjectId);
/*  84:    */           
/*  85:    */ 
/*  86:174 */           this.logger.debug("Child Object Id: " + object.getName());
/*  87:175 */           this.logger.debug("Parent Object Id: " + parentObject.getName());
/*  88:178 */           if (parentObject.isFolder()) {
/*  89:179 */             isApplicable = false;
/*  90:    */           } else {
/*  91:183 */             isApplicable = (evaluateParent(parentObject)) && (evaluateChild(object));
/*  92:    */           }
/*  93:    */         }
/*  94:    */       }
/*  95:    */       catch (Exception ex)
/*  96:    */       {
/*  97:188 */         this.logger.error("EXCEPTION!!!!!!!!!!!!!!! isApplicable(DisassociateResourceEvent)" + CommonUtil.getStackTrace(ex));
/*  98:189 */         isApplicable = false;
/*  99:    */       }
/* 100:    */     }
/* 101:193 */     return isApplicable;
/* 102:    */   }
/* 103:    */   
/* 104:    */   private boolean evaluateParent(IGRCObject object)
/* 105:    */     throws Exception
/* 106:    */   {
/* 107:208 */     boolean isApplicable = false;
/* 108:    */     
/* 109:210 */     ITypeDefinition def = null;
/* 110:211 */     List<String> objectTypes = null;
/* 111:212 */     String contentTypes = "";
/* 112:    */     
/* 113:    */ 
/* 114:215 */     contentTypes = getTriggerAttrbuteValue("parent.content.type.names");
/* 115:216 */     if ((contentTypes == null) || (contentTypes.isEmpty())) {
/* 116:217 */       throw new IllegalStateException("Null content type names attribute");
/* 117:    */     }
/* 118:220 */     objectTypes = CommonUtil.parseDelimitedValues(contentTypes, ",");
/* 119:221 */     this.logger.debug("Object Types: " + objectTypes);
/* 120:    */     
/* 121:223 */     def = object.getType();
/* 122:225 */     for (String contentType : objectTypes)
/* 123:    */     {
/* 124:227 */       this.logger.debug("Content Types: " + contentType);
/* 125:228 */       this.logger.debug("Object Type Def: " + def.getName());
/* 126:230 */       if (def.getName().equals(contentType))
/* 127:    */       {
/* 128:232 */         isApplicable = true;
/* 129:233 */         break;
/* 130:    */       }
/* 131:236 */       isApplicable = false;
/* 132:    */     }
/* 133:240 */     return isApplicable;
/* 134:    */   }
/* 135:    */   
/* 136:    */   private boolean evaluateChild(IGRCObject object)
/* 137:    */     throws Exception
/* 138:    */   {
/* 139:256 */     boolean isApplicable = false;
/* 140:    */     
/* 141:258 */     ITypeDefinition def = null;
/* 142:259 */     List<String> objectTypes = null;
/* 143:260 */     String contentTypes = "";
/* 144:    */     
/* 145:    */ 
/* 146:263 */     contentTypes = getTriggerAttrbuteValue("child.content.type.names");
/* 147:265 */     if ((contentTypes == null) || (contentTypes.isEmpty())) {
/* 148:266 */       throw new IllegalStateException("Null child content type names attribute");
/* 149:    */     }
/* 150:269 */     objectTypes = CommonUtil.parseDelimitedValues(contentTypes, ",");
/* 151:270 */     this.logger.debug("Object Types: " + objectTypes);
/* 152:    */     
/* 153:272 */     def = object.getType();
/* 154:274 */     for (String contentType : objectTypes)
/* 155:    */     {
/* 156:276 */       this.logger.debug("Content Types: " + contentType);
/* 157:277 */       this.logger.debug("Object Type Def: " + def.getName());
/* 158:279 */       if (def.getName().equals(contentType))
/* 159:    */       {
/* 160:281 */         isApplicable = true;
/* 161:282 */         break;
/* 162:    */       }
/* 163:285 */       isApplicable = false;
/* 164:    */     }
/* 165:289 */     return isApplicable;
/* 166:    */   }
/* 167:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.triggers.rule.ParentChildContentTypeMatchRule
 * JD-Core Version:    0.7.0.1
 */