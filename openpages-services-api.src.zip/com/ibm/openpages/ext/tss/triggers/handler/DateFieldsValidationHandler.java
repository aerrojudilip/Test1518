/*   1:    */ package com.ibm.openpages.ext.tss.triggers.handler;
/*   2:    */ 
/*   3:    */ import com.ibm.openpages.api.resource.IGRCObject;
/*   4:    */ import com.ibm.openpages.api.trigger.events.CreateResourceEvent;
/*   5:    */ import com.ibm.openpages.api.trigger.events.UpdateResourceEvent;
/*   6:    */ import com.ibm.openpages.ext.tss.service.IApplicationUtil;
/*   7:    */ import com.ibm.openpages.ext.tss.service.IFieldUtil;
/*   8:    */ import com.ibm.openpages.ext.tss.service.constants.Comparators;
/*   9:    */ import com.ibm.openpages.ext.tss.service.util.CommonUtil;
/*  10:    */ import com.ibm.openpages.ext.tss.service.util.DateUtil;
/*  11:    */ import java.util.ArrayList;
/*  12:    */ import java.util.List;
/*  13:    */ import org.apache.commons.logging.Log;
/*  14:    */ 
/*  15:    */ public class DateFieldsValidationHandler
/*  16:    */   extends BaseEventHandler
/*  17:    */ {
/*  18:    */   public boolean handleEvent(CreateResourceEvent event)
/*  19:    */   {
/*  20: 77 */     this.logger.debug("handleEvent(CreateResourceEvent)Start");
/*  21:    */     
/*  22:    */ 
/*  23: 80 */     boolean isValid = true;
/*  24: 81 */     int index = 0;
/*  25: 82 */     String sourceDateValue = "";
/*  26: 83 */     String compareDateValue = "";
/*  27: 84 */     String errorText = "com.openpages.trigger.common.exception";
/*  28:    */     
/*  29: 86 */     IGRCObject object = null;
/*  30: 87 */     String errorMessage = null;
/*  31: 88 */     String formattedErrorMessage = null;
/*  32: 89 */     List<String> errorMessagesList = null;
/*  33: 90 */     List<String> placeHolderValues = null;
/*  34: 91 */     List<String> comparatorsList = null;
/*  35: 92 */     List<String> sourceDateFieldsList = null;
/*  36: 93 */     List<String> compareDateFieldsList = null;
/*  37: 94 */     List<String> validationErrorMessagesList = null;
/*  38: 95 */     List<String> messagesPlaceHolderValuesList = null;
/*  39: 96 */     List<String> msgsPlaceHolderValuesInfoList = null;
/*  40: 97 */     List<List<?>> combinedList = null;
/*  41:    */     try
/*  42:    */     {
/*  43:108 */       initFieldUtilServices();
/*  44:109 */       initApplicationUtilServices();
/*  45:110 */       object = (IGRCObject)event.getResource();
/*  46:111 */       combinedList = new ArrayList();
/*  47:112 */       errorMessagesList = new ArrayList();
/*  48:113 */       comparatorsList = CommonUtil.parseCommaDelimitedValues(getTriggerAttrbuteValue("compare.date.fields"));
/*  49:114 */       sourceDateFieldsList = CommonUtil.parseCommaDelimitedValues(getTriggerAttrbuteValue("source.date.fields"));
/*  50:115 */       compareDateFieldsList = CommonUtil.parseCommaDelimitedValues(getTriggerAttrbuteValue("compare.date.fields"));
/*  51:116 */       validationErrorMessagesList = CommonUtil.parseCommaDelimitedValues(getTriggerAttrbuteValue("date.validation.error.messages"));
/*  52:117 */       messagesPlaceHolderValuesList = CommonUtil.parsePipeDelimitedValues(getTriggerAttrbuteValue("date.validation.error.messages.place.holder.values"));
/*  53:118 */       msgsPlaceHolderValuesInfoList = CommonUtil.parsePipeDelimitedValues(getTriggerAttrbuteValue("date.validation.error.message.place.holder.values.info"));
/*  54:    */       
/*  55:120 */       combinedList.add(comparatorsList);
/*  56:121 */       combinedList.add(sourceDateFieldsList);
/*  57:122 */       combinedList.add(compareDateFieldsList);
/*  58:123 */       combinedList.add(validationErrorMessagesList);
/*  59:124 */       combinedList.add(messagesPlaceHolderValuesList);
/*  60:125 */       combinedList.add(msgsPlaceHolderValuesInfoList);
/*  61:    */       
/*  62:    */ 
/*  63:128 */       this.logger.debug("Object Name: " + object.getName());
/*  64:129 */       this.logger.debug("Comparators List: " + comparatorsList);
/*  65:130 */       this.logger.debug("Source Date Fields List: " + sourceDateFieldsList);
/*  66:131 */       this.logger.debug("Comapre Date Fields List: " + compareDateFieldsList);
/*  67:132 */       this.logger.debug("Validation Error Message List: " + validationErrorMessagesList);
/*  68:133 */       this.logger.debug("Message Place Holder Values List: " + messagesPlaceHolderValuesList);
/*  69:134 */       this.logger.debug("Message Place holder Values Info List: " + msgsPlaceHolderValuesInfoList);
/*  70:135 */       this.logger.debug("Is Lists of the same size: " + CommonUtil.isListsOfTheSameSize(combinedList));
/*  71:137 */       if (CommonUtil.isListsOfTheSameSize(combinedList)) {
/*  72:139 */         for (String sourceDateField : sourceDateFieldsList)
/*  73:    */         {
/*  74:141 */           placeHolderValues = null;
/*  75:142 */           sourceDateValue = getDateFieldValue(object, sourceDateField);
/*  76:143 */           compareDateValue = getDateFieldValue(object, (String)compareDateFieldsList.get(index));
/*  77:144 */           isValid = DateUtil.compareDates(sourceDateField, compareDateValue, Comparators.valueOf((String)comparatorsList.get(index)));
/*  78:    */           
/*  79:146 */           this.logger.debug("The value of " + sourceDateField + " = " + sourceDateValue);
/*  80:147 */           this.logger.debug("The value of " + (String)compareDateFieldsList.get(index) + " = " + compareDateValue);
/*  81:148 */           this.logger.debug("The value of " + (String)comparatorsList.get(index) + " = " + Comparators.valueOf((String)comparatorsList.get(index)));
/*  82:149 */           this.logger.debug("Is " + sourceDateValue + " " + (String)comparatorsList.get(index) + " " + compareDateValue + "? " + isValid);
/*  83:151 */           if (!isValid)
/*  84:    */           {
/*  85:153 */             errorMessage = (String)validationErrorMessagesList.get(index);
/*  86:154 */             placeHolderValues = getPlaceHolderValues(object, (String)messagesPlaceHolderValuesList.get(index), (String)msgsPlaceHolderValuesInfoList.get(index));
/*  87:155 */             formattedErrorMessage = this.applicationUtil.getApplicationString(errorMessage, placeHolderValues);
/*  88:156 */             errorMessagesList.add(formattedErrorMessage);
/*  89:    */           }
/*  90:159 */           index++;
/*  91:    */         }
/*  92:    */       }
/*  93:163 */       if (CommonUtil.isListNotNullOrEmpty(errorMessagesList)) {
/*  94:164 */         this.logger.debug("Error Messages List: " + errorMessagesList);
/*  95:    */       }
/*  96:    */     }
/*  97:    */     catch (Exception e)
/*  98:    */     {
/*  99:168 */       this.logger.error("EXCEPTION!!!!!!!!!!!!!!! handleEvent(CreateResourceEvent)" + CommonUtil.getStackTrace(e));
/* 100:169 */       throwException(errorText, new ArrayList(), e, event.getContext());
/* 101:    */     }
/* 102:172 */     this.logger.debug("handleEvent(CreateResourceEvent)End");
/* 103:173 */     return true;
/* 104:    */   }
/* 105:    */   
/* 106:    */   public boolean handleEvent(UpdateResourceEvent event)
/* 107:    */   {
/* 108:191 */     this.logger.debug("handleEvent(CreateResourceEvent)Start");
/* 109:    */     
/* 110:    */ 
/* 111:194 */     boolean isValid = true;
/* 112:195 */     int index = 0;
/* 113:196 */     String sourceDateValue = "";
/* 114:197 */     String compareDateValue = "";
/* 115:198 */     String errorText = "com.openpages.trigger.common.exception";
/* 116:    */     
/* 117:200 */     IGRCObject object = null;
/* 118:201 */     String errorMessage = null;
/* 119:202 */     String formattedErrorMessage = null;
/* 120:203 */     List<String> checkForList = null;
/* 121:204 */     List<String> errorMessagesList = null;
/* 122:205 */     List<String> placeHolderValues = null;
/* 123:206 */     List<String> comparatorsList = null;
/* 124:207 */     List<String> sourceDateFieldsList = null;
/* 125:208 */     List<String> compareDateFieldsList = null;
/* 126:209 */     List<String> allComparatorsList = null;
/* 127:210 */     List<String> allSourceDateFieldsList = null;
/* 128:211 */     List<String> allCompareDateFieldsList = null;
/* 129:212 */     List<String> validationErrorMessagesList = null;
/* 130:213 */     List<String> messagesPlaceHolderValuesList = null;
/* 131:214 */     List<String> msgsPlaceHolderValuesInfoList = null;
/* 132:215 */     List<List<?>> combinedList = null;
/* 133:    */     try
/* 134:    */     {
/* 135:226 */       initFieldUtilServices();
/* 136:227 */       initApplicationUtilServices();
/* 137:228 */       object = (IGRCObject)event.getResource();
/* 138:229 */       combinedList = new ArrayList();
/* 139:230 */       errorMessagesList = new ArrayList();
/* 140:231 */       checkForList = CommonUtil.parseCommaDelimitedValues(getTriggerAttrbuteValue("check.for"));
/* 141:232 */       allComparatorsList = CommonUtil.parsePipeDelimitedValues(getTriggerAttrbuteValue("compare.date.fields"));
/* 142:233 */       allSourceDateFieldsList = CommonUtil.parsePipeDelimitedValues(getTriggerAttrbuteValue("source.date.fields"));
/* 143:234 */       allCompareDateFieldsList = CommonUtil.parsePipeDelimitedValues(getTriggerAttrbuteValue("compare.date.fields"));
/* 144:235 */       validationErrorMessagesList = CommonUtil.parseCommaDelimitedValues(getTriggerAttrbuteValue("date.validation.error.messages"));
/* 145:236 */       messagesPlaceHolderValuesList = CommonUtil.parsePipeDelimitedValues(getTriggerAttrbuteValue("date.validation.error.messages.place.holder.values"));
/* 146:237 */       msgsPlaceHolderValuesInfoList = CommonUtil.parsePipeDelimitedValues(getTriggerAttrbuteValue("date.validation.error.message.place.holder.values.info"));
/* 147:    */       
/* 148:239 */       combinedList.add(checkForList);
/* 149:240 */       combinedList.add(allComparatorsList);
/* 150:241 */       combinedList.add(allSourceDateFieldsList);
/* 151:242 */       combinedList.add(allCompareDateFieldsList);
/* 152:243 */       combinedList.add(validationErrorMessagesList);
/* 153:244 */       combinedList.add(messagesPlaceHolderValuesList);
/* 154:245 */       combinedList.add(msgsPlaceHolderValuesInfoList);
/* 155:    */       
/* 156:    */ 
/* 157:248 */       this.logger.debug("Object Name: " + object.getName());
/* 158:249 */       this.logger.debug("Check For List: " + checkForList);
/* 159:250 */       this.logger.debug("All Comparators List: " + allComparatorsList);
/* 160:251 */       this.logger.debug("All Source Date Fields List: " + allSourceDateFieldsList);
/* 161:252 */       this.logger.debug("All Comapre Date Fields List: " + allCompareDateFieldsList);
/* 162:253 */       this.logger.debug("Validation Error Message List: " + validationErrorMessagesList);
/* 163:254 */       this.logger.debug("Message Place Holder Values List: " + messagesPlaceHolderValuesList);
/* 164:255 */       this.logger.debug("Message Place holder Values Info List: " + msgsPlaceHolderValuesInfoList);
/* 165:256 */       this.logger.debug("Is Lists of the same size: " + CommonUtil.isListsOfTheSameSize(combinedList));
/* 166:258 */       if (CommonUtil.isListsOfTheSameSize(combinedList)) {
/* 167:260 */         for (String sourceDateField : allSourceDateFieldsList)
/* 168:    */         {
/* 169:262 */           placeHolderValues = null;
/* 170:263 */           comparatorsList = CommonUtil.parseCommaDelimitedValues((String)allComparatorsList.get(index));
/* 171:264 */           sourceDateFieldsList = CommonUtil.parseCommaDelimitedValues(sourceDateField);
/* 172:265 */           compareDateFieldsList = CommonUtil.parseCommaDelimitedValues((String)allCompareDateFieldsList.get(index));
/* 173:    */           
/* 174:267 */           combinedList = new ArrayList();
/* 175:268 */           combinedList.add(comparatorsList);
/* 176:269 */           combinedList.add(sourceDateFieldsList);
/* 177:270 */           combinedList.add(compareDateFieldsList);
/* 178:    */           
/* 179:272 */           this.logger.debug("Comparators List: " + comparatorsList);
/* 180:273 */           this.logger.debug("Source Date Fields List: " + sourceDateFieldsList);
/* 181:274 */           this.logger.debug("Comparators List: " + compareDateFieldsList);
/* 182:    */           int dateIndex;
/* 183:276 */           if (CommonUtil.isListsOfTheSameSize(combinedList))
/* 184:    */           {
/* 185:278 */             dateIndex = 0;
/* 186:280 */             for (String sourceDate : sourceDateFieldsList)
/* 187:    */             {
/* 188:282 */               sourceDateValue = getDateFieldValue(object, sourceDate);
/* 189:283 */               compareDateValue = getDateFieldValue(object, (String)compareDateFieldsList.get(dateIndex));
/* 190:284 */               isValid = DateUtil.compareDates(sourceDateValue, compareDateValue, Comparators.valueOf((String)comparatorsList.get(index)));
/* 191:    */               
/* 192:286 */               this.logger.debug("The value of " + sourceDateField + " = " + sourceDateValue);
/* 193:287 */               this.logger.debug("The value of " + (String)allCompareDateFieldsList.get(index) + " = " + compareDateValue);
/* 194:288 */               this.logger.debug("The value of " + (String)allComparatorsList.get(index) + " = " + Comparators.valueOf((String)allComparatorsList.get(index)));
/* 195:289 */               this.logger.debug("Is " + sourceDateValue + " " + (String)allComparatorsList.get(index) + " " + compareDateValue + "? " + isValid);
/* 196:291 */               if (!isValid)
/* 197:    */               {
/* 198:293 */                 errorMessage = (String)validationErrorMessagesList.get(index);
/* 199:294 */                 placeHolderValues = getPlaceHolderValues(object, (String)messagesPlaceHolderValuesList.get(index), (String)msgsPlaceHolderValuesInfoList.get(index));
/* 200:295 */                 formattedErrorMessage = this.applicationUtil.getApplicationString(errorMessage, placeHolderValues);
/* 201:296 */                 errorMessagesList.add(formattedErrorMessage);
/* 202:    */               }
/* 203:299 */               dateIndex++;
/* 204:    */             }
/* 205:    */           }
/* 206:303 */           index++;
/* 207:    */         }
/* 208:    */       }
/* 209:307 */       if (CommonUtil.isListNotNullOrEmpty(errorMessagesList)) {
/* 210:308 */         this.logger.debug("Error Messages List: " + errorMessagesList);
/* 211:    */       }
/* 212:    */     }
/* 213:    */     catch (Exception e)
/* 214:    */     {
/* 215:312 */       this.logger.error("EXCEPTION!!!!!!!!!!!!!!! handleEvent(CreateResourceEvent)" + CommonUtil.getStackTrace(e));
/* 216:313 */       throwException(errorText, new ArrayList(), e, event.getContext());
/* 217:    */     }
/* 218:316 */     this.logger.debug("handleEvent(CreateResourceEvent)End");
/* 219:317 */     return true;
/* 220:    */   }
/* 221:    */   
/* 222:    */   private String getDateFieldValue(IGRCObject object, String fieldInfo)
/* 223:    */     throws Exception
/* 224:    */   {
/* 225:322 */     return CommonUtil.isEqualIgnoreCase("CURRENT_DATE", fieldInfo) ? DateUtil.getCurrentDateAsString() : this.fieldUtil.getFieldValueAsString(object, fieldInfo);
/* 226:    */   }
/* 227:    */   
/* 228:    */   private List<String> getPlaceHolderValues(IGRCObject object, String placeHolderValues, String placeHolderValueInfo)
/* 229:    */     throws Exception
/* 230:    */   {
/* 231:327 */     this.logger.debug("getPlaceHolderValues() Start");
/* 232:    */     
/* 233:    */ 
/* 234:330 */     int index = 0;
/* 235:331 */     List<String> placeHolderValueList = null;
/* 236:332 */     List<String> placeHolderValueInfoList = null;
/* 237:333 */     List<String> placeHolderValuesList = null;
/* 238:    */     
/* 239:    */ 
/* 240:336 */     placeHolderValuesList = new ArrayList();
/* 241:337 */     placeHolderValueList = CommonUtil.parseCommaDelimitedValues(placeHolderValues);
/* 242:338 */     placeHolderValueInfoList = CommonUtil.parseCommaDelimitedValues(placeHolderValueInfo);
/* 243:    */     
/* 244:340 */     this.logger.debug("Place Holder Values List: " + placeHolderValueList);
/* 245:341 */     this.logger.debug("Place Holder Value Info List: " + placeHolderValueInfoList);
/* 246:343 */     for (String placeHolderValue : placeHolderValueList) {
/* 247:345 */       if (CommonUtil.isEqualIgnoreCase((String)placeHolderValueInfoList.get(index), "Constant")) {
/* 248:347 */         placeHolderValuesList.add(placeHolderValue);
/* 249:    */       } else {
/* 250:351 */         placeHolderValuesList.add(this.fieldUtil.getFieldValueAsString(object, placeHolderValue));
/* 251:    */       }
/* 252:    */     }
/* 253:355 */     this.logger.debug("Place Hodler Values List: " + placeHolderValuesList);
/* 254:356 */     this.logger.debug("getPlaceHolderValues() End");
/* 255:357 */     return placeHolderValuesList;
/* 256:    */   }
/* 257:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.triggers.handler.DateFieldsValidationHandler
 * JD-Core Version:    0.7.0.1
 */