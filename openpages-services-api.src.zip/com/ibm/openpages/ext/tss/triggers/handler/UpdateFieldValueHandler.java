/*   1:    */ package com.ibm.openpages.ext.tss.triggers.handler;
/*   2:    */ 
/*   3:    */ import com.ibm.openpages.api.resource.IGRCObject;
/*   4:    */ import com.ibm.openpages.api.trigger.events.CreateResourceEvent;
/*   5:    */ import com.ibm.openpages.api.trigger.events.UpdateResourceEvent;
/*   6:    */ import com.ibm.openpages.ext.tss.service.IFieldUtil;
/*   7:    */ import com.ibm.openpages.ext.tss.service.util.CommonUtil;
/*   8:    */ import java.util.ArrayList;
/*   9:    */ import java.util.List;
/*  10:    */ import org.apache.commons.logging.Log;
/*  11:    */ 
/*  12:    */ public class UpdateFieldValueHandler
/*  13:    */   extends BaseEventHandler
/*  14:    */ {
/*  15:    */   public boolean handleEvent(CreateResourceEvent event)
/*  16:    */   {
/*  17: 70 */     this.logger.debug("handleEvent(CreateResourceEvent)Start");
/*  18:    */     
/*  19:    */ 
/*  20: 73 */     int count = 0;
/*  21: 74 */     boolean isCheckForEmpty = false;
/*  22: 75 */     String fieldToBeUpdated = "";
/*  23: 76 */     String errorText = "com.openpages.trigger.common.exception";
/*  24: 77 */     String fieldValueToBeUpdated = "";
/*  25:    */     
/*  26: 79 */     IGRCObject object = null;
/*  27: 80 */     List<String> fieldsToBeUpdatedList = null;
/*  28: 81 */     List<String> fieldValuesToBeUpdatedList = null;
/*  29:    */     try
/*  30:    */     {
/*  31: 92 */       initFieldUtilServices();
/*  32: 93 */       object = (IGRCObject)event.getResource();
/*  33: 94 */       fieldToBeUpdated = getTriggerAttrbuteValue("field.to.be.updated");
/*  34: 95 */       fieldValueToBeUpdated = getTriggerAttrbuteValue("field.value.to.be.updated");
/*  35: 96 */       fieldsToBeUpdatedList = CommonUtil.parseDelimitedValues(fieldToBeUpdated, ",");
/*  36: 97 */       isCheckForEmpty = CommonUtil.isEqualIgnoreCase(getTriggerAttrbuteValue("check.field.is.empty"), "true");
/*  37: 98 */       fieldValuesToBeUpdatedList = CommonUtil.parseDelimitedValues(fieldValueToBeUpdated, ",");
/*  38:    */       
/*  39:    */ 
/*  40:101 */       this.logger.debug("Object Name: " + object.getName());
/*  41:102 */       this.logger.debug("Fields to be updated: " + fieldToBeUpdated);
/*  42:103 */       this.logger.debug("Field values to be updated: " + fieldValueToBeUpdated);
/*  43:104 */       this.logger.debug("Fields to be updated List: " + fieldsToBeUpdatedList);
/*  44:105 */       this.logger.debug("Field values to be updated List: " + fieldValuesToBeUpdatedList);
/*  45:106 */       this.logger.debug("Fields and Field values list size the same: " + (fieldsToBeUpdatedList.size() == fieldValuesToBeUpdatedList.size()));
/*  46:113 */       if (CommonUtil.isListsOfTheSameSize(fieldsToBeUpdatedList, fieldValuesToBeUpdatedList)) {
/*  47:119 */         for (String fieldInfo : fieldsToBeUpdatedList) {
/*  48:121 */           if ((!isCheckForEmpty) || ((isCheckForEmpty) && (CommonUtil.isNotNullOrEmpty(this.fieldUtil.getFieldValueAsString(object, fieldInfo)))))
/*  49:    */           {
/*  50:124 */             this.fieldUtil.setFieldValue(object, fieldInfo, (String)fieldValuesToBeUpdatedList.get(count));
/*  51:125 */             count++;
/*  52:    */           }
/*  53:    */         }
/*  54:    */       }
/*  55:    */     }
/*  56:    */     catch (Exception e)
/*  57:    */     {
/*  58:132 */       this.logger.error("EXCEPTION!!!!!!!!!!!!!!! handleEvent(CreateResourceEvent)" + CommonUtil.getStackTrace(e));
/*  59:133 */       throwException(errorText, new ArrayList(), e, event.getContext());
/*  60:    */     }
/*  61:136 */     this.logger.debug("handleEvent(CreateResourceEvent)End");
/*  62:137 */     return true;
/*  63:    */   }
/*  64:    */   
/*  65:    */   public boolean handleEvent(UpdateResourceEvent event)
/*  66:    */   {
/*  67:155 */     this.logger.debug("handleEvent(UpdateResourceEvent)Start");
/*  68:    */     
/*  69:    */ 
/*  70:158 */     int count = 0;
/*  71:159 */     String fieldToBeUpdated = "";
/*  72:160 */     String errorText = "com.openpages.trigger.common.exception";
/*  73:161 */     String fieldValueToBeUpdate = "";
/*  74:    */     
/*  75:163 */     IGRCObject object = null;
/*  76:164 */     List<String> fieldsToBeUpdatedList = null;
/*  77:165 */     List<String> fieldValuesToBeUpdatedList = null;
/*  78:    */     try
/*  79:    */     {
/*  80:176 */       initFieldUtilServices();
/*  81:177 */       object = (IGRCObject)event.getResource();
/*  82:178 */       fieldToBeUpdated = getTriggerAttrbuteValue("field.to.be.updated");
/*  83:179 */       fieldValueToBeUpdate = getTriggerAttrbuteValue("field.value.to.be.updated");
/*  84:180 */       fieldsToBeUpdatedList = CommonUtil.parseDelimitedValues(fieldToBeUpdated, ",");
/*  85:181 */       fieldValuesToBeUpdatedList = CommonUtil.parseDelimitedValues(fieldValueToBeUpdate, ",");
/*  86:    */       
/*  87:    */ 
/*  88:184 */       this.logger.debug("Object Name: " + object.getName());
/*  89:185 */       this.logger.debug("Fields to be updated: " + fieldToBeUpdated);
/*  90:186 */       this.logger.debug("Field values to be updated: " + fieldValueToBeUpdate);
/*  91:187 */       this.logger.debug("Fields to be updated List: " + fieldsToBeUpdatedList);
/*  92:188 */       this.logger.debug("Field values to be updated List: " + fieldValuesToBeUpdatedList);
/*  93:189 */       this.logger.debug("Fields and Field values list size the same: " + (fieldsToBeUpdatedList.size() == fieldValuesToBeUpdatedList.size()));
/*  94:196 */       if (CommonUtil.isListsOfTheSameSize(fieldsToBeUpdatedList, fieldValuesToBeUpdatedList)) {
/*  95:202 */         for (String fieldsInfo : fieldsToBeUpdatedList)
/*  96:    */         {
/*  97:204 */           this.fieldUtil.setFieldValue(object, fieldsInfo, (String)fieldValuesToBeUpdatedList.get(count));
/*  98:205 */           count++;
/*  99:    */         }
/* 100:    */       }
/* 101:    */     }
/* 102:    */     catch (Exception e)
/* 103:    */     {
/* 104:210 */       this.logger.error("EXCEPTION!!!!!!!!!!!!!!! handleEvent(UpdateResourceEvent)" + CommonUtil.getStackTrace(e));
/* 105:211 */       throwException(errorText, new ArrayList(), e, event.getContext());
/* 106:    */     }
/* 107:214 */     this.logger.debug("handleEvent(UpdateResourceEvent)End");
/* 108:215 */     return true;
/* 109:    */   }
/* 110:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.triggers.handler.UpdateFieldValueHandler
 * JD-Core Version:    0.7.0.1
 */