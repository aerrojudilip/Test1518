/*   1:    */ package com.ibm.openpages.ext.tss.triggers.handler;
/*   2:    */ 
/*   3:    */ import com.ibm.openpages.api.resource.IGRCObject;
/*   4:    */ import com.ibm.openpages.api.trigger.events.CreateResourceEvent;
/*   5:    */ import com.ibm.openpages.api.trigger.events.UpdateResourceEvent;
/*   6:    */ import com.ibm.openpages.ext.tss.service.IFieldUtil;
/*   7:    */ import com.ibm.openpages.ext.tss.service.util.CommonUtil;
/*   8:    */ import java.util.ArrayList;
/*   9:    */ import java.util.List;
/*  10:    */ import org.apache.commons.logging.Log;
/*  11:    */ 
/*  12:    */ public class UpdateTargetValueFromSourceHandler
/*  13:    */   extends BaseEventHandler
/*  14:    */ {
/*  15:    */   public boolean handleEvent(CreateResourceEvent event)
/*  16:    */   {
/*  17: 71 */     this.logger.debug("handleEvent(CreateResourceEvent)");
/*  18:    */     
/*  19:    */ 
/*  20: 74 */     int count = 0;
/*  21: 75 */     String errorText = "com.openpages.trigger.common.exception";
/*  22:    */     
/*  23: 77 */     List<List<?>> listCheckLists = null;
/*  24: 78 */     List<String> resetSourceList = null;
/*  25: 79 */     List<String> sourceFieldsList = null;
/*  26: 80 */     List<String> destinationFieldsList = null;
/*  27:    */     
/*  28: 82 */     IGRCObject object = null;
/*  29:    */     try
/*  30:    */     {
/*  31: 93 */       initFieldUtilServices();
/*  32: 94 */       object = (IGRCObject)event.getResource();
/*  33: 95 */       listCheckLists = new ArrayList();
/*  34: 96 */       resetSourceList = CommonUtil.parseDelimitedValues(getTriggerAttrbuteValue("reset.sources"), ",");
/*  35:    */       
/*  36: 98 */       sourceFieldsList = CommonUtil.parseDelimitedValues(getTriggerAttrbuteValue("source.fields"), ",");
/*  37:    */       
/*  38:100 */       destinationFieldsList = CommonUtil.parseDelimitedValues(getTriggerAttrbuteValue("destination.fields"), ",");
/*  39:    */       
/*  40:    */ 
/*  41:    */ 
/*  42:104 */       this.logger.debug("Object Name: " + object.getName());
/*  43:105 */       this.logger.debug("Source Fields: " + getTriggerAttrbuteValue("source.fields"));
/*  44:106 */       this.logger.debug("Reset Source: " + getTriggerAttrbuteValue("reset.sources"));
/*  45:107 */       this.logger.debug("SDestination Fields: " + getTriggerAttrbuteValue("destination.fields"));
/*  46:108 */       this.logger.debug("Source Fields List: " + sourceFieldsList);
/*  47:109 */       this.logger.debug("Destination Fields List: " + destinationFieldsList);
/*  48:110 */       this.logger.debug("Reset Source List: " + resetSourceList);
/*  49:    */       
/*  50:112 */       listCheckLists.add(resetSourceList);
/*  51:113 */       listCheckLists.add(sourceFieldsList);
/*  52:114 */       listCheckLists.add(destinationFieldsList);
/*  53:116 */       if (CommonUtil.isListsOfTheSameSize(listCheckLists)) {
/*  54:118 */         for (String sourceField : sourceFieldsList)
/*  55:    */         {
/*  56:121 */           this.logger.debug("Source Field Info: " + sourceField);
/*  57:122 */           this.logger.debug("Source Field Value: " + this.fieldUtil.getFieldValueAsString(object, sourceField));
/*  58:123 */           this.logger.debug("Destination Field: " + (String)destinationFieldsList.get(count));
/*  59:124 */           this.logger.debug("Reset Source: " + (String)resetSourceList.get(count));
/*  60:126 */           if (CommonUtil.isEqualIgnoreCase("System:Name", sourceField)) {
/*  61:127 */             this.fieldUtil.setFieldValue(object, (String)destinationFieldsList.get(count), object.getName());
/*  62:128 */           } else if (CommonUtil.isNotNullOrEmpty(this.fieldUtil.getFieldValueAsString(object, sourceField))) {
/*  63:129 */             this.fieldUtil.setFieldValue(object, (String)destinationFieldsList.get(count), this.fieldUtil.getFieldValueAsString(object, sourceField));
/*  64:    */           }
/*  65:132 */           if (CommonUtil.isEqual((String)resetSourceList.get(count), "true")) {
/*  66:133 */             this.fieldUtil.setFieldValueWithNull(object, sourceField);
/*  67:    */           }
/*  68:135 */           count++;
/*  69:    */         }
/*  70:    */       }
/*  71:    */     }
/*  72:    */     catch (Exception e)
/*  73:    */     {
/*  74:140 */       this.logger.error("EXCEPTION!!!!!!!!!!!!!!! handleEvent(CreateResourceEvent)" + CommonUtil.getStackTrace(e));
/*  75:141 */       throwException(errorText, new ArrayList(), e, event.getContext());
/*  76:    */     }
/*  77:144 */     this.logger.debug("handleEvent(CreateResourceEvent)");
/*  78:145 */     return true;
/*  79:    */   }
/*  80:    */   
/*  81:    */   public boolean handleEvent(UpdateResourceEvent event)
/*  82:    */   {
/*  83:164 */     this.logger.debug("handleEvent(UpdateResourceEvent)");
/*  84:    */     
/*  85:    */ 
/*  86:167 */     int count = 0;
/*  87:168 */     String errorText = "com.openpages.trigger.common.exception";
/*  88:    */     
/*  89:170 */     List<List<?>> listCheckLists = null;
/*  90:171 */     List<String> resetSourceList = null;
/*  91:172 */     List<String> sourceFieldsList = null;
/*  92:173 */     List<String> destinationFieldsList = null;
/*  93:    */     
/*  94:175 */     IGRCObject object = null;
/*  95:    */     try
/*  96:    */     {
/*  97:186 */       initFieldUtilServices();
/*  98:187 */       object = (IGRCObject)event.getResource();
/*  99:188 */       listCheckLists = new ArrayList();
/* 100:189 */       resetSourceList = CommonUtil.parseDelimitedValues(getTriggerAttrbuteValue("reset.sources"), ",");
/* 101:    */       
/* 102:191 */       sourceFieldsList = CommonUtil.parseDelimitedValues(getTriggerAttrbuteValue("source.fields"), ",");
/* 103:    */       
/* 104:193 */       destinationFieldsList = CommonUtil.parseDelimitedValues(getTriggerAttrbuteValue("destination.fields"), ",");
/* 105:    */       
/* 106:    */ 
/* 107:    */ 
/* 108:197 */       this.logger.debug("Object Name: " + object.getName());
/* 109:198 */       this.logger.debug("Source Fields: " + getTriggerAttrbuteValue("source.fields"));
/* 110:199 */       this.logger.debug("Reset Source: " + getTriggerAttrbuteValue("reset.sources"));
/* 111:200 */       this.logger.debug("SDestination Fields: " + getTriggerAttrbuteValue("destination.fields"));
/* 112:201 */       this.logger.debug("Source Fields List: " + sourceFieldsList);
/* 113:202 */       this.logger.debug("Destination Fields List: " + destinationFieldsList);
/* 114:203 */       this.logger.debug("Reset Source List: " + resetSourceList);
/* 115:    */       
/* 116:205 */       listCheckLists.add(resetSourceList);
/* 117:206 */       listCheckLists.add(sourceFieldsList);
/* 118:207 */       listCheckLists.add(destinationFieldsList);
/* 119:209 */       if (CommonUtil.isListsOfTheSameSize(listCheckLists)) {
/* 120:211 */         for (String sourceField : sourceFieldsList)
/* 121:    */         {
/* 122:214 */           this.logger.debug("Source Field Info: " + sourceField);
/* 123:215 */           this.logger.debug("Source Field Value: " + this.fieldUtil.getFieldValueAsString(object, sourceField));
/* 124:216 */           this.logger.debug("Destination Field: " + (String)destinationFieldsList.get(count));
/* 125:217 */           this.logger.debug("Reset Source: " + (String)resetSourceList.get(count));
/* 126:219 */           if (CommonUtil.isEqualIgnoreCase("System:Name", sourceField)) {
/* 127:220 */             this.fieldUtil.setFieldValue(object, (String)destinationFieldsList.get(count), object.getName());
/* 128:221 */           } else if (CommonUtil.isNotNullOrEmpty(this.fieldUtil.getFieldValueAsString(object, sourceField))) {
/* 129:222 */             this.fieldUtil.setFieldValue(object, (String)destinationFieldsList.get(count), this.fieldUtil.getFieldValueAsString(object, sourceField));
/* 130:    */           }
/* 131:225 */           if (CommonUtil.isEqual((String)resetSourceList.get(count), "true")) {
/* 132:226 */             this.fieldUtil.setFieldValueWithNull(object, sourceField);
/* 133:    */           }
/* 134:228 */           count++;
/* 135:    */         }
/* 136:    */       }
/* 137:    */     }
/* 138:    */     catch (Exception e)
/* 139:    */     {
/* 140:233 */       this.logger.error("EXCEPTION!!!!!!!!!!!!!!! handleEvent(UpdateResourceEvent)" + CommonUtil.getStackTrace(e));
/* 141:234 */       throwException(errorText, new ArrayList(), e, event.getContext());
/* 142:    */     }
/* 143:237 */     this.logger.debug("handleEvent(UpdateResourceEvent)");
/* 144:238 */     return true;
/* 145:    */   }
/* 146:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.triggers.handler.UpdateTargetValueFromSourceHandler
 * JD-Core Version:    0.7.0.1
 */