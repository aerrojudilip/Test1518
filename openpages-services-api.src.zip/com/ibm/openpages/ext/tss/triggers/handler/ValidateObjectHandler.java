/*   1:    */ package com.ibm.openpages.ext.tss.triggers.handler;
/*   2:    */ 
/*   3:    */ import com.ibm.openpages.api.metadata.DataType;
/*   4:    */ import com.ibm.openpages.api.metadata.Id;
/*   5:    */ import com.ibm.openpages.api.resource.IDateField;
/*   6:    */ import com.ibm.openpages.api.resource.IField;
/*   7:    */ import com.ibm.openpages.api.resource.IGRCObject;
/*   8:    */ import com.ibm.openpages.api.service.IResourceService;
/*   9:    */ import com.ibm.openpages.api.service.IServiceFactory;
/*  10:    */ import com.ibm.openpages.api.trigger.events.AbstractResourceEvent;
/*  11:    */ import com.ibm.openpages.api.trigger.events.TriggerEventType;
/*  12:    */ import com.ibm.openpages.ext.tss.service.ICognosUtil;
/*  13:    */ import com.ibm.openpages.ext.tss.service.IFieldUtil;
/*  14:    */ import com.ibm.openpages.ext.tss.service.IGRCObjectSearchUtil;
/*  15:    */ import com.ibm.openpages.ext.tss.service.beans.CompareFieldValuesOnObjectInfo;
/*  16:    */ import com.ibm.openpages.ext.tss.service.config.OPSServiceFactory;
/*  17:    */ import com.ibm.openpages.ext.tss.service.util.CommonUtil;
/*  18:    */ import com.ibm.openpages.ext.tss.service.util.DateUtil;
/*  19:    */ import com.ibm.openpages.ext.tss.service.util.NumericUtil;
/*  20:    */ import com.openpages.sdk.repository.Resource;
/*  21:    */ import com.openpages.sdk.repository.ResourceId;
/*  22:    */ import com.openpages.sdk.trigger.TriggerContext;
/*  23:    */ import com.openpages.sdk.trigger.object.TriggerConstants.ResourceTriggerConstants;
/*  24:    */ import java.util.ArrayList;
/*  25:    */ import java.util.HashMap;
/*  26:    */ import java.util.List;
/*  27:    */ import java.util.Map;
/*  28:    */ import org.apache.commons.logging.Log;
/*  29:    */ import org.jdom.Element;
/*  30:    */ import org.jdom.Namespace;
/*  31:    */ 
/*  32:    */ public class ValidateObjectHandler
/*  33:    */   extends BaseEventHandler
/*  34:    */ {
/*  35:    */   public CompareFieldValuesOnObjectInfo processObjectInformation(IServiceFactory serviceFactory)
/*  36:    */     throws Exception
/*  37:    */   {
/*  38:104 */     this.logger.debug("processObjectInformation()Start");
/*  39:    */     
/*  40:    */ 
/*  41:107 */     boolean isCompareOnObject = false;
/*  42:108 */     boolean isCompareOnParent = false;
/*  43:109 */     boolean isCompareParentChild = false;
/*  44:110 */     boolean isCompareFieldToField = false;
/*  45:111 */     boolean isPlaceHolderValueFromParent = false;
/*  46:112 */     boolean isParentValuesFromCognosReport = false;
/*  47:113 */     boolean isCompareHeirarchyParentToChild = false;
/*  48:    */     
/*  49:115 */     IGRCObject object = null;
/*  50:116 */     CompareFieldValuesOnObjectInfo objectsInfoDTO = null;
/*  51:117 */     CompareFieldValuesOnObjectInfo childObjectInfoDTO = null;
/*  52:    */     
/*  53:    */ 
/*  54:120 */     isCompareOnObject = CommonUtil.isEqualIgnoreCase("true", getTriggerAttrbuteValue("is.compare.on.object"));
/*  55:121 */     isCompareOnParent = CommonUtil.isEqualIgnoreCase("true", getTriggerAttrbuteValue("is.compare.on.object.parent"));
/*  56:122 */     isCompareParentChild = CommonUtil.isEqualIgnoreCase("true", getTriggerAttrbuteValue("is.compare.parent.child"));
/*  57:123 */     isCompareFieldToField = CommonUtil.isEqualIgnoreCase("true", getTriggerAttrbuteValue("is.compare.field.to.field"));
/*  58:124 */     isCompareHeirarchyParentToChild = CommonUtil.isEqualIgnoreCase("true", getTriggerAttrbuteValue("is.compare.heirarchy.parent.to.child"));
/*  59:    */     
/*  60:126 */     isPlaceHolderValueFromParent = CommonUtil.isEqualIgnoreCase("true", getTriggerAttrbuteValue("is.get.place.holder.values.from.parent"));
/*  61:    */     
/*  62:128 */     isParentValuesFromCognosReport = CommonUtil.isEqualIgnoreCase("true", getTriggerAttrbuteValue("is.get.parent.values.from.cognos.report"));
/*  63:    */     
/*  64:    */ 
/*  65:131 */     this.logger.debug("Is Compare On Object: " + isCompareOnObject);
/*  66:132 */     this.logger.debug("Is Compare On Parent: " + isCompareOnParent);
/*  67:133 */     this.logger.debug("Is Compare Parent Child: " + isCompareParentChild);
/*  68:134 */     this.logger.debug("Is Compare Field to Field: " + isCompareFieldToField);
/*  69:135 */     this.logger.debug("Is Compare Field to Field: " + isCompareFieldToField);
/*  70:136 */     this.logger.debug("Is Compare Heirarchy Parent To Child: " + isCompareHeirarchyParentToChild);
/*  71:137 */     this.logger.debug("Is Parent values from cognos report: " + isParentValuesFromCognosReport);
/*  72:139 */     if (isCompareOnObject)
/*  73:    */     {
/*  74:141 */       objectsInfoDTO = new CompareFieldValuesOnObjectInfo();
/*  75:    */       
/*  76:143 */       this.logger.debug("Check For in Object: " + getTriggerAttrbuteValue("check.for.in.object"));
/*  77:144 */       this.logger.debug("Comparator in Object: " + getTriggerAttrbuteValue("comparator.in.object"));
/*  78:145 */       this.logger.debug("Comparator exception in Object ALL: " + getTriggerAttrbuteValue("compare.exception.for.all"));
/*  79:    */       
/*  80:147 */       this.logger.debug("Comparator exception in Object ANY: " + getTriggerAttrbuteValue("compare.exceptions.for.any"));
/*  81:    */       
/*  82:149 */       this.logger.debug("Field in Object to compare: " + getTriggerAttrbuteValue("fields.in.object.for.compare"));
/*  83:150 */       this.logger.debug("Fields to be Compared in Object: " + getTriggerAttrbuteValue("fields.to.be.compared.in.object"));
/*  84:    */       
/*  85:152 */       this.logger.debug("Fields Values to be Compared in Object: " + getTriggerAttrbuteValue("field.values.to.be.compared.in.object"));
/*  86:    */       
/*  87:    */ 
/*  88:155 */       objectsInfoDTO.setObject(object);
/*  89:156 */       objectsInfoDTO.setCompareOnObject(isCompareOnObject);
/*  90:157 */       objectsInfoDTO.setCompareOnParent(isCompareOnParent);
/*  91:158 */       objectsInfoDTO.setCompareFieldToField(isCompareFieldToField);
/*  92:159 */       objectsInfoDTO.setPlaceHolderValueFromParent(isPlaceHolderValueFromParent);
/*  93:160 */       objectsInfoDTO.setParentValuesFromCognosReport(isParentValuesFromCognosReport);
/*  94:161 */       objectsInfoDTO.setCheckForInObject(getTriggerAttrbuteValue("check.for.in.object"));
/*  95:162 */       objectsInfoDTO.setComparatorList(CommonUtil.parseDelimitedValues(getTriggerAttrbuteValue("comparator.in.object"), ","));
/*  96:    */       
/*  97:164 */       objectsInfoDTO.setCompareExceptionInObjectForAll(getTriggerAttrbuteValue("compare.exception.for.all"));
/*  98:165 */       objectsInfoDTO.setCompareExceptionInObjectForAny(getTriggerAttrbuteValue("compare.exceptions.for.any"));
/*  99:166 */       objectsInfoDTO.setFieldsInObjectForCompareList(CommonUtil.parseDelimitedValues(getTriggerAttrbuteValue("fields.in.object.for.compare"), ","));
/* 100:    */       
/* 101:168 */       objectsInfoDTO.setFieldsToBeComparedInObjectList(CommonUtil.parseDelimitedValues(getTriggerAttrbuteValue("fields.to.be.compared.in.object"), ","));
/* 102:    */       
/* 103:170 */       objectsInfoDTO.setFieldValuesToBeComparedInObjectList(CommonUtil.parseDelimitedValues(getTriggerAttrbuteValue("field.values.to.be.compared.in.object"), ","));
/* 104:    */       
/* 105:    */ 
/* 106:173 */       objectsInfoDTO.setCompareExceptionPlaceHolderValuesForAll(CommonUtil.parseDelimitedValues(getTriggerAttrbuteValue("compare.exceptions.place.holder.for.all"), ","));
/* 107:    */       
/* 108:175 */       objectsInfoDTO.setCompareExceptionPlaceHolderValuesForAny(CommonUtil.parseDelimitedValues(getTriggerAttrbuteValue("compare.exceptions.place.holder.for.any"), ","));
/* 109:    */     }
/* 110:177 */     else if (isCompareOnParent)
/* 111:    */     {
/* 112:179 */       objectsInfoDTO = new CompareFieldValuesOnObjectInfo();
/* 113:180 */       objectsInfoDTO.setCompareOnObject(isCompareOnObject);
/* 114:181 */       objectsInfoDTO.setCompareOnParent(isCompareOnParent);
/* 115:182 */       objectsInfoDTO.setCompareParentChild(isCompareParentChild);
/* 116:183 */       objectsInfoDTO.setCompareFieldToField(isCompareFieldToField);
/* 117:184 */       objectsInfoDTO.setPlaceHolderValueFromParent(isPlaceHolderValueFromParent);
/* 118:185 */       objectsInfoDTO.setParentValuesFromCognosReport(isParentValuesFromCognosReport);
/* 119:186 */       objectsInfoDTO.setCompareHeirarchyParentToChild(isCompareHeirarchyParentToChild);
/* 120:187 */       objectsInfoDTO.setCheckForInObject(getTriggerAttrbuteValue("check.for.in.parent.object"));
/* 121:188 */       objectsInfoDTO.setComparatorList(CommonUtil.parseDelimitedValues(getTriggerAttrbuteValue("comparator.in.parent.object"), ","));
/* 122:    */       
/* 123:190 */       objectsInfoDTO.setCompareExceptionInObjectForAll(getTriggerAttrbuteValue("compare.exception.for.all"));
/* 124:191 */       objectsInfoDTO.setCompareExceptionInObjectForAny(getTriggerAttrbuteValue("compare.exceptions.for.any"));
/* 125:192 */       objectsInfoDTO.setFieldsInObjectForCompareList(CommonUtil.parseDelimitedValues(getTriggerAttrbuteValue("fields.in.parent.object.for.compare"), ","));
/* 126:    */       
/* 127:194 */       objectsInfoDTO.setFieldsToBeComparedInObjectList(CommonUtil.parseDelimitedValues(getTriggerAttrbuteValue("fields.to.be.compared.in.parent.object"), ","));
/* 128:    */       
/* 129:196 */       objectsInfoDTO.setFieldValuesToBeComparedInObjectList(CommonUtil.parseDelimitedValues(getTriggerAttrbuteValue("field.values.to.be.compared.in.parent.object"), ","));
/* 130:    */       
/* 131:    */ 
/* 132:    */ 
/* 133:200 */       objectsInfoDTO.setCompareExceptionPlaceHolderValuesForAll(CommonUtil.parseDelimitedValues(getTriggerAttrbuteValue("compare.exceptions.place.holder.for.all"), ","));
/* 134:    */       
/* 135:202 */       objectsInfoDTO.setCompareExceptionPlaceHolderValuesForAny(CommonUtil.parseDelimitedValues(getTriggerAttrbuteValue("compare.exceptions.place.holder.for.any"), ","));
/* 136:    */     }
/* 137:204 */     else if (isCompareParentChild)
/* 138:    */     {
/* 139:206 */       objectsInfoDTO = new CompareFieldValuesOnObjectInfo();
/* 140:207 */       childObjectInfoDTO = new CompareFieldValuesOnObjectInfo();
/* 141:    */       
/* 142:209 */       childObjectInfoDTO.setObject(object);
/* 143:210 */       childObjectInfoDTO.setCompareFieldToField(isCompareFieldToField);
/* 144:211 */       childObjectInfoDTO.setCheckForInObject(getTriggerAttrbuteValue("check.for.in.object"));
/* 145:212 */       childObjectInfoDTO.setComparatorList(CommonUtil.parseDelimitedValues(getTriggerAttrbuteValue("comparator.in.object"), ","));
/* 146:    */       
/* 147:214 */       childObjectInfoDTO.setCompareExceptionInObjectForAll(getTriggerAttrbuteValue("compare.exception.for.all"));
/* 148:    */       
/* 149:216 */       childObjectInfoDTO.setCompareExceptionInObjectForAny(getTriggerAttrbuteValue("compare.exceptions.for.any"));
/* 150:    */       
/* 151:218 */       childObjectInfoDTO.setFieldsInObjectForCompareList(CommonUtil.parseDelimitedValues(getTriggerAttrbuteValue("fields.in.object.for.compare"), ","));
/* 152:    */       
/* 153:220 */       childObjectInfoDTO.setFieldsToBeComparedInObjectList(CommonUtil.parseDelimitedValues(getTriggerAttrbuteValue("fields.to.be.compared.in.object"), ","));
/* 154:    */       
/* 155:222 */       childObjectInfoDTO.setFieldValuesToBeComparedInObjectList(CommonUtil.parseDelimitedValues(getTriggerAttrbuteValue("field.values.to.be.compared.in.object"), ","));
/* 156:    */       
/* 157:    */ 
/* 158:225 */       objectsInfoDTO.setCompareOnObject(isCompareOnObject);
/* 159:226 */       objectsInfoDTO.setCompareOnParent(isCompareOnParent);
/* 160:227 */       objectsInfoDTO.setCompareParentChild(isCompareParentChild);
/* 161:228 */       objectsInfoDTO.setCompareFieldToField(isCompareFieldToField);
/* 162:229 */       objectsInfoDTO.setChildFieldValuesOnObjectDTO(childObjectInfoDTO);
/* 163:230 */       objectsInfoDTO.setPlaceHolderValueFromParent(isPlaceHolderValueFromParent);
/* 164:231 */       objectsInfoDTO.setParentValuesFromCognosReport(isParentValuesFromCognosReport);
/* 165:232 */       objectsInfoDTO.setCompareHeirarchyParentToChild(isCompareHeirarchyParentToChild);
/* 166:233 */       objectsInfoDTO.setCompareExceptionPlaceHolderValuesForAll(CommonUtil.parseDelimitedValues(getTriggerAttrbuteValue("compare.exceptions.place.holder.for.all"), ","));
/* 167:    */       
/* 168:235 */       objectsInfoDTO.setCompareExceptionPlaceHolderValuesForAny(CommonUtil.parseDelimitedValues(getTriggerAttrbuteValue("compare.exceptions.place.holder.for.any"), ","));
/* 169:    */       
/* 170:237 */       objectsInfoDTO.setCheckForInObject(getTriggerAttrbuteValue("check.for.in.parent.object"));
/* 171:238 */       objectsInfoDTO.setComparatorList(CommonUtil.parseDelimitedValues(getTriggerAttrbuteValue("comparator.in.parent.object"), ","));
/* 172:    */       
/* 173:240 */       objectsInfoDTO.setCompareExceptionInObjectForAll(getTriggerAttrbuteValue("compare.exception.for.all"));
/* 174:241 */       objectsInfoDTO.setCompareExceptionInObjectForAny(getTriggerAttrbuteValue("compare.exceptions.for.any"));
/* 175:242 */       objectsInfoDTO.setFieldsInObjectForCompareList(CommonUtil.parseDelimitedValues(getTriggerAttrbuteValue("fields.in.object.for.compare"), ","));
/* 176:    */       
/* 177:244 */       objectsInfoDTO.setFieldsToBeComparedInObjectList(CommonUtil.parseDelimitedValues(getTriggerAttrbuteValue("fields.to.be.compared.in.parent.object"), ","));
/* 178:    */       
/* 179:246 */       objectsInfoDTO.setFieldValuesToBeComparedInObjectList(CommonUtil.parseDelimitedValues(getTriggerAttrbuteValue("field.values.to.be.compared.in.parent.object"), ","));
/* 180:    */     }
/* 181:252 */     this.logger.debug("Object Information from Trigger Config: " + objectsInfoDTO.toString());
/* 182:253 */     this.logger.debug("processObjectInformation()End");
/* 183:254 */     return objectsInfoDTO;
/* 184:    */   }
/* 185:    */   
/* 186:    */   public void getParentObject(AbstractResourceEvent event, IServiceFactory serviceFactory, CompareFieldValuesOnObjectInfo parentObjectsInfoDTO)
/* 187:    */     throws Exception
/* 188:    */   {
/* 189:260 */     this.logger.debug("getParentObject()Start");
/* 190:    */     
/* 191:262 */     Map<String, String[]> parametersMap = null;
/* 192:    */     
/* 193:264 */     this.logger.debug("Trigger Event: " + event.getTriggerEventType().toString());
/* 194:266 */     if (CommonUtil.isEqualIgnoreCase(TriggerEventType.CREATE_OBJECT.toString(), event.getTriggerEventType().toString()))
/* 195:    */     {
/* 196:267 */       parentObjectsInfoDTO.setObject(getImmediateParentForCreate());
/* 197:    */     }
/* 198:268 */     else if (CommonUtil.isEqualIgnoreCase(TriggerEventType.UPDATE_OBJECT.toString(), event.getTriggerEventType().toString()))
/* 199:    */     {
/* 200:271 */       this.logger.debug("Is Parent values from Cognos Report: " + parentObjectsInfoDTO.isParentValuesFromCognosReport());
/* 201:273 */       if (parentObjectsInfoDTO.isParentValuesFromCognosReport())
/* 202:    */       {
/* 203:275 */         parametersMap = new HashMap();
/* 204:    */         
/* 205:277 */         parametersMap.put("action_id", new String[] { ((IGRCObject)event.getResource()).getId().toString() });
/* 206:    */         
/* 207:279 */         getImmediateParentInformationFromCognosReport(parametersMap, parentObjectsInfoDTO);
/* 208:    */       }
/* 209:    */       else
/* 210:    */       {
/* 211:282 */         IGRCObject parentObject = getImmediateParentForUpdate(((IGRCObject)event.getResource()).getId().toString());
/* 212:283 */         parentObjectsInfoDTO.setObject(parentObject);
/* 213:    */       }
/* 214:    */     }
/* 215:287 */     this.logger.debug("getParentObject()End");
/* 216:    */   }
/* 217:    */   
/* 218:    */   public void processCompare(CompareFieldValuesOnObjectInfo compareDTO)
/* 219:    */     throws Exception
/* 220:    */   {
/* 221:292 */     this.logger.debug("processCompare()Start");
/* 222:    */     
/* 223:    */ 
/* 224:295 */     int index = 0;
/* 225:296 */     boolean returnValForAll = false;
/* 226:297 */     String checkFor = "";
/* 227:298 */     String compareExceptionForAny = null;
/* 228:299 */     String compareExceptionForAll = "";
/* 229:    */     
/* 230:301 */     IGRCObject childObject = null;
/* 231:302 */     IGRCObject parentObject = null;
/* 232:303 */     List<String> comparatorList = null;
/* 233:304 */     List<String> placeHolderValuesList = null;
/* 234:305 */     List<Object> exceptionArgumentsList = null;
/* 235:306 */     List<String> fieldsToBeComparedList = null;
/* 236:307 */     List<String> fieldsInObjectForCompareList = null;
/* 237:    */     
/* 238:    */ 
/* 239:310 */     this.logger.debug("Compare DTO Info: " + compareDTO);
/* 240:    */     
/* 241:312 */     this.logger.debug("Field Values in object compared: " + compareDTO.getFieldsInObjectForCompareList());
/* 242:313 */     this.logger.debug("Field Value to be compared: " + compareDTO.getFieldsToBeComparedInObjectList());
/* 243:314 */     this.logger.debug("Field Value to be compared: " + compareDTO.getFieldValuesToBeComparedInObjectList());
/* 244:316 */     if (compareDTO.isCompareParentChild())
/* 245:    */     {
/* 246:318 */       initFieldUtilServices();
/* 247:319 */       this.logger.debug("Parent Compare: ");
/* 248:321 */       if (compareDTO.isCompareHeirarchyParentToChild())
/* 249:    */       {
/* 250:323 */         this.logger.debug("Parent Compare: Heirarchy Parent to Child");
/* 251:324 */         parentObject = compareDTO.getObject();
/* 252:325 */         checkFor = compareDTO.getCheckForInObject();
/* 253:326 */         childObject = compareDTO.getChildFieldValuesOnObjectDTO().getObject();
/* 254:327 */         comparatorList = compareDTO.getComparatorList();
/* 255:328 */         compareExceptionForAll = compareDTO.getCompareExceptionInObjectForAll();
/* 256:329 */         compareExceptionForAny = compareDTO.getCompareExceptionInObjectForAny();
/* 257:330 */         fieldsToBeComparedList = compareDTO.getChildFieldValuesOnObjectDTO().getFieldsToBeComparedInObjectList();
/* 258:    */         
/* 259:332 */         fieldsInObjectForCompareList = compareDTO.isParentValuesFromCognosReport() ? compareDTO.getFieldValuesFromCognosToBeComparedInObjectList() : compareDTO.getFieldsInObjectForCompareList();
/* 260:    */       }
/* 261:335 */       else if (compareDTO.isParentValuesFromCognosReport())
/* 262:    */       {
/* 263:337 */         this.logger.debug("Parent Compare: Heirarchy not Parent to Child From Cognos");
/* 264:338 */         parentObject = compareDTO.getChildFieldValuesOnObjectDTO().getObject();
/* 265:339 */         checkFor = compareDTO.getChildFieldValuesOnObjectDTO().getCheckForInObject();
/* 266:340 */         childObject = compareDTO.getObject();
/* 267:341 */         comparatorList = compareDTO.getChildFieldValuesOnObjectDTO().getComparatorList();
/* 268:342 */         compareExceptionForAll = compareDTO.getChildFieldValuesOnObjectDTO().getCompareExceptionInObjectForAll();
/* 269:    */         
/* 270:344 */         compareExceptionForAny = compareDTO.getChildFieldValuesOnObjectDTO().getCompareExceptionInObjectForAny();
/* 271:    */         
/* 272:346 */         fieldsToBeComparedList = compareDTO.getChildFieldValuesOnObjectDTO().getFieldsInObjectForCompareList();
/* 273:347 */         fieldsInObjectForCompareList = compareDTO.getFieldValuesFromCognosToBeComparedInObjectList();
/* 274:    */       }
/* 275:    */       else
/* 276:    */       {
/* 277:350 */         this.logger.debug("Parent Compare: Heirarchy not Parent to Child");
/* 278:351 */         parentObject = compareDTO.getObject();
/* 279:352 */         checkFor = compareDTO.getChildFieldValuesOnObjectDTO().getCheckForInObject();
/* 280:353 */         childObject = compareDTO.getChildFieldValuesOnObjectDTO().getObject();
/* 281:354 */         comparatorList = compareDTO.getChildFieldValuesOnObjectDTO().getComparatorList();
/* 282:355 */         fieldsInObjectForCompareList = compareDTO.getChildFieldValuesOnObjectDTO().getFieldsInObjectForCompareList();
/* 283:    */         
/* 284:357 */         compareExceptionForAll = compareDTO.getChildFieldValuesOnObjectDTO().getCompareExceptionInObjectForAll();
/* 285:    */         
/* 286:359 */         compareExceptionForAny = compareDTO.getChildFieldValuesOnObjectDTO().getCompareExceptionInObjectForAny();
/* 287:    */         
/* 288:361 */         fieldsToBeComparedList = compareDTO.isParentValuesFromCognosReport() ? compareDTO.getFieldValuesFromCognosToBeComparedInObjectList() : compareDTO.getFieldsToBeComparedInObjectList();
/* 289:    */       }
/* 290:    */     }
/* 291:    */     else
/* 292:    */     {
/* 293:367 */       this.logger.debug("Object Compare: ");
/* 294:369 */       if (compareDTO.isCompareFieldToField())
/* 295:    */       {
/* 296:371 */         fieldsInObjectForCompareList = compareDTO.getFieldsInObjectForCompareList();
/* 297:372 */         fieldsToBeComparedList = compareDTO.getFieldsToBeComparedInObjectList();
/* 298:    */       }
/* 299:    */       else
/* 300:    */       {
/* 301:375 */         this.logger.debug("Field Values in object compared: " + compareDTO.getFieldsInObjectForCompareList());
/* 302:376 */         this.logger.debug("Field Value to be compared: " + compareDTO.getFieldValuesToBeComparedInObjectList());
/* 303:377 */         this.logger.debug("Field Value to be compared: " + compareDTO.getFieldValuesToBeComparedInObjectList());
/* 304:378 */         this.logger.debug("Object Compare Else compare section: ");
/* 305:379 */         fieldsInObjectForCompareList = compareDTO.getFieldsInObjectForCompareList();
/* 306:380 */         fieldsToBeComparedList = compareDTO.getFieldValuesToBeComparedInObjectList();
/* 307:    */       }
/* 308:383 */       childObject = compareDTO.getObject();
/* 309:384 */       parentObject = compareDTO.getObject();
/* 310:385 */       checkFor = compareDTO.getCheckForInObject();
/* 311:386 */       comparatorList = compareDTO.getComparatorList();
/* 312:387 */       compareExceptionForAll = compareDTO.getCompareExceptionInObjectForAll();
/* 313:388 */       compareExceptionForAny = compareDTO.getCompareExceptionInObjectForAny();
/* 314:    */     }
/* 315:391 */     this.logger.debug("Compare DTO: before Compare: " + compareDTO);
/* 316:392 */     this.logger.debug("Is Compare Parent Child: " + compareDTO.isCompareParentChild());
/* 317:393 */     this.logger.debug("Is Compare Heirarchy Parent To Child: " + compareDTO.isCompareHeirarchyParentToChild());
/* 318:394 */     this.logger.debug("Is Compare Field to Field: " + compareDTO.isCompareFieldToField());
/* 319:    */     
/* 320:396 */     this.logger.debug("Fields To Be Compared List: " + fieldsToBeComparedList);
/* 321:397 */     this.logger.debug("Fields In Object For Compare List: " + fieldsInObjectForCompareList);
/* 322:398 */     this.logger.debug("Child Object Name: " + (compareDTO.isParentValuesFromCognosReport() ? "Parent info from Cognos" : childObject.getName()));
/* 323:    */     
/* 324:400 */     this.logger.debug("Parent Object Name: " + parentObject.getName());
/* 325:    */     
/* 326:402 */     this.logger.debug("Is Info Available for Object Compare: " + compareDTO.isInfoAvailableForCompare());
/* 327:403 */     this.logger.debug("Is Info Available for Parent Child Compare: " + (compareDTO.isCompareParentChild() ? Boolean.valueOf(compareDTO.isInfoAvailableForParentChildCompare()) : "Not available for Parent child compare"));
/* 328:    */     
/* 329:405 */     this.logger.debug("Second Condition: " + ((compareDTO.isCompareParentChild()) && (compareDTO.isInfoAvailableForParentChildCompare())));
/* 330:408 */     if ((compareDTO.isInfoAvailableForCompare()) || ((compareDTO.isCompareParentChild()) && (compareDTO.isInfoAvailableForParentChildCompare())))
/* 331:    */     {
/* 332:411 */       returnValForAll = CommonUtil.isEqualIgnoreCase(checkFor, "all");
/* 333:412 */       this.logger.debug("Check For: " + checkFor);
/* 334:414 */       for (String fieldInfo : fieldsInObjectForCompareList)
/* 335:    */       {
/* 336:416 */         boolean flag = false;
/* 337:417 */         IField parentField = this.fieldUtil.getField(childObject, fieldInfo);
/* 338:418 */         String comparator = (String)comparatorList.get(index);
/* 339:419 */         String fieldValue = this.fieldUtil.getFieldValueAsString(parentField);
/* 340:420 */         String fieldValueToCompare = compareDTO.isCompareFieldToField() ? this.fieldUtil.getFieldValueAsString(parentObject, (String)fieldsToBeComparedList.get(index)) : (String)fieldsToBeComparedList.get(index);
/* 341:    */         
/* 342:    */ 
/* 343:    */ 
/* 344:424 */         this.logger.debug("Field Info: " + fieldInfo);
/* 345:425 */         this.logger.debug("Parent name: " + CommonUtil.isObjectNotNull(parentObject.getField(fieldInfo)));
/* 346:426 */         this.logger.debug("Parent name: " + parentObject.getName());
/* 347:427 */         this.logger.debug("Child name: " + (compareDTO.isParentValuesFromCognosReport() ? "Parent info from Cognos" : childObject.getName()));
/* 348:    */         
/* 349:429 */         this.logger.debug("All Flag: " + flag);
/* 350:430 */         this.logger.debug("Is " + fieldValue + " " + comparator + " " + fieldValueToCompare);
/* 351:431 */         this.logger.debug("Field Value To Compare: " + fieldValueToCompare);
/* 352:432 */         this.logger.debug("Is Compare Field to Field: " + compareDTO.isCompareFieldToField());
/* 353:433 */         this.logger.debug("Is Compare Field to Field: " + (compareDTO.isCompareFieldToField() ? (String)fieldsToBeComparedList.get(index) : "Value"));
/* 354:    */         
/* 355:435 */         this.logger.debug("Compare Field 1: " + this.fieldUtil.getField(childObject, fieldInfo));
/* 356:436 */         this.logger.debug("Compare Field 2: " + fieldValueToCompare);
/* 357:    */         
/* 358:438 */         this.logger.debug("Compare: " + this.fieldUtil.compareFields(this.fieldUtil.getField(childObject, fieldInfo), fieldValueToCompare, comparator));
/* 359:440 */         if (this.fieldUtil.compareFields(this.fieldUtil.getField(childObject, fieldInfo), fieldValueToCompare, comparator))
/* 360:    */         {
/* 361:443 */           if (CommonUtil.isEqualIgnoreCase(checkFor, "any"))
/* 362:    */           {
/* 363:445 */             exceptionArgumentsList = new ArrayList();
/* 364:446 */             compareDTO.setExceptionToThrow(compareExceptionForAny);
/* 365:447 */             placeHolderValuesList = compareDTO.isParentValuesFromCognosReport() ? fieldsToBeComparedList : compareDTO.getCompareExceptionPlaceHolderValuesForAny();
/* 366:    */             
/* 367:    */ 
/* 368:450 */             this.logger.debug("Compare Exception for Any: " + placeHolderValuesList);
/* 369:451 */             for (String exceptionFieldInfo : placeHolderValuesList) {
/* 370:453 */               if (CommonUtil.isEqualIgnoreCase(exceptionFieldInfo, parentField.getName()))
/* 371:    */               {
/* 372:454 */                 this.logger.debug("Condition 1");
/* 373:455 */                 exceptionArgumentsList.add(getFieldValueForExceptionPlaceHolder(parentField));
/* 374:    */               }
/* 375:456 */               else if ((compareDTO.isCompareFieldToField()) && (CommonUtil.isEqualIgnoreCase(exceptionFieldInfo, this.fieldUtil.getField(parentObject, (String)fieldsToBeComparedList.get(index)).getName())))
/* 376:    */               {
/* 377:459 */                 this.logger.debug("Condition 2");
/* 378:460 */                 exceptionArgumentsList.add(getFieldValueForExceptionPlaceHolder(this.fieldUtil.getField(parentObject, (String)fieldsToBeComparedList.get(index))));
/* 379:    */               }
/* 380:462 */               else if (CommonUtil.isEqualIgnoreCase(exceptionFieldInfo, (String)fieldsToBeComparedList.get(index)))
/* 381:    */               {
/* 382:464 */                 if (compareDTO.isParentValuesFromCognosReport())
/* 383:    */                 {
/* 384:466 */                   this.logger.debug("Condition 4");
/* 385:467 */                   exceptionArgumentsList.add(getFieldValueForExceptionPlaceHolder((String)fieldsToBeComparedList.get(index), parentField.getDataType()));
/* 386:    */                 }
/* 387:    */                 else
/* 388:    */                 {
/* 389:470 */                   this.logger.debug("Condition 3");
/* 390:471 */                   exceptionArgumentsList.add(fieldsToBeComparedList.get(index));
/* 391:    */                 }
/* 392:    */               }
/* 393:    */             }
/* 394:476 */             this.logger.debug("exceptionArgumentsList: " + exceptionArgumentsList);
/* 395:477 */             compareDTO.setExceptionArgumentsList(exceptionArgumentsList);
/* 396:478 */             break;
/* 397:    */           }
/* 398:479 */           if (CommonUtil.isEqualIgnoreCase(checkFor, "all")) {
/* 399:480 */             flag = true;
/* 400:    */           }
/* 401:    */         }
/* 402:484 */         if ((CommonUtil.isEqualIgnoreCase(checkFor, "all")) && (!flag))
/* 403:    */         {
/* 404:485 */           returnValForAll = false;
/* 405:486 */           break;
/* 406:    */         }
/* 407:488 */         index++;
/* 408:    */       }
/* 409:    */     }
/* 410:492 */     if (returnValForAll) {
/* 411:493 */       compareDTO.setExceptionToThrow(compareExceptionForAll);
/* 412:    */     }
/* 413:496 */     this.logger.debug("Process Compare Exception: " + compareDTO.getExceptionToThrow());
/* 414:497 */     this.logger.debug("processCompare()End");
/* 415:    */   }
/* 416:    */   
/* 417:    */   private String getFieldValueForExceptionPlaceHolder(IField field)
/* 418:    */     throws Exception
/* 419:    */   {
/* 420:502 */     this.logger.debug("getFieldValueForExceptionPlaceHolder()Start");
/* 421:    */     
/* 422:504 */     String placeHolderValue = "";
/* 423:506 */     if (DataType.DATE_TYPE.equals(field.getDataType())) {
/* 424:507 */       placeHolderValue = DateUtil.getDateInSpecificFormat(((IDateField)field).getValue(), "MMM dd, yyyy");
/* 425:    */     } else {
/* 426:509 */       placeHolderValue = this.fieldUtil.getFieldValueAsString(field);
/* 427:    */     }
/* 428:511 */     this.logger.debug("Place Holder Value: " + placeHolderValue);
/* 429:512 */     this.logger.debug("getFieldValueForExceptionPlaceHolder()End");
/* 430:513 */     return placeHolderValue;
/* 431:    */   }
/* 432:    */   
/* 433:    */   private String getFieldValueForExceptionPlaceHolder(String fieldValue, DataType dataType)
/* 434:    */     throws Exception
/* 435:    */   {
/* 436:518 */     this.logger.debug("getFieldValueForExceptionPlaceHolder()Start");
/* 437:    */     
/* 438:520 */     String placeHolderValue = "";
/* 439:522 */     if (DataType.DATE_TYPE.equals(dataType)) {
/* 440:523 */       placeHolderValue = DateUtil.getDateInSpecificFormat(DateUtil.convertDateStringToDate(fieldValue), "MMM dd, yyyy");
/* 441:    */     } else {
/* 442:525 */       placeHolderValue = fieldValue;
/* 443:    */     }
/* 444:527 */     this.logger.debug("Place Holder Value: " + placeHolderValue);
/* 445:528 */     this.logger.debug("getFieldValueForExceptionPlaceHolder()End");
/* 446:529 */     return placeHolderValue;
/* 447:    */   }
/* 448:    */   
/* 449:    */   private IGRCObject getImmediateParentForCreate()
/* 450:    */     throws Exception
/* 451:    */   {
/* 452:534 */     this.logger.debug("getImmediateParentIssueForCreate()Start");
/* 453:    */     
/* 454:    */ 
/* 455:537 */     long resourceId = 0L;
/* 456:538 */     IResourceService resourceService = null;
/* 457:    */     
/* 458:540 */     IGRCObject parentIssue = null;
/* 459:541 */     Resource primaryParentResource = null;
/* 460:    */     
/* 461:    */ 
/* 462:544 */     initServiceFactory();
/* 463:545 */     resourceService = this.serviceFactory.createResourceService();
/* 464:    */     
/* 465:547 */     primaryParentResource = (Resource)TriggerContext.get().getContextAttribute(TriggerConstants.ResourceTriggerConstants.CONTEXT_ATTR_PRIMARY_PARENT);
/* 466:    */     
/* 467:    */ 
/* 468:550 */     this.logger.debug("Is Primary Parent Resource null: " + CommonUtil.isObjectNotNull(primaryParentResource));
/* 469:551 */     this.logger.debug("Primary Parent Resource name: " + (CommonUtil.isObjectNotNull(primaryParentResource) ? primaryParentResource.getName() : "null"));
/* 470:    */     
/* 471:553 */     resourceId = primaryParentResource.getResourceId().getId();
/* 472:554 */     parentIssue = resourceService.getGRCObject(new Id(Long.toString(resourceId)));
/* 473:    */     
/* 474:556 */     this.logger.debug("Parent Issue: " + parentIssue.getName());
/* 475:557 */     this.logger.debug("getImmediateParentIssueForCreate()End");
/* 476:558 */     return parentIssue;
/* 477:    */   }
/* 478:    */   
/* 479:    */   private IGRCObject getImmediateParentForUpdate(String childObjectId)
/* 480:    */     throws Exception
/* 481:    */   {
/* 482:563 */     this.logger.debug("getImmediateParentIssueForUpdate()Start");
/* 483:    */     
/* 484:    */ 
/* 485:566 */     String objectHierarchyPath = "";
/* 486:    */     
/* 487:568 */     IGRCObject parentObject = null;
/* 488:569 */     List<String> objectHeirarchyList = null;
/* 489:    */     
/* 490:    */ 
/* 491:572 */     initGRCObjectSearchUtilServices();
/* 492:573 */     objectHierarchyPath = "SOXIssue,SOXTask";
/* 493:574 */     if (CommonUtil.isNotNullOrEmpty(objectHierarchyPath))
/* 494:    */     {
/* 495:576 */       objectHeirarchyList = CommonUtil.parseDelimitedValues(objectHierarchyPath, ",");
/* 496:577 */       this.logger.debug("Object Hierarchy List Before getting the entity: " + objectHeirarchyList);
/* 497:    */       
/* 498:579 */       parentObject = this.grcObjectSearchUtil.getImmediatePrimaryParentFromId(childObjectId, objectHeirarchyList, true);
/* 499:580 */       objectHierarchyPath = CommonUtil.isObjectNotNull(parentObject) ? null : objectHierarchyPath;
/* 500:    */       
/* 501:582 */       this.logger.debug("Object Hierarchy List: " + objectHeirarchyList);
/* 502:    */     }
/* 503:585 */     this.logger.debug("getImmediateParentIssueForUpdate()End");
/* 504:586 */     return parentObject;
/* 505:    */   }
/* 506:    */   
/* 507:    */   private String getImmediateParentInformationFromCognosReport(Map<String, String[]> parametersMap, CompareFieldValuesOnObjectInfo compareFieldValuesOnObjectDTO)
/* 508:    */     throws Exception
/* 509:    */   {
/* 510:593 */     this.logger.debug("getImmediateParentIssueForUpdate()Start");
/* 511:    */     
/* 512:595 */     ICognosUtil cognosUtil = OPSServiceFactory.getCognosUtil();
/* 513:    */     
/* 514:597 */     int index = 0;
/* 515:598 */     String valueFromParentIssue = null;
/* 516:599 */     String cognosReportPath = "";
/* 517:    */     
/* 518:601 */     List<Element> xmlValues = null;
/* 519:602 */     Namespace cognosNamespace = null;
/* 520:603 */     List<Element> cognosReportResults = null;
/* 521:604 */     List<String> cognosValuesPostions = null;
/* 522:605 */     List<String> fieldValuesFromCognosToBeComparedInObjectList = null;
/* 523:    */     
/* 524:    */ 
/* 525:608 */     cognosNamespace = Namespace.getNamespace("http://developer.cognos.com/schemas/xmldata/1/");
/* 526:609 */     cognosReportPath = getTriggerAttrbuteValue("parent.information.cognos.report.path");
/* 527:610 */     cognosReportResults = cognosUtil.getCognosResultsAsXMLRows(cognosReportPath, parametersMap);
/* 528:611 */     cognosValuesPostions = CommonUtil.parseDelimitedValues(getTriggerAttrbuteValue("positions.of.field.values.to.be.compared.in.parent.object"), ",");
/* 529:    */     
/* 530:    */ 
/* 531:    */ 
/* 532:615 */     this.logger.debug("Cognos Report Results is not null: " + CommonUtil.isObjectNotNull(cognosReportResults));
/* 533:616 */     this.logger.debug("Cognos Values Postions List not null or empty: " + CommonUtil.isListNotNullOrEmpty(cognosValuesPostions));
/* 534:617 */     this.logger.debug("Are the above two lists of same size: " + (cognosValuesPostions.size() == cognosReportResults.size()));
/* 535:620 */     if ((CommonUtil.isObjectNotNull(cognosReportResults)) && (CommonUtil.isListNotNullOrEmpty(cognosValuesPostions)) && (cognosValuesPostions.size() == cognosReportResults.size()))
/* 536:    */     {
/* 537:623 */       fieldValuesFromCognosToBeComparedInObjectList = new ArrayList();
/* 538:625 */       for (Element xmlRow : cognosReportResults)
/* 539:    */       {
/* 540:627 */         xmlValues = xmlRow.getChildren("value", cognosNamespace);
/* 541:628 */         this.logger.debug("Position value from list: " + (String)cognosValuesPostions.get(index));
/* 542:629 */         this.logger.debug("Postions Int value: " + NumericUtil.getIntValue((String)cognosValuesPostions.get(index)));
/* 543:630 */         int postion = NumericUtil.getIntValue((String)cognosValuesPostions.get(index));
/* 544:    */         
/* 545:632 */         this.logger.debug("Is XML Values list not null: " + CommonUtil.isListNotNullOrEmpty(xmlValues));
/* 546:633 */         this.logger.debug("XML Value in postion not null: " + CommonUtil.isObjectNotNull(xmlValues.get(postion)));
/* 547:635 */         if ((CommonUtil.isListNotNullOrEmpty(xmlValues)) && (CommonUtil.isObjectNotNull(xmlValues.get(postion))))
/* 548:    */         {
/* 549:637 */           valueFromParentIssue = ((Element)xmlValues.get(postion)).getText();
/* 550:638 */           fieldValuesFromCognosToBeComparedInObjectList.add(valueFromParentIssue);
/* 551:    */         }
/* 552:642 */         index++;
/* 553:    */       }
/* 554:    */     }
/* 555:646 */     compareFieldValuesOnObjectDTO.setFieldValuesFromCognosToBeComparedInObjectList(fieldValuesFromCognosToBeComparedInObjectList);
/* 556:    */     
/* 557:648 */     this.logger.debug("Values from Cognos: " + fieldValuesFromCognosToBeComparedInObjectList);
/* 558:649 */     this.logger.debug("getImmediateParentIssueForUpdate()End");
/* 559:650 */     return valueFromParentIssue;
/* 560:    */   }
/* 561:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.triggers.handler.ValidateObjectHandler
 * JD-Core Version:    0.7.0.1
 */