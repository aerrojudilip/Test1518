/*   1:    */ package com.ibm.openpages.ext.tss.triggers.handler;
/*   2:    */ 
/*   3:    */ import com.ibm.openpages.api.resource.IFolder;
/*   4:    */ import com.ibm.openpages.api.resource.IGRCObject;
/*   5:    */ import com.ibm.openpages.api.service.IServiceFactory;
/*   6:    */ import com.ibm.openpages.api.trigger.ext.DefaultEventHandler;
/*   7:    */ import com.ibm.openpages.ext.tss.service.IApplicationUtil;
/*   8:    */ import com.ibm.openpages.ext.tss.service.ICognosUtil;
/*   9:    */ import com.ibm.openpages.ext.tss.service.ICurrencyFieldUtil;
/*  10:    */ import com.ibm.openpages.ext.tss.service.IDateFieldUtil;
/*  11:    */ import com.ibm.openpages.ext.tss.service.IEmailUtil;
/*  12:    */ import com.ibm.openpages.ext.tss.service.IEnumFieldUtil;
/*  13:    */ import com.ibm.openpages.ext.tss.service.IFieldUtil;
/*  14:    */ import com.ibm.openpages.ext.tss.service.IGRCObjectSearchUtil;
/*  15:    */ import com.ibm.openpages.ext.tss.service.IGRCObjectUtil;
/*  16:    */ import com.ibm.openpages.ext.tss.service.IGRCTriggerUtil;
/*  17:    */ import com.ibm.openpages.ext.tss.service.IGRCUpdateTriggerUtil;
/*  18:    */ import com.ibm.openpages.ext.tss.service.IGRCValidationTriggerUtil;
/*  19:    */ import com.ibm.openpages.ext.tss.service.IIntegerFieldUtil;
/*  20:    */ import com.ibm.openpages.ext.tss.service.ILoggerUtil;
/*  21:    */ import com.ibm.openpages.ext.tss.service.IMultiEnumFieldUtil;
/*  22:    */ import com.ibm.openpages.ext.tss.service.IStringFieldUtil;
/*  23:    */ import com.ibm.openpages.ext.tss.service.IUserUtil;
/*  24:    */ import com.ibm.openpages.ext.tss.service.config.OPSServiceFactory;
/*  25:    */ import com.ibm.openpages.ext.tss.service.constants.StringOrder;
/*  26:    */ import com.ibm.openpages.ext.tss.service.proxy.IServiceFactoryProxy;
/*  27:    */ import com.ibm.openpages.ext.tss.service.util.CommonUtil;
/*  28:    */ import com.ibm.openpages.ext.tss.triggers.backingbean.BaseTriggerBackingBean;
/*  29:    */ import com.openpages.sdk.trigger.TriggerContext;
/*  30:    */ import java.util.ArrayList;
/*  31:    */ import java.util.HashMap;
/*  32:    */ import java.util.List;
/*  33:    */ import org.apache.commons.logging.Log;
/*  34:    */ 
/*  35:    */ public class BaseEventHandler
/*  36:    */   extends DefaultEventHandler
/*  37:    */ {
/*  38: 74 */   public Log logger = null;
/*  39: 75 */   public IEmailUtil emailUtil = null;
/*  40: 76 */   public IFieldUtil fieldUtil = null;
/*  41: 77 */   public ICognosUtil cognosUtil = null;
/*  42: 78 */   public IDateFieldUtil datefieldUtil = null;
/*  43: 79 */   public ICurrencyFieldUtil currencyFieldUtil = null;
/*  44: 80 */   public IEnumFieldUtil enumFieldUtil = null;
/*  45: 81 */   public IIntegerFieldUtil integerFieldUtil = null;
/*  46: 82 */   public IMultiEnumFieldUtil multiEnumFieldUtil = null;
/*  47: 83 */   public IStringFieldUtil stringFieldUtil = null;
/*  48: 84 */   public IUserUtil userUtil = null;
/*  49: 85 */   public IGRCObjectUtil grcObjectUtil = null;
/*  50: 86 */   public IGRCTriggerUtil grcTriggerUtil = null;
/*  51: 87 */   public IServiceFactory serviceFactory = null;
/*  52: 88 */   public IApplicationUtil applicationUtil = null;
/*  53: 89 */   public IGRCObjectSearchUtil grcObjectSearchUtil = null;
/*  54: 90 */   public IGRCValidationTriggerUtil grcValidationTriggerUtil = null;
/*  55: 91 */   public IGRCUpdateTriggerUtil grcUpdateTriggerUtil = null;
/*  56:    */   
/*  57:    */   public BaseEventHandler()
/*  58:    */   {
/*  59:100 */     initLogServices();
/*  60:101 */     initGRCTriggerUtilServices();
/*  61:    */   }
/*  62:    */   
/*  63:    */   public boolean isTriggerAttrbuteValuePresent(String propertyName)
/*  64:    */     throws Exception
/*  65:    */   {
/*  66:118 */     String attributeValue = this.grcTriggerUtil.getAttributeName(getAttributes(), propertyName);
/*  67:    */     
/*  68:120 */     return CommonUtil.isNotNullOrEmpty(attributeValue);
/*  69:    */   }
/*  70:    */   
/*  71:    */   public IGRCObject saveResourceOnPostTrigger(IGRCObject object)
/*  72:    */     throws Exception
/*  73:    */   {
/*  74:135 */     initGRCObjectUtilServices();
/*  75:136 */     IGRCObject savedObject = null;
/*  76:    */     try
/*  77:    */     {
/*  78:140 */       TriggerContext.get().setDisableAllTriggers(true);
/*  79:141 */       savedObject = this.grcObjectUtil.saveResource(object);
/*  80:    */     }
/*  81:    */     catch (Exception ex)
/*  82:    */     {
/*  83:145 */       throw ex;
/*  84:    */     }
/*  85:    */     finally
/*  86:    */     {
/*  87:149 */       TriggerContext.get().setDisableAllTriggers(false);
/*  88:    */     }
/*  89:152 */     return savedObject;
/*  90:    */   }
/*  91:    */   
/*  92:    */   public String getTriggerAttrbuteValue(String propertyName)
/*  93:    */     throws Exception
/*  94:    */   {
/*  95:168 */     String attributeValue = this.grcTriggerUtil.getAttributeName(getAttributes(), propertyName);
/*  96:    */     
/*  97:170 */     return CommonUtil.trimString(attributeValue);
/*  98:    */   }
/*  99:    */   
/* 100:    */   public boolean getBooleanTriggerAttrbuteValue(String propertyName)
/* 101:    */     throws Exception
/* 102:    */   {
/* 103:186 */     String attributeValue = this.grcTriggerUtil.getAttributeName(getAttributes(), propertyName);
/* 104:    */     
/* 105:188 */     return CommonUtil.isNotNullOrEmpty(attributeValue) ? CommonUtil.parseBoolean(attributeValue) : false;
/* 106:    */   }
/* 107:    */   
/* 108:    */   public List<String> getParsedTriggerAttrbuteValue(String propertyName)
/* 109:    */     throws Exception
/* 110:    */   {
/* 111:205 */     String attributeValue = getTriggerAttrbuteValue(propertyName);
/* 112:    */     
/* 113:207 */     return CommonUtil.isNotNullOrEmpty(attributeValue) ? CommonUtil.parseCommaDelimitedValues(attributeValue) : new ArrayList();
/* 114:    */   }
/* 115:    */   
/* 116:    */   public IGRCObject getImmediateParentObjectForCreate()
/* 117:    */     throws Exception
/* 118:    */   {
/* 119:218 */     BaseTriggerBackingBean baseTrigger = new BaseTriggerBackingBean();
/* 120:219 */     return baseTrigger.getImmediateParentObjectForCreate();
/* 121:    */   }
/* 122:    */   
/* 123:    */   public IGRCObject getImmediateParentEntityFromHierarchyForUpdate(String objectId, String objectHeirarchyPath)
/* 124:    */     throws Exception
/* 125:    */   {
/* 126:236 */     this.logger.debug("getImmediateParentEntityFromHierarchyForUpdate()Start");
/* 127:    */     
/* 128:    */ 
/* 129:239 */     int count = 1;
/* 130:240 */     String objectHierarchyPath = "";
/* 131:    */     
/* 132:242 */     IGRCObject parentBusEntity = null;
/* 133:243 */     List<String> objectHeirarchyList = null;
/* 134:    */     
/* 135:    */ 
/* 136:246 */     initGRCObjectSearchUtilServices();
/* 137:247 */     while (CommonUtil.isObjectNotNull(objectHierarchyPath))
/* 138:    */     {
/* 139:249 */       objectHierarchyPath = getTriggerAttrbuteValue(objectHeirarchyPath + "." + count);
/* 140:250 */       this.logger.debug("Object Hierarchy Path: " + objectHierarchyPath);
/* 141:251 */       this.logger.debug("Is Object Hierarchy Path Not null: " + CommonUtil.isObjectNotNull(objectHierarchyPath));
/* 142:253 */       if (CommonUtil.isNotNullOrEmpty(objectHierarchyPath))
/* 143:    */       {
/* 144:255 */         objectHeirarchyList = CommonUtil.parseDelimitedValues(objectHierarchyPath, ",");
/* 145:256 */         this.logger.debug("Object Hierarchy List Before getting the entity: " + objectHeirarchyList);
/* 146:    */         
/* 147:258 */         parentBusEntity = this.grcObjectSearchUtil.getImmediatePrimaryParentFromId(objectId, objectHeirarchyList, true);
/* 148:259 */         objectHierarchyPath = CommonUtil.isObjectNotNull(parentBusEntity) ? null : objectHierarchyPath;
/* 149:    */         
/* 150:261 */         this.logger.debug("Object Hierarchy List: " + objectHeirarchyList);
/* 151:    */       }
/* 152:264 */       count++;
/* 153:    */     }
/* 154:267 */     this.logger.debug("getImmediateParentEntityFromHierarchyForUpdate()End");
/* 155:268 */     return parentBusEntity;
/* 156:    */   }
/* 157:    */   
/* 158:    */   public IGRCObject getImmediateParentEntityForCreate(IGRCObject object)
/* 159:    */     throws Exception
/* 160:    */   {
/* 161:284 */     this.logger.debug("getImmediateParentEntityFromHierarchyForCreate()Start");
/* 162:    */     
/* 163:    */ 
/* 164:287 */     String objectPath = "";
/* 165:288 */     String parentEntityName = "";
/* 166:    */     
/* 167:290 */     IGRCObject parentBusEntity = null;
/* 168:    */     
/* 169:    */ 
/* 170:293 */     initGRCObjectSearchUtilServices();
/* 171:294 */     parentEntityName = object.getParentFolder().getName();
/* 172:295 */     objectPath = object.getParentFolder().getPath();
/* 173:    */     
/* 174:297 */     this.logger.debug("Parent Folder Path: " + objectPath);
/* 175:298 */     this.logger.debug("Parent Entity Name: " + parentEntityName);
/* 176:    */     
/* 177:300 */     objectPath = objectPath.replace("/_op_sox/Project/Default/ICDocumentation/", "");
/* 178:    */     
/* 179:302 */     this.logger.debug("Substring 1: " + objectPath);
/* 180:303 */     objectPath = objectPath.substring(objectPath.indexOf("/"), objectPath.length());
/* 181:    */     
/* 182:305 */     this.logger.debug("Substring 2: " + objectPath);
/* 183:    */     
/* 184:307 */     parentBusEntity = this.grcObjectSearchUtil.getObjectFromNameAndPath("SOXBusEntity", parentEntityName, objectPath, true);
/* 185:    */     
/* 186:309 */     this.logger.debug("Is Parent Not null: " + CommonUtil.isObjectNotNull(parentBusEntity));
/* 187:310 */     this.logger.debug("Parent Entity Name: " + (CommonUtil.isObjectNotNull(parentBusEntity) ? parentBusEntity.getName() : null));
/* 188:    */     
/* 189:312 */     this.logger.debug("getImmediateParentEntityFromHierarchyForCreate()End");
/* 190:313 */     return parentBusEntity;
/* 191:    */   }
/* 192:    */   
/* 193:    */   public List<String> getSpecificTriggerAttributes(String triggerAttributeName, StringOrder stringOrder)
/* 194:    */     throws Exception
/* 195:    */   {
/* 196:331 */     this.logger.debug("getSpecificTriggerAttributes() Start");
/* 197:    */     
/* 198:333 */     HashMap<String, String> propertiesMap = null;
/* 199:334 */     List<String> specificTriggerAttributes = null;
/* 200:    */     
/* 201:336 */     specificTriggerAttributes = new ArrayList();
/* 202:337 */     propertiesMap = getAttributes();
/* 203:339 */     for (String keys : propertiesMap.keySet()) {
/* 204:341 */       if ((StringOrder.START_WITH.equals(stringOrder)) && (keys.startsWith(triggerAttributeName)))
/* 205:    */       {
/* 206:343 */         this.logger.debug("getSpecificTriggerAttributes()" + specificTriggerAttributes);
/* 207:344 */         specificTriggerAttributes.add(propertiesMap.get(keys));
/* 208:    */       }
/* 209:345 */       else if ((StringOrder.CONTAINS.equals(stringOrder)) && (keys.contains(triggerAttributeName)))
/* 210:    */       {
/* 211:347 */         this.logger.debug("getSpecificTriggerAttributes()" + specificTriggerAttributes);
/* 212:348 */         specificTriggerAttributes.add(propertiesMap.get(keys));
/* 213:    */       }
/* 214:349 */       else if ((StringOrder.EQUALS.equals(stringOrder)) && (CommonUtil.isEqual(keys, triggerAttributeName)))
/* 215:    */       {
/* 216:351 */         this.logger.debug("getSpecificTriggerAttributes()" + specificTriggerAttributes);
/* 217:352 */         specificTriggerAttributes.add(propertiesMap.get(keys));
/* 218:    */       }
/* 219:353 */       else if ((StringOrder.EQUALS_IGNORE_CASE.equals(stringOrder)) && (CommonUtil.isEqualIgnoreCase(keys, triggerAttributeName)))
/* 220:    */       {
/* 221:356 */         this.logger.debug("getSpecificTriggerAttributes()" + specificTriggerAttributes);
/* 222:357 */         specificTriggerAttributes.add(propertiesMap.get(keys));
/* 223:    */       }
/* 224:    */     }
/* 225:361 */     this.logger.debug("getSpecificTriggerAttributes()" + specificTriggerAttributes);
/* 226:362 */     this.logger.debug("getSpecificTriggerAttributes()End");
/* 227:363 */     return specificTriggerAttributes;
/* 228:    */   }
/* 229:    */   
/* 230:    */   public void initLogServices()
/* 231:    */   {
/* 232:374 */     this.logger = (CommonUtil.isObjectNotNull(this.logger) ? this.logger : OPSServiceFactory.getLoggerUtil().getExtLogger());
/* 233:    */   }
/* 234:    */   
/* 235:    */   public void initServiceFactory()
/* 236:    */   {
/* 237:386 */     this.serviceFactory = (CommonUtil.isObjectNotNull(this.serviceFactory) ? this.serviceFactory : OPSServiceFactory.getServiceFactoryProxy().getServiceFactory());
/* 238:    */   }
/* 239:    */   
/* 240:    */   public void initCognosUtilServices()
/* 241:    */   {
/* 242:398 */     this.cognosUtil = (CommonUtil.isObjectNotNull(this.cognosUtil) ? this.cognosUtil : OPSServiceFactory.getCognosUtil());
/* 243:    */   }
/* 244:    */   
/* 245:    */   public void initDateFieldUtilServices()
/* 246:    */   {
/* 247:410 */     this.datefieldUtil = (CommonUtil.isObjectNotNull(this.datefieldUtil) ? this.datefieldUtil : OPSServiceFactory.getDateFieldUtil());
/* 248:    */   }
/* 249:    */   
/* 250:    */   public void initCurrencyFieldUtilServices()
/* 251:    */   {
/* 252:422 */     this.currencyFieldUtil = (CommonUtil.isObjectNotNull(this.currencyFieldUtil) ? this.currencyFieldUtil : OPSServiceFactory.getICurrencyFieldUtil());
/* 253:    */   }
/* 254:    */   
/* 255:    */   public void initEnumFieldUtilServices()
/* 256:    */   {
/* 257:434 */     this.enumFieldUtil = (CommonUtil.isObjectNotNull(this.enumFieldUtil) ? this.enumFieldUtil : OPSServiceFactory.getEnumFieldUtil());
/* 258:    */   }
/* 259:    */   
/* 260:    */   public void initMultiEnumFieldUtilServices()
/* 261:    */   {
/* 262:446 */     this.multiEnumFieldUtil = (CommonUtil.isObjectNotNull(this.multiEnumFieldUtil) ? this.multiEnumFieldUtil : OPSServiceFactory.getMultiEnumFieldUtil());
/* 263:    */   }
/* 264:    */   
/* 265:    */   public void initStringFieldUtilServices()
/* 266:    */   {
/* 267:458 */     this.stringFieldUtil = (CommonUtil.isObjectNotNull(this.stringFieldUtil) ? this.stringFieldUtil : OPSServiceFactory.getStringFieldUtil());
/* 268:    */   }
/* 269:    */   
/* 270:    */   public void initEmailUtilServices()
/* 271:    */   {
/* 272:470 */     this.emailUtil = (CommonUtil.isObjectNotNull(this.emailUtil) ? this.emailUtil : OPSServiceFactory.getEmailUtil());
/* 273:    */   }
/* 274:    */   
/* 275:    */   public void initUserUtilServices()
/* 276:    */   {
/* 277:482 */     this.userUtil = (CommonUtil.isObjectNotNull(this.userUtil) ? this.userUtil : OPSServiceFactory.getUserUtil());
/* 278:    */   }
/* 279:    */   
/* 280:    */   public void initGRCTriggerUtilServices()
/* 281:    */   {
/* 282:494 */     this.grcTriggerUtil = (CommonUtil.isObjectNotNull(this.grcTriggerUtil) ? this.grcTriggerUtil : OPSServiceFactory.getGRCTriggerUtil());
/* 283:    */   }
/* 284:    */   
/* 285:    */   public void initGRCValidationTriggerUtilServices()
/* 286:    */   {
/* 287:506 */     this.grcValidationTriggerUtil = (CommonUtil.isObjectNotNull(this.grcValidationTriggerUtil) ? this.grcValidationTriggerUtil : OPSServiceFactory.getGRCValidationTriggerUtil());
/* 288:    */   }
/* 289:    */   
/* 290:    */   public void initGRCUpdateTriggerUtilServices()
/* 291:    */   {
/* 292:518 */     this.grcUpdateTriggerUtil = (CommonUtil.isObjectNotNull(this.grcUpdateTriggerUtil) ? this.grcUpdateTriggerUtil : OPSServiceFactory.getGRCUpdateTriggerUtil());
/* 293:    */   }
/* 294:    */   
/* 295:    */   public void initGRCObjectUtilServices()
/* 296:    */   {
/* 297:530 */     this.grcObjectUtil = (CommonUtil.isObjectNotNull(this.grcObjectUtil) ? this.grcObjectUtil : OPSServiceFactory.getGRCObjectUtil());
/* 298:    */   }
/* 299:    */   
/* 300:    */   public void initGRCObjectSearchUtilServices()
/* 301:    */   {
/* 302:542 */     this.grcObjectSearchUtil = (CommonUtil.isObjectNotNull(this.grcObjectSearchUtil) ? this.grcObjectSearchUtil : OPSServiceFactory.getGRCObjectSearchUtil());
/* 303:    */   }
/* 304:    */   
/* 305:    */   public void initFieldUtilServices()
/* 306:    */   {
/* 307:554 */     this.fieldUtil = (CommonUtil.isObjectNotNull(this.fieldUtil) ? this.fieldUtil : OPSServiceFactory.getFieldUtil());
/* 308:    */   }
/* 309:    */   
/* 310:    */   public void initApplicationUtilServices()
/* 311:    */   {
/* 312:566 */     this.applicationUtil = (CommonUtil.isObjectNotNull(this.applicationUtil) ? this.applicationUtil : OPSServiceFactory.getApplicationUtil());
/* 313:    */   }
/* 314:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     com.ibm.openpages.ext.tss.triggers.handler.BaseEventHandler
 * JD-Core Version:    0.7.0.1
 */