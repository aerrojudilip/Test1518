package org.springframework.transaction;

public abstract interface TransactionDefinition
{
  public static final int PROPAGATION_REQUIRED = 0;
  public static final int PROPAGATION_SUPPORTS = 1;
  public static final int PROPAGATION_MANDATORY = 2;
  public static final int PROPAGATION_REQUIRES_NEW = 3;
  public static final int PROPAGATION_NOT_SUPPORTED = 4;
  public static final int PROPAGATION_NEVER = 5;
  public static final int PROPAGATION_NESTED = 6;
  public static final int ISOLATION_DEFAULT = -1;
  public static final int ISOLATION_READ_UNCOMMITTED = 1;
  public static final int ISOLATION_READ_COMMITTED = 2;
  public static final int ISOLATION_REPEATABLE_READ = 4;
  public static final int ISOLATION_SERIALIZABLE = 8;
  public static final int TIMEOUT_DEFAULT = -1;
  
  public abstract int getPropagationBehavior();
  
  public abstract int getIsolationLevel();
  
  public abstract int getTimeout();
  
  public abstract boolean isReadOnly();
  
  public abstract String getName();
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.transaction.TransactionDefinition
 * JD-Core Version:    0.7.0.1
 */