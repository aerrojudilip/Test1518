/*  1:   */ package org.springframework.transaction;
/*  2:   */ 
/*  3:   */ import org.springframework.core.NestedRuntimeException;
/*  4:   */ 
/*  5:   */ public abstract class TransactionException
/*  6:   */   extends NestedRuntimeException
/*  7:   */ {
/*  8:   */   public TransactionException(String msg)
/*  9:   */   {
/* 10:34 */     super(msg);
/* 11:   */   }
/* 12:   */   
/* 13:   */   public TransactionException(String msg, Throwable cause)
/* 14:   */   {
/* 15:43 */     super(msg, cause);
/* 16:   */   }
/* 17:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.transaction.TransactionException
 * JD-Core Version:    0.7.0.1
 */