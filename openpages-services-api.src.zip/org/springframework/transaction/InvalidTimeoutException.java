/*  1:   */ package org.springframework.transaction;
/*  2:   */ 
/*  3:   */ public class InvalidTimeoutException
/*  4:   */   extends TransactionUsageException
/*  5:   */ {
/*  6:   */   private int timeout;
/*  7:   */   
/*  8:   */   public InvalidTimeoutException(String msg, int timeout)
/*  9:   */   {
/* 10:38 */     super(msg);
/* 11:39 */     this.timeout = timeout;
/* 12:   */   }
/* 13:   */   
/* 14:   */   public int getTimeout()
/* 15:   */   {
/* 16:46 */     return this.timeout;
/* 17:   */   }
/* 18:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.transaction.InvalidTimeoutException
 * JD-Core Version:    0.7.0.1
 */