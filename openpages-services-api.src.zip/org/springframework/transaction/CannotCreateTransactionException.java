/*  1:   */ package org.springframework.transaction;
/*  2:   */ 
/*  3:   */ public class CannotCreateTransactionException
/*  4:   */   extends TransactionException
/*  5:   */ {
/*  6:   */   public CannotCreateTransactionException(String msg)
/*  7:   */   {
/*  8:33 */     super(msg);
/*  9:   */   }
/* 10:   */   
/* 11:   */   public CannotCreateTransactionException(String msg, Throwable cause)
/* 12:   */   {
/* 13:42 */     super(msg, cause);
/* 14:   */   }
/* 15:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.transaction.CannotCreateTransactionException
 * JD-Core Version:    0.7.0.1
 */