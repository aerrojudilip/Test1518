/*  1:   */ package org.springframework.transaction;
/*  2:   */ 
/*  3:   */ public class InvalidIsolationLevelException
/*  4:   */   extends TransactionUsageException
/*  5:   */ {
/*  6:   */   public InvalidIsolationLevelException(String msg)
/*  7:   */   {
/*  8:34 */     super(msg);
/*  9:   */   }
/* 10:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.transaction.InvalidIsolationLevelException
 * JD-Core Version:    0.7.0.1
 */