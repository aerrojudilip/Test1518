package org.springframework.transaction.interceptor;

import org.springframework.transaction.TransactionDefinition;

public abstract interface TransactionAttribute
  extends TransactionDefinition
{
  public abstract String getQualifier();
  
  public abstract boolean rollbackOn(Throwable paramThrowable);
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.transaction.interceptor.TransactionAttribute
 * JD-Core Version:    0.7.0.1
 */