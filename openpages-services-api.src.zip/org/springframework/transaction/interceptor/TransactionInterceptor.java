/*   1:    */ package org.springframework.transaction.interceptor;
/*   2:    */ 
/*   3:    */ import java.io.IOException;
/*   4:    */ import java.io.ObjectInputStream;
/*   5:    */ import java.io.ObjectOutputStream;
/*   6:    */ import java.io.Serializable;
/*   7:    */ import java.util.Properties;
/*   8:    */ import org.aopalliance.intercept.MethodInterceptor;
/*   9:    */ import org.aopalliance.intercept.MethodInvocation;
/*  10:    */ import org.springframework.aop.support.AopUtils;
/*  11:    */ import org.springframework.beans.factory.BeanFactory;
/*  12:    */ import org.springframework.transaction.PlatformTransactionManager;
/*  13:    */ import org.springframework.transaction.TransactionStatus;
/*  14:    */ import org.springframework.transaction.support.CallbackPreferringPlatformTransactionManager;
/*  15:    */ import org.springframework.transaction.support.TransactionCallback;
/*  16:    */ 
/*  17:    */ public class TransactionInterceptor
/*  18:    */   extends TransactionAspectSupport
/*  19:    */   implements MethodInterceptor, Serializable
/*  20:    */ {
/*  21:    */   public TransactionInterceptor() {}
/*  22:    */   
/*  23:    */   public TransactionInterceptor(PlatformTransactionManager ptm, Properties attributes)
/*  24:    */   {
/*  25: 74 */     setTransactionManager(ptm);
/*  26: 75 */     setTransactionAttributes(attributes);
/*  27:    */   }
/*  28:    */   
/*  29:    */   public TransactionInterceptor(PlatformTransactionManager ptm, TransactionAttributeSource tas)
/*  30:    */   {
/*  31: 86 */     setTransactionManager(ptm);
/*  32: 87 */     setTransactionAttributeSource(tas);
/*  33:    */   }
/*  34:    */   
/*  35:    */   public Object invoke(final MethodInvocation invocation)
/*  36:    */     throws Throwable
/*  37:    */   {
/*  38: 95 */     Class<?> targetClass = invocation.getThis() != null ? AopUtils.getTargetClass(invocation.getThis()) : null;
/*  39:    */     
/*  40:    */ 
/*  41: 98 */     final TransactionAttribute txAttr = getTransactionAttributeSource().getTransactionAttribute(invocation.getMethod(), targetClass);
/*  42:    */     
/*  43:100 */     final PlatformTransactionManager tm = determineTransactionManager(txAttr);
/*  44:101 */     final String joinpointIdentification = methodIdentification(invocation.getMethod(), targetClass);
/*  45:103 */     if ((txAttr == null) || (!(tm instanceof CallbackPreferringPlatformTransactionManager)))
/*  46:    */     {
/*  47:105 */       TransactionAspectSupport.TransactionInfo txInfo = createTransactionIfNecessary(tm, txAttr, joinpointIdentification);
/*  48:106 */       Object retVal = null;
/*  49:    */       try
/*  50:    */       {
/*  51:110 */         retVal = invocation.proceed();
/*  52:    */       }
/*  53:    */       catch (Throwable ex)
/*  54:    */       {
/*  55:114 */         completeTransactionAfterThrowing(txInfo, ex);
/*  56:115 */         throw ex;
/*  57:    */       }
/*  58:    */       finally
/*  59:    */       {
/*  60:118 */         cleanupTransactionInfo(txInfo);
/*  61:    */       }
/*  62:120 */       commitTransactionAfterReturning(txInfo);
/*  63:121 */       return retVal;
/*  64:    */     }
/*  65:    */     try
/*  66:    */     {
/*  67:127 */       Object result = ((CallbackPreferringPlatformTransactionManager)tm).execute(txAttr, new TransactionCallback()
/*  68:    */       {
/*  69:    */         public Object doInTransaction(TransactionStatus status)
/*  70:    */         {
/*  71:130 */           TransactionAspectSupport.TransactionInfo txInfo = TransactionInterceptor.this.prepareTransactionInfo(tm, txAttr, joinpointIdentification, status);
/*  72:    */           try
/*  73:    */           {
/*  74:132 */             return invocation.proceed();
/*  75:    */           }
/*  76:    */           catch (Throwable ex)
/*  77:    */           {
/*  78:135 */             if (txAttr.rollbackOn(ex))
/*  79:    */             {
/*  80:137 */               if ((ex instanceof RuntimeException)) {
/*  81:138 */                 throw ((RuntimeException)ex);
/*  82:    */               }
/*  83:141 */               throw new TransactionInterceptor.ThrowableHolderException(ex);
/*  84:    */             }
/*  85:146 */             return new TransactionInterceptor.ThrowableHolder(ex);
/*  86:    */           }
/*  87:    */           finally
/*  88:    */           {
/*  89:150 */             TransactionInterceptor.this.cleanupTransactionInfo(txInfo);
/*  90:    */           }
/*  91:    */         }
/*  92:    */       });
/*  93:156 */       if ((result instanceof ThrowableHolder)) {
/*  94:157 */         throw ((ThrowableHolder)result).getThrowable();
/*  95:    */       }
/*  96:160 */       return result;
/*  97:    */     }
/*  98:    */     catch (ThrowableHolderException ex)
/*  99:    */     {
/* 100:164 */       throw ex.getCause();
/* 101:    */     }
/* 102:    */   }
/* 103:    */   
/* 104:    */   private void writeObject(ObjectOutputStream oos)
/* 105:    */     throws IOException
/* 106:    */   {
/* 107:176 */     oos.defaultWriteObject();
/* 108:    */     
/* 109:    */ 
/* 110:179 */     oos.writeObject(getTransactionManagerBeanName());
/* 111:180 */     oos.writeObject(getTransactionManager());
/* 112:181 */     oos.writeObject(getTransactionAttributeSource());
/* 113:182 */     oos.writeObject(getBeanFactory());
/* 114:    */   }
/* 115:    */   
/* 116:    */   private void readObject(ObjectInputStream ois)
/* 117:    */     throws IOException, ClassNotFoundException
/* 118:    */   {
/* 119:187 */     ois.defaultReadObject();
/* 120:    */     
/* 121:    */ 
/* 122:    */ 
/* 123:    */ 
/* 124:192 */     setTransactionManagerBeanName((String)ois.readObject());
/* 125:193 */     setTransactionManager((PlatformTransactionManager)ois.readObject());
/* 126:194 */     setTransactionAttributeSource((TransactionAttributeSource)ois.readObject());
/* 127:195 */     setBeanFactory((BeanFactory)ois.readObject());
/* 128:    */   }
/* 129:    */   
/* 130:    */   private static class ThrowableHolder
/* 131:    */   {
/* 132:    */     private final Throwable throwable;
/* 133:    */     
/* 134:    */     public ThrowableHolder(Throwable throwable)
/* 135:    */     {
/* 136:208 */       this.throwable = throwable;
/* 137:    */     }
/* 138:    */     
/* 139:    */     public final Throwable getThrowable()
/* 140:    */     {
/* 141:212 */       return this.throwable;
/* 142:    */     }
/* 143:    */   }
/* 144:    */   
/* 145:    */   private static class ThrowableHolderException
/* 146:    */     extends RuntimeException
/* 147:    */   {
/* 148:    */     public ThrowableHolderException(Throwable throwable)
/* 149:    */     {
/* 150:224 */       super();
/* 151:    */     }
/* 152:    */     
/* 153:    */     public String toString()
/* 154:    */     {
/* 155:229 */       return getCause().toString();
/* 156:    */     }
/* 157:    */   }
/* 158:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.transaction.interceptor.TransactionInterceptor
 * JD-Core Version:    0.7.0.1
 */