/*  1:   */ package org.springframework.transaction.interceptor;
/*  2:   */ 
/*  3:   */ import java.io.Serializable;
/*  4:   */ import org.springframework.transaction.support.DelegatingTransactionDefinition;
/*  5:   */ 
/*  6:   */ public abstract class DelegatingTransactionAttribute
/*  7:   */   extends DelegatingTransactionDefinition
/*  8:   */   implements TransactionAttribute, Serializable
/*  9:   */ {
/* 10:   */   private final TransactionAttribute targetAttribute;
/* 11:   */   
/* 12:   */   public DelegatingTransactionAttribute(TransactionAttribute targetAttribute)
/* 13:   */   {
/* 14:43 */     super(targetAttribute);
/* 15:44 */     this.targetAttribute = targetAttribute;
/* 16:   */   }
/* 17:   */   
/* 18:   */   public String getQualifier()
/* 19:   */   {
/* 20:49 */     return this.targetAttribute.getQualifier();
/* 21:   */   }
/* 22:   */   
/* 23:   */   public boolean rollbackOn(Throwable ex)
/* 24:   */   {
/* 25:53 */     return this.targetAttribute.rollbackOn(ex);
/* 26:   */   }
/* 27:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.transaction.interceptor.DelegatingTransactionAttribute
 * JD-Core Version:    0.7.0.1
 */