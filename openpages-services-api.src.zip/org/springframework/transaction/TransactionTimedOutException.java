/*  1:   */ package org.springframework.transaction;
/*  2:   */ 
/*  3:   */ public class TransactionTimedOutException
/*  4:   */   extends TransactionException
/*  5:   */ {
/*  6:   */   public TransactionTimedOutException(String msg)
/*  7:   */   {
/*  8:52 */     super(msg);
/*  9:   */   }
/* 10:   */   
/* 11:   */   public TransactionTimedOutException(String msg, Throwable cause)
/* 12:   */   {
/* 13:61 */     super(msg, cause);
/* 14:   */   }
/* 15:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.transaction.TransactionTimedOutException
 * JD-Core Version:    0.7.0.1
 */