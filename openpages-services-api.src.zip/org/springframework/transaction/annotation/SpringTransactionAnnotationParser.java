/*  1:   */ package org.springframework.transaction.annotation;
/*  2:   */ 
/*  3:   */ import java.io.Serializable;
/*  4:   */ import java.lang.reflect.AnnotatedElement;
/*  5:   */ import java.util.ArrayList;
/*  6:   */ import java.util.List;
/*  7:   */ import org.springframework.core.annotation.AnnotationUtils;
/*  8:   */ import org.springframework.transaction.interceptor.NoRollbackRuleAttribute;
/*  9:   */ import org.springframework.transaction.interceptor.RollbackRuleAttribute;
/* 10:   */ import org.springframework.transaction.interceptor.RuleBasedTransactionAttribute;
/* 11:   */ import org.springframework.transaction.interceptor.TransactionAttribute;
/* 12:   */ 
/* 13:   */ public class SpringTransactionAnnotationParser
/* 14:   */   implements TransactionAnnotationParser, Serializable
/* 15:   */ {
/* 16:   */   public TransactionAttribute parseTransactionAnnotation(AnnotatedElement ae)
/* 17:   */   {
/* 18:38 */     Transactional ann = (Transactional)AnnotationUtils.getAnnotation(ae, Transactional.class);
/* 19:39 */     if (ann != null) {
/* 20:40 */       return parseTransactionAnnotation(ann);
/* 21:   */     }
/* 22:43 */     return null;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public TransactionAttribute parseTransactionAnnotation(Transactional ann)
/* 26:   */   {
/* 27:48 */     RuleBasedTransactionAttribute rbta = new RuleBasedTransactionAttribute();
/* 28:49 */     rbta.setPropagationBehavior(ann.propagation().value());
/* 29:50 */     rbta.setIsolationLevel(ann.isolation().value());
/* 30:51 */     rbta.setTimeout(ann.timeout());
/* 31:52 */     rbta.setReadOnly(ann.readOnly());
/* 32:53 */     rbta.setQualifier(ann.value());
/* 33:54 */     ArrayList<RollbackRuleAttribute> rollBackRules = new ArrayList();
/* 34:55 */     Class[] rbf = ann.rollbackFor();
/* 35:56 */     for (Class rbRule : rbf)
/* 36:   */     {
/* 37:57 */       RollbackRuleAttribute rule = new RollbackRuleAttribute(rbRule);
/* 38:58 */       rollBackRules.add(rule);
/* 39:   */     }
/* 40:60 */     String[] rbfc = ann.rollbackForClassName();
/* 41:61 */     for (String rbRule : rbfc)
/* 42:   */     {
/* 43:62 */       RollbackRuleAttribute rule = new RollbackRuleAttribute(rbRule);
/* 44:63 */       rollBackRules.add(rule);
/* 45:   */     }
/* 46:65 */     Class[] nrbf = ann.noRollbackFor();
/* 47:66 */     for (Class rbRule : nrbf)
/* 48:   */     {
/* 49:67 */       NoRollbackRuleAttribute rule = new NoRollbackRuleAttribute(rbRule);
/* 50:68 */       rollBackRules.add(rule);
/* 51:   */     }
/* 52:70 */     String[] nrbfc = ann.noRollbackForClassName();
/* 53:71 */     for (String rbRule : nrbfc)
/* 54:   */     {
/* 55:72 */       NoRollbackRuleAttribute rule = new NoRollbackRuleAttribute(rbRule);
/* 56:73 */       rollBackRules.add(rule);
/* 57:   */     }
/* 58:75 */     rbta.getRollbackRules().addAll(rollBackRules);
/* 59:76 */     return rbta;
/* 60:   */   }
/* 61:   */   
/* 62:   */   public boolean equals(Object other)
/* 63:   */   {
/* 64:81 */     return (this == other) || ((other instanceof SpringTransactionAnnotationParser));
/* 65:   */   }
/* 66:   */   
/* 67:   */   public int hashCode()
/* 68:   */   {
/* 69:86 */     return SpringTransactionAnnotationParser.class.hashCode();
/* 70:   */   }
/* 71:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.transaction.annotation.SpringTransactionAnnotationParser
 * JD-Core Version:    0.7.0.1
 */