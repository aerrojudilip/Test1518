/*  1:   */ package org.springframework.transaction.annotation;
/*  2:   */ 
/*  3:   */ import java.io.Serializable;
/*  4:   */ import java.lang.reflect.AnnotatedElement;
/*  5:   */ import javax.ejb.ApplicationException;
/*  6:   */ import javax.ejb.TransactionAttributeType;
/*  7:   */ import org.springframework.transaction.interceptor.DefaultTransactionAttribute;
/*  8:   */ 
/*  9:   */ public class Ejb3TransactionAnnotationParser
/* 10:   */   implements TransactionAnnotationParser, Serializable
/* 11:   */ {
/* 12:   */   public org.springframework.transaction.interceptor.TransactionAttribute parseTransactionAnnotation(AnnotatedElement ae)
/* 13:   */   {
/* 14:37 */     javax.ejb.TransactionAttribute ann = (javax.ejb.TransactionAttribute)ae.getAnnotation(javax.ejb.TransactionAttribute.class);
/* 15:38 */     if (ann != null) {
/* 16:39 */       return parseTransactionAnnotation(ann);
/* 17:   */     }
/* 18:42 */     return null;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public org.springframework.transaction.interceptor.TransactionAttribute parseTransactionAnnotation(javax.ejb.TransactionAttribute ann)
/* 22:   */   {
/* 23:47 */     return new Ejb3TransactionAttribute(ann.value());
/* 24:   */   }
/* 25:   */   
/* 26:   */   public boolean equals(Object other)
/* 27:   */   {
/* 28:52 */     return (this == other) || ((other instanceof Ejb3TransactionAnnotationParser));
/* 29:   */   }
/* 30:   */   
/* 31:   */   public int hashCode()
/* 32:   */   {
/* 33:57 */     return Ejb3TransactionAnnotationParser.class.hashCode();
/* 34:   */   }
/* 35:   */   
/* 36:   */   private static class Ejb3TransactionAttribute
/* 37:   */     extends DefaultTransactionAttribute
/* 38:   */   {
/* 39:   */     public Ejb3TransactionAttribute(TransactionAttributeType type)
/* 40:   */     {
/* 41:68 */       setPropagationBehaviorName("PROPAGATION_" + type.name());
/* 42:   */     }
/* 43:   */     
/* 44:   */     public boolean rollbackOn(Throwable ex)
/* 45:   */     {
/* 46:73 */       ApplicationException ann = (ApplicationException)ex.getClass().getAnnotation(ApplicationException.class);
/* 47:74 */       return ann != null ? ann.rollback() : super.rollbackOn(ex);
/* 48:   */     }
/* 49:   */   }
/* 50:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.transaction.annotation.Ejb3TransactionAnnotationParser
 * JD-Core Version:    0.7.0.1
 */