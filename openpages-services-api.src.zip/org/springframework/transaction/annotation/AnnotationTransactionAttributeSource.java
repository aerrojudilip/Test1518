/*   1:    */ package org.springframework.transaction.annotation;
/*   2:    */ 
/*   3:    */ import java.io.Serializable;
/*   4:    */ import java.lang.reflect.AnnotatedElement;
/*   5:    */ import java.lang.reflect.Method;
/*   6:    */ import java.util.Collections;
/*   7:    */ import java.util.LinkedHashSet;
/*   8:    */ import java.util.Set;
/*   9:    */ import org.springframework.transaction.interceptor.AbstractFallbackTransactionAttributeSource;
/*  10:    */ import org.springframework.transaction.interceptor.TransactionAttribute;
/*  11:    */ import org.springframework.util.Assert;
/*  12:    */ import org.springframework.util.ClassUtils;
/*  13:    */ 
/*  14:    */ public class AnnotationTransactionAttributeSource
/*  15:    */   extends AbstractFallbackTransactionAttributeSource
/*  16:    */   implements Serializable
/*  17:    */ {
/*  18: 55 */   private static final boolean ejb3Present = ClassUtils.isPresent("javax.ejb.TransactionAttribute", AnnotationTransactionAttributeSource.class.getClassLoader());
/*  19:    */   private final boolean publicMethodsOnly;
/*  20:    */   private final Set<TransactionAnnotationParser> annotationParsers;
/*  21:    */   
/*  22:    */   public AnnotationTransactionAttributeSource()
/*  23:    */   {
/*  24: 69 */     this(true);
/*  25:    */   }
/*  26:    */   
/*  27:    */   public AnnotationTransactionAttributeSource(boolean publicMethodsOnly)
/*  28:    */   {
/*  29: 82 */     this.publicMethodsOnly = publicMethodsOnly;
/*  30: 83 */     this.annotationParsers = new LinkedHashSet(2);
/*  31: 84 */     this.annotationParsers.add(new SpringTransactionAnnotationParser());
/*  32: 85 */     if (ejb3Present) {
/*  33: 86 */       this.annotationParsers.add(new Ejb3TransactionAnnotationParser());
/*  34:    */     }
/*  35:    */   }
/*  36:    */   
/*  37:    */   public AnnotationTransactionAttributeSource(TransactionAnnotationParser annotationParser)
/*  38:    */   {
/*  39: 95 */     this.publicMethodsOnly = true;
/*  40: 96 */     Assert.notNull(annotationParser, "TransactionAnnotationParser must not be null");
/*  41: 97 */     this.annotationParsers = Collections.singleton(annotationParser);
/*  42:    */   }
/*  43:    */   
/*  44:    */   public AnnotationTransactionAttributeSource(TransactionAnnotationParser... annotationParsers)
/*  45:    */   {
/*  46:105 */     this.publicMethodsOnly = true;
/*  47:106 */     Assert.notEmpty(annotationParsers, "At least one TransactionAnnotationParser needs to be specified");
/*  48:107 */     Set<TransactionAnnotationParser> parsers = new LinkedHashSet(annotationParsers.length);
/*  49:108 */     Collections.addAll(parsers, annotationParsers);
/*  50:109 */     this.annotationParsers = parsers;
/*  51:    */   }
/*  52:    */   
/*  53:    */   public AnnotationTransactionAttributeSource(Set<TransactionAnnotationParser> annotationParsers)
/*  54:    */   {
/*  55:117 */     this.publicMethodsOnly = true;
/*  56:118 */     Assert.notEmpty(annotationParsers, "At least one TransactionAnnotationParser needs to be specified");
/*  57:119 */     this.annotationParsers = annotationParsers;
/*  58:    */   }
/*  59:    */   
/*  60:    */   protected TransactionAttribute findTransactionAttribute(Method method)
/*  61:    */   {
/*  62:125 */     return determineTransactionAttribute(method);
/*  63:    */   }
/*  64:    */   
/*  65:    */   protected TransactionAttribute findTransactionAttribute(Class<?> clazz)
/*  66:    */   {
/*  67:130 */     return determineTransactionAttribute(clazz);
/*  68:    */   }
/*  69:    */   
/*  70:    */   protected TransactionAttribute determineTransactionAttribute(AnnotatedElement ae)
/*  71:    */   {
/*  72:145 */     for (TransactionAnnotationParser annotationParser : this.annotationParsers)
/*  73:    */     {
/*  74:146 */       TransactionAttribute attr = annotationParser.parseTransactionAnnotation(ae);
/*  75:147 */       if (attr != null) {
/*  76:148 */         return attr;
/*  77:    */       }
/*  78:    */     }
/*  79:151 */     return null;
/*  80:    */   }
/*  81:    */   
/*  82:    */   protected boolean allowPublicMethodsOnly()
/*  83:    */   {
/*  84:159 */     return this.publicMethodsOnly;
/*  85:    */   }
/*  86:    */   
/*  87:    */   public boolean equals(Object other)
/*  88:    */   {
/*  89:165 */     if (this == other) {
/*  90:166 */       return true;
/*  91:    */     }
/*  92:168 */     if (!(other instanceof AnnotationTransactionAttributeSource)) {
/*  93:169 */       return false;
/*  94:    */     }
/*  95:171 */     AnnotationTransactionAttributeSource otherTas = (AnnotationTransactionAttributeSource)other;
/*  96:172 */     return (this.annotationParsers.equals(otherTas.annotationParsers)) && (this.publicMethodsOnly == otherTas.publicMethodsOnly);
/*  97:    */   }
/*  98:    */   
/*  99:    */   public int hashCode()
/* 100:    */   {
/* 101:178 */     return this.annotationParsers.hashCode();
/* 102:    */   }
/* 103:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.transaction.annotation.AnnotationTransactionAttributeSource
 * JD-Core Version:    0.7.0.1
 */