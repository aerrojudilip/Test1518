/*  1:   */ package org.springframework.transaction.annotation;
/*  2:   */ 
/*  3:   */ import java.util.Collection;
/*  4:   */ import java.util.Iterator;
/*  5:   */ import org.springframework.beans.factory.annotation.Autowired;
/*  6:   */ import org.springframework.context.annotation.Configuration;
/*  7:   */ import org.springframework.context.annotation.ImportAware;
/*  8:   */ import org.springframework.core.annotation.AnnotationAttributes;
/*  9:   */ import org.springframework.core.type.AnnotationMetadata;
/* 10:   */ import org.springframework.transaction.PlatformTransactionManager;
/* 11:   */ import org.springframework.util.Assert;
/* 12:   */ 
/* 13:   */ @Configuration
/* 14:   */ public abstract class AbstractTransactionManagementConfiguration
/* 15:   */   implements ImportAware
/* 16:   */ {
/* 17:   */   protected AnnotationAttributes enableTx;
/* 18:   */   protected PlatformTransactionManager txManager;
/* 19:   */   
/* 20:   */   public void setImportMetadata(AnnotationMetadata importMetadata)
/* 21:   */   {
/* 22:44 */     this.enableTx = AnnotationAttributes.fromMap(importMetadata.getAnnotationAttributes(EnableTransactionManagement.class.getName(), false));
/* 23:   */     
/* 24:46 */     Assert.notNull(this.enableTx, "@EnableTransactionManagement is not present on importing class " + importMetadata.getClassName());
/* 25:   */   }
/* 26:   */   
/* 27:   */   @Autowired(required=false)
/* 28:   */   void setConfigurers(Collection<TransactionManagementConfigurer> configurers)
/* 29:   */   {
/* 30:53 */     if ((configurers == null) || (configurers.isEmpty())) {
/* 31:54 */       return;
/* 32:   */     }
/* 33:57 */     if (configurers.size() > 1) {
/* 34:58 */       throw new IllegalStateException("only one TransactionManagementConfigurer may exist");
/* 35:   */     }
/* 36:61 */     TransactionManagementConfigurer configurer = (TransactionManagementConfigurer)configurers.iterator().next();
/* 37:62 */     this.txManager = configurer.annotationDrivenTransactionManager();
/* 38:   */   }
/* 39:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.transaction.annotation.AbstractTransactionManagementConfiguration
 * JD-Core Version:    0.7.0.1
 */