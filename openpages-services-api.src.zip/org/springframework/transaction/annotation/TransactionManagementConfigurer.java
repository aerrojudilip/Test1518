package org.springframework.transaction.annotation;

import org.springframework.transaction.PlatformTransactionManager;

public abstract interface TransactionManagementConfigurer
{
  public abstract PlatformTransactionManager annotationDrivenTransactionManager();
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.transaction.annotation.TransactionManagementConfigurer
 * JD-Core Version:    0.7.0.1
 */