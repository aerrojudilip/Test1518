/*   1:    */ package org.springframework.transaction.annotation;
/*   2:    */ 
/*   3:    */ public enum Propagation
/*   4:    */ {
/*   5: 37 */   REQUIRED(0),  SUPPORTS(1),  MANDATORY(2),  REQUIRES_NEW(3),  NOT_SUPPORTED(4),  NEVER(5),  NESTED(6);
/*   6:    */   
/*   7:    */   private final int value;
/*   8:    */   
/*   9:    */   private Propagation(int value)
/*  10:    */   {
/*  11:101 */     this.value = value;
/*  12:    */   }
/*  13:    */   
/*  14:    */   public int value()
/*  15:    */   {
/*  16:103 */     return this.value;
/*  17:    */   }
/*  18:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.transaction.annotation.Propagation
 * JD-Core Version:    0.7.0.1
 */