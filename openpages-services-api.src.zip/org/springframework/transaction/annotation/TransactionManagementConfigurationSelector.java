/*  1:   */ package org.springframework.transaction.annotation;
/*  2:   */ 
/*  3:   */ import org.springframework.context.annotation.AdviceMode;
/*  4:   */ import org.springframework.context.annotation.AdviceModeImportSelector;
/*  5:   */ import org.springframework.context.annotation.AutoProxyRegistrar;
/*  6:   */ 
/*  7:   */ public class TransactionManagementConfigurationSelector
/*  8:   */   extends AdviceModeImportSelector<EnableTransactionManagement>
/*  9:   */ {
/* 10:   */   protected String[] selectImports(AdviceMode adviceMode)
/* 11:   */   {
/* 12:46 */     switch (1.$SwitchMap$org$springframework$context$annotation$AdviceMode[adviceMode.ordinal()])
/* 13:   */     {
/* 14:   */     case 1: 
/* 15:48 */       return new String[] { AutoProxyRegistrar.class.getName(), ProxyTransactionManagementConfiguration.class.getName() };
/* 16:   */     case 2: 
/* 17:50 */       return new String[] { "org.springframework.transaction.aspectj.AspectJTransactionManagementConfiguration" };
/* 18:   */     }
/* 19:52 */     return null;
/* 20:   */   }
/* 21:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.transaction.annotation.TransactionManagementConfigurationSelector
 * JD-Core Version:    0.7.0.1
 */