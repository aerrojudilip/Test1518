/*   1:    */ package org.springframework.transaction.jta;
/*   2:    */ 
/*   3:    */ import java.io.Serializable;
/*   4:    */ import java.lang.reflect.InvocationTargetException;
/*   5:    */ import java.lang.reflect.Method;
/*   6:    */ import javax.transaction.InvalidTransactionException;
/*   7:    */ import javax.transaction.NotSupportedException;
/*   8:    */ import javax.transaction.SystemException;
/*   9:    */ import javax.transaction.Transaction;
/*  10:    */ import javax.transaction.TransactionManager;
/*  11:    */ import javax.transaction.UserTransaction;
/*  12:    */ import org.apache.commons.logging.Log;
/*  13:    */ import org.springframework.transaction.TransactionDefinition;
/*  14:    */ import org.springframework.transaction.TransactionSystemException;
/*  15:    */ 
/*  16:    */ public class WebLogicJtaTransactionManager
/*  17:    */   extends JtaTransactionManager
/*  18:    */ {
/*  19:    */   private static final String USER_TRANSACTION_CLASS_NAME = "weblogic.transaction.UserTransaction";
/*  20:    */   private static final String CLIENT_TRANSACTION_MANAGER_CLASS_NAME = "weblogic.transaction.ClientTransactionManager";
/*  21:    */   private static final String TRANSACTION_CLASS_NAME = "weblogic.transaction.Transaction";
/*  22:    */   private static final String TRANSACTION_HELPER_CLASS_NAME = "weblogic.transaction.TransactionHelper";
/*  23:    */   private static final String ISOLATION_LEVEL_KEY = "ISOLATION LEVEL";
/*  24:    */   private boolean weblogicUserTransactionAvailable;
/*  25:    */   private Method beginWithNameMethod;
/*  26:    */   private Method beginWithNameAndTimeoutMethod;
/*  27:    */   private boolean weblogicTransactionManagerAvailable;
/*  28:    */   private Method forceResumeMethod;
/*  29:    */   private Method setPropertyMethod;
/*  30:    */   private Object transactionHelper;
/*  31:    */   
/*  32:    */   public void afterPropertiesSet()
/*  33:    */     throws TransactionSystemException
/*  34:    */   {
/*  35: 98 */     super.afterPropertiesSet();
/*  36: 99 */     loadWebLogicTransactionClasses();
/*  37:    */   }
/*  38:    */   
/*  39:    */   protected UserTransaction retrieveUserTransaction()
/*  40:    */     throws TransactionSystemException
/*  41:    */   {
/*  42:104 */     loadWebLogicTransactionHelper();
/*  43:    */     try
/*  44:    */     {
/*  45:106 */       this.logger.debug("Retrieving JTA UserTransaction from WebLogic TransactionHelper");
/*  46:107 */       Method getUserTransactionMethod = this.transactionHelper.getClass().getMethod("getUserTransaction", new Class[0]);
/*  47:108 */       return (UserTransaction)getUserTransactionMethod.invoke(this.transactionHelper, new Object[0]);
/*  48:    */     }
/*  49:    */     catch (InvocationTargetException ex)
/*  50:    */     {
/*  51:111 */       throw new TransactionSystemException("WebLogic's TransactionHelper.getUserTransaction() method failed", ex.getTargetException());
/*  52:    */     }
/*  53:    */     catch (Exception ex)
/*  54:    */     {
/*  55:115 */       throw new TransactionSystemException("Could not invoke WebLogic's TransactionHelper.getUserTransaction() method", ex);
/*  56:    */     }
/*  57:    */   }
/*  58:    */   
/*  59:    */   protected TransactionManager retrieveTransactionManager()
/*  60:    */     throws TransactionSystemException
/*  61:    */   {
/*  62:122 */     loadWebLogicTransactionHelper();
/*  63:    */     try
/*  64:    */     {
/*  65:124 */       this.logger.debug("Retrieving JTA TransactionManager from WebLogic TransactionHelper");
/*  66:125 */       Method getTransactionManagerMethod = this.transactionHelper.getClass().getMethod("getTransactionManager", new Class[0]);
/*  67:126 */       return (TransactionManager)getTransactionManagerMethod.invoke(this.transactionHelper, new Object[0]);
/*  68:    */     }
/*  69:    */     catch (InvocationTargetException ex)
/*  70:    */     {
/*  71:129 */       throw new TransactionSystemException("WebLogic's TransactionHelper.getTransactionManager() method failed", ex.getTargetException());
/*  72:    */     }
/*  73:    */     catch (Exception ex)
/*  74:    */     {
/*  75:133 */       throw new TransactionSystemException("Could not invoke WebLogic's TransactionHelper.getTransactionManager() method", ex);
/*  76:    */     }
/*  77:    */   }
/*  78:    */   
/*  79:    */   private void loadWebLogicTransactionHelper()
/*  80:    */     throws TransactionSystemException
/*  81:    */   {
/*  82:140 */     if (this.transactionHelper == null) {
/*  83:    */       try
/*  84:    */       {
/*  85:142 */         Class transactionHelperClass = getClass().getClassLoader().loadClass("weblogic.transaction.TransactionHelper");
/*  86:143 */         Method getTransactionHelperMethod = transactionHelperClass.getMethod("getTransactionHelper", new Class[0]);
/*  87:144 */         this.transactionHelper = getTransactionHelperMethod.invoke(null, new Object[0]);
/*  88:145 */         this.logger.debug("WebLogic TransactionHelper found");
/*  89:    */       }
/*  90:    */       catch (InvocationTargetException ex)
/*  91:    */       {
/*  92:148 */         throw new TransactionSystemException("WebLogic's TransactionHelper.getTransactionHelper() method failed", ex.getTargetException());
/*  93:    */       }
/*  94:    */       catch (Exception ex)
/*  95:    */       {
/*  96:152 */         throw new TransactionSystemException("Could not initialize WebLogicJtaTransactionManager because WebLogic API classes are not available", ex);
/*  97:    */       }
/*  98:    */     }
/*  99:    */   }
/* 100:    */   
/* 101:    */   private void loadWebLogicTransactionClasses()
/* 102:    */     throws TransactionSystemException
/* 103:    */   {
/* 104:    */     try
/* 105:    */     {
/* 106:161 */       Class userTransactionClass = getClass().getClassLoader().loadClass("weblogic.transaction.UserTransaction");
/* 107:162 */       this.weblogicUserTransactionAvailable = userTransactionClass.isInstance(getUserTransaction());
/* 108:163 */       if (this.weblogicUserTransactionAvailable)
/* 109:    */       {
/* 110:164 */         this.beginWithNameMethod = userTransactionClass.getMethod("begin", new Class[] { String.class });
/* 111:165 */         this.beginWithNameAndTimeoutMethod = userTransactionClass.getMethod("begin", new Class[] { String.class, Integer.TYPE });
/* 112:166 */         this.logger.info("Support for WebLogic transaction names available");
/* 113:    */       }
/* 114:    */       else
/* 115:    */       {
/* 116:169 */         this.logger.info("Support for WebLogic transaction names not available");
/* 117:    */       }
/* 118:173 */       Class transactionManagerClass = getClass().getClassLoader().loadClass("weblogic.transaction.ClientTransactionManager");
/* 119:    */       
/* 120:175 */       this.logger.debug("WebLogic ClientTransactionManager found");
/* 121:    */       
/* 122:177 */       this.weblogicTransactionManagerAvailable = transactionManagerClass.isInstance(getTransactionManager());
/* 123:178 */       if (this.weblogicTransactionManagerAvailable)
/* 124:    */       {
/* 125:179 */         Class transactionClass = getClass().getClassLoader().loadClass("weblogic.transaction.Transaction");
/* 126:180 */         this.forceResumeMethod = transactionManagerClass.getMethod("forceResume", new Class[] { Transaction.class });
/* 127:181 */         this.setPropertyMethod = transactionClass.getMethod("setProperty", new Class[] { String.class, Serializable.class });
/* 128:182 */         this.logger.debug("Support for WebLogic forceResume available");
/* 129:    */       }
/* 130:    */       else
/* 131:    */       {
/* 132:185 */         this.logger.warn("Support for WebLogic forceResume not available");
/* 133:    */       }
/* 134:    */     }
/* 135:    */     catch (Exception ex)
/* 136:    */     {
/* 137:189 */       throw new TransactionSystemException("Could not initialize WebLogicJtaTransactionManager because WebLogic API classes are not available", ex);
/* 138:    */     }
/* 139:    */   }
/* 140:    */   
/* 141:    */   protected void doJtaBegin(JtaTransactionObject txObject, TransactionDefinition definition)
/* 142:    */     throws NotSupportedException, SystemException
/* 143:    */   {
/* 144:200 */     int timeout = determineTimeout(definition);
/* 145:203 */     if ((this.weblogicUserTransactionAvailable) && (definition.getName() != null))
/* 146:    */     {
/* 147:    */       try
/* 148:    */       {
/* 149:205 */         if (timeout > -1) {
/* 150:210 */           this.beginWithNameAndTimeoutMethod.invoke(txObject.getUserTransaction(), new Object[] { definition.getName(), Integer.valueOf(timeout) });
/* 151:    */         } else {
/* 152:217 */           this.beginWithNameMethod.invoke(txObject.getUserTransaction(), new Object[] { definition.getName() });
/* 153:    */         }
/* 154:    */       }
/* 155:    */       catch (InvocationTargetException ex)
/* 156:    */       {
/* 157:221 */         throw new TransactionSystemException("WebLogic's UserTransaction.begin() method failed", ex.getTargetException());
/* 158:    */       }
/* 159:    */       catch (Exception ex)
/* 160:    */       {
/* 161:225 */         throw new TransactionSystemException("Could not invoke WebLogic's UserTransaction.begin() method", ex);
/* 162:    */       }
/* 163:    */     }
/* 164:    */     else
/* 165:    */     {
/* 166:232 */       applyTimeout(txObject, timeout);
/* 167:233 */       txObject.getUserTransaction().begin();
/* 168:    */     }
/* 169:237 */     if (this.weblogicTransactionManagerAvailable)
/* 170:    */     {
/* 171:238 */       if (definition.getIsolationLevel() != -1) {
/* 172:    */         try
/* 173:    */         {
/* 174:240 */           Transaction tx = getTransactionManager().getTransaction();
/* 175:241 */           Integer isolationLevel = Integer.valueOf(definition.getIsolationLevel());
/* 176:    */           
/* 177:    */ 
/* 178:    */ 
/* 179:    */ 
/* 180:246 */           this.setPropertyMethod.invoke(tx, new Object[] { "ISOLATION LEVEL", isolationLevel });
/* 181:    */         }
/* 182:    */         catch (InvocationTargetException ex)
/* 183:    */         {
/* 184:249 */           throw new TransactionSystemException("WebLogic's Transaction.setProperty(String, Serializable) method failed", ex.getTargetException());
/* 185:    */         }
/* 186:    */         catch (Exception ex)
/* 187:    */         {
/* 188:253 */           throw new TransactionSystemException("Could not invoke WebLogic's Transaction.setProperty(String, Serializable) method", ex);
/* 189:    */         }
/* 190:    */       }
/* 191:    */     }
/* 192:    */     else {
/* 193:259 */       applyIsolationLevel(txObject, definition.getIsolationLevel());
/* 194:    */     }
/* 195:    */   }
/* 196:    */   
/* 197:    */   protected void doJtaResume(JtaTransactionObject txObject, Object suspendedTransaction)
/* 198:    */     throws InvalidTransactionException, SystemException
/* 199:    */   {
/* 200:    */     try
/* 201:    */     {
/* 202:268 */       getTransactionManager().resume((Transaction)suspendedTransaction);
/* 203:    */     }
/* 204:    */     catch (InvalidTransactionException ex)
/* 205:    */     {
/* 206:271 */       if (!this.weblogicTransactionManagerAvailable) {
/* 207:272 */         throw ex;
/* 208:    */       }
/* 209:275 */       if (this.logger.isDebugEnabled()) {
/* 210:276 */         this.logger.debug("Standard JTA resume threw InvalidTransactionException: " + ex.getMessage() + " - trying WebLogic JTA forceResume");
/* 211:    */       }
/* 212:    */       try
/* 213:    */       {
/* 214:285 */         this.forceResumeMethod.invoke(getTransactionManager(), new Object[] { suspendedTransaction });
/* 215:    */       }
/* 216:    */       catch (InvocationTargetException ex2)
/* 217:    */       {
/* 218:288 */         throw new TransactionSystemException("WebLogic's TransactionManager.forceResume(Transaction) method failed", ex2.getTargetException());
/* 219:    */       }
/* 220:    */       catch (Exception ex2)
/* 221:    */       {
/* 222:292 */         throw new TransactionSystemException("Could not access WebLogic's TransactionManager.forceResume(Transaction) method", ex2);
/* 223:    */       }
/* 224:    */     }
/* 225:    */   }
/* 226:    */   
/* 227:    */   public Transaction createTransaction(String name, int timeout)
/* 228:    */     throws NotSupportedException, SystemException
/* 229:    */   {
/* 230:301 */     if ((this.weblogicUserTransactionAvailable) && (name != null))
/* 231:    */     {
/* 232:    */       try
/* 233:    */       {
/* 234:303 */         if (timeout >= 0) {
/* 235:304 */           this.beginWithNameAndTimeoutMethod.invoke(getUserTransaction(), new Object[] { name, Integer.valueOf(timeout) });
/* 236:    */         } else {
/* 237:307 */           this.beginWithNameMethod.invoke(getUserTransaction(), new Object[] { name });
/* 238:    */         }
/* 239:    */       }
/* 240:    */       catch (InvocationTargetException ex)
/* 241:    */       {
/* 242:311 */         if ((ex.getTargetException() instanceof NotSupportedException)) {
/* 243:312 */           throw ((NotSupportedException)ex.getTargetException());
/* 244:    */         }
/* 245:314 */         if ((ex.getTargetException() instanceof SystemException)) {
/* 246:315 */           throw ((SystemException)ex.getTargetException());
/* 247:    */         }
/* 248:317 */         if ((ex.getTargetException() instanceof RuntimeException)) {
/* 249:318 */           throw ((RuntimeException)ex.getTargetException());
/* 250:    */         }
/* 251:321 */         throw new SystemException("WebLogic's begin() method failed with an unexpected error: " + ex.getTargetException());
/* 252:    */       }
/* 253:    */       catch (Exception ex)
/* 254:    */       {
/* 255:326 */         throw new SystemException("Could not invoke WebLogic's UserTransaction.begin() method: " + ex);
/* 256:    */       }
/* 257:328 */       return new ManagedTransactionAdapter(getTransactionManager());
/* 258:    */     }
/* 259:333 */     return super.createTransaction(name, timeout);
/* 260:    */   }
/* 261:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.transaction.jta.WebLogicJtaTransactionManager
 * JD-Core Version:    0.7.0.1
 */