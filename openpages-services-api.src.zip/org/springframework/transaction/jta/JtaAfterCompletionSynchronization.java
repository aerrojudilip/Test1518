/*  1:   */ package org.springframework.transaction.jta;
/*  2:   */ 
/*  3:   */ import java.util.List;
/*  4:   */ import javax.transaction.Synchronization;
/*  5:   */ import org.springframework.transaction.support.TransactionSynchronization;
/*  6:   */ import org.springframework.transaction.support.TransactionSynchronizationUtils;
/*  7:   */ 
/*  8:   */ public class JtaAfterCompletionSynchronization
/*  9:   */   implements Synchronization
/* 10:   */ {
/* 11:   */   private final List<TransactionSynchronization> synchronizations;
/* 12:   */   
/* 13:   */   public JtaAfterCompletionSynchronization(List<TransactionSynchronization> synchronizations)
/* 14:   */   {
/* 15:48 */     this.synchronizations = synchronizations;
/* 16:   */   }
/* 17:   */   
/* 18:   */   public void beforeCompletion() {}
/* 19:   */   
/* 20:   */   public void afterCompletion(int status)
/* 21:   */   {
/* 22:56 */     switch (status)
/* 23:   */     {
/* 24:   */     case 3: 
/* 25:   */       try
/* 26:   */       {
/* 27:59 */         TransactionSynchronizationUtils.invokeAfterCommit(this.synchronizations);
/* 28:   */       }
/* 29:   */       finally
/* 30:   */       {
/* 31:62 */         TransactionSynchronizationUtils.invokeAfterCompletion(this.synchronizations, 0);
/* 32:   */       }
/* 33:65 */       break;
/* 34:   */     case 4: 
/* 35:67 */       TransactionSynchronizationUtils.invokeAfterCompletion(this.synchronizations, 1);
/* 36:   */       
/* 37:69 */       break;
/* 38:   */     default: 
/* 39:71 */       TransactionSynchronizationUtils.invokeAfterCompletion(this.synchronizations, 2);
/* 40:   */     }
/* 41:   */   }
/* 42:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.transaction.jta.JtaAfterCompletionSynchronization
 * JD-Core Version:    0.7.0.1
 */