/*   1:    */ package org.springframework.transaction.jta;
/*   2:    */ 
/*   3:    */ import com.ibm.wsspi.uow.UOWAction;
/*   4:    */ import com.ibm.wsspi.uow.UOWActionException;
/*   5:    */ import com.ibm.wsspi.uow.UOWException;
/*   6:    */ import com.ibm.wsspi.uow.UOWManager;
/*   7:    */ import com.ibm.wsspi.uow.UOWManagerFactory;
/*   8:    */ import java.util.List;
/*   9:    */ import javax.naming.NamingException;
/*  10:    */ import org.apache.commons.logging.Log;
/*  11:    */ import org.springframework.jndi.JndiTemplate;
/*  12:    */ import org.springframework.transaction.IllegalTransactionStateException;
/*  13:    */ import org.springframework.transaction.InvalidTimeoutException;
/*  14:    */ import org.springframework.transaction.NestedTransactionNotSupportedException;
/*  15:    */ import org.springframework.transaction.TransactionDefinition;
/*  16:    */ import org.springframework.transaction.TransactionException;
/*  17:    */ import org.springframework.transaction.TransactionSystemException;
/*  18:    */ import org.springframework.transaction.support.AbstractPlatformTransactionManager.SuspendedResourcesHolder;
/*  19:    */ import org.springframework.transaction.support.CallbackPreferringPlatformTransactionManager;
/*  20:    */ import org.springframework.transaction.support.DefaultTransactionDefinition;
/*  21:    */ import org.springframework.transaction.support.DefaultTransactionStatus;
/*  22:    */ import org.springframework.transaction.support.TransactionCallback;
/*  23:    */ import org.springframework.transaction.support.TransactionSynchronization;
/*  24:    */ import org.springframework.transaction.support.TransactionSynchronizationManager;
/*  25:    */ import org.springframework.util.ReflectionUtils;
/*  26:    */ 
/*  27:    */ public class WebSphereUowTransactionManager
/*  28:    */   extends JtaTransactionManager
/*  29:    */   implements CallbackPreferringPlatformTransactionManager
/*  30:    */ {
/*  31:    */   public static final String DEFAULT_UOW_MANAGER_NAME = "java:comp/websphere/UOWManager";
/*  32:    */   private UOWManager uowManager;
/*  33:    */   private String uowManagerName;
/*  34:    */   
/*  35:    */   public WebSphereUowTransactionManager()
/*  36:    */   {
/*  37: 99 */     setAutodetectTransactionManager(false);
/*  38:    */   }
/*  39:    */   
/*  40:    */   public WebSphereUowTransactionManager(UOWManager uowManager)
/*  41:    */   {
/*  42:107 */     this();
/*  43:108 */     this.uowManager = uowManager;
/*  44:    */   }
/*  45:    */   
/*  46:    */   public void setUowManager(UOWManager uowManager)
/*  47:    */   {
/*  48:119 */     this.uowManager = uowManager;
/*  49:    */   }
/*  50:    */   
/*  51:    */   public void setUowManagerName(String uowManagerName)
/*  52:    */   {
/*  53:129 */     this.uowManagerName = uowManagerName;
/*  54:    */   }
/*  55:    */   
/*  56:    */   public void afterPropertiesSet()
/*  57:    */     throws TransactionSystemException
/*  58:    */   {
/*  59:135 */     initUserTransactionAndTransactionManager();
/*  60:138 */     if (this.uowManager == null) {
/*  61:139 */       if (this.uowManagerName != null) {
/*  62:140 */         this.uowManager = lookupUowManager(this.uowManagerName);
/*  63:    */       } else {
/*  64:143 */         this.uowManager = lookupDefaultUowManager();
/*  65:    */       }
/*  66:    */     }
/*  67:    */   }
/*  68:    */   
/*  69:    */   protected UOWManager lookupUowManager(String uowManagerName)
/*  70:    */     throws TransactionSystemException
/*  71:    */   {
/*  72:    */     try
/*  73:    */     {
/*  74:158 */       if (this.logger.isDebugEnabled()) {
/*  75:159 */         this.logger.debug("Retrieving WebSphere UOWManager from JNDI location [" + uowManagerName + "]");
/*  76:    */       }
/*  77:161 */       return (UOWManager)getJndiTemplate().lookup(uowManagerName, UOWManager.class);
/*  78:    */     }
/*  79:    */     catch (NamingException ex)
/*  80:    */     {
/*  81:164 */       throw new TransactionSystemException("WebSphere UOWManager is not available at JNDI location [" + uowManagerName + "]", ex);
/*  82:    */     }
/*  83:    */   }
/*  84:    */   
/*  85:    */   protected UOWManager lookupDefaultUowManager()
/*  86:    */     throws TransactionSystemException
/*  87:    */   {
/*  88:    */     try
/*  89:    */     {
/*  90:178 */       this.logger.debug("Retrieving WebSphere UOWManager from default JNDI location [java:comp/websphere/UOWManager]");
/*  91:179 */       return (UOWManager)getJndiTemplate().lookup("java:comp/websphere/UOWManager", UOWManager.class);
/*  92:    */     }
/*  93:    */     catch (NamingException ex)
/*  94:    */     {
/*  95:182 */       this.logger.debug("WebSphere UOWManager is not available at default JNDI location [java:comp/websphere/UOWManager] - falling back to UOWManagerFactory lookup");
/*  96:    */     }
/*  97:184 */     return UOWManagerFactory.getUOWManager();
/*  98:    */   }
/*  99:    */   
/* 100:    */   protected void doRegisterAfterCompletionWithJtaTransaction(JtaTransactionObject txObject, List<TransactionSynchronization> synchronizations)
/* 101:    */   {
/* 102:195 */     this.uowManager.registerInterposedSynchronization(new JtaAfterCompletionSynchronization(synchronizations));
/* 103:    */   }
/* 104:    */   
/* 105:    */   public boolean supportsResourceAdapterManagedTransactions()
/* 106:    */   {
/* 107:209 */     return true;
/* 108:    */   }
/* 109:    */   
/* 110:    */   public <T> T execute(TransactionDefinition definition, TransactionCallback<T> callback)
/* 111:    */     throws TransactionException
/* 112:    */   {
/* 113:214 */     if (definition == null) {
/* 114:216 */       definition = new DefaultTransactionDefinition();
/* 115:    */     }
/* 116:219 */     if (definition.getTimeout() < -1) {
/* 117:220 */       throw new InvalidTimeoutException("Invalid transaction timeout", definition.getTimeout());
/* 118:    */     }
/* 119:222 */     int pb = definition.getPropagationBehavior();
/* 120:223 */     boolean existingTx = (this.uowManager.getUOWStatus() != 5) && (this.uowManager.getUOWType() != 0);
/* 121:    */     
/* 122:    */ 
/* 123:226 */     int uowType = 1;
/* 124:227 */     boolean joinTx = false;
/* 125:228 */     boolean newSynch = false;
/* 126:230 */     if (existingTx)
/* 127:    */     {
/* 128:231 */       if (pb == 5) {
/* 129:232 */         throw new IllegalTransactionStateException("Transaction propagation 'never' but existing transaction found");
/* 130:    */       }
/* 131:235 */       if (pb == 6) {
/* 132:236 */         throw new NestedTransactionNotSupportedException("Transaction propagation 'nested' not supported for WebSphere UOW transactions");
/* 133:    */       }
/* 134:239 */       if ((pb == 1) || (pb == 0) || (pb == 2))
/* 135:    */       {
/* 136:241 */         joinTx = true;
/* 137:242 */         newSynch = getTransactionSynchronization() != 2;
/* 138:    */       }
/* 139:244 */       else if (pb == 4)
/* 140:    */       {
/* 141:245 */         uowType = 0;
/* 142:246 */         newSynch = getTransactionSynchronization() == 0;
/* 143:    */       }
/* 144:    */       else
/* 145:    */       {
/* 146:249 */         newSynch = getTransactionSynchronization() != 2;
/* 147:    */       }
/* 148:    */     }
/* 149:    */     else
/* 150:    */     {
/* 151:253 */       if (pb == 2) {
/* 152:254 */         throw new IllegalTransactionStateException("Transaction propagation 'mandatory' but no existing transaction found");
/* 153:    */       }
/* 154:257 */       if ((pb == 1) || (pb == 4) || (pb == 5))
/* 155:    */       {
/* 156:259 */         uowType = 0;
/* 157:260 */         newSynch = getTransactionSynchronization() == 0;
/* 158:    */       }
/* 159:    */       else
/* 160:    */       {
/* 161:263 */         newSynch = getTransactionSynchronization() != 2;
/* 162:    */       }
/* 163:    */     }
/* 164:267 */     boolean debug = this.logger.isDebugEnabled();
/* 165:268 */     if (debug) {
/* 166:269 */       this.logger.debug("Creating new transaction with name [" + definition.getName() + "]: " + definition);
/* 167:    */     }
/* 168:271 */     AbstractPlatformTransactionManager.SuspendedResourcesHolder suspendedResources = !joinTx ? suspend(null) : null;
/* 169:    */     try
/* 170:    */     {
/* 171:273 */       if (definition.getTimeout() > -1) {
/* 172:274 */         this.uowManager.setUOWTimeout(uowType, definition.getTimeout());
/* 173:    */       }
/* 174:276 */       if (debug) {
/* 175:277 */         this.logger.debug("Invoking WebSphere UOW action: type=" + uowType + ", join=" + joinTx);
/* 176:    */       }
/* 177:279 */       UOWActionAdapter<T> action = new UOWActionAdapter(definition, callback, uowType == 1, !joinTx, newSynch, debug);
/* 178:    */       
/* 179:281 */       this.uowManager.runUnderUOW(uowType, joinTx, action);
/* 180:282 */       if (debug) {
/* 181:283 */         this.logger.debug("Returned from WebSphere UOW action: type=" + uowType + ", join=" + joinTx);
/* 182:    */       }
/* 183:285 */       return action.getResult();
/* 184:    */     }
/* 185:    */     catch (UOWException ex)
/* 186:    */     {
/* 187:288 */       throw new TransactionSystemException("UOWManager transaction processing failed", ex);
/* 188:    */     }
/* 189:    */     catch (UOWActionException ex)
/* 190:    */     {
/* 191:291 */       throw new TransactionSystemException("UOWManager threw unexpected UOWActionException", ex);
/* 192:    */     }
/* 193:    */     finally
/* 194:    */     {
/* 195:294 */       if (suspendedResources != null) {
/* 196:295 */         resume(null, suspendedResources);
/* 197:    */       }
/* 198:    */     }
/* 199:    */   }
/* 200:    */   
/* 201:    */   private class UOWActionAdapter<T>
/* 202:    */     implements UOWAction
/* 203:    */   {
/* 204:    */     private final TransactionDefinition definition;
/* 205:    */     private final TransactionCallback<T> callback;
/* 206:    */     private final boolean actualTransaction;
/* 207:    */     private final boolean newTransaction;
/* 208:    */     private final boolean newSynchronization;
/* 209:    */     private boolean debug;
/* 210:    */     private T result;
/* 211:    */     private Throwable exception;
/* 212:    */     
/* 213:    */     public UOWActionAdapter(TransactionCallback<T> definition, boolean callback, boolean actualTransaction, boolean newTransaction, boolean newSynchronization)
/* 214:    */     {
/* 215:324 */       this.definition = definition;
/* 216:325 */       this.callback = callback;
/* 217:326 */       this.actualTransaction = actualTransaction;
/* 218:327 */       this.newTransaction = newTransaction;
/* 219:328 */       this.newSynchronization = newSynchronization;
/* 220:329 */       this.debug = debug;
/* 221:    */     }
/* 222:    */     
/* 223:    */     public void run()
/* 224:    */     {
/* 225:333 */       DefaultTransactionStatus status = WebSphereUowTransactionManager.this.prepareTransactionStatus(this.definition, this.actualTransaction ? this : null, this.newTransaction, this.newSynchronization, this.debug, null);
/* 226:    */       try
/* 227:    */       {
/* 228:337 */         this.result = this.callback.doInTransaction(status);
/* 229:338 */         WebSphereUowTransactionManager.this.triggerBeforeCommit(status);
/* 230:    */       }
/* 231:    */       catch (Throwable ex)
/* 232:    */       {
/* 233:341 */         this.exception = ex;
/* 234:342 */         WebSphereUowTransactionManager.this.uowManager.setRollbackOnly();
/* 235:    */       }
/* 236:    */       finally
/* 237:    */       {
/* 238:345 */         if (status.isLocalRollbackOnly())
/* 239:    */         {
/* 240:346 */           if (status.isDebug()) {
/* 241:347 */             WebSphereUowTransactionManager.this.logger.debug("Transactional code has requested rollback");
/* 242:    */           }
/* 243:349 */           WebSphereUowTransactionManager.this.uowManager.setRollbackOnly();
/* 244:    */         }
/* 245:351 */         WebSphereUowTransactionManager.this.triggerBeforeCompletion(status);
/* 246:352 */         if (status.isNewSynchronization())
/* 247:    */         {
/* 248:353 */           List<TransactionSynchronization> synchronizations = TransactionSynchronizationManager.getSynchronizations();
/* 249:354 */           TransactionSynchronizationManager.clear();
/* 250:355 */           if (!synchronizations.isEmpty()) {
/* 251:356 */             WebSphereUowTransactionManager.this.uowManager.registerInterposedSynchronization(new JtaAfterCompletionSynchronization(synchronizations));
/* 252:    */           }
/* 253:    */         }
/* 254:    */       }
/* 255:    */     }
/* 256:    */     
/* 257:    */     public T getResult()
/* 258:    */     {
/* 259:363 */       if (this.exception != null) {
/* 260:364 */         ReflectionUtils.rethrowRuntimeException(this.exception);
/* 261:    */       }
/* 262:366 */       return this.result;
/* 263:    */     }
/* 264:    */   }
/* 265:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.transaction.jta.WebSphereUowTransactionManager
 * JD-Core Version:    0.7.0.1
 */