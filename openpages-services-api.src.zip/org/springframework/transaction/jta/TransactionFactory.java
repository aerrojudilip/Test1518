package org.springframework.transaction.jta;

import javax.transaction.NotSupportedException;
import javax.transaction.SystemException;
import javax.transaction.Transaction;

public abstract interface TransactionFactory
{
  public abstract Transaction createTransaction(String paramString, int paramInt)
    throws NotSupportedException, SystemException;
  
  public abstract boolean supportsResourceAdapterManagedTransactions();
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.transaction.jta.TransactionFactory
 * JD-Core Version:    0.7.0.1
 */