/*   1:    */ package org.springframework.transaction.jta;
/*   2:    */ 
/*   3:    */ import java.lang.reflect.InvocationTargetException;
/*   4:    */ import java.lang.reflect.Method;
/*   5:    */ import javax.transaction.NotSupportedException;
/*   6:    */ import javax.transaction.SystemException;
/*   7:    */ import javax.transaction.Transaction;
/*   8:    */ import javax.transaction.TransactionManager;
/*   9:    */ import javax.transaction.UserTransaction;
/*  10:    */ import org.apache.commons.logging.Log;
/*  11:    */ import org.springframework.transaction.TransactionDefinition;
/*  12:    */ import org.springframework.transaction.TransactionSystemException;
/*  13:    */ import org.springframework.util.ClassUtils;
/*  14:    */ 
/*  15:    */ @Deprecated
/*  16:    */ public class OC4JJtaTransactionManager
/*  17:    */   extends JtaTransactionManager
/*  18:    */ {
/*  19:    */   private static final String TRANSACTION_UTILITY_CLASS_NAME = "oracle.j2ee.transaction.TransactionUtility";
/*  20:    */   private static final String TRANSACTION_MANAGER_CLASS_NAME = "oracle.j2ee.transaction.OC4JTransactionManager";
/*  21:    */   private static final String TRANSACTION_CLASS_NAME = "oracle.j2ee.transaction.OC4JTransaction";
/*  22:    */   private static final String FALLBACK_TRANSACTION_MANAGER_CLASS_NAME = "com.evermind.server.ApplicationServerTransactionManager";
/*  23:    */   private static final String FALLBACK_TRANSACTION_CLASS_NAME = "com.evermind.server.ApplicationServerTransaction";
/*  24:    */   private Method beginWithNameMethod;
/*  25:    */   private Method setTransactionIsolationMethod;
/*  26:    */   
/*  27:    */   public void afterPropertiesSet()
/*  28:    */     throws TransactionSystemException
/*  29:    */   {
/*  30: 93 */     super.afterPropertiesSet();
/*  31: 94 */     loadOC4JTransactionClasses();
/*  32:    */   }
/*  33:    */   
/*  34:    */   protected UserTransaction retrieveUserTransaction()
/*  35:    */     throws TransactionSystemException
/*  36:    */   {
/*  37:    */     try
/*  38:    */     {
/*  39:100 */       Class transactionUtilityClass = getClass().getClassLoader().loadClass("oracle.j2ee.transaction.TransactionUtility");
/*  40:101 */       Method getInstanceMethod = transactionUtilityClass.getMethod("getInstance", new Class[0]);
/*  41:102 */       Object transactionUtility = getInstanceMethod.invoke(null, new Object[0]);
/*  42:103 */       this.logger.debug("Retrieving JTA UserTransaction from OC4J TransactionUtility");
/*  43:104 */       Method getUserTransactionMethod = transactionUtility.getClass().getMethod("getOC4JUserTransaction", new Class[0]);
/*  44:    */       
/*  45:106 */       return (UserTransaction)getUserTransactionMethod.invoke(transactionUtility, new Object[0]);
/*  46:    */     }
/*  47:    */     catch (ClassNotFoundException ex)
/*  48:    */     {
/*  49:109 */       this.logger.debug("Could not find OC4J 10.1.3.2 TransactionUtility: " + ex);
/*  50:    */       
/*  51:    */ 
/*  52:112 */       return null;
/*  53:    */     }
/*  54:    */     catch (InvocationTargetException ex)
/*  55:    */     {
/*  56:115 */       throw new TransactionSystemException("OC4J's TransactionUtility.getOC4JUserTransaction() method failed", ex.getTargetException());
/*  57:    */     }
/*  58:    */     catch (Exception ex)
/*  59:    */     {
/*  60:119 */       throw new TransactionSystemException("Could not invoke OC4J's TransactionUtility.getOC4JUserTransaction() method", ex);
/*  61:    */     }
/*  62:    */   }
/*  63:    */   
/*  64:    */   private void loadOC4JTransactionClasses()
/*  65:    */     throws TransactionSystemException
/*  66:    */   {
/*  67:126 */     Class transactionManagerClass = null;
/*  68:127 */     Class transactionClass = null;
/*  69:    */     try
/*  70:    */     {
/*  71:129 */       transactionManagerClass = getClass().getClassLoader().loadClass("oracle.j2ee.transaction.OC4JTransactionManager");
/*  72:130 */       transactionClass = getClass().getClassLoader().loadClass("oracle.j2ee.transaction.OC4JTransaction");
/*  73:    */     }
/*  74:    */     catch (ClassNotFoundException ex)
/*  75:    */     {
/*  76:    */       try
/*  77:    */       {
/*  78:134 */         transactionManagerClass = getClass().getClassLoader().loadClass("com.evermind.server.ApplicationServerTransactionManager");
/*  79:135 */         transactionClass = getClass().getClassLoader().loadClass("com.evermind.server.ApplicationServerTransaction");
/*  80:    */       }
/*  81:    */       catch (ClassNotFoundException ex2)
/*  82:    */       {
/*  83:138 */         throw new TransactionSystemException("Could not initialize OC4JJtaTransactionManager because OC4J API classes are not available", ex);
/*  84:    */       }
/*  85:    */     }
/*  86:144 */     if (transactionManagerClass.isInstance(getUserTransaction()))
/*  87:    */     {
/*  88:145 */       this.beginWithNameMethod = ClassUtils.getMethodIfAvailable(transactionManagerClass, "begin", new Class[] { String.class });
/*  89:    */       
/*  90:147 */       this.setTransactionIsolationMethod = ClassUtils.getMethodIfAvailable(transactionClass, "setTransactionIsolation", new Class[] { Integer.TYPE });
/*  91:    */       
/*  92:149 */       this.logger.info("Support for OC4J transaction names and isolation levels available");
/*  93:    */     }
/*  94:    */     else
/*  95:    */     {
/*  96:152 */       this.logger.info("Support for OC4J transaction names and isolation levels not available");
/*  97:    */     }
/*  98:    */   }
/*  99:    */   
/* 100:    */   protected void doJtaBegin(JtaTransactionObject txObject, TransactionDefinition definition)
/* 101:    */     throws NotSupportedException, SystemException
/* 102:    */   {
/* 103:161 */     int timeout = determineTimeout(definition);
/* 104:162 */     applyTimeout(txObject, timeout);
/* 105:165 */     if ((this.beginWithNameMethod != null) && (definition.getName() != null)) {
/* 106:    */       try
/* 107:    */       {
/* 108:171 */         this.beginWithNameMethod.invoke(txObject.getUserTransaction(), new Object[] { definition.getName() });
/* 109:    */       }
/* 110:    */       catch (InvocationTargetException ex)
/* 111:    */       {
/* 112:174 */         throw new TransactionSystemException("OC4J's UserTransaction.begin(String) method failed", ex.getTargetException());
/* 113:    */       }
/* 114:    */       catch (Exception ex)
/* 115:    */       {
/* 116:178 */         throw new TransactionSystemException("Could not invoke OC4J's UserTransaction.begin(String) method", ex);
/* 117:    */       }
/* 118:    */     } else {
/* 119:185 */       txObject.getUserTransaction().begin();
/* 120:    */     }
/* 121:189 */     if (this.setTransactionIsolationMethod != null)
/* 122:    */     {
/* 123:190 */       if (definition.getIsolationLevel() != -1) {
/* 124:    */         try
/* 125:    */         {
/* 126:192 */           Transaction tx = getTransactionManager().getTransaction();
/* 127:    */           
/* 128:    */ 
/* 129:    */ 
/* 130:    */ 
/* 131:197 */           this.setTransactionIsolationMethod.invoke(tx, new Object[] { Integer.valueOf(definition.getIsolationLevel()) });
/* 132:    */         }
/* 133:    */         catch (InvocationTargetException ex)
/* 134:    */         {
/* 135:200 */           throw new TransactionSystemException("OC4J's Transaction.setTransactionIsolation(int) method failed", ex.getTargetException());
/* 136:    */         }
/* 137:    */         catch (Exception ex)
/* 138:    */         {
/* 139:204 */           throw new TransactionSystemException("Could not invoke OC4J's Transaction.setTransactionIsolation(int) method", ex);
/* 140:    */         }
/* 141:    */       }
/* 142:    */     }
/* 143:    */     else {
/* 144:210 */       applyIsolationLevel(txObject, definition.getIsolationLevel());
/* 145:    */     }
/* 146:    */   }
/* 147:    */   
/* 148:    */   public Transaction createTransaction(String name, int timeout)
/* 149:    */     throws NotSupportedException, SystemException
/* 150:    */   {
/* 151:217 */     if ((this.beginWithNameMethod != null) && (name != null))
/* 152:    */     {
/* 153:218 */       UserTransaction ut = getUserTransaction();
/* 154:219 */       if (timeout >= 0) {
/* 155:220 */         ut.setTransactionTimeout(timeout);
/* 156:    */       }
/* 157:    */       try
/* 158:    */       {
/* 159:223 */         this.beginWithNameMethod.invoke(ut, new Object[] { name });
/* 160:    */       }
/* 161:    */       catch (InvocationTargetException ex)
/* 162:    */       {
/* 163:226 */         if ((ex.getTargetException() instanceof NotSupportedException)) {
/* 164:227 */           throw ((NotSupportedException)ex.getTargetException());
/* 165:    */         }
/* 166:229 */         if ((ex.getTargetException() instanceof SystemException)) {
/* 167:230 */           throw ((SystemException)ex.getTargetException());
/* 168:    */         }
/* 169:232 */         if ((ex.getTargetException() instanceof RuntimeException)) {
/* 170:233 */           throw ((RuntimeException)ex.getTargetException());
/* 171:    */         }
/* 172:236 */         throw new SystemException("OC4J's begin(String) method failed with an unexpected error: " + ex.getTargetException());
/* 173:    */       }
/* 174:    */       catch (Exception ex)
/* 175:    */       {
/* 176:241 */         throw new SystemException("Could not invoke OC4J's UserTransaction.begin(String) method: " + ex);
/* 177:    */       }
/* 178:243 */       return new ManagedTransactionAdapter(getTransactionManager());
/* 179:    */     }
/* 180:248 */     return super.createTransaction(name, timeout);
/* 181:    */   }
/* 182:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.transaction.jta.OC4JJtaTransactionManager
 * JD-Core Version:    0.7.0.1
 */