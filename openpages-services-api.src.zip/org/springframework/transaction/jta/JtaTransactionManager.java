/*    1:     */ package org.springframework.transaction.jta;
/*    2:     */ 
/*    3:     */ import java.io.IOException;
/*    4:     */ import java.io.ObjectInputStream;
/*    5:     */ import java.io.Serializable;
/*    6:     */ import java.util.List;
/*    7:     */ import java.util.Properties;
/*    8:     */ import javax.naming.NamingException;
/*    9:     */ import javax.transaction.HeuristicMixedException;
/*   10:     */ import javax.transaction.HeuristicRollbackException;
/*   11:     */ import javax.transaction.InvalidTransactionException;
/*   12:     */ import javax.transaction.NotSupportedException;
/*   13:     */ import javax.transaction.RollbackException;
/*   14:     */ import javax.transaction.Synchronization;
/*   15:     */ import javax.transaction.SystemException;
/*   16:     */ import javax.transaction.Transaction;
/*   17:     */ import javax.transaction.TransactionManager;
/*   18:     */ import javax.transaction.TransactionSynchronizationRegistry;
/*   19:     */ import javax.transaction.UserTransaction;
/*   20:     */ import org.apache.commons.logging.Log;
/*   21:     */ import org.springframework.beans.factory.InitializingBean;
/*   22:     */ import org.springframework.jndi.JndiTemplate;
/*   23:     */ import org.springframework.transaction.CannotCreateTransactionException;
/*   24:     */ import org.springframework.transaction.HeuristicCompletionException;
/*   25:     */ import org.springframework.transaction.IllegalTransactionStateException;
/*   26:     */ import org.springframework.transaction.InvalidIsolationLevelException;
/*   27:     */ import org.springframework.transaction.NestedTransactionNotSupportedException;
/*   28:     */ import org.springframework.transaction.TransactionDefinition;
/*   29:     */ import org.springframework.transaction.TransactionSuspensionNotSupportedException;
/*   30:     */ import org.springframework.transaction.TransactionSystemException;
/*   31:     */ import org.springframework.transaction.UnexpectedRollbackException;
/*   32:     */ import org.springframework.transaction.support.AbstractPlatformTransactionManager;
/*   33:     */ import org.springframework.transaction.support.DefaultTransactionStatus;
/*   34:     */ import org.springframework.transaction.support.TransactionSynchronization;
/*   35:     */ import org.springframework.util.Assert;
/*   36:     */ import org.springframework.util.StringUtils;
/*   37:     */ 
/*   38:     */ public class JtaTransactionManager
/*   39:     */   extends AbstractPlatformTransactionManager
/*   40:     */   implements TransactionFactory, InitializingBean, Serializable
/*   41:     */ {
/*   42:     */   public static final String DEFAULT_USER_TRANSACTION_NAME = "java:comp/UserTransaction";
/*   43: 138 */   public static final String[] FALLBACK_TRANSACTION_MANAGER_NAMES = { "java:comp/TransactionManager", "java:appserver/TransactionManager", "java:pm/TransactionManager", "java:/TransactionManager" };
/*   44:     */   public static final String DEFAULT_TRANSACTION_SYNCHRONIZATION_REGISTRY_NAME = "java:comp/TransactionSynchronizationRegistry";
/*   45:     */   private static final String TRANSACTION_SYNCHRONIZATION_REGISTRY_CLASS_NAME = "javax.transaction.TransactionSynchronizationRegistry";
/*   46:     */   private static Class<?> transactionSynchronizationRegistryClass;
/*   47:     */   
/*   48:     */   static
/*   49:     */   {
/*   50: 156 */     ClassLoader cl = JtaTransactionManager.class.getClassLoader();
/*   51:     */     try
/*   52:     */     {
/*   53: 158 */       transactionSynchronizationRegistryClass = cl.loadClass("javax.transaction.TransactionSynchronizationRegistry");
/*   54:     */     }
/*   55:     */     catch (ClassNotFoundException ex) {}
/*   56:     */   }
/*   57:     */   
/*   58: 166 */   private transient JndiTemplate jndiTemplate = new JndiTemplate();
/*   59:     */   private transient UserTransaction userTransaction;
/*   60:     */   private String userTransactionName;
/*   61: 172 */   private boolean autodetectUserTransaction = true;
/*   62: 174 */   private boolean cacheUserTransaction = true;
/*   63: 176 */   private boolean userTransactionObtainedFromJndi = false;
/*   64:     */   private transient TransactionManager transactionManager;
/*   65:     */   private String transactionManagerName;
/*   66: 182 */   private boolean autodetectTransactionManager = true;
/*   67:     */   private String transactionSynchronizationRegistryName;
/*   68:     */   private transient Object transactionSynchronizationRegistry;
/*   69: 188 */   private boolean allowCustomIsolationLevels = false;
/*   70:     */   
/*   71:     */   public JtaTransactionManager()
/*   72:     */   {
/*   73: 201 */     setNestedTransactionAllowed(true);
/*   74:     */   }
/*   75:     */   
/*   76:     */   public JtaTransactionManager(UserTransaction userTransaction)
/*   77:     */   {
/*   78: 209 */     this();
/*   79: 210 */     Assert.notNull(userTransaction, "UserTransaction must not be null");
/*   80: 211 */     this.userTransaction = userTransaction;
/*   81:     */   }
/*   82:     */   
/*   83:     */   public JtaTransactionManager(UserTransaction userTransaction, TransactionManager transactionManager)
/*   84:     */   {
/*   85: 220 */     this();
/*   86: 221 */     Assert.notNull(userTransaction, "UserTransaction must not be null");
/*   87: 222 */     Assert.notNull(transactionManager, "TransactionManager must not be null");
/*   88: 223 */     this.userTransaction = userTransaction;
/*   89: 224 */     this.transactionManager = transactionManager;
/*   90:     */   }
/*   91:     */   
/*   92:     */   public JtaTransactionManager(TransactionManager transactionManager)
/*   93:     */   {
/*   94: 232 */     this();
/*   95: 233 */     Assert.notNull(transactionManager, "TransactionManager must not be null");
/*   96: 234 */     this.transactionManager = transactionManager;
/*   97: 235 */     this.userTransaction = buildUserTransaction(transactionManager);
/*   98:     */   }
/*   99:     */   
/*  100:     */   public void setJndiTemplate(JndiTemplate jndiTemplate)
/*  101:     */   {
/*  102: 244 */     Assert.notNull(jndiTemplate, "JndiTemplate must not be null");
/*  103: 245 */     this.jndiTemplate = jndiTemplate;
/*  104:     */   }
/*  105:     */   
/*  106:     */   public JndiTemplate getJndiTemplate()
/*  107:     */   {
/*  108: 252 */     return this.jndiTemplate;
/*  109:     */   }
/*  110:     */   
/*  111:     */   public void setJndiEnvironment(Properties jndiEnvironment)
/*  112:     */   {
/*  113: 261 */     this.jndiTemplate = new JndiTemplate(jndiEnvironment);
/*  114:     */   }
/*  115:     */   
/*  116:     */   public Properties getJndiEnvironment()
/*  117:     */   {
/*  118: 268 */     return this.jndiTemplate.getEnvironment();
/*  119:     */   }
/*  120:     */   
/*  121:     */   public void setUserTransaction(UserTransaction userTransaction)
/*  122:     */   {
/*  123: 280 */     this.userTransaction = userTransaction;
/*  124:     */   }
/*  125:     */   
/*  126:     */   public UserTransaction getUserTransaction()
/*  127:     */   {
/*  128: 287 */     return this.userTransaction;
/*  129:     */   }
/*  130:     */   
/*  131:     */   public void setUserTransactionName(String userTransactionName)
/*  132:     */   {
/*  133: 299 */     this.userTransactionName = userTransactionName;
/*  134:     */   }
/*  135:     */   
/*  136:     */   public void setAutodetectUserTransaction(boolean autodetectUserTransaction)
/*  137:     */   {
/*  138: 313 */     this.autodetectUserTransaction = autodetectUserTransaction;
/*  139:     */   }
/*  140:     */   
/*  141:     */   public void setCacheUserTransaction(boolean cacheUserTransaction)
/*  142:     */   {
/*  143: 329 */     this.cacheUserTransaction = cacheUserTransaction;
/*  144:     */   }
/*  145:     */   
/*  146:     */   public void setTransactionManager(TransactionManager transactionManager)
/*  147:     */   {
/*  148: 343 */     this.transactionManager = transactionManager;
/*  149:     */   }
/*  150:     */   
/*  151:     */   public TransactionManager getTransactionManager()
/*  152:     */   {
/*  153: 350 */     return this.transactionManager;
/*  154:     */   }
/*  155:     */   
/*  156:     */   public void setTransactionManagerName(String transactionManagerName)
/*  157:     */   {
/*  158: 364 */     this.transactionManagerName = transactionManagerName;
/*  159:     */   }
/*  160:     */   
/*  161:     */   public void setAutodetectTransactionManager(boolean autodetectTransactionManager)
/*  162:     */   {
/*  163: 380 */     this.autodetectTransactionManager = autodetectTransactionManager;
/*  164:     */   }
/*  165:     */   
/*  166:     */   public void setTransactionSynchronizationRegistryName(String transactionSynchronizationRegistryName)
/*  167:     */   {
/*  168: 391 */     this.transactionSynchronizationRegistryName = transactionSynchronizationRegistryName;
/*  169:     */   }
/*  170:     */   
/*  171:     */   public void setAllowCustomIsolationLevels(boolean allowCustomIsolationLevels)
/*  172:     */   {
/*  173: 404 */     this.allowCustomIsolationLevels = allowCustomIsolationLevels;
/*  174:     */   }
/*  175:     */   
/*  176:     */   public void afterPropertiesSet()
/*  177:     */     throws TransactionSystemException
/*  178:     */   {
/*  179: 413 */     initUserTransactionAndTransactionManager();
/*  180: 414 */     checkUserTransactionAndTransactionManager();
/*  181: 415 */     initTransactionSynchronizationRegistry();
/*  182:     */   }
/*  183:     */   
/*  184:     */   protected void initUserTransactionAndTransactionManager()
/*  185:     */     throws TransactionSystemException
/*  186:     */   {
/*  187: 424 */     if (this.userTransaction == null) {
/*  188: 425 */       if (StringUtils.hasLength(this.userTransactionName))
/*  189:     */       {
/*  190: 426 */         this.userTransaction = lookupUserTransaction(this.userTransactionName);
/*  191: 427 */         this.userTransactionObtainedFromJndi = true;
/*  192:     */       }
/*  193:     */       else
/*  194:     */       {
/*  195: 430 */         this.userTransaction = retrieveUserTransaction();
/*  196:     */       }
/*  197:     */     }
/*  198: 435 */     if (this.transactionManager == null) {
/*  199: 436 */       if (StringUtils.hasLength(this.transactionManagerName)) {
/*  200: 437 */         this.transactionManager = lookupTransactionManager(this.transactionManagerName);
/*  201:     */       } else {
/*  202: 440 */         this.transactionManager = retrieveTransactionManager();
/*  203:     */       }
/*  204:     */     }
/*  205: 445 */     if ((this.userTransaction == null) && (this.autodetectUserTransaction)) {
/*  206: 446 */       this.userTransaction = findUserTransaction();
/*  207:     */     }
/*  208: 451 */     if ((this.transactionManager == null) && (this.autodetectTransactionManager)) {
/*  209: 452 */       this.transactionManager = findTransactionManager(this.userTransaction);
/*  210:     */     }
/*  211: 456 */     if ((this.userTransaction == null) && (this.transactionManager != null)) {
/*  212: 457 */       this.userTransaction = buildUserTransaction(this.transactionManager);
/*  213:     */     }
/*  214:     */   }
/*  215:     */   
/*  216:     */   protected void checkUserTransactionAndTransactionManager()
/*  217:     */     throws IllegalStateException
/*  218:     */   {
/*  219: 468 */     if (this.userTransaction != null)
/*  220:     */     {
/*  221: 469 */       if (this.logger.isInfoEnabled()) {
/*  222: 470 */         this.logger.info("Using JTA UserTransaction: " + this.userTransaction);
/*  223:     */       }
/*  224:     */     }
/*  225:     */     else {
/*  226: 474 */       throw new IllegalStateException("No JTA UserTransaction available - specify either 'userTransaction' or 'userTransactionName' or 'transactionManager' or 'transactionManagerName'");
/*  227:     */     }
/*  228: 479 */     if (this.transactionManager != null)
/*  229:     */     {
/*  230: 480 */       if (this.logger.isInfoEnabled()) {
/*  231: 481 */         this.logger.info("Using JTA TransactionManager: " + this.transactionManager);
/*  232:     */       }
/*  233:     */     }
/*  234:     */     else {
/*  235: 485 */       this.logger.warn("No JTA TransactionManager found: transaction suspension not available");
/*  236:     */     }
/*  237:     */   }
/*  238:     */   
/*  239:     */   protected void initTransactionSynchronizationRegistry()
/*  240:     */   {
/*  241: 496 */     if (StringUtils.hasLength(this.transactionSynchronizationRegistryName))
/*  242:     */     {
/*  243: 497 */       this.transactionSynchronizationRegistry = lookupTransactionSynchronizationRegistry(this.transactionSynchronizationRegistryName);
/*  244:     */     }
/*  245:     */     else
/*  246:     */     {
/*  247: 501 */       this.transactionSynchronizationRegistry = retrieveTransactionSynchronizationRegistry();
/*  248: 502 */       if (this.transactionSynchronizationRegistry == null) {
/*  249: 503 */         this.transactionSynchronizationRegistry = findTransactionSynchronizationRegistry(this.userTransaction, this.transactionManager);
/*  250:     */       }
/*  251:     */     }
/*  252: 508 */     if ((this.transactionSynchronizationRegistry != null) && 
/*  253: 509 */       (this.logger.isInfoEnabled())) {
/*  254: 510 */       this.logger.info("Using JTA TransactionSynchronizationRegistry: " + this.transactionSynchronizationRegistry);
/*  255:     */     }
/*  256:     */   }
/*  257:     */   
/*  258:     */   protected UserTransaction buildUserTransaction(TransactionManager transactionManager)
/*  259:     */   {
/*  260: 522 */     if ((transactionManager instanceof UserTransaction)) {
/*  261: 523 */       return (UserTransaction)transactionManager;
/*  262:     */     }
/*  263: 526 */     return new UserTransactionAdapter(transactionManager);
/*  264:     */   }
/*  265:     */   
/*  266:     */   protected UserTransaction lookupUserTransaction(String userTransactionName)
/*  267:     */     throws TransactionSystemException
/*  268:     */   {
/*  269:     */     try
/*  270:     */     {
/*  271: 543 */       if (this.logger.isDebugEnabled()) {
/*  272: 544 */         this.logger.debug("Retrieving JTA UserTransaction from JNDI location [" + userTransactionName + "]");
/*  273:     */       }
/*  274: 546 */       return (UserTransaction)getJndiTemplate().lookup(userTransactionName, UserTransaction.class);
/*  275:     */     }
/*  276:     */     catch (NamingException ex)
/*  277:     */     {
/*  278: 549 */       throw new TransactionSystemException("JTA UserTransaction is not available at JNDI location [" + userTransactionName + "]", ex);
/*  279:     */     }
/*  280:     */   }
/*  281:     */   
/*  282:     */   protected TransactionManager lookupTransactionManager(String transactionManagerName)
/*  283:     */     throws TransactionSystemException
/*  284:     */   {
/*  285:     */     try
/*  286:     */     {
/*  287: 567 */       if (this.logger.isDebugEnabled()) {
/*  288: 568 */         this.logger.debug("Retrieving JTA TransactionManager from JNDI location [" + transactionManagerName + "]");
/*  289:     */       }
/*  290: 570 */       return (TransactionManager)getJndiTemplate().lookup(transactionManagerName, TransactionManager.class);
/*  291:     */     }
/*  292:     */     catch (NamingException ex)
/*  293:     */     {
/*  294: 573 */       throw new TransactionSystemException("JTA TransactionManager is not available at JNDI location [" + transactionManagerName + "]", ex);
/*  295:     */     }
/*  296:     */   }
/*  297:     */   
/*  298:     */   protected Object lookupTransactionSynchronizationRegistry(String registryName)
/*  299:     */     throws TransactionSystemException
/*  300:     */   {
/*  301: 589 */     if (transactionSynchronizationRegistryClass == null) {
/*  302: 590 */       throw new TransactionSystemException("JTA 1.1 [javax.transaction.TransactionSynchronizationRegistry] API not available");
/*  303:     */     }
/*  304:     */     try
/*  305:     */     {
/*  306: 594 */       if (this.logger.isDebugEnabled()) {
/*  307: 595 */         this.logger.debug("Retrieving JTA TransactionSynchronizationRegistry from JNDI location [" + registryName + "]");
/*  308:     */       }
/*  309: 597 */       return getJndiTemplate().lookup(registryName, transactionSynchronizationRegistryClass);
/*  310:     */     }
/*  311:     */     catch (NamingException ex)
/*  312:     */     {
/*  313: 600 */       throw new TransactionSystemException("JTA TransactionSynchronizationRegistry is not available at JNDI location [" + registryName + "]", ex);
/*  314:     */     }
/*  315:     */   }
/*  316:     */   
/*  317:     */   protected UserTransaction retrieveUserTransaction()
/*  318:     */     throws TransactionSystemException
/*  319:     */   {
/*  320: 615 */     return null;
/*  321:     */   }
/*  322:     */   
/*  323:     */   protected TransactionManager retrieveTransactionManager()
/*  324:     */     throws TransactionSystemException
/*  325:     */   {
/*  326: 628 */     return null;
/*  327:     */   }
/*  328:     */   
/*  329:     */   protected Object retrieveTransactionSynchronizationRegistry()
/*  330:     */     throws TransactionSystemException
/*  331:     */   {
/*  332: 640 */     return null;
/*  333:     */   }
/*  334:     */   
/*  335:     */   protected UserTransaction findUserTransaction()
/*  336:     */   {
/*  337: 650 */     String jndiName = "java:comp/UserTransaction";
/*  338:     */     try
/*  339:     */     {
/*  340: 652 */       UserTransaction ut = (UserTransaction)getJndiTemplate().lookup(jndiName, UserTransaction.class);
/*  341: 653 */       if (this.logger.isDebugEnabled()) {
/*  342: 654 */         this.logger.debug("JTA UserTransaction found at default JNDI location [" + jndiName + "]");
/*  343:     */       }
/*  344: 656 */       this.userTransactionObtainedFromJndi = true;
/*  345: 657 */       return ut;
/*  346:     */     }
/*  347:     */     catch (NamingException ex)
/*  348:     */     {
/*  349: 660 */       if (this.logger.isDebugEnabled()) {
/*  350: 661 */         this.logger.debug("No JTA UserTransaction found at default JNDI location [" + jndiName + "]", ex);
/*  351:     */       }
/*  352:     */     }
/*  353: 663 */     return null;
/*  354:     */   }
/*  355:     */   
/*  356:     */   protected TransactionManager findTransactionManager(UserTransaction ut)
/*  357:     */   {
/*  358: 676 */     if ((ut instanceof TransactionManager))
/*  359:     */     {
/*  360: 677 */       if (this.logger.isDebugEnabled()) {
/*  361: 678 */         this.logger.debug("JTA UserTransaction object [" + ut + "] implements TransactionManager");
/*  362:     */       }
/*  363: 680 */       return (TransactionManager)ut;
/*  364:     */     }
/*  365: 684 */     for (String jndiName : FALLBACK_TRANSACTION_MANAGER_NAMES) {
/*  366:     */       try
/*  367:     */       {
/*  368: 686 */         TransactionManager tm = (TransactionManager)getJndiTemplate().lookup(jndiName, TransactionManager.class);
/*  369: 687 */         if (this.logger.isDebugEnabled()) {
/*  370: 688 */           this.logger.debug("JTA TransactionManager found at fallback JNDI location [" + jndiName + "]");
/*  371:     */         }
/*  372: 690 */         return tm;
/*  373:     */       }
/*  374:     */       catch (NamingException ex)
/*  375:     */       {
/*  376: 693 */         if (this.logger.isDebugEnabled()) {
/*  377: 694 */           this.logger.debug("No JTA TransactionManager found at fallback JNDI location [" + jndiName + "]", ex);
/*  378:     */         }
/*  379:     */       }
/*  380:     */     }
/*  381: 700 */     return null;
/*  382:     */   }
/*  383:     */   
/*  384:     */   protected Object findTransactionSynchronizationRegistry(UserTransaction ut, TransactionManager tm)
/*  385:     */     throws TransactionSystemException
/*  386:     */   {
/*  387: 717 */     if (transactionSynchronizationRegistryClass == null)
/*  388:     */     {
/*  389: 719 */       if (this.logger.isDebugEnabled()) {
/*  390: 720 */         this.logger.debug("JTA 1.1 [javax.transaction.TransactionSynchronizationRegistry] API not available");
/*  391:     */       }
/*  392: 722 */       return null;
/*  393:     */     }
/*  394: 726 */     if (this.userTransactionObtainedFromJndi)
/*  395:     */     {
/*  396: 729 */       String jndiName = "java:comp/TransactionSynchronizationRegistry";
/*  397:     */       try
/*  398:     */       {
/*  399: 731 */         Object tsr = getJndiTemplate().lookup(jndiName, transactionSynchronizationRegistryClass);
/*  400: 732 */         if (this.logger.isDebugEnabled()) {
/*  401: 733 */           this.logger.debug("JTA TransactionSynchronizationRegistry found at default JNDI location [" + jndiName + "]");
/*  402:     */         }
/*  403: 735 */         return tsr;
/*  404:     */       }
/*  405:     */       catch (NamingException ex)
/*  406:     */       {
/*  407: 738 */         if (this.logger.isDebugEnabled()) {
/*  408: 739 */           this.logger.debug("No JTA TransactionSynchronizationRegistry found at default JNDI location [" + jndiName + "]", ex);
/*  409:     */         }
/*  410:     */       }
/*  411:     */     }
/*  412: 745 */     if (transactionSynchronizationRegistryClass.isInstance(ut)) {
/*  413: 746 */       return ut;
/*  414:     */     }
/*  415: 748 */     if (transactionSynchronizationRegistryClass.isInstance(tm)) {
/*  416: 749 */       return tm;
/*  417:     */     }
/*  418: 753 */     return null;
/*  419:     */   }
/*  420:     */   
/*  421:     */   protected Object doGetTransaction()
/*  422:     */   {
/*  423: 769 */     UserTransaction ut = getUserTransaction();
/*  424: 770 */     if (ut == null) {
/*  425: 771 */       throw new CannotCreateTransactionException("No JTA UserTransaction available - programmatic PlatformTransactionManager.getTransaction usage not supported");
/*  426:     */     }
/*  427: 774 */     if (!this.cacheUserTransaction) {
/*  428: 775 */       ut = lookupUserTransaction(this.userTransactionName != null ? this.userTransactionName : "java:comp/UserTransaction");
/*  429:     */     }
/*  430: 778 */     return doGetJtaTransaction(ut);
/*  431:     */   }
/*  432:     */   
/*  433:     */   protected JtaTransactionObject doGetJtaTransaction(UserTransaction ut)
/*  434:     */   {
/*  435: 789 */     return new JtaTransactionObject(ut);
/*  436:     */   }
/*  437:     */   
/*  438:     */   protected boolean isExistingTransaction(Object transaction)
/*  439:     */   {
/*  440: 794 */     JtaTransactionObject txObject = (JtaTransactionObject)transaction;
/*  441:     */     try
/*  442:     */     {
/*  443: 796 */       return txObject.getUserTransaction().getStatus() != 6;
/*  444:     */     }
/*  445:     */     catch (SystemException ex)
/*  446:     */     {
/*  447: 799 */       throw new TransactionSystemException("JTA failure on getStatus", ex);
/*  448:     */     }
/*  449:     */   }
/*  450:     */   
/*  451:     */   protected boolean useSavepointForNestedTransaction()
/*  452:     */   {
/*  453: 813 */     return false;
/*  454:     */   }
/*  455:     */   
/*  456:     */   protected void doBegin(Object transaction, TransactionDefinition definition)
/*  457:     */   {
/*  458: 819 */     JtaTransactionObject txObject = (JtaTransactionObject)transaction;
/*  459:     */     try
/*  460:     */     {
/*  461: 821 */       doJtaBegin(txObject, definition);
/*  462:     */     }
/*  463:     */     catch (NotSupportedException ex)
/*  464:     */     {
/*  465: 825 */       throw new NestedTransactionNotSupportedException("JTA implementation does not support nested transactions", ex);
/*  466:     */     }
/*  467:     */     catch (UnsupportedOperationException ex)
/*  468:     */     {
/*  469: 830 */       throw new NestedTransactionNotSupportedException("JTA implementation does not support nested transactions", ex);
/*  470:     */     }
/*  471:     */     catch (SystemException ex)
/*  472:     */     {
/*  473: 834 */       throw new CannotCreateTransactionException("JTA failure on begin", ex);
/*  474:     */     }
/*  475:     */   }
/*  476:     */   
/*  477:     */   protected void doJtaBegin(JtaTransactionObject txObject, TransactionDefinition definition)
/*  478:     */     throws NotSupportedException, SystemException
/*  479:     */   {
/*  480: 861 */     applyIsolationLevel(txObject, definition.getIsolationLevel());
/*  481: 862 */     int timeout = determineTimeout(definition);
/*  482: 863 */     applyTimeout(txObject, timeout);
/*  483: 864 */     txObject.getUserTransaction().begin();
/*  484:     */   }
/*  485:     */   
/*  486:     */   protected void applyIsolationLevel(JtaTransactionObject txObject, int isolationLevel)
/*  487:     */     throws InvalidIsolationLevelException, SystemException
/*  488:     */   {
/*  489: 884 */     if ((!this.allowCustomIsolationLevels) && (isolationLevel != -1)) {
/*  490: 885 */       throw new InvalidIsolationLevelException("JtaTransactionManager does not support custom isolation levels by default - switch 'allowCustomIsolationLevels' to 'true'");
/*  491:     */     }
/*  492:     */   }
/*  493:     */   
/*  494:     */   protected void applyTimeout(JtaTransactionObject txObject, int timeout)
/*  495:     */     throws SystemException
/*  496:     */   {
/*  497: 902 */     if (timeout > -1) {
/*  498: 903 */       txObject.getUserTransaction().setTransactionTimeout(timeout);
/*  499:     */     }
/*  500:     */   }
/*  501:     */   
/*  502:     */   protected Object doSuspend(Object transaction)
/*  503:     */   {
/*  504: 910 */     JtaTransactionObject txObject = (JtaTransactionObject)transaction;
/*  505:     */     try
/*  506:     */     {
/*  507: 912 */       return doJtaSuspend(txObject);
/*  508:     */     }
/*  509:     */     catch (SystemException ex)
/*  510:     */     {
/*  511: 915 */       throw new TransactionSystemException("JTA failure on suspend", ex);
/*  512:     */     }
/*  513:     */   }
/*  514:     */   
/*  515:     */   protected Object doJtaSuspend(JtaTransactionObject txObject)
/*  516:     */     throws SystemException
/*  517:     */   {
/*  518: 929 */     if (getTransactionManager() == null) {
/*  519: 930 */       throw new TransactionSuspensionNotSupportedException("JtaTransactionManager needs a JTA TransactionManager for suspending a transaction: specify the 'transactionManager' or 'transactionManagerName' property");
/*  520:     */     }
/*  521: 934 */     return getTransactionManager().suspend();
/*  522:     */   }
/*  523:     */   
/*  524:     */   protected void doResume(Object transaction, Object suspendedResources)
/*  525:     */   {
/*  526: 939 */     JtaTransactionObject txObject = (JtaTransactionObject)transaction;
/*  527:     */     try
/*  528:     */     {
/*  529: 941 */       doJtaResume(txObject, suspendedResources);
/*  530:     */     }
/*  531:     */     catch (InvalidTransactionException ex)
/*  532:     */     {
/*  533: 944 */       throw new IllegalTransactionStateException("Tried to resume invalid JTA transaction", ex);
/*  534:     */     }
/*  535:     */     catch (IllegalStateException ex)
/*  536:     */     {
/*  537: 947 */       throw new TransactionSystemException("Unexpected internal transaction state", ex);
/*  538:     */     }
/*  539:     */     catch (SystemException ex)
/*  540:     */     {
/*  541: 950 */       throw new TransactionSystemException("JTA failure on resume", ex);
/*  542:     */     }
/*  543:     */   }
/*  544:     */   
/*  545:     */   protected void doJtaResume(JtaTransactionObject txObject, Object suspendedTransaction)
/*  546:     */     throws InvalidTransactionException, SystemException
/*  547:     */   {
/*  548: 967 */     if (getTransactionManager() == null) {
/*  549: 968 */       throw new TransactionSuspensionNotSupportedException("JtaTransactionManager needs a JTA TransactionManager for suspending a transaction: specify the 'transactionManager' or 'transactionManagerName' property");
/*  550:     */     }
/*  551: 972 */     getTransactionManager().resume((Transaction)suspendedTransaction);
/*  552:     */   }
/*  553:     */   
/*  554:     */   protected boolean shouldCommitOnGlobalRollbackOnly()
/*  555:     */   {
/*  556: 982 */     return true;
/*  557:     */   }
/*  558:     */   
/*  559:     */   protected void doCommit(DefaultTransactionStatus status)
/*  560:     */   {
/*  561: 987 */     JtaTransactionObject txObject = (JtaTransactionObject)status.getTransaction();
/*  562:     */     try
/*  563:     */     {
/*  564: 989 */       int jtaStatus = txObject.getUserTransaction().getStatus();
/*  565: 990 */       if (jtaStatus == 6) {
/*  566: 994 */         throw new UnexpectedRollbackException("JTA transaction already completed - probably rolled back");
/*  567:     */       }
/*  568: 996 */       if (jtaStatus == 4)
/*  569:     */       {
/*  570:     */         try
/*  571:     */         {
/*  572:1001 */           txObject.getUserTransaction().rollback();
/*  573:     */         }
/*  574:     */         catch (IllegalStateException ex)
/*  575:     */         {
/*  576:1004 */           if (this.logger.isDebugEnabled()) {
/*  577:1005 */             this.logger.debug("Rollback failure with transaction already marked as rolled back: " + ex);
/*  578:     */           }
/*  579:     */         }
/*  580:1008 */         throw new UnexpectedRollbackException("JTA transaction already rolled back (probably due to a timeout)");
/*  581:     */       }
/*  582:1010 */       txObject.getUserTransaction().commit();
/*  583:     */     }
/*  584:     */     catch (RollbackException ex)
/*  585:     */     {
/*  586:1013 */       throw new UnexpectedRollbackException("JTA transaction unexpectedly rolled back (maybe due to a timeout)", ex);
/*  587:     */     }
/*  588:     */     catch (HeuristicMixedException ex)
/*  589:     */     {
/*  590:1017 */       throw new HeuristicCompletionException(3, ex);
/*  591:     */     }
/*  592:     */     catch (HeuristicRollbackException ex)
/*  593:     */     {
/*  594:1020 */       throw new HeuristicCompletionException(2, ex);
/*  595:     */     }
/*  596:     */     catch (IllegalStateException ex)
/*  597:     */     {
/*  598:1023 */       throw new TransactionSystemException("Unexpected internal transaction state", ex);
/*  599:     */     }
/*  600:     */     catch (SystemException ex)
/*  601:     */     {
/*  602:1026 */       throw new TransactionSystemException("JTA failure on commit", ex);
/*  603:     */     }
/*  604:     */   }
/*  605:     */   
/*  606:     */   protected void doRollback(DefaultTransactionStatus status)
/*  607:     */   {
/*  608:1032 */     JtaTransactionObject txObject = (JtaTransactionObject)status.getTransaction();
/*  609:     */     try
/*  610:     */     {
/*  611:1034 */       int jtaStatus = txObject.getUserTransaction().getStatus();
/*  612:1035 */       if (jtaStatus != 6) {
/*  613:     */         try
/*  614:     */         {
/*  615:1037 */           txObject.getUserTransaction().rollback();
/*  616:     */         }
/*  617:     */         catch (IllegalStateException ex)
/*  618:     */         {
/*  619:1040 */           if (jtaStatus == 4)
/*  620:     */           {
/*  621:1042 */             if (this.logger.isDebugEnabled()) {
/*  622:1043 */               this.logger.debug("Rollback failure with transaction already marked as rolled back: " + ex);
/*  623:     */             }
/*  624:     */           }
/*  625:     */           else {
/*  626:1047 */             throw new TransactionSystemException("Unexpected internal transaction state", ex);
/*  627:     */           }
/*  628:     */         }
/*  629:     */       }
/*  630:     */     }
/*  631:     */     catch (SystemException ex)
/*  632:     */     {
/*  633:1053 */       throw new TransactionSystemException("JTA failure on rollback", ex);
/*  634:     */     }
/*  635:     */   }
/*  636:     */   
/*  637:     */   protected void doSetRollbackOnly(DefaultTransactionStatus status)
/*  638:     */   {
/*  639:1059 */     JtaTransactionObject txObject = (JtaTransactionObject)status.getTransaction();
/*  640:1060 */     if (status.isDebug()) {
/*  641:1061 */       this.logger.debug("Setting JTA transaction rollback-only");
/*  642:     */     }
/*  643:     */     try
/*  644:     */     {
/*  645:1064 */       int jtaStatus = txObject.getUserTransaction().getStatus();
/*  646:1065 */       if ((jtaStatus != 6) && (jtaStatus != 4)) {
/*  647:1066 */         txObject.getUserTransaction().setRollbackOnly();
/*  648:     */       }
/*  649:     */     }
/*  650:     */     catch (IllegalStateException ex)
/*  651:     */     {
/*  652:1070 */       throw new TransactionSystemException("Unexpected internal transaction state", ex);
/*  653:     */     }
/*  654:     */     catch (SystemException ex)
/*  655:     */     {
/*  656:1073 */       throw new TransactionSystemException("JTA failure on setRollbackOnly", ex);
/*  657:     */     }
/*  658:     */   }
/*  659:     */   
/*  660:     */   protected void registerAfterCompletionWithExistingTransaction(Object transaction, List<TransactionSynchronization> synchronizations)
/*  661:     */   {
/*  662:1082 */     JtaTransactionObject txObject = (JtaTransactionObject)transaction;
/*  663:1083 */     this.logger.debug("Registering after-completion synchronization with existing JTA transaction");
/*  664:     */     try
/*  665:     */     {
/*  666:1085 */       doRegisterAfterCompletionWithJtaTransaction(txObject, synchronizations);
/*  667:     */     }
/*  668:     */     catch (SystemException ex)
/*  669:     */     {
/*  670:1088 */       throw new TransactionSystemException("JTA failure on registerSynchronization", ex);
/*  671:     */     }
/*  672:     */     catch (Exception ex)
/*  673:     */     {
/*  674:1092 */       if (((ex instanceof RollbackException)) || ((ex.getCause() instanceof RollbackException)))
/*  675:     */       {
/*  676:1093 */         this.logger.debug("Participating in existing JTA transaction that has been marked for rollback: cannot register Spring after-completion callbacks with outer JTA transaction - immediately performing Spring after-completion callbacks with outcome status 'rollback'. Original exception: " + ex);
/*  677:     */         
/*  678:     */ 
/*  679:     */ 
/*  680:1097 */         invokeAfterCompletion(synchronizations, 1);
/*  681:     */       }
/*  682:     */       else
/*  683:     */       {
/*  684:1100 */         this.logger.debug("Participating in existing JTA transaction, but unexpected internal transaction state encountered: cannot register Spring after-completion callbacks with outer JTA transaction - processing Spring after-completion callbacks with outcome status 'unknown'Original exception: " + ex);
/*  685:     */         
/*  686:     */ 
/*  687:     */ 
/*  688:1104 */         invokeAfterCompletion(synchronizations, 2);
/*  689:     */       }
/*  690:     */     }
/*  691:     */   }
/*  692:     */   
/*  693:     */   protected void doRegisterAfterCompletionWithJtaTransaction(JtaTransactionObject txObject, List<TransactionSynchronization> synchronizations)
/*  694:     */     throws RollbackException, SystemException
/*  695:     */   {
/*  696:1129 */     int jtaStatus = txObject.getUserTransaction().getStatus();
/*  697:1130 */     if (jtaStatus == 6) {
/*  698:1131 */       throw new RollbackException("JTA transaction already completed - probably rolled back");
/*  699:     */     }
/*  700:1133 */     if (jtaStatus == 4) {
/*  701:1134 */       throw new RollbackException("JTA transaction already rolled back (probably due to a timeout)");
/*  702:     */     }
/*  703:1137 */     if (this.transactionSynchronizationRegistry != null)
/*  704:     */     {
/*  705:1139 */       new InterposedSynchronizationDelegate(null).registerInterposedSynchronization(new JtaAfterCompletionSynchronization(synchronizations));
/*  706:     */     }
/*  707:1143 */     else if (getTransactionManager() != null)
/*  708:     */     {
/*  709:1145 */       Transaction transaction = getTransactionManager().getTransaction();
/*  710:1146 */       if (transaction == null) {
/*  711:1147 */         throw new IllegalStateException("No JTA Transaction available");
/*  712:     */       }
/*  713:1149 */       transaction.registerSynchronization(new JtaAfterCompletionSynchronization(synchronizations));
/*  714:     */     }
/*  715:     */     else
/*  716:     */     {
/*  717:1154 */       this.logger.warn("Participating in existing JTA transaction, but no JTA TransactionManager available: cannot register Spring after-completion callbacks with outer JTA transaction - processing Spring after-completion callbacks with outcome status 'unknown'");
/*  718:     */       
/*  719:     */ 
/*  720:1157 */       invokeAfterCompletion(synchronizations, 2);
/*  721:     */     }
/*  722:     */   }
/*  723:     */   
/*  724:     */   public Transaction createTransaction(String name, int timeout)
/*  725:     */     throws NotSupportedException, SystemException
/*  726:     */   {
/*  727:1167 */     TransactionManager tm = getTransactionManager();
/*  728:1168 */     Assert.state(tm != null, "No JTA TransactionManager available");
/*  729:1169 */     if (timeout >= 0) {
/*  730:1170 */       tm.setTransactionTimeout(timeout);
/*  731:     */     }
/*  732:1172 */     tm.begin();
/*  733:1173 */     return new ManagedTransactionAdapter(tm);
/*  734:     */   }
/*  735:     */   
/*  736:     */   public boolean supportsResourceAdapterManagedTransactions()
/*  737:     */   {
/*  738:1177 */     return false;
/*  739:     */   }
/*  740:     */   
/*  741:     */   private void readObject(ObjectInputStream ois)
/*  742:     */     throws IOException, ClassNotFoundException
/*  743:     */   {
/*  744:1187 */     ois.defaultReadObject();
/*  745:     */     
/*  746:     */ 
/*  747:1190 */     this.jndiTemplate = new JndiTemplate();
/*  748:     */     
/*  749:     */ 
/*  750:1193 */     initUserTransactionAndTransactionManager();
/*  751:1194 */     initTransactionSynchronizationRegistry();
/*  752:     */   }
/*  753:     */   
/*  754:     */   private class InterposedSynchronizationDelegate
/*  755:     */   {
/*  756:     */     private InterposedSynchronizationDelegate() {}
/*  757:     */     
/*  758:     */     public void registerInterposedSynchronization(Synchronization synch)
/*  759:     */     {
/*  760:1205 */       ((TransactionSynchronizationRegistry)JtaTransactionManager.this.transactionSynchronizationRegistry).registerInterposedSynchronization(synch);
/*  761:     */     }
/*  762:     */   }
/*  763:     */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.transaction.jta.JtaTransactionManager
 * JD-Core Version:    0.7.0.1
 */