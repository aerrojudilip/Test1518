package org.springframework.transaction;

public abstract interface TransactionStatus
  extends SavepointManager
{
  public abstract boolean isNewTransaction();
  
  public abstract boolean hasSavepoint();
  
  public abstract void setRollbackOnly();
  
  public abstract boolean isRollbackOnly();
  
  public abstract void flush();
  
  public abstract boolean isCompleted();
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.transaction.TransactionStatus
 * JD-Core Version:    0.7.0.1
 */