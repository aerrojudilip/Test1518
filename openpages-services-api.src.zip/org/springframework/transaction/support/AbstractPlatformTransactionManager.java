/*    1:     */ package org.springframework.transaction.support;
/*    2:     */ 
/*    3:     */ import java.io.IOException;
/*    4:     */ import java.io.ObjectInputStream;
/*    5:     */ import java.io.Serializable;
/*    6:     */ import java.util.List;
/*    7:     */ import org.apache.commons.logging.Log;
/*    8:     */ import org.apache.commons.logging.LogFactory;
/*    9:     */ import org.springframework.core.Constants;
/*   10:     */ import org.springframework.transaction.IllegalTransactionStateException;
/*   11:     */ import org.springframework.transaction.InvalidTimeoutException;
/*   12:     */ import org.springframework.transaction.NestedTransactionNotSupportedException;
/*   13:     */ import org.springframework.transaction.PlatformTransactionManager;
/*   14:     */ import org.springframework.transaction.TransactionDefinition;
/*   15:     */ import org.springframework.transaction.TransactionException;
/*   16:     */ import org.springframework.transaction.TransactionStatus;
/*   17:     */ import org.springframework.transaction.TransactionSuspensionNotSupportedException;
/*   18:     */ import org.springframework.transaction.UnexpectedRollbackException;
/*   19:     */ 
/*   20:     */ public abstract class AbstractPlatformTransactionManager
/*   21:     */   implements PlatformTransactionManager, Serializable
/*   22:     */ {
/*   23:     */   public static final int SYNCHRONIZATION_ALWAYS = 0;
/*   24:     */   public static final int SYNCHRONIZATION_ON_ACTUAL_TRANSACTION = 1;
/*   25:     */   public static final int SYNCHRONIZATION_NEVER = 2;
/*   26: 109 */   private static final Constants constants = new Constants(AbstractPlatformTransactionManager.class);
/*   27:     */   protected transient Log logger;
/*   28:     */   private int transactionSynchronization;
/*   29:     */   private int defaultTimeout;
/*   30:     */   private boolean nestedTransactionAllowed;
/*   31:     */   private boolean validateExistingTransaction;
/*   32:     */   private boolean globalRollbackOnParticipationFailure;
/*   33:     */   private boolean failEarlyOnGlobalRollbackOnly;
/*   34:     */   private boolean rollbackOnCommitFailure;
/*   35:     */   
/*   36:     */   public AbstractPlatformTransactionManager()
/*   37:     */   {
/*   38: 112 */     this.logger = LogFactory.getLog(getClass());
/*   39:     */     
/*   40: 114 */     this.transactionSynchronization = 0;
/*   41:     */     
/*   42: 116 */     this.defaultTimeout = -1;
/*   43:     */     
/*   44: 118 */     this.nestedTransactionAllowed = false;
/*   45:     */     
/*   46: 120 */     this.validateExistingTransaction = false;
/*   47:     */     
/*   48: 122 */     this.globalRollbackOnParticipationFailure = true;
/*   49:     */     
/*   50: 124 */     this.failEarlyOnGlobalRollbackOnly = false;
/*   51:     */     
/*   52: 126 */     this.rollbackOnCommitFailure = false;
/*   53:     */   }
/*   54:     */   
/*   55:     */   public final void setTransactionSynchronizationName(String constantName)
/*   56:     */   {
/*   57: 136 */     setTransactionSynchronization(constants.asNumber(constantName).intValue());
/*   58:     */   }
/*   59:     */   
/*   60:     */   public final void setTransactionSynchronization(int transactionSynchronization)
/*   61:     */   {
/*   62: 152 */     this.transactionSynchronization = transactionSynchronization;
/*   63:     */   }
/*   64:     */   
/*   65:     */   public final int getTransactionSynchronization()
/*   66:     */   {
/*   67: 160 */     return this.transactionSynchronization;
/*   68:     */   }
/*   69:     */   
/*   70:     */   public final void setDefaultTimeout(int defaultTimeout)
/*   71:     */   {
/*   72: 172 */     if (defaultTimeout < -1) {
/*   73: 173 */       throw new InvalidTimeoutException("Invalid default timeout", defaultTimeout);
/*   74:     */     }
/*   75: 175 */     this.defaultTimeout = defaultTimeout;
/*   76:     */   }
/*   77:     */   
/*   78:     */   public final int getDefaultTimeout()
/*   79:     */   {
/*   80: 185 */     return this.defaultTimeout;
/*   81:     */   }
/*   82:     */   
/*   83:     */   public final void setNestedTransactionAllowed(boolean nestedTransactionAllowed)
/*   84:     */   {
/*   85: 194 */     this.nestedTransactionAllowed = nestedTransactionAllowed;
/*   86:     */   }
/*   87:     */   
/*   88:     */   public final boolean isNestedTransactionAllowed()
/*   89:     */   {
/*   90: 201 */     return this.nestedTransactionAllowed;
/*   91:     */   }
/*   92:     */   
/*   93:     */   public final void setValidateExistingTransaction(boolean validateExistingTransaction)
/*   94:     */   {
/*   95: 218 */     this.validateExistingTransaction = validateExistingTransaction;
/*   96:     */   }
/*   97:     */   
/*   98:     */   public final boolean isValidateExistingTransaction()
/*   99:     */   {
/*  100: 226 */     return this.validateExistingTransaction;
/*  101:     */   }
/*  102:     */   
/*  103:     */   public final void setGlobalRollbackOnParticipationFailure(boolean globalRollbackOnParticipationFailure)
/*  104:     */   {
/*  105: 262 */     this.globalRollbackOnParticipationFailure = globalRollbackOnParticipationFailure;
/*  106:     */   }
/*  107:     */   
/*  108:     */   public final boolean isGlobalRollbackOnParticipationFailure()
/*  109:     */   {
/*  110: 270 */     return this.globalRollbackOnParticipationFailure;
/*  111:     */   }
/*  112:     */   
/*  113:     */   public final void setFailEarlyOnGlobalRollbackOnly(boolean failEarlyOnGlobalRollbackOnly)
/*  114:     */   {
/*  115: 289 */     this.failEarlyOnGlobalRollbackOnly = failEarlyOnGlobalRollbackOnly;
/*  116:     */   }
/*  117:     */   
/*  118:     */   public final boolean isFailEarlyOnGlobalRollbackOnly()
/*  119:     */   {
/*  120: 297 */     return this.failEarlyOnGlobalRollbackOnly;
/*  121:     */   }
/*  122:     */   
/*  123:     */   public final void setRollbackOnCommitFailure(boolean rollbackOnCommitFailure)
/*  124:     */   {
/*  125: 310 */     this.rollbackOnCommitFailure = rollbackOnCommitFailure;
/*  126:     */   }
/*  127:     */   
/*  128:     */   public final boolean isRollbackOnCommitFailure()
/*  129:     */   {
/*  130: 318 */     return this.rollbackOnCommitFailure;
/*  131:     */   }
/*  132:     */   
/*  133:     */   public final TransactionStatus getTransaction(TransactionDefinition definition)
/*  134:     */     throws TransactionException
/*  135:     */   {
/*  136: 335 */     Object transaction = doGetTransaction();
/*  137:     */     
/*  138:     */ 
/*  139: 338 */     boolean debugEnabled = this.logger.isDebugEnabled();
/*  140: 340 */     if (definition == null) {
/*  141: 342 */       definition = new DefaultTransactionDefinition();
/*  142:     */     }
/*  143: 345 */     if (isExistingTransaction(transaction)) {
/*  144: 347 */       return handleExistingTransaction(definition, transaction, debugEnabled);
/*  145:     */     }
/*  146: 351 */     if (definition.getTimeout() < -1) {
/*  147: 352 */       throw new InvalidTimeoutException("Invalid transaction timeout", definition.getTimeout());
/*  148:     */     }
/*  149: 356 */     if (definition.getPropagationBehavior() == 2) {
/*  150: 357 */       throw new IllegalTransactionStateException("No existing transaction found for transaction marked with propagation 'mandatory'");
/*  151:     */     }
/*  152: 360 */     if ((definition.getPropagationBehavior() == 0) || (definition.getPropagationBehavior() == 3) || (definition.getPropagationBehavior() == 6))
/*  153:     */     {
/*  154: 363 */       SuspendedResourcesHolder suspendedResources = suspend(null);
/*  155: 364 */       if (debugEnabled) {
/*  156: 365 */         this.logger.debug("Creating new transaction with name [" + definition.getName() + "]: " + definition);
/*  157:     */       }
/*  158:     */       try
/*  159:     */       {
/*  160: 368 */         boolean newSynchronization = getTransactionSynchronization() != 2;
/*  161: 369 */         DefaultTransactionStatus status = newTransactionStatus(definition, transaction, true, newSynchronization, debugEnabled, suspendedResources);
/*  162:     */         
/*  163: 371 */         doBegin(transaction, definition);
/*  164: 372 */         prepareSynchronization(status, definition);
/*  165: 373 */         return status;
/*  166:     */       }
/*  167:     */       catch (RuntimeException ex)
/*  168:     */       {
/*  169: 376 */         resume(null, suspendedResources);
/*  170: 377 */         throw ex;
/*  171:     */       }
/*  172:     */       catch (Error err)
/*  173:     */       {
/*  174: 380 */         resume(null, suspendedResources);
/*  175: 381 */         throw err;
/*  176:     */       }
/*  177:     */     }
/*  178: 386 */     boolean newSynchronization = getTransactionSynchronization() == 0;
/*  179: 387 */     return prepareTransactionStatus(definition, null, true, newSynchronization, debugEnabled, null);
/*  180:     */   }
/*  181:     */   
/*  182:     */   private TransactionStatus handleExistingTransaction(TransactionDefinition definition, Object transaction, boolean debugEnabled)
/*  183:     */     throws TransactionException
/*  184:     */   {
/*  185: 398 */     if (definition.getPropagationBehavior() == 5) {
/*  186: 399 */       throw new IllegalTransactionStateException("Existing transaction found for transaction marked with propagation 'never'");
/*  187:     */     }
/*  188: 403 */     if (definition.getPropagationBehavior() == 4)
/*  189:     */     {
/*  190: 404 */       if (debugEnabled) {
/*  191: 405 */         this.logger.debug("Suspending current transaction");
/*  192:     */       }
/*  193: 407 */       Object suspendedResources = suspend(transaction);
/*  194: 408 */       boolean newSynchronization = getTransactionSynchronization() == 0;
/*  195: 409 */       return prepareTransactionStatus(definition, null, false, newSynchronization, debugEnabled, suspendedResources);
/*  196:     */     }
/*  197: 413 */     if (definition.getPropagationBehavior() == 3)
/*  198:     */     {
/*  199: 414 */       if (debugEnabled) {
/*  200: 415 */         this.logger.debug("Suspending current transaction, creating new transaction with name [" + definition.getName() + "]");
/*  201:     */       }
/*  202: 418 */       SuspendedResourcesHolder suspendedResources = suspend(transaction);
/*  203:     */       try
/*  204:     */       {
/*  205: 420 */         boolean newSynchronization = getTransactionSynchronization() != 2;
/*  206: 421 */         DefaultTransactionStatus status = newTransactionStatus(definition, transaction, true, newSynchronization, debugEnabled, suspendedResources);
/*  207:     */         
/*  208: 423 */         doBegin(transaction, definition);
/*  209: 424 */         prepareSynchronization(status, definition);
/*  210: 425 */         return status;
/*  211:     */       }
/*  212:     */       catch (RuntimeException beginEx)
/*  213:     */       {
/*  214: 428 */         resumeAfterBeginException(transaction, suspendedResources, beginEx);
/*  215: 429 */         throw beginEx;
/*  216:     */       }
/*  217:     */       catch (Error beginErr)
/*  218:     */       {
/*  219: 432 */         resumeAfterBeginException(transaction, suspendedResources, beginErr);
/*  220: 433 */         throw beginErr;
/*  221:     */       }
/*  222:     */     }
/*  223: 437 */     if (definition.getPropagationBehavior() == 6)
/*  224:     */     {
/*  225: 438 */       if (!isNestedTransactionAllowed()) {
/*  226: 439 */         throw new NestedTransactionNotSupportedException("Transaction manager does not allow nested transactions by default - specify 'nestedTransactionAllowed' property with value 'true'");
/*  227:     */       }
/*  228: 443 */       if (debugEnabled) {
/*  229: 444 */         this.logger.debug("Creating nested transaction with name [" + definition.getName() + "]");
/*  230:     */       }
/*  231: 446 */       if (useSavepointForNestedTransaction())
/*  232:     */       {
/*  233: 450 */         DefaultTransactionStatus status = prepareTransactionStatus(definition, transaction, false, false, debugEnabled, null);
/*  234:     */         
/*  235: 452 */         status.createAndHoldSavepoint();
/*  236: 453 */         return status;
/*  237:     */       }
/*  238: 459 */       boolean newSynchronization = getTransactionSynchronization() != 2;
/*  239: 460 */       DefaultTransactionStatus status = newTransactionStatus(definition, transaction, true, newSynchronization, debugEnabled, null);
/*  240:     */       
/*  241: 462 */       doBegin(transaction, definition);
/*  242: 463 */       prepareSynchronization(status, definition);
/*  243: 464 */       return status;
/*  244:     */     }
/*  245: 469 */     if (debugEnabled) {
/*  246: 470 */       this.logger.debug("Participating in existing transaction");
/*  247:     */     }
/*  248: 472 */     if (isValidateExistingTransaction())
/*  249:     */     {
/*  250: 473 */       if (definition.getIsolationLevel() != -1)
/*  251:     */       {
/*  252: 474 */         Integer currentIsolationLevel = TransactionSynchronizationManager.getCurrentTransactionIsolationLevel();
/*  253: 475 */         if ((currentIsolationLevel == null) || (currentIsolationLevel.intValue() != definition.getIsolationLevel()))
/*  254:     */         {
/*  255: 476 */           Constants isoConstants = DefaultTransactionDefinition.constants;
/*  256: 477 */           throw new IllegalTransactionStateException("Participating transaction with definition [" + definition + "] specifies isolation level which is incompatible with existing transaction: " + (currentIsolationLevel != null ? isoConstants.toCode(currentIsolationLevel, "ISOLATION_") : "(unknown)"));
/*  257:     */         }
/*  258:     */       }
/*  259: 484 */       if ((!definition.isReadOnly()) && 
/*  260: 485 */         (TransactionSynchronizationManager.isCurrentTransactionReadOnly())) {
/*  261: 486 */         throw new IllegalTransactionStateException("Participating transaction with definition [" + definition + "] is not marked as read-only but existing transaction is");
/*  262:     */       }
/*  263:     */     }
/*  264: 491 */     boolean newSynchronization = getTransactionSynchronization() != 2;
/*  265: 492 */     return prepareTransactionStatus(definition, transaction, false, newSynchronization, debugEnabled, null);
/*  266:     */   }
/*  267:     */   
/*  268:     */   protected final DefaultTransactionStatus prepareTransactionStatus(TransactionDefinition definition, Object transaction, boolean newTransaction, boolean newSynchronization, boolean debug, Object suspendedResources)
/*  269:     */   {
/*  270: 505 */     DefaultTransactionStatus status = newTransactionStatus(definition, transaction, newTransaction, newSynchronization, debug, suspendedResources);
/*  271:     */     
/*  272: 507 */     prepareSynchronization(status, definition);
/*  273: 508 */     return status;
/*  274:     */   }
/*  275:     */   
/*  276:     */   protected DefaultTransactionStatus newTransactionStatus(TransactionDefinition definition, Object transaction, boolean newTransaction, boolean newSynchronization, boolean debug, Object suspendedResources)
/*  277:     */   {
/*  278: 518 */     boolean actualNewSynchronization = (newSynchronization) && (!TransactionSynchronizationManager.isSynchronizationActive());
/*  279:     */     
/*  280: 520 */     return new DefaultTransactionStatus(transaction, newTransaction, actualNewSynchronization, definition.isReadOnly(), debug, suspendedResources);
/*  281:     */   }
/*  282:     */   
/*  283:     */   protected void prepareSynchronization(DefaultTransactionStatus status, TransactionDefinition definition)
/*  284:     */   {
/*  285: 529 */     if (status.isNewSynchronization())
/*  286:     */     {
/*  287: 530 */       TransactionSynchronizationManager.setActualTransactionActive(status.hasTransaction());
/*  288: 531 */       TransactionSynchronizationManager.setCurrentTransactionIsolationLevel(definition.getIsolationLevel() != -1 ? Integer.valueOf(definition.getIsolationLevel()) : null);
/*  289:     */       
/*  290:     */ 
/*  291: 534 */       TransactionSynchronizationManager.setCurrentTransactionReadOnly(definition.isReadOnly());
/*  292: 535 */       TransactionSynchronizationManager.setCurrentTransactionName(definition.getName());
/*  293: 536 */       TransactionSynchronizationManager.initSynchronization();
/*  294:     */     }
/*  295:     */   }
/*  296:     */   
/*  297:     */   protected int determineTimeout(TransactionDefinition definition)
/*  298:     */   {
/*  299: 550 */     if (definition.getTimeout() != -1) {
/*  300: 551 */       return definition.getTimeout();
/*  301:     */     }
/*  302: 553 */     return this.defaultTimeout;
/*  303:     */   }
/*  304:     */   
/*  305:     */   protected final SuspendedResourcesHolder suspend(Object transaction)
/*  306:     */     throws TransactionException
/*  307:     */   {
/*  308: 568 */     if (TransactionSynchronizationManager.isSynchronizationActive())
/*  309:     */     {
/*  310: 569 */       List<TransactionSynchronization> suspendedSynchronizations = doSuspendSynchronization();
/*  311:     */       try
/*  312:     */       {
/*  313: 571 */         Object suspendedResources = null;
/*  314: 572 */         if (transaction != null) {
/*  315: 573 */           suspendedResources = doSuspend(transaction);
/*  316:     */         }
/*  317: 575 */         String name = TransactionSynchronizationManager.getCurrentTransactionName();
/*  318: 576 */         TransactionSynchronizationManager.setCurrentTransactionName(null);
/*  319: 577 */         boolean readOnly = TransactionSynchronizationManager.isCurrentTransactionReadOnly();
/*  320: 578 */         TransactionSynchronizationManager.setCurrentTransactionReadOnly(false);
/*  321: 579 */         Integer isolationLevel = TransactionSynchronizationManager.getCurrentTransactionIsolationLevel();
/*  322: 580 */         TransactionSynchronizationManager.setCurrentTransactionIsolationLevel(null);
/*  323: 581 */         boolean wasActive = TransactionSynchronizationManager.isActualTransactionActive();
/*  324: 582 */         TransactionSynchronizationManager.setActualTransactionActive(false);
/*  325: 583 */         return new SuspendedResourcesHolder(suspendedResources, suspendedSynchronizations, name, readOnly, isolationLevel, wasActive, null);
/*  326:     */       }
/*  327:     */       catch (RuntimeException ex)
/*  328:     */       {
/*  329: 588 */         doResumeSynchronization(suspendedSynchronizations);
/*  330: 589 */         throw ex;
/*  331:     */       }
/*  332:     */       catch (Error err)
/*  333:     */       {
/*  334: 593 */         doResumeSynchronization(suspendedSynchronizations);
/*  335: 594 */         throw err;
/*  336:     */       }
/*  337:     */     }
/*  338: 597 */     if (transaction != null)
/*  339:     */     {
/*  340: 599 */       Object suspendedResources = doSuspend(transaction);
/*  341: 600 */       return new SuspendedResourcesHolder(suspendedResources, null);
/*  342:     */     }
/*  343: 604 */     return null;
/*  344:     */   }
/*  345:     */   
/*  346:     */   protected final void resume(Object transaction, SuspendedResourcesHolder resourcesHolder)
/*  347:     */     throws TransactionException
/*  348:     */   {
/*  349: 621 */     if (resourcesHolder != null)
/*  350:     */     {
/*  351: 622 */       Object suspendedResources = resourcesHolder.suspendedResources;
/*  352: 623 */       if (suspendedResources != null) {
/*  353: 624 */         doResume(transaction, suspendedResources);
/*  354:     */       }
/*  355: 626 */       List<TransactionSynchronization> suspendedSynchronizations = resourcesHolder.suspendedSynchronizations;
/*  356: 627 */       if (suspendedSynchronizations != null)
/*  357:     */       {
/*  358: 628 */         TransactionSynchronizationManager.setActualTransactionActive(resourcesHolder.wasActive);
/*  359: 629 */         TransactionSynchronizationManager.setCurrentTransactionIsolationLevel(resourcesHolder.isolationLevel);
/*  360: 630 */         TransactionSynchronizationManager.setCurrentTransactionReadOnly(resourcesHolder.readOnly);
/*  361: 631 */         TransactionSynchronizationManager.setCurrentTransactionName(resourcesHolder.name);
/*  362: 632 */         doResumeSynchronization(suspendedSynchronizations);
/*  363:     */       }
/*  364:     */     }
/*  365:     */   }
/*  366:     */   
/*  367:     */   private void resumeAfterBeginException(Object transaction, SuspendedResourcesHolder suspendedResources, Throwable beginEx)
/*  368:     */   {
/*  369: 643 */     String exMessage = "Inner transaction begin exception overridden by outer transaction resume exception";
/*  370:     */     try
/*  371:     */     {
/*  372: 645 */       resume(transaction, suspendedResources);
/*  373:     */     }
/*  374:     */     catch (RuntimeException resumeEx)
/*  375:     */     {
/*  376: 648 */       this.logger.error(exMessage, beginEx);
/*  377: 649 */       throw resumeEx;
/*  378:     */     }
/*  379:     */     catch (Error resumeErr)
/*  380:     */     {
/*  381: 652 */       this.logger.error(exMessage, beginEx);
/*  382: 653 */       throw resumeErr;
/*  383:     */     }
/*  384:     */   }
/*  385:     */   
/*  386:     */   private List<TransactionSynchronization> doSuspendSynchronization()
/*  387:     */   {
/*  388: 663 */     List<TransactionSynchronization> suspendedSynchronizations = TransactionSynchronizationManager.getSynchronizations();
/*  389: 665 */     for (TransactionSynchronization synchronization : suspendedSynchronizations) {
/*  390: 666 */       synchronization.suspend();
/*  391:     */     }
/*  392: 668 */     TransactionSynchronizationManager.clearSynchronization();
/*  393: 669 */     return suspendedSynchronizations;
/*  394:     */   }
/*  395:     */   
/*  396:     */   private void doResumeSynchronization(List<TransactionSynchronization> suspendedSynchronizations)
/*  397:     */   {
/*  398:     */     
/*  399: 679 */     for (TransactionSynchronization synchronization : suspendedSynchronizations)
/*  400:     */     {
/*  401: 680 */       synchronization.resume();
/*  402: 681 */       TransactionSynchronizationManager.registerSynchronization(synchronization);
/*  403:     */     }
/*  404:     */   }
/*  405:     */   
/*  406:     */   public final void commit(TransactionStatus status)
/*  407:     */     throws TransactionException
/*  408:     */   {
/*  409: 696 */     if (status.isCompleted()) {
/*  410: 697 */       throw new IllegalTransactionStateException("Transaction is already completed - do not call commit or rollback more than once per transaction");
/*  411:     */     }
/*  412: 701 */     DefaultTransactionStatus defStatus = (DefaultTransactionStatus)status;
/*  413: 702 */     if (defStatus.isLocalRollbackOnly())
/*  414:     */     {
/*  415: 703 */       if (defStatus.isDebug()) {
/*  416: 704 */         this.logger.debug("Transactional code has requested rollback");
/*  417:     */       }
/*  418: 706 */       processRollback(defStatus);
/*  419: 707 */       return;
/*  420:     */     }
/*  421: 709 */     if ((!shouldCommitOnGlobalRollbackOnly()) && (defStatus.isGlobalRollbackOnly()))
/*  422:     */     {
/*  423: 710 */       if (defStatus.isDebug()) {
/*  424: 711 */         this.logger.debug("Global transaction is marked as rollback-only but transactional code requested commit");
/*  425:     */       }
/*  426: 713 */       processRollback(defStatus);
/*  427: 716 */       if ((status.isNewTransaction()) || (isFailEarlyOnGlobalRollbackOnly())) {
/*  428: 717 */         throw new UnexpectedRollbackException("Transaction rolled back because it has been marked as rollback-only");
/*  429:     */       }
/*  430: 720 */       return;
/*  431:     */     }
/*  432: 723 */     processCommit(defStatus);
/*  433:     */   }
/*  434:     */   
/*  435:     */   private void processCommit(DefaultTransactionStatus status)
/*  436:     */     throws TransactionException
/*  437:     */   {
/*  438:     */     try
/*  439:     */     {
/*  440: 734 */       boolean beforeCompletionInvoked = false;
/*  441:     */       try
/*  442:     */       {
/*  443: 736 */         prepareForCommit(status);
/*  444: 737 */         triggerBeforeCommit(status);
/*  445: 738 */         triggerBeforeCompletion(status);
/*  446: 739 */         beforeCompletionInvoked = true;
/*  447: 740 */         boolean globalRollbackOnly = false;
/*  448: 741 */         if ((status.isNewTransaction()) || (isFailEarlyOnGlobalRollbackOnly())) {
/*  449: 742 */           globalRollbackOnly = status.isGlobalRollbackOnly();
/*  450:     */         }
/*  451: 744 */         if (status.hasSavepoint())
/*  452:     */         {
/*  453: 745 */           if (status.isDebug()) {
/*  454: 746 */             this.logger.debug("Releasing transaction savepoint");
/*  455:     */           }
/*  456: 748 */           status.releaseHeldSavepoint();
/*  457:     */         }
/*  458: 750 */         else if (status.isNewTransaction())
/*  459:     */         {
/*  460: 751 */           if (status.isDebug()) {
/*  461: 752 */             this.logger.debug("Initiating transaction commit");
/*  462:     */           }
/*  463: 754 */           doCommit(status);
/*  464:     */         }
/*  465: 758 */         if (globalRollbackOnly) {
/*  466: 759 */           throw new UnexpectedRollbackException("Transaction silently rolled back because it has been marked as rollback-only");
/*  467:     */         }
/*  468:     */       }
/*  469:     */       catch (UnexpectedRollbackException ex)
/*  470:     */       {
/*  471: 765 */         triggerAfterCompletion(status, 1);
/*  472: 766 */         throw ex;
/*  473:     */       }
/*  474:     */       catch (TransactionException ex)
/*  475:     */       {
/*  476: 770 */         if (isRollbackOnCommitFailure()) {
/*  477: 771 */           doRollbackOnCommitException(status, ex);
/*  478:     */         } else {
/*  479: 774 */           triggerAfterCompletion(status, 2);
/*  480:     */         }
/*  481: 776 */         throw ex;
/*  482:     */       }
/*  483:     */       catch (RuntimeException ex)
/*  484:     */       {
/*  485: 779 */         if (!beforeCompletionInvoked) {
/*  486: 780 */           triggerBeforeCompletion(status);
/*  487:     */         }
/*  488: 782 */         doRollbackOnCommitException(status, ex);
/*  489: 783 */         throw ex;
/*  490:     */       }
/*  491:     */       catch (Error err)
/*  492:     */       {
/*  493: 786 */         if (!beforeCompletionInvoked) {
/*  494: 787 */           triggerBeforeCompletion(status);
/*  495:     */         }
/*  496: 789 */         doRollbackOnCommitException(status, err);
/*  497: 790 */         throw err;
/*  498:     */       }
/*  499:     */       try {}finally
/*  500:     */       {
/*  501: 799 */         triggerAfterCompletion(status, 0);
/*  502:     */       }
/*  503:     */     }
/*  504:     */     finally
/*  505:     */     {
/*  506: 804 */       cleanupAfterCompletion(status);
/*  507:     */     }
/*  508:     */   }
/*  509:     */   
/*  510:     */   public final void rollback(TransactionStatus status)
/*  511:     */     throws TransactionException
/*  512:     */   {
/*  513: 816 */     if (status.isCompleted()) {
/*  514: 817 */       throw new IllegalTransactionStateException("Transaction is already completed - do not call commit or rollback more than once per transaction");
/*  515:     */     }
/*  516: 821 */     DefaultTransactionStatus defStatus = (DefaultTransactionStatus)status;
/*  517: 822 */     processRollback(defStatus);
/*  518:     */   }
/*  519:     */   
/*  520:     */   private void processRollback(DefaultTransactionStatus status)
/*  521:     */   {
/*  522:     */     try
/*  523:     */     {
/*  524:     */       try
/*  525:     */       {
/*  526: 834 */         triggerBeforeCompletion(status);
/*  527: 835 */         if (status.hasSavepoint())
/*  528:     */         {
/*  529: 836 */           if (status.isDebug()) {
/*  530: 837 */             this.logger.debug("Rolling back transaction to savepoint");
/*  531:     */           }
/*  532: 839 */           status.rollbackToHeldSavepoint();
/*  533:     */         }
/*  534: 841 */         else if (status.isNewTransaction())
/*  535:     */         {
/*  536: 842 */           if (status.isDebug()) {
/*  537: 843 */             this.logger.debug("Initiating transaction rollback");
/*  538:     */           }
/*  539: 845 */           doRollback(status);
/*  540:     */         }
/*  541: 847 */         else if (status.hasTransaction())
/*  542:     */         {
/*  543: 848 */           if ((status.isLocalRollbackOnly()) || (isGlobalRollbackOnParticipationFailure()))
/*  544:     */           {
/*  545: 849 */             if (status.isDebug()) {
/*  546: 850 */               this.logger.debug("Participating transaction failed - marking existing transaction as rollback-only");
/*  547:     */             }
/*  548: 852 */             doSetRollbackOnly(status);
/*  549:     */           }
/*  550: 855 */           else if (status.isDebug())
/*  551:     */           {
/*  552: 856 */             this.logger.debug("Participating transaction failed - letting transaction originator decide on rollback");
/*  553:     */           }
/*  554:     */         }
/*  555:     */         else
/*  556:     */         {
/*  557: 861 */           this.logger.debug("Should roll back transaction but cannot - no transaction available");
/*  558:     */         }
/*  559:     */       }
/*  560:     */       catch (RuntimeException ex)
/*  561:     */       {
/*  562: 865 */         triggerAfterCompletion(status, 2);
/*  563: 866 */         throw ex;
/*  564:     */       }
/*  565:     */       return;
/*  566:     */     }
/*  567:     */     catch (Error err)
/*  568:     */     {
/*  569: 869 */       triggerAfterCompletion(status, 2);
/*  570: 870 */       throw err;
/*  571:     */       
/*  572: 872 */       triggerAfterCompletion(status, 1);
/*  573:     */     }
/*  574:     */     finally
/*  575:     */     {
/*  576: 875 */       cleanupAfterCompletion(status);
/*  577:     */     }
/*  578:     */   }
/*  579:     */   
/*  580:     */   private void doRollbackOnCommitException(DefaultTransactionStatus status, Throwable ex)
/*  581:     */     throws TransactionException
/*  582:     */   {
/*  583:     */     try
/*  584:     */     {
/*  585: 888 */       if (status.isNewTransaction())
/*  586:     */       {
/*  587: 889 */         if (status.isDebug()) {
/*  588: 890 */           this.logger.debug("Initiating transaction rollback after commit exception", ex);
/*  589:     */         }
/*  590: 892 */         doRollback(status);
/*  591:     */       }
/*  592: 894 */       else if ((status.hasTransaction()) && (isGlobalRollbackOnParticipationFailure()))
/*  593:     */       {
/*  594: 895 */         if (status.isDebug()) {
/*  595: 896 */           this.logger.debug("Marking existing transaction as rollback-only after commit exception", ex);
/*  596:     */         }
/*  597: 898 */         doSetRollbackOnly(status);
/*  598:     */       }
/*  599:     */     }
/*  600:     */     catch (RuntimeException rbex)
/*  601:     */     {
/*  602: 902 */       this.logger.error("Commit exception overridden by rollback exception", ex);
/*  603: 903 */       triggerAfterCompletion(status, 2);
/*  604: 904 */       throw rbex;
/*  605:     */     }
/*  606:     */     catch (Error rberr)
/*  607:     */     {
/*  608: 907 */       this.logger.error("Commit exception overridden by rollback exception", ex);
/*  609: 908 */       triggerAfterCompletion(status, 2);
/*  610: 909 */       throw rberr;
/*  611:     */     }
/*  612: 911 */     triggerAfterCompletion(status, 1);
/*  613:     */   }
/*  614:     */   
/*  615:     */   protected final void triggerBeforeCommit(DefaultTransactionStatus status)
/*  616:     */   {
/*  617: 920 */     if (status.isNewSynchronization())
/*  618:     */     {
/*  619: 921 */       if (status.isDebug()) {
/*  620: 922 */         this.logger.trace("Triggering beforeCommit synchronization");
/*  621:     */       }
/*  622: 924 */       TransactionSynchronizationUtils.triggerBeforeCommit(status.isReadOnly());
/*  623:     */     }
/*  624:     */   }
/*  625:     */   
/*  626:     */   protected final void triggerBeforeCompletion(DefaultTransactionStatus status)
/*  627:     */   {
/*  628: 933 */     if (status.isNewSynchronization())
/*  629:     */     {
/*  630: 934 */       if (status.isDebug()) {
/*  631: 935 */         this.logger.trace("Triggering beforeCompletion synchronization");
/*  632:     */       }
/*  633: 937 */       TransactionSynchronizationUtils.triggerBeforeCompletion();
/*  634:     */     }
/*  635:     */   }
/*  636:     */   
/*  637:     */   private void triggerAfterCommit(DefaultTransactionStatus status)
/*  638:     */   {
/*  639: 946 */     if (status.isNewSynchronization())
/*  640:     */     {
/*  641: 947 */       if (status.isDebug()) {
/*  642: 948 */         this.logger.trace("Triggering afterCommit synchronization");
/*  643:     */       }
/*  644: 950 */       TransactionSynchronizationUtils.triggerAfterCommit();
/*  645:     */     }
/*  646:     */   }
/*  647:     */   
/*  648:     */   private void triggerAfterCompletion(DefaultTransactionStatus status, int completionStatus)
/*  649:     */   {
/*  650: 960 */     if (status.isNewSynchronization())
/*  651:     */     {
/*  652: 961 */       List<TransactionSynchronization> synchronizations = TransactionSynchronizationManager.getSynchronizations();
/*  653: 962 */       if ((!status.hasTransaction()) || (status.isNewTransaction()))
/*  654:     */       {
/*  655: 963 */         if (status.isDebug()) {
/*  656: 964 */           this.logger.trace("Triggering afterCompletion synchronization");
/*  657:     */         }
/*  658: 968 */         invokeAfterCompletion(synchronizations, completionStatus);
/*  659:     */       }
/*  660: 970 */       else if (!synchronizations.isEmpty())
/*  661:     */       {
/*  662: 974 */         registerAfterCompletionWithExistingTransaction(status.getTransaction(), synchronizations);
/*  663:     */       }
/*  664:     */     }
/*  665:     */   }
/*  666:     */   
/*  667:     */   protected final void invokeAfterCompletion(List<TransactionSynchronization> synchronizations, int completionStatus)
/*  668:     */   {
/*  669: 993 */     TransactionSynchronizationUtils.invokeAfterCompletion(synchronizations, completionStatus);
/*  670:     */   }
/*  671:     */   
/*  672:     */   private void cleanupAfterCompletion(DefaultTransactionStatus status)
/*  673:     */   {
/*  674:1003 */     status.setCompleted();
/*  675:1004 */     if (status.isNewSynchronization()) {
/*  676:1005 */       TransactionSynchronizationManager.clear();
/*  677:     */     }
/*  678:1007 */     if (status.isNewTransaction()) {
/*  679:1008 */       doCleanupAfterCompletion(status.getTransaction());
/*  680:     */     }
/*  681:1010 */     if (status.getSuspendedResources() != null)
/*  682:     */     {
/*  683:1011 */       if (status.isDebug()) {
/*  684:1012 */         this.logger.debug("Resuming suspended transaction after completion of inner transaction");
/*  685:     */       }
/*  686:1014 */       resume(status.getTransaction(), (SuspendedResourcesHolder)status.getSuspendedResources());
/*  687:     */     }
/*  688:     */   }
/*  689:     */   
/*  690:     */   protected abstract Object doGetTransaction()
/*  691:     */     throws TransactionException;
/*  692:     */   
/*  693:     */   protected boolean isExistingTransaction(Object transaction)
/*  694:     */     throws TransactionException
/*  695:     */   {
/*  696:1063 */     return false;
/*  697:     */   }
/*  698:     */   
/*  699:     */   protected boolean useSavepointForNestedTransaction()
/*  700:     */   {
/*  701:1083 */     return true;
/*  702:     */   }
/*  703:     */   
/*  704:     */   protected abstract void doBegin(Object paramObject, TransactionDefinition paramTransactionDefinition)
/*  705:     */     throws TransactionException;
/*  706:     */   
/*  707:     */   protected Object doSuspend(Object transaction)
/*  708:     */     throws TransactionException
/*  709:     */   {
/*  710:1120 */     throw new TransactionSuspensionNotSupportedException("Transaction manager [" + getClass().getName() + "] does not support transaction suspension");
/*  711:     */   }
/*  712:     */   
/*  713:     */   protected void doResume(Object transaction, Object suspendedResources)
/*  714:     */     throws TransactionException
/*  715:     */   {
/*  716:1138 */     throw new TransactionSuspensionNotSupportedException("Transaction manager [" + getClass().getName() + "] does not support transaction suspension");
/*  717:     */   }
/*  718:     */   
/*  719:     */   protected boolean shouldCommitOnGlobalRollbackOnly()
/*  720:     */   {
/*  721:1172 */     return false;
/*  722:     */   }
/*  723:     */   
/*  724:     */   protected void prepareForCommit(DefaultTransactionStatus status) {}
/*  725:     */   
/*  726:     */   protected abstract void doCommit(DefaultTransactionStatus paramDefaultTransactionStatus)
/*  727:     */     throws TransactionException;
/*  728:     */   
/*  729:     */   protected abstract void doRollback(DefaultTransactionStatus paramDefaultTransactionStatus)
/*  730:     */     throws TransactionException;
/*  731:     */   
/*  732:     */   protected void doSetRollbackOnly(DefaultTransactionStatus status)
/*  733:     */     throws TransactionException
/*  734:     */   {
/*  735:1220 */     throw new IllegalTransactionStateException("Participating in existing transactions is not supported - when 'isExistingTransaction' returns true, appropriate 'doSetRollbackOnly' behavior must be provided");
/*  736:     */   }
/*  737:     */   
/*  738:     */   protected void registerAfterCompletionWithExistingTransaction(Object transaction, List<TransactionSynchronization> synchronizations)
/*  739:     */     throws TransactionException
/*  740:     */   {
/*  741:1243 */     this.logger.debug("Cannot register Spring after-completion synchronization with existing transaction - processing Spring after-completion callbacks immediately, with outcome status 'unknown'");
/*  742:     */     
/*  743:1245 */     invokeAfterCompletion(synchronizations, 2);
/*  744:     */   }
/*  745:     */   
/*  746:     */   protected void doCleanupAfterCompletion(Object transaction) {}
/*  747:     */   
/*  748:     */   private void readObject(ObjectInputStream ois)
/*  749:     */     throws IOException, ClassNotFoundException
/*  750:     */   {
/*  751:1265 */     ois.defaultReadObject();
/*  752:     */     
/*  753:     */ 
/*  754:1268 */     this.logger = LogFactory.getLog(getClass());
/*  755:     */   }
/*  756:     */   
/*  757:     */   protected static class SuspendedResourcesHolder
/*  758:     */   {
/*  759:     */     private final Object suspendedResources;
/*  760:     */     private List<TransactionSynchronization> suspendedSynchronizations;
/*  761:     */     private String name;
/*  762:     */     private boolean readOnly;
/*  763:     */     private Integer isolationLevel;
/*  764:     */     private boolean wasActive;
/*  765:     */     
/*  766:     */     private SuspendedResourcesHolder(Object suspendedResources)
/*  767:     */     {
/*  768:1285 */       this.suspendedResources = suspendedResources;
/*  769:     */     }
/*  770:     */     
/*  771:     */     private SuspendedResourcesHolder(Object suspendedResources, List<TransactionSynchronization> suspendedSynchronizations, String name, boolean readOnly, Integer isolationLevel, boolean wasActive)
/*  772:     */     {
/*  773:1291 */       this.suspendedResources = suspendedResources;
/*  774:1292 */       this.suspendedSynchronizations = suspendedSynchronizations;
/*  775:1293 */       this.name = name;
/*  776:1294 */       this.readOnly = readOnly;
/*  777:1295 */       this.isolationLevel = isolationLevel;
/*  778:1296 */       this.wasActive = wasActive;
/*  779:     */     }
/*  780:     */   }
/*  781:     */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.transaction.support.AbstractPlatformTransactionManager
 * JD-Core Version:    0.7.0.1
 */