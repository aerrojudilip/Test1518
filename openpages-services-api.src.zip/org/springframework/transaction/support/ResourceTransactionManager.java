package org.springframework.transaction.support;

import org.springframework.transaction.PlatformTransactionManager;

public abstract interface ResourceTransactionManager
  extends PlatformTransactionManager
{
  public abstract Object getResourceFactory();
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.transaction.support.ResourceTransactionManager
 * JD-Core Version:    0.7.0.1
 */