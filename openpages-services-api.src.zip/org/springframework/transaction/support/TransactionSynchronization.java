package org.springframework.transaction.support;

public abstract interface TransactionSynchronization
{
  public static final int STATUS_COMMITTED = 0;
  public static final int STATUS_ROLLED_BACK = 1;
  public static final int STATUS_UNKNOWN = 2;
  
  public abstract void suspend();
  
  public abstract void resume();
  
  public abstract void flush();
  
  public abstract void beforeCommit(boolean paramBoolean);
  
  public abstract void beforeCompletion();
  
  public abstract void afterCommit();
  
  public abstract void afterCompletion(int paramInt);
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.transaction.support.TransactionSynchronization
 * JD-Core Version:    0.7.0.1
 */