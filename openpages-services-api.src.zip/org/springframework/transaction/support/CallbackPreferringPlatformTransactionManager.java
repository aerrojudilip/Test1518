package org.springframework.transaction.support;

import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionException;

public abstract interface CallbackPreferringPlatformTransactionManager
  extends PlatformTransactionManager
{
  public abstract <T> T execute(TransactionDefinition paramTransactionDefinition, TransactionCallback<T> paramTransactionCallback)
    throws TransactionException;
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.transaction.support.CallbackPreferringPlatformTransactionManager
 * JD-Core Version:    0.7.0.1
 */