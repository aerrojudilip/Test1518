package org.springframework.transaction.support;

public abstract interface SmartTransactionObject
{
  public abstract boolean isRollbackOnly();
  
  public abstract void flush();
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.transaction.support.SmartTransactionObject
 * JD-Core Version:    0.7.0.1
 */