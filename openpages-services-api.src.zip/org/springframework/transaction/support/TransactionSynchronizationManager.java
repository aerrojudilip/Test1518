/*   1:    */ package org.springframework.transaction.support;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.Collections;
/*   5:    */ import java.util.HashMap;
/*   6:    */ import java.util.LinkedHashSet;
/*   7:    */ import java.util.List;
/*   8:    */ import java.util.Map;
/*   9:    */ import java.util.Set;
/*  10:    */ import org.apache.commons.logging.Log;
/*  11:    */ import org.apache.commons.logging.LogFactory;
/*  12:    */ import org.springframework.core.NamedThreadLocal;
/*  13:    */ import org.springframework.core.OrderComparator;
/*  14:    */ import org.springframework.util.Assert;
/*  15:    */ 
/*  16:    */ public abstract class TransactionSynchronizationManager
/*  17:    */ {
/*  18: 78 */   private static final Log logger = LogFactory.getLog(TransactionSynchronizationManager.class);
/*  19: 80 */   private static final ThreadLocal<Map<Object, Object>> resources = new NamedThreadLocal("Transactional resources");
/*  20: 83 */   private static final ThreadLocal<Set<TransactionSynchronization>> synchronizations = new NamedThreadLocal("Transaction synchronizations");
/*  21: 86 */   private static final ThreadLocal<String> currentTransactionName = new NamedThreadLocal("Current transaction name");
/*  22: 89 */   private static final ThreadLocal<Boolean> currentTransactionReadOnly = new NamedThreadLocal("Current transaction read-only status");
/*  23: 92 */   private static final ThreadLocal<Integer> currentTransactionIsolationLevel = new NamedThreadLocal("Current transaction isolation level");
/*  24: 95 */   private static final ThreadLocal<Boolean> actualTransactionActive = new NamedThreadLocal("Actual transaction active");
/*  25:    */   
/*  26:    */   public static Map<Object, Object> getResourceMap()
/*  27:    */   {
/*  28:113 */     Map<Object, Object> map = (Map)resources.get();
/*  29:114 */     return map != null ? Collections.unmodifiableMap(map) : Collections.emptyMap();
/*  30:    */   }
/*  31:    */   
/*  32:    */   public static boolean hasResource(Object key)
/*  33:    */   {
/*  34:124 */     Object actualKey = TransactionSynchronizationUtils.unwrapResourceIfNecessary(key);
/*  35:125 */     Object value = doGetResource(actualKey);
/*  36:126 */     return value != null;
/*  37:    */   }
/*  38:    */   
/*  39:    */   public static Object getResource(Object key)
/*  40:    */   {
/*  41:137 */     Object actualKey = TransactionSynchronizationUtils.unwrapResourceIfNecessary(key);
/*  42:138 */     Object value = doGetResource(actualKey);
/*  43:139 */     if ((value != null) && (logger.isTraceEnabled())) {
/*  44:140 */       logger.trace("Retrieved value [" + value + "] for key [" + actualKey + "] bound to thread [" + Thread.currentThread().getName() + "]");
/*  45:    */     }
/*  46:143 */     return value;
/*  47:    */   }
/*  48:    */   
/*  49:    */   private static Object doGetResource(Object actualKey)
/*  50:    */   {
/*  51:150 */     Map<Object, Object> map = (Map)resources.get();
/*  52:151 */     if (map == null) {
/*  53:152 */       return null;
/*  54:    */     }
/*  55:154 */     Object value = map.get(actualKey);
/*  56:156 */     if (((value instanceof ResourceHolder)) && (((ResourceHolder)value).isVoid()))
/*  57:    */     {
/*  58:157 */       map.remove(actualKey);
/*  59:159 */       if (map.isEmpty()) {
/*  60:160 */         resources.remove();
/*  61:    */       }
/*  62:162 */       value = null;
/*  63:    */     }
/*  64:164 */     return value;
/*  65:    */   }
/*  66:    */   
/*  67:    */   public static void bindResource(Object key, Object value)
/*  68:    */     throws IllegalStateException
/*  69:    */   {
/*  70:175 */     Object actualKey = TransactionSynchronizationUtils.unwrapResourceIfNecessary(key);
/*  71:176 */     Assert.notNull(value, "Value must not be null");
/*  72:177 */     Map<Object, Object> map = (Map)resources.get();
/*  73:179 */     if (map == null)
/*  74:    */     {
/*  75:180 */       map = new HashMap();
/*  76:181 */       resources.set(map);
/*  77:    */     }
/*  78:183 */     Object oldValue = map.put(actualKey, value);
/*  79:185 */     if (((oldValue instanceof ResourceHolder)) && (((ResourceHolder)oldValue).isVoid())) {
/*  80:186 */       oldValue = null;
/*  81:    */     }
/*  82:188 */     if (oldValue != null) {
/*  83:189 */       throw new IllegalStateException("Already value [" + oldValue + "] for key [" + actualKey + "] bound to thread [" + Thread.currentThread().getName() + "]");
/*  84:    */     }
/*  85:192 */     if (logger.isTraceEnabled()) {
/*  86:193 */       logger.trace("Bound value [" + value + "] for key [" + actualKey + "] to thread [" + Thread.currentThread().getName() + "]");
/*  87:    */     }
/*  88:    */   }
/*  89:    */   
/*  90:    */   public static Object unbindResource(Object key)
/*  91:    */     throws IllegalStateException
/*  92:    */   {
/*  93:206 */     Object actualKey = TransactionSynchronizationUtils.unwrapResourceIfNecessary(key);
/*  94:207 */     Object value = doUnbindResource(actualKey);
/*  95:208 */     if (value == null) {
/*  96:209 */       throw new IllegalStateException("No value for key [" + actualKey + "] bound to thread [" + Thread.currentThread().getName() + "]");
/*  97:    */     }
/*  98:212 */     return value;
/*  99:    */   }
/* 100:    */   
/* 101:    */   public static Object unbindResourceIfPossible(Object key)
/* 102:    */   {
/* 103:221 */     Object actualKey = TransactionSynchronizationUtils.unwrapResourceIfNecessary(key);
/* 104:222 */     return doUnbindResource(actualKey);
/* 105:    */   }
/* 106:    */   
/* 107:    */   private static Object doUnbindResource(Object actualKey)
/* 108:    */   {
/* 109:229 */     Map<Object, Object> map = (Map)resources.get();
/* 110:230 */     if (map == null) {
/* 111:231 */       return null;
/* 112:    */     }
/* 113:233 */     Object value = map.remove(actualKey);
/* 114:235 */     if (map.isEmpty()) {
/* 115:236 */       resources.remove();
/* 116:    */     }
/* 117:239 */     if (((value instanceof ResourceHolder)) && (((ResourceHolder)value).isVoid())) {
/* 118:240 */       value = null;
/* 119:    */     }
/* 120:242 */     if ((value != null) && (logger.isTraceEnabled())) {
/* 121:243 */       logger.trace("Removed value [" + value + "] for key [" + actualKey + "] from thread [" + Thread.currentThread().getName() + "]");
/* 122:    */     }
/* 123:246 */     return value;
/* 124:    */   }
/* 125:    */   
/* 126:    */   public static boolean isSynchronizationActive()
/* 127:    */   {
/* 128:260 */     return synchronizations.get() != null;
/* 129:    */   }
/* 130:    */   
/* 131:    */   public static void initSynchronization()
/* 132:    */     throws IllegalStateException
/* 133:    */   {
/* 134:269 */     if (isSynchronizationActive()) {
/* 135:270 */       throw new IllegalStateException("Cannot activate transaction synchronization - already active");
/* 136:    */     }
/* 137:272 */     logger.trace("Initializing transaction synchronization");
/* 138:273 */     synchronizations.set(new LinkedHashSet());
/* 139:    */   }
/* 140:    */   
/* 141:    */   public static void registerSynchronization(TransactionSynchronization synchronization)
/* 142:    */     throws IllegalStateException
/* 143:    */   {
/* 144:289 */     Assert.notNull(synchronization, "TransactionSynchronization must not be null");
/* 145:290 */     if (!isSynchronizationActive()) {
/* 146:291 */       throw new IllegalStateException("Transaction synchronization is not active");
/* 147:    */     }
/* 148:293 */     ((Set)synchronizations.get()).add(synchronization);
/* 149:    */   }
/* 150:    */   
/* 151:    */   public static List<TransactionSynchronization> getSynchronizations()
/* 152:    */     throws IllegalStateException
/* 153:    */   {
/* 154:304 */     Set<TransactionSynchronization> synchs = (Set)synchronizations.get();
/* 155:305 */     if (synchs == null) {
/* 156:306 */       throw new IllegalStateException("Transaction synchronization is not active");
/* 157:    */     }
/* 158:311 */     if (synchs.isEmpty()) {
/* 159:312 */       return Collections.emptyList();
/* 160:    */     }
/* 161:316 */     List<TransactionSynchronization> sortedSynchs = new ArrayList(synchs);
/* 162:317 */     OrderComparator.sort(sortedSynchs);
/* 163:318 */     return Collections.unmodifiableList(sortedSynchs);
/* 164:    */   }
/* 165:    */   
/* 166:    */   public static void clearSynchronization()
/* 167:    */     throws IllegalStateException
/* 168:    */   {
/* 169:328 */     if (!isSynchronizationActive()) {
/* 170:329 */       throw new IllegalStateException("Cannot deactivate transaction synchronization - not active");
/* 171:    */     }
/* 172:331 */     logger.trace("Clearing transaction synchronization");
/* 173:332 */     synchronizations.remove();
/* 174:    */   }
/* 175:    */   
/* 176:    */   public static void setCurrentTransactionName(String name)
/* 177:    */   {
/* 178:347 */     currentTransactionName.set(name);
/* 179:    */   }
/* 180:    */   
/* 181:    */   public static String getCurrentTransactionName()
/* 182:    */   {
/* 183:357 */     return (String)currentTransactionName.get();
/* 184:    */   }
/* 185:    */   
/* 186:    */   public static void setCurrentTransactionReadOnly(boolean readOnly)
/* 187:    */   {
/* 188:368 */     currentTransactionReadOnly.set(readOnly ? Boolean.TRUE : null);
/* 189:    */   }
/* 190:    */   
/* 191:    */   public static boolean isCurrentTransactionReadOnly()
/* 192:    */   {
/* 193:384 */     return currentTransactionReadOnly.get() != null;
/* 194:    */   }
/* 195:    */   
/* 196:    */   public static void setCurrentTransactionIsolationLevel(Integer isolationLevel)
/* 197:    */   {
/* 198:404 */     currentTransactionIsolationLevel.set(isolationLevel);
/* 199:    */   }
/* 200:    */   
/* 201:    */   public static Integer getCurrentTransactionIsolationLevel()
/* 202:    */   {
/* 203:425 */     return (Integer)currentTransactionIsolationLevel.get();
/* 204:    */   }
/* 205:    */   
/* 206:    */   public static void setActualTransactionActive(boolean active)
/* 207:    */   {
/* 208:435 */     actualTransactionActive.set(active ? Boolean.TRUE : null);
/* 209:    */   }
/* 210:    */   
/* 211:    */   public static boolean isActualTransactionActive()
/* 212:    */   {
/* 213:450 */     return actualTransactionActive.get() != null;
/* 214:    */   }
/* 215:    */   
/* 216:    */   public static void clear()
/* 217:    */   {
/* 218:464 */     clearSynchronization();
/* 219:465 */     setCurrentTransactionName(null);
/* 220:466 */     setCurrentTransactionReadOnly(false);
/* 221:467 */     setCurrentTransactionIsolationLevel(null);
/* 222:468 */     setActualTransactionActive(false);
/* 223:    */   }
/* 224:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.transaction.support.TransactionSynchronizationManager
 * JD-Core Version:    0.7.0.1
 */