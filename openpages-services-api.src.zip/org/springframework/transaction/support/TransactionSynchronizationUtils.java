/*   1:    */ package org.springframework.transaction.support;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import org.apache.commons.logging.Log;
/*   5:    */ import org.apache.commons.logging.LogFactory;
/*   6:    */ import org.springframework.aop.scope.ScopedObject;
/*   7:    */ import org.springframework.core.InfrastructureProxy;
/*   8:    */ import org.springframework.util.Assert;
/*   9:    */ import org.springframework.util.ClassUtils;
/*  10:    */ 
/*  11:    */ public abstract class TransactionSynchronizationUtils
/*  12:    */ {
/*  13: 40 */   private static final Log logger = LogFactory.getLog(TransactionSynchronizationUtils.class);
/*  14: 42 */   private static final boolean aopAvailable = ClassUtils.isPresent("org.springframework.aop.scope.ScopedObject", TransactionSynchronizationUtils.class.getClassLoader());
/*  15:    */   
/*  16:    */   public static boolean sameResourceFactory(ResourceTransactionManager tm, Object resourceFactory)
/*  17:    */   {
/*  18: 53 */     return unwrapResourceIfNecessary(tm.getResourceFactory()).equals(unwrapResourceIfNecessary(resourceFactory));
/*  19:    */   }
/*  20:    */   
/*  21:    */   static Object unwrapResourceIfNecessary(Object resource)
/*  22:    */   {
/*  23: 62 */     Assert.notNull(resource, "Resource must not be null");
/*  24: 63 */     Object resourceRef = resource;
/*  25: 65 */     if ((resourceRef instanceof InfrastructureProxy)) {
/*  26: 66 */       resourceRef = ((InfrastructureProxy)resourceRef).getWrappedObject();
/*  27:    */     }
/*  28: 68 */     if (aopAvailable) {
/*  29: 70 */       resourceRef = ScopedProxyUnwrapper.unwrapIfNecessary(resourceRef);
/*  30:    */     }
/*  31: 72 */     return resourceRef;
/*  32:    */   }
/*  33:    */   
/*  34:    */   public static void triggerFlush()
/*  35:    */   {
/*  36: 82 */     for (TransactionSynchronization synchronization : ) {
/*  37: 83 */       synchronization.flush();
/*  38:    */     }
/*  39:    */   }
/*  40:    */   
/*  41:    */   public static void triggerBeforeCommit(boolean readOnly)
/*  42:    */   {
/*  43: 94 */     for (TransactionSynchronization synchronization : ) {
/*  44: 95 */       synchronization.beforeCommit(readOnly);
/*  45:    */     }
/*  46:    */   }
/*  47:    */   
/*  48:    */   public static void triggerBeforeCompletion()
/*  49:    */   {
/*  50:104 */     for (TransactionSynchronization synchronization : ) {
/*  51:    */       try
/*  52:    */       {
/*  53:106 */         synchronization.beforeCompletion();
/*  54:    */       }
/*  55:    */       catch (Throwable tsex)
/*  56:    */       {
/*  57:109 */         logger.error("TransactionSynchronization.beforeCompletion threw exception", tsex);
/*  58:    */       }
/*  59:    */     }
/*  60:    */   }
/*  61:    */   
/*  62:    */   public static void triggerAfterCommit()
/*  63:    */   {
/*  64:121 */     invokeAfterCommit(TransactionSynchronizationManager.getSynchronizations());
/*  65:    */   }
/*  66:    */   
/*  67:    */   public static void invokeAfterCommit(List<TransactionSynchronization> synchronizations)
/*  68:    */   {
/*  69:131 */     if (synchronizations != null) {
/*  70:132 */       for (TransactionSynchronization synchronization : synchronizations) {
/*  71:133 */         synchronization.afterCommit();
/*  72:    */       }
/*  73:    */     }
/*  74:    */   }
/*  75:    */   
/*  76:    */   public static void triggerAfterCompletion(int completionStatus)
/*  77:    */   {
/*  78:149 */     List<TransactionSynchronization> synchronizations = TransactionSynchronizationManager.getSynchronizations();
/*  79:150 */     invokeAfterCompletion(synchronizations, completionStatus);
/*  80:    */   }
/*  81:    */   
/*  82:    */   public static void invokeAfterCompletion(List<TransactionSynchronization> synchronizations, int completionStatus)
/*  83:    */   {
/*  84:165 */     if (synchronizations != null) {
/*  85:166 */       for (TransactionSynchronization synchronization : synchronizations) {
/*  86:    */         try
/*  87:    */         {
/*  88:168 */           synchronization.afterCompletion(completionStatus);
/*  89:    */         }
/*  90:    */         catch (Throwable tsex)
/*  91:    */         {
/*  92:171 */           logger.error("TransactionSynchronization.afterCompletion threw exception", tsex);
/*  93:    */         }
/*  94:    */       }
/*  95:    */     }
/*  96:    */   }
/*  97:    */   
/*  98:    */   private static class ScopedProxyUnwrapper
/*  99:    */   {
/* 100:    */     public static Object unwrapIfNecessary(Object resource)
/* 101:    */     {
/* 102:184 */       if ((resource instanceof ScopedObject)) {
/* 103:185 */         return ((ScopedObject)resource).getTargetObject();
/* 104:    */       }
/* 105:188 */       return resource;
/* 106:    */     }
/* 107:    */   }
/* 108:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.transaction.support.TransactionSynchronizationUtils
 * JD-Core Version:    0.7.0.1
 */