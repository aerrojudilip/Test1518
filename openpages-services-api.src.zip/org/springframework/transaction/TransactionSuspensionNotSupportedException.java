/*  1:   */ package org.springframework.transaction;
/*  2:   */ 
/*  3:   */ public class TransactionSuspensionNotSupportedException
/*  4:   */   extends CannotCreateTransactionException
/*  5:   */ {
/*  6:   */   public TransactionSuspensionNotSupportedException(String msg)
/*  7:   */   {
/*  8:33 */     super(msg);
/*  9:   */   }
/* 10:   */   
/* 11:   */   public TransactionSuspensionNotSupportedException(String msg, Throwable cause)
/* 12:   */   {
/* 13:42 */     super(msg, cause);
/* 14:   */   }
/* 15:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.transaction.TransactionSuspensionNotSupportedException
 * JD-Core Version:    0.7.0.1
 */