package org.springframework.transaction;

public abstract interface SavepointManager
{
  public abstract Object createSavepoint()
    throws TransactionException;
  
  public abstract void rollbackToSavepoint(Object paramObject)
    throws TransactionException;
  
  public abstract void releaseSavepoint(Object paramObject)
    throws TransactionException;
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.transaction.SavepointManager
 * JD-Core Version:    0.7.0.1
 */