/*   1:    */ package org.springframework.jca.work;
/*   2:    */ 
/*   3:    */ import javax.resource.spi.work.ExecutionContext;
/*   4:    */ import javax.resource.spi.work.Work;
/*   5:    */ import javax.resource.spi.work.WorkAdapter;
/*   6:    */ import javax.resource.spi.work.WorkCompletedException;
/*   7:    */ import javax.resource.spi.work.WorkEvent;
/*   8:    */ import javax.resource.spi.work.WorkException;
/*   9:    */ import javax.resource.spi.work.WorkListener;
/*  10:    */ import javax.resource.spi.work.WorkManager;
/*  11:    */ import javax.resource.spi.work.WorkRejectedException;
/*  12:    */ import org.springframework.core.task.AsyncTaskExecutor;
/*  13:    */ import org.springframework.core.task.SimpleAsyncTaskExecutor;
/*  14:    */ import org.springframework.core.task.SyncTaskExecutor;
/*  15:    */ import org.springframework.core.task.TaskExecutor;
/*  16:    */ import org.springframework.core.task.TaskRejectedException;
/*  17:    */ import org.springframework.core.task.TaskTimeoutException;
/*  18:    */ import org.springframework.util.Assert;
/*  19:    */ 
/*  20:    */ public class SimpleTaskWorkManager
/*  21:    */   implements WorkManager
/*  22:    */ {
/*  23:    */   private TaskExecutor syncTaskExecutor;
/*  24:    */   private AsyncTaskExecutor asyncTaskExecutor;
/*  25:    */   
/*  26:    */   public SimpleTaskWorkManager()
/*  27:    */   {
/*  28: 65 */     this.syncTaskExecutor = new SyncTaskExecutor();
/*  29:    */     
/*  30: 67 */     this.asyncTaskExecutor = new SimpleAsyncTaskExecutor();
/*  31:    */   }
/*  32:    */   
/*  33:    */   public void setSyncTaskExecutor(TaskExecutor syncTaskExecutor)
/*  34:    */   {
/*  35: 76 */     this.syncTaskExecutor = syncTaskExecutor;
/*  36:    */   }
/*  37:    */   
/*  38:    */   public void setAsyncTaskExecutor(AsyncTaskExecutor asyncTaskExecutor)
/*  39:    */   {
/*  40: 87 */     this.asyncTaskExecutor = asyncTaskExecutor;
/*  41:    */   }
/*  42:    */   
/*  43:    */   public void doWork(Work work)
/*  44:    */     throws WorkException
/*  45:    */   {
/*  46: 92 */     doWork(work, 9223372036854775807L, null, null);
/*  47:    */   }
/*  48:    */   
/*  49:    */   public void doWork(Work work, long startTimeout, ExecutionContext executionContext, WorkListener workListener)
/*  50:    */     throws WorkException
/*  51:    */   {
/*  52: 98 */     Assert.state(this.syncTaskExecutor != null, "No 'syncTaskExecutor' set");
/*  53: 99 */     executeWork(this.syncTaskExecutor, work, startTimeout, false, executionContext, workListener);
/*  54:    */   }
/*  55:    */   
/*  56:    */   public long startWork(Work work)
/*  57:    */     throws WorkException
/*  58:    */   {
/*  59:103 */     return startWork(work, 9223372036854775807L, null, null);
/*  60:    */   }
/*  61:    */   
/*  62:    */   public long startWork(Work work, long startTimeout, ExecutionContext executionContext, WorkListener workListener)
/*  63:    */     throws WorkException
/*  64:    */   {
/*  65:109 */     Assert.state(this.asyncTaskExecutor != null, "No 'asyncTaskExecutor' set");
/*  66:110 */     return executeWork(this.asyncTaskExecutor, work, startTimeout, true, executionContext, workListener);
/*  67:    */   }
/*  68:    */   
/*  69:    */   public void scheduleWork(Work work)
/*  70:    */     throws WorkException
/*  71:    */   {
/*  72:114 */     scheduleWork(work, 9223372036854775807L, null, null);
/*  73:    */   }
/*  74:    */   
/*  75:    */   public void scheduleWork(Work work, long startTimeout, ExecutionContext executionContext, WorkListener workListener)
/*  76:    */     throws WorkException
/*  77:    */   {
/*  78:120 */     Assert.state(this.asyncTaskExecutor != null, "No 'asyncTaskExecutor' set");
/*  79:121 */     executeWork(this.asyncTaskExecutor, work, startTimeout, false, executionContext, workListener);
/*  80:    */   }
/*  81:    */   
/*  82:    */   protected long executeWork(TaskExecutor taskExecutor, Work work, long startTimeout, boolean blockUntilStarted, ExecutionContext executionContext, WorkListener workListener)
/*  83:    */     throws WorkException
/*  84:    */   {
/*  85:141 */     if ((executionContext != null) && (executionContext.getXid() != null)) {
/*  86:142 */       throw new WorkException("SimpleTaskWorkManager does not supported imported XIDs: " + executionContext.getXid());
/*  87:    */     }
/*  88:144 */     WorkListener workListenerToUse = workListener;
/*  89:145 */     if (workListenerToUse == null) {
/*  90:146 */       workListenerToUse = new WorkAdapter();
/*  91:    */     }
/*  92:149 */     boolean isAsync = taskExecutor instanceof AsyncTaskExecutor;
/*  93:150 */     DelegatingWorkAdapter workHandle = new DelegatingWorkAdapter(work, workListenerToUse, !isAsync);
/*  94:    */     try
/*  95:    */     {
/*  96:152 */       if (isAsync) {
/*  97:153 */         ((AsyncTaskExecutor)taskExecutor).execute(workHandle, startTimeout);
/*  98:    */       } else {
/*  99:156 */         taskExecutor.execute(workHandle);
/* 100:    */       }
/* 101:    */     }
/* 102:    */     catch (TaskTimeoutException ex)
/* 103:    */     {
/* 104:160 */       WorkException wex = new WorkRejectedException("TaskExecutor rejected Work because of timeout: " + work, ex);
/* 105:161 */       wex.setErrorCode("1");
/* 106:162 */       workListenerToUse.workRejected(new WorkEvent(this, 2, work, wex));
/* 107:163 */       throw wex;
/* 108:    */     }
/* 109:    */     catch (TaskRejectedException ex)
/* 110:    */     {
/* 111:166 */       WorkException wex = new WorkRejectedException("TaskExecutor rejected Work: " + work, ex);
/* 112:167 */       wex.setErrorCode("-1");
/* 113:168 */       workListenerToUse.workRejected(new WorkEvent(this, 2, work, wex));
/* 114:169 */       throw wex;
/* 115:    */     }
/* 116:    */     catch (Throwable ex)
/* 117:    */     {
/* 118:172 */       WorkException wex = new WorkException("TaskExecutor failed to execute Work: " + work, ex);
/* 119:173 */       wex.setErrorCode("-1");
/* 120:174 */       throw wex;
/* 121:    */     }
/* 122:176 */     if (isAsync) {
/* 123:177 */       workListenerToUse.workAccepted(new WorkEvent(this, 1, work, null));
/* 124:    */     }
/* 125:180 */     if (blockUntilStarted)
/* 126:    */     {
/* 127:181 */       long acceptanceTime = System.currentTimeMillis();
/* 128:182 */       synchronized (workHandle.monitor)
/* 129:    */       {
/* 130:    */         try
/* 131:    */         {
/* 132:184 */           while (!workHandle.started) {
/* 133:185 */             workHandle.monitor.wait();
/* 134:    */           }
/* 135:    */         }
/* 136:    */         catch (InterruptedException ex)
/* 137:    */         {
/* 138:189 */           Thread.currentThread().interrupt();
/* 139:    */         }
/* 140:    */       }
/* 141:192 */       return System.currentTimeMillis() - acceptanceTime;
/* 142:    */     }
/* 143:195 */     return -1L;
/* 144:    */   }
/* 145:    */   
/* 146:    */   private static class DelegatingWorkAdapter
/* 147:    */     implements Work
/* 148:    */   {
/* 149:    */     private final Work work;
/* 150:    */     private final WorkListener workListener;
/* 151:    */     private final boolean acceptOnExecution;
/* 152:212 */     public final Object monitor = new Object();
/* 153:214 */     public boolean started = false;
/* 154:    */     
/* 155:    */     public DelegatingWorkAdapter(Work work, WorkListener workListener, boolean acceptOnExecution)
/* 156:    */     {
/* 157:217 */       this.work = work;
/* 158:218 */       this.workListener = workListener;
/* 159:219 */       this.acceptOnExecution = acceptOnExecution;
/* 160:    */     }
/* 161:    */     
/* 162:    */     public void run()
/* 163:    */     {
/* 164:223 */       if (this.acceptOnExecution) {
/* 165:224 */         this.workListener.workAccepted(new WorkEvent(this, 1, this.work, null));
/* 166:    */       }
/* 167:226 */       synchronized (this.monitor)
/* 168:    */       {
/* 169:227 */         this.started = true;
/* 170:228 */         this.monitor.notify();
/* 171:    */       }
/* 172:230 */       this.workListener.workStarted(new WorkEvent(this, 3, this.work, null));
/* 173:    */       try
/* 174:    */       {
/* 175:232 */         this.work.run();
/* 176:    */       }
/* 177:    */       catch (RuntimeException ex)
/* 178:    */       {
/* 179:235 */         this.workListener.workCompleted(new WorkEvent(this, 4, this.work, new WorkCompletedException(ex)));
/* 180:    */         
/* 181:237 */         throw ex;
/* 182:    */       }
/* 183:    */       catch (Error err)
/* 184:    */       {
/* 185:240 */         this.workListener.workCompleted(new WorkEvent(this, 4, this.work, new WorkCompletedException(err)));
/* 186:    */         
/* 187:242 */         throw err;
/* 188:    */       }
/* 189:244 */       this.workListener.workCompleted(new WorkEvent(this, 4, this.work, null));
/* 190:    */     }
/* 191:    */     
/* 192:    */     public void release()
/* 193:    */     {
/* 194:248 */       this.work.release();
/* 195:    */     }
/* 196:    */   }
/* 197:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jca.work.SimpleTaskWorkManager
 * JD-Core Version:    0.7.0.1
 */