/*   1:    */ package org.springframework.jca.work;
/*   2:    */ 
/*   3:    */ import java.util.concurrent.Callable;
/*   4:    */ import java.util.concurrent.Future;
/*   5:    */ import java.util.concurrent.FutureTask;
/*   6:    */ import javax.naming.NamingException;
/*   7:    */ import javax.resource.spi.BootstrapContext;
/*   8:    */ import javax.resource.spi.work.ExecutionContext;
/*   9:    */ import javax.resource.spi.work.Work;
/*  10:    */ import javax.resource.spi.work.WorkException;
/*  11:    */ import javax.resource.spi.work.WorkListener;
/*  12:    */ import javax.resource.spi.work.WorkManager;
/*  13:    */ import javax.resource.spi.work.WorkRejectedException;
/*  14:    */ import org.springframework.beans.factory.InitializingBean;
/*  15:    */ import org.springframework.core.task.TaskRejectedException;
/*  16:    */ import org.springframework.core.task.TaskTimeoutException;
/*  17:    */ import org.springframework.jca.context.BootstrapContextAware;
/*  18:    */ import org.springframework.jndi.JndiLocatorSupport;
/*  19:    */ import org.springframework.scheduling.SchedulingException;
/*  20:    */ import org.springframework.scheduling.SchedulingTaskExecutor;
/*  21:    */ import org.springframework.util.Assert;
/*  22:    */ 
/*  23:    */ public class WorkManagerTaskExecutor
/*  24:    */   extends JndiLocatorSupport
/*  25:    */   implements SchedulingTaskExecutor, WorkManager, BootstrapContextAware, InitializingBean
/*  26:    */ {
/*  27:    */   private WorkManager workManager;
/*  28:    */   private String workManagerName;
/*  29: 79 */   private boolean blockUntilStarted = false;
/*  30: 81 */   private boolean blockUntilCompleted = false;
/*  31:    */   private WorkListener workListener;
/*  32:    */   
/*  33:    */   public WorkManagerTaskExecutor() {}
/*  34:    */   
/*  35:    */   public WorkManagerTaskExecutor(WorkManager workManager)
/*  36:    */   {
/*  37: 98 */     setWorkManager(workManager);
/*  38:    */   }
/*  39:    */   
/*  40:    */   public void setWorkManager(WorkManager workManager)
/*  41:    */   {
/*  42:106 */     Assert.notNull(workManager, "WorkManager must not be null");
/*  43:107 */     this.workManager = workManager;
/*  44:    */   }
/*  45:    */   
/*  46:    */   public void setWorkManagerName(String workManagerName)
/*  47:    */   {
/*  48:119 */     this.workManagerName = workManagerName;
/*  49:    */   }
/*  50:    */   
/*  51:    */   public void setBootstrapContext(BootstrapContext bootstrapContext)
/*  52:    */   {
/*  53:127 */     Assert.notNull(bootstrapContext, "BootstrapContext must not be null");
/*  54:128 */     this.workManager = bootstrapContext.getWorkManager();
/*  55:    */   }
/*  56:    */   
/*  57:    */   public void setBlockUntilStarted(boolean blockUntilStarted)
/*  58:    */   {
/*  59:140 */     this.blockUntilStarted = blockUntilStarted;
/*  60:    */   }
/*  61:    */   
/*  62:    */   public void setBlockUntilCompleted(boolean blockUntilCompleted)
/*  63:    */   {
/*  64:152 */     this.blockUntilCompleted = blockUntilCompleted;
/*  65:    */   }
/*  66:    */   
/*  67:    */   public void setWorkListener(WorkListener workListener)
/*  68:    */   {
/*  69:161 */     this.workListener = workListener;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public void afterPropertiesSet()
/*  73:    */     throws NamingException
/*  74:    */   {
/*  75:165 */     if (this.workManager == null) {
/*  76:166 */       if (this.workManagerName != null) {
/*  77:167 */         this.workManager = ((WorkManager)lookup(this.workManagerName, WorkManager.class));
/*  78:    */       } else {
/*  79:170 */         this.workManager = getDefaultWorkManager();
/*  80:    */       }
/*  81:    */     }
/*  82:    */   }
/*  83:    */   
/*  84:    */   protected WorkManager getDefaultWorkManager()
/*  85:    */   {
/*  86:182 */     return new SimpleTaskWorkManager();
/*  87:    */   }
/*  88:    */   
/*  89:    */   public void execute(Runnable task)
/*  90:    */   {
/*  91:191 */     execute(task, 9223372036854775807L);
/*  92:    */   }
/*  93:    */   
/*  94:    */   public void execute(Runnable task, long startTimeout)
/*  95:    */   {
/*  96:195 */     Assert.state(this.workManager != null, "No WorkManager specified");
/*  97:196 */     Work work = new DelegatingWork(task);
/*  98:    */     try
/*  99:    */     {
/* 100:198 */       if (this.blockUntilCompleted)
/* 101:    */       {
/* 102:199 */         if ((startTimeout != 9223372036854775807L) || (this.workListener != null)) {
/* 103:200 */           this.workManager.doWork(work, startTimeout, null, this.workListener);
/* 104:    */         } else {
/* 105:203 */           this.workManager.doWork(work);
/* 106:    */         }
/* 107:    */       }
/* 108:206 */       else if (this.blockUntilStarted)
/* 109:    */       {
/* 110:207 */         if ((startTimeout != 9223372036854775807L) || (this.workListener != null)) {
/* 111:208 */           this.workManager.startWork(work, startTimeout, null, this.workListener);
/* 112:    */         } else {
/* 113:211 */           this.workManager.startWork(work);
/* 114:    */         }
/* 115:    */       }
/* 116:215 */       else if ((startTimeout != 9223372036854775807L) || (this.workListener != null)) {
/* 117:216 */         this.workManager.scheduleWork(work, startTimeout, null, this.workListener);
/* 118:    */       } else {
/* 119:219 */         this.workManager.scheduleWork(work);
/* 120:    */       }
/* 121:    */     }
/* 122:    */     catch (WorkRejectedException ex)
/* 123:    */     {
/* 124:224 */       if ("1".equals(ex.getErrorCode())) {
/* 125:225 */         throw new TaskTimeoutException("JCA WorkManager rejected task because of timeout: " + task, ex);
/* 126:    */       }
/* 127:228 */       throw new TaskRejectedException("JCA WorkManager rejected task: " + task, ex);
/* 128:    */     }
/* 129:    */     catch (WorkException ex)
/* 130:    */     {
/* 131:232 */       throw new SchedulingException("Could not schedule task on JCA WorkManager", ex);
/* 132:    */     }
/* 133:    */   }
/* 134:    */   
/* 135:    */   public Future<?> submit(Runnable task)
/* 136:    */   {
/* 137:237 */     FutureTask<Object> future = new FutureTask(task, null);
/* 138:238 */     execute(future, 9223372036854775807L);
/* 139:239 */     return future;
/* 140:    */   }
/* 141:    */   
/* 142:    */   public <T> Future<T> submit(Callable<T> task)
/* 143:    */   {
/* 144:243 */     FutureTask<T> future = new FutureTask(task);
/* 145:244 */     execute(future, 9223372036854775807L);
/* 146:245 */     return future;
/* 147:    */   }
/* 148:    */   
/* 149:    */   public boolean prefersShortLivedTasks()
/* 150:    */   {
/* 151:252 */     return true;
/* 152:    */   }
/* 153:    */   
/* 154:    */   public void doWork(Work work)
/* 155:    */     throws WorkException
/* 156:    */   {
/* 157:261 */     this.workManager.doWork(work);
/* 158:    */   }
/* 159:    */   
/* 160:    */   public void doWork(Work work, long delay, ExecutionContext executionContext, WorkListener workListener)
/* 161:    */     throws WorkException
/* 162:    */   {
/* 163:267 */     this.workManager.doWork(work, delay, executionContext, workListener);
/* 164:    */   }
/* 165:    */   
/* 166:    */   public long startWork(Work work)
/* 167:    */     throws WorkException
/* 168:    */   {
/* 169:271 */     return this.workManager.startWork(work);
/* 170:    */   }
/* 171:    */   
/* 172:    */   public long startWork(Work work, long delay, ExecutionContext executionContext, WorkListener workListener)
/* 173:    */     throws WorkException
/* 174:    */   {
/* 175:277 */     return this.workManager.startWork(work, delay, executionContext, workListener);
/* 176:    */   }
/* 177:    */   
/* 178:    */   public void scheduleWork(Work work)
/* 179:    */     throws WorkException
/* 180:    */   {
/* 181:281 */     this.workManager.scheduleWork(work);
/* 182:    */   }
/* 183:    */   
/* 184:    */   public void scheduleWork(Work work, long delay, ExecutionContext executionContext, WorkListener workListener)
/* 185:    */     throws WorkException
/* 186:    */   {
/* 187:287 */     this.workManager.scheduleWork(work, delay, executionContext, workListener);
/* 188:    */   }
/* 189:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jca.work.WorkManagerTaskExecutor
 * JD-Core Version:    0.7.0.1
 */