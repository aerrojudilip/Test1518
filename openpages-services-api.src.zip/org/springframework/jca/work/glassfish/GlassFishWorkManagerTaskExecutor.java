/*  1:   */ package org.springframework.jca.work.glassfish;
/*  2:   */ 
/*  3:   */ import java.lang.reflect.Method;
/*  4:   */ import javax.resource.spi.work.WorkManager;
/*  5:   */ import org.springframework.jca.work.WorkManagerTaskExecutor;
/*  6:   */ import org.springframework.util.ReflectionUtils;
/*  7:   */ 
/*  8:   */ public class GlassFishWorkManagerTaskExecutor
/*  9:   */   extends WorkManagerTaskExecutor
/* 10:   */ {
/* 11:   */   private static final String WORK_MANAGER_FACTORY_CLASS = "com.sun.enterprise.connectors.work.WorkManagerFactory";
/* 12:   */   private final Method getWorkManagerMethod;
/* 13:   */   
/* 14:   */   public GlassFishWorkManagerTaskExecutor()
/* 15:   */   {
/* 16:   */     try
/* 17:   */     {
/* 18:46 */       Class wmf = getClass().getClassLoader().loadClass("com.sun.enterprise.connectors.work.WorkManagerFactory");
/* 19:47 */       this.getWorkManagerMethod = wmf.getMethod("getWorkManager", new Class[] { String.class });
/* 20:   */     }
/* 21:   */     catch (Exception ex)
/* 22:   */     {
/* 23:50 */       throw new IllegalStateException("Could not initialize GlassFishWorkManagerTaskExecutor because GlassFish API is not available: " + ex);
/* 24:   */     }
/* 25:   */   }
/* 26:   */   
/* 27:   */   public void setThreadPoolName(String threadPoolName)
/* 28:   */   {
/* 29:61 */     WorkManager wm = (WorkManager)ReflectionUtils.invokeMethod(this.getWorkManagerMethod, null, new Object[] { threadPoolName });
/* 30:62 */     if (wm == null) {
/* 31:63 */       throw new IllegalArgumentException("Specified thread pool name '" + threadPoolName + "' does not correspond to an actual pool definition in GlassFish. Check your configuration!");
/* 32:   */     }
/* 33:66 */     setWorkManager(wm);
/* 34:   */   }
/* 35:   */   
/* 36:   */   protected WorkManager getDefaultWorkManager()
/* 37:   */   {
/* 38:74 */     return (WorkManager)ReflectionUtils.invokeMethod(this.getWorkManagerMethod, null, new Object[] { null });
/* 39:   */   }
/* 40:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jca.work.glassfish.GlassFishWorkManagerTaskExecutor
 * JD-Core Version:    0.7.0.1
 */