/*  1:   */ package org.springframework.jca.cci;
/*  2:   */ 
/*  3:   */ import javax.resource.ResourceException;
/*  4:   */ import org.springframework.dao.DataAccessResourceFailureException;
/*  5:   */ 
/*  6:   */ public class CannotGetCciConnectionException
/*  7:   */   extends DataAccessResourceFailureException
/*  8:   */ {
/*  9:   */   public CannotGetCciConnectionException(String msg, ResourceException ex)
/* 10:   */   {
/* 11:38 */     super(msg, ex);
/* 12:   */   }
/* 13:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jca.cci.CannotGetCciConnectionException
 * JD-Core Version:    0.7.0.1
 */