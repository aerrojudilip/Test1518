package org.springframework.jca.cci.core;

import javax.resource.ResourceException;
import javax.resource.cci.Record;
import javax.resource.cci.RecordFactory;
import org.springframework.dao.DataAccessException;

public abstract interface RecordCreator
{
  public abstract Record createRecord(RecordFactory paramRecordFactory)
    throws ResourceException, DataAccessException;
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jca.cci.core.RecordCreator
 * JD-Core Version:    0.7.0.1
 */