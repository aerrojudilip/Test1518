package org.springframework.jca.cci.core;

import java.sql.SQLException;
import javax.resource.ResourceException;
import javax.resource.cci.Record;
import org.springframework.dao.DataAccessException;

public abstract interface RecordExtractor<T>
{
  public abstract T extractData(Record paramRecord)
    throws ResourceException, SQLException, DataAccessException;
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jca.cci.core.RecordExtractor
 * JD-Core Version:    0.7.0.1
 */