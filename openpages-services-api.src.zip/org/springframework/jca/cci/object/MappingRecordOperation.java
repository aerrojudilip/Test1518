/*   1:    */ package org.springframework.jca.cci.object;
/*   2:    */ 
/*   3:    */ import java.sql.SQLException;
/*   4:    */ import javax.resource.ResourceException;
/*   5:    */ import javax.resource.cci.ConnectionFactory;
/*   6:    */ import javax.resource.cci.InteractionSpec;
/*   7:    */ import javax.resource.cci.Record;
/*   8:    */ import javax.resource.cci.RecordFactory;
/*   9:    */ import org.springframework.dao.DataAccessException;
/*  10:    */ import org.springframework.jca.cci.core.CciTemplate;
/*  11:    */ import org.springframework.jca.cci.core.RecordCreator;
/*  12:    */ import org.springframework.jca.cci.core.RecordExtractor;
/*  13:    */ 
/*  14:    */ public abstract class MappingRecordOperation
/*  15:    */   extends EisOperation
/*  16:    */ {
/*  17:    */   public MappingRecordOperation() {}
/*  18:    */   
/*  19:    */   public MappingRecordOperation(ConnectionFactory connectionFactory, InteractionSpec interactionSpec)
/*  20:    */   {
/*  21: 61 */     getCciTemplate().setConnectionFactory(connectionFactory);
/*  22: 62 */     setInteractionSpec(interactionSpec);
/*  23:    */   }
/*  24:    */   
/*  25:    */   public void setOutputRecordCreator(RecordCreator creator)
/*  26:    */   {
/*  27: 77 */     getCciTemplate().setOutputRecordCreator(creator);
/*  28:    */   }
/*  29:    */   
/*  30:    */   public Object execute(Object inputObject)
/*  31:    */     throws DataAccessException
/*  32:    */   {
/*  33: 90 */     return getCciTemplate().execute(getInteractionSpec(), new RecordCreatorImpl(inputObject), new RecordExtractorImpl());
/*  34:    */   }
/*  35:    */   
/*  36:    */   protected abstract Record createInputRecord(RecordFactory paramRecordFactory, Object paramObject)
/*  37:    */     throws ResourceException, DataAccessException;
/*  38:    */   
/*  39:    */   protected abstract Object extractOutputData(Record paramRecord)
/*  40:    */     throws ResourceException, SQLException, DataAccessException;
/*  41:    */   
/*  42:    */   protected class RecordCreatorImpl
/*  43:    */     implements RecordCreator
/*  44:    */   {
/*  45:    */     private final Object inputObject;
/*  46:    */     
/*  47:    */     public RecordCreatorImpl(Object inObject)
/*  48:    */     {
/*  49:129 */       this.inputObject = inObject;
/*  50:    */     }
/*  51:    */     
/*  52:    */     public Record createRecord(RecordFactory recordFactory)
/*  53:    */       throws ResourceException, DataAccessException
/*  54:    */     {
/*  55:133 */       return MappingRecordOperation.this.createInputRecord(recordFactory, this.inputObject);
/*  56:    */     }
/*  57:    */   }
/*  58:    */   
/*  59:    */   protected class RecordExtractorImpl
/*  60:    */     implements RecordExtractor
/*  61:    */   {
/*  62:    */     protected RecordExtractorImpl() {}
/*  63:    */     
/*  64:    */     public Object extractData(Record record)
/*  65:    */       throws ResourceException, SQLException, DataAccessException
/*  66:    */     {
/*  67:145 */       return MappingRecordOperation.this.extractOutputData(record);
/*  68:    */     }
/*  69:    */   }
/*  70:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jca.cci.object.MappingRecordOperation
 * JD-Core Version:    0.7.0.1
 */