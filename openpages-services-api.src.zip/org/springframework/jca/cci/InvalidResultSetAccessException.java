/*  1:   */ package org.springframework.jca.cci;
/*  2:   */ 
/*  3:   */ import java.sql.SQLException;
/*  4:   */ import org.springframework.dao.InvalidDataAccessResourceUsageException;
/*  5:   */ 
/*  6:   */ public class InvalidResultSetAccessException
/*  7:   */   extends InvalidDataAccessResourceUsageException
/*  8:   */ {
/*  9:   */   public InvalidResultSetAccessException(String msg, SQLException ex)
/* 10:   */   {
/* 11:42 */     super(ex.getMessage(), ex);
/* 12:   */   }
/* 13:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jca.cci.InvalidResultSetAccessException
 * JD-Core Version:    0.7.0.1
 */