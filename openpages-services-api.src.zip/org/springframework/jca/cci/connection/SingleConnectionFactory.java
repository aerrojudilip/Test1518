/*   1:    */ package org.springframework.jca.cci.connection;
/*   2:    */ 
/*   3:    */ import java.lang.reflect.InvocationHandler;
/*   4:    */ import java.lang.reflect.InvocationTargetException;
/*   5:    */ import java.lang.reflect.Method;
/*   6:    */ import java.lang.reflect.Proxy;
/*   7:    */ import javax.resource.NotSupportedException;
/*   8:    */ import javax.resource.ResourceException;
/*   9:    */ import javax.resource.cci.Connection;
/*  10:    */ import javax.resource.cci.ConnectionFactory;
/*  11:    */ import javax.resource.cci.ConnectionSpec;
/*  12:    */ import org.apache.commons.logging.Log;
/*  13:    */ import org.apache.commons.logging.LogFactory;
/*  14:    */ import org.springframework.beans.factory.DisposableBean;
/*  15:    */ import org.springframework.util.Assert;
/*  16:    */ 
/*  17:    */ public class SingleConnectionFactory
/*  18:    */   extends DelegatingConnectionFactory
/*  19:    */   implements DisposableBean
/*  20:    */ {
/*  21: 56 */   protected final Log logger = LogFactory.getLog(getClass());
/*  22:    */   private Connection target;
/*  23:    */   private Connection connection;
/*  24: 65 */   private final Object connectionMonitor = new Object();
/*  25:    */   
/*  26:    */   public SingleConnectionFactory() {}
/*  27:    */   
/*  28:    */   public SingleConnectionFactory(Connection target)
/*  29:    */   {
/*  30: 81 */     Assert.notNull(target, "Target Connection must not be null");
/*  31: 82 */     this.target = target;
/*  32: 83 */     this.connection = getCloseSuppressingConnectionProxy(target);
/*  33:    */   }
/*  34:    */   
/*  35:    */   public SingleConnectionFactory(ConnectionFactory targetConnectionFactory)
/*  36:    */   {
/*  37: 93 */     Assert.notNull(targetConnectionFactory, "Target ConnectionFactory must not be null");
/*  38: 94 */     setTargetConnectionFactory(targetConnectionFactory);
/*  39:    */   }
/*  40:    */   
/*  41:    */   public void afterPropertiesSet()
/*  42:    */   {
/*  43:103 */     if ((this.connection == null) && (getTargetConnectionFactory() == null)) {
/*  44:104 */       throw new IllegalArgumentException("Connection or 'targetConnectionFactory' is required");
/*  45:    */     }
/*  46:    */   }
/*  47:    */   
/*  48:    */   public Connection getConnection()
/*  49:    */     throws ResourceException
/*  50:    */   {
/*  51:111 */     synchronized (this.connectionMonitor)
/*  52:    */     {
/*  53:112 */       if (this.connection == null) {
/*  54:113 */         initConnection();
/*  55:    */       }
/*  56:115 */       return this.connection;
/*  57:    */     }
/*  58:    */   }
/*  59:    */   
/*  60:    */   public Connection getConnection(ConnectionSpec connectionSpec)
/*  61:    */     throws ResourceException
/*  62:    */   {
/*  63:121 */     throw new NotSupportedException("SingleConnectionFactory does not support custom ConnectionSpec");
/*  64:    */   }
/*  65:    */   
/*  66:    */   public void destroy()
/*  67:    */   {
/*  68:132 */     resetConnection();
/*  69:    */   }
/*  70:    */   
/*  71:    */   public void initConnection()
/*  72:    */     throws ResourceException
/*  73:    */   {
/*  74:143 */     if (getTargetConnectionFactory() == null) {
/*  75:144 */       throw new IllegalStateException("'targetConnectionFactory' is required for lazily initializing a Connection");
/*  76:    */     }
/*  77:147 */     synchronized (this.connectionMonitor)
/*  78:    */     {
/*  79:148 */       if (this.target != null) {
/*  80:149 */         closeConnection(this.target);
/*  81:    */       }
/*  82:151 */       this.target = doCreateConnection();
/*  83:152 */       prepareConnection(this.target);
/*  84:153 */       if (this.logger.isInfoEnabled()) {
/*  85:154 */         this.logger.info("Established shared CCI Connection: " + this.target);
/*  86:    */       }
/*  87:156 */       this.connection = getCloseSuppressingConnectionProxy(this.target);
/*  88:    */     }
/*  89:    */   }
/*  90:    */   
/*  91:    */   public void resetConnection()
/*  92:    */   {
/*  93:164 */     synchronized (this.connectionMonitor)
/*  94:    */     {
/*  95:165 */       if (this.target != null) {
/*  96:166 */         closeConnection(this.target);
/*  97:    */       }
/*  98:168 */       this.target = null;
/*  99:169 */       this.connection = null;
/* 100:    */     }
/* 101:    */   }
/* 102:    */   
/* 103:    */   protected Connection doCreateConnection()
/* 104:    */     throws ResourceException
/* 105:    */   {
/* 106:179 */     return getTargetConnectionFactory().getConnection();
/* 107:    */   }
/* 108:    */   
/* 109:    */   protected void prepareConnection(Connection con)
/* 110:    */     throws ResourceException
/* 111:    */   {}
/* 112:    */   
/* 113:    */   protected void closeConnection(Connection con)
/* 114:    */   {
/* 115:    */     try
/* 116:    */     {
/* 117:196 */       con.close();
/* 118:    */     }
/* 119:    */     catch (Throwable ex)
/* 120:    */     {
/* 121:199 */       this.logger.warn("Could not close shared CCI Connection", ex);
/* 122:    */     }
/* 123:    */   }
/* 124:    */   
/* 125:    */   protected Connection getCloseSuppressingConnectionProxy(Connection target)
/* 126:    */   {
/* 127:212 */     return (Connection)Proxy.newProxyInstance(Connection.class.getClassLoader(), new Class[] { Connection.class }, new CloseSuppressingInvocationHandler(target, null));
/* 128:    */   }
/* 129:    */   
/* 130:    */   private static class CloseSuppressingInvocationHandler
/* 131:    */     implements InvocationHandler
/* 132:    */   {
/* 133:    */     private final Connection target;
/* 134:    */     
/* 135:    */     private CloseSuppressingInvocationHandler(Connection target)
/* 136:    */     {
/* 137:227 */       this.target = target;
/* 138:    */     }
/* 139:    */     
/* 140:    */     public Object invoke(Object proxy, Method method, Object[] args)
/* 141:    */       throws Throwable
/* 142:    */     {
/* 143:231 */       if (method.getName().equals("equals")) {
/* 144:233 */         return Boolean.valueOf(proxy == args[0]);
/* 145:    */       }
/* 146:235 */       if (method.getName().equals("hashCode")) {
/* 147:237 */         return Integer.valueOf(System.identityHashCode(proxy));
/* 148:    */       }
/* 149:239 */       if (method.getName().equals("close")) {
/* 150:241 */         return null;
/* 151:    */       }
/* 152:    */       try
/* 153:    */       {
/* 154:244 */         return method.invoke(this.target, args);
/* 155:    */       }
/* 156:    */       catch (InvocationTargetException ex)
/* 157:    */       {
/* 158:247 */         throw ex.getTargetException();
/* 159:    */       }
/* 160:    */     }
/* 161:    */   }
/* 162:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jca.cci.connection.SingleConnectionFactory
 * JD-Core Version:    0.7.0.1
 */