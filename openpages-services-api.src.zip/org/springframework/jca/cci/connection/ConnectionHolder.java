/*  1:   */ package org.springframework.jca.cci.connection;
/*  2:   */ 
/*  3:   */ import javax.resource.cci.Connection;
/*  4:   */ import org.springframework.transaction.support.ResourceHolderSupport;
/*  5:   */ 
/*  6:   */ public class ConnectionHolder
/*  7:   */   extends ResourceHolderSupport
/*  8:   */ {
/*  9:   */   private final Connection connection;
/* 10:   */   
/* 11:   */   public ConnectionHolder(Connection connection)
/* 12:   */   {
/* 13:42 */     this.connection = connection;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public Connection getConnection()
/* 17:   */   {
/* 18:46 */     return this.connection;
/* 19:   */   }
/* 20:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jca.cci.connection.ConnectionHolder
 * JD-Core Version:    0.7.0.1
 */