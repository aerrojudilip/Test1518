/*   1:    */ package org.springframework.jca.cci.connection;
/*   2:    */ 
/*   3:    */ import java.lang.reflect.InvocationHandler;
/*   4:    */ import java.lang.reflect.InvocationTargetException;
/*   5:    */ import java.lang.reflect.Method;
/*   6:    */ import java.lang.reflect.Proxy;
/*   7:    */ import javax.resource.ResourceException;
/*   8:    */ import javax.resource.cci.Connection;
/*   9:    */ import javax.resource.cci.ConnectionFactory;
/*  10:    */ import javax.resource.spi.IllegalStateException;
/*  11:    */ 
/*  12:    */ public class TransactionAwareConnectionFactoryProxy
/*  13:    */   extends DelegatingConnectionFactory
/*  14:    */ {
/*  15:    */   public TransactionAwareConnectionFactoryProxy() {}
/*  16:    */   
/*  17:    */   public TransactionAwareConnectionFactoryProxy(ConnectionFactory targetConnectionFactory)
/*  18:    */   {
/*  19: 81 */     setTargetConnectionFactory(targetConnectionFactory);
/*  20: 82 */     afterPropertiesSet();
/*  21:    */   }
/*  22:    */   
/*  23:    */   public Connection getConnection()
/*  24:    */     throws ResourceException
/*  25:    */   {
/*  26: 94 */     Connection con = ConnectionFactoryUtils.doGetConnection(getTargetConnectionFactory());
/*  27: 95 */     return getTransactionAwareConnectionProxy(con, getTargetConnectionFactory());
/*  28:    */   }
/*  29:    */   
/*  30:    */   protected Connection getTransactionAwareConnectionProxy(Connection target, ConnectionFactory cf)
/*  31:    */   {
/*  32:108 */     return (Connection)Proxy.newProxyInstance(Connection.class.getClassLoader(), new Class[] { Connection.class }, new TransactionAwareInvocationHandler(target, cf));
/*  33:    */   }
/*  34:    */   
/*  35:    */   private static class TransactionAwareInvocationHandler
/*  36:    */     implements InvocationHandler
/*  37:    */   {
/*  38:    */     private final Connection target;
/*  39:    */     private final ConnectionFactory connectionFactory;
/*  40:    */     
/*  41:    */     public TransactionAwareInvocationHandler(Connection target, ConnectionFactory cf)
/*  42:    */     {
/*  43:126 */       this.target = target;
/*  44:127 */       this.connectionFactory = cf;
/*  45:    */     }
/*  46:    */     
/*  47:    */     public Object invoke(Object proxy, Method method, Object[] args)
/*  48:    */       throws Throwable
/*  49:    */     {
/*  50:133 */       if (method.getName().equals("equals")) {
/*  51:135 */         return Boolean.valueOf(proxy == args[0]);
/*  52:    */       }
/*  53:137 */       if (method.getName().equals("hashCode")) {
/*  54:139 */         return Integer.valueOf(System.identityHashCode(proxy));
/*  55:    */       }
/*  56:141 */       if (method.getName().equals("getLocalTransaction"))
/*  57:    */       {
/*  58:142 */         if (ConnectionFactoryUtils.isConnectionTransactional(this.target, this.connectionFactory)) {
/*  59:143 */           throw new IllegalStateException("Local transaction handling not allowed within a managed transaction");
/*  60:    */         }
/*  61:    */       }
/*  62:147 */       else if (method.getName().equals("close"))
/*  63:    */       {
/*  64:149 */         ConnectionFactoryUtils.doReleaseConnection(this.target, this.connectionFactory);
/*  65:150 */         return null;
/*  66:    */       }
/*  67:    */       try
/*  68:    */       {
/*  69:155 */         return method.invoke(this.target, args);
/*  70:    */       }
/*  71:    */       catch (InvocationTargetException ex)
/*  72:    */       {
/*  73:158 */         throw ex.getTargetException();
/*  74:    */       }
/*  75:    */     }
/*  76:    */   }
/*  77:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jca.cci.connection.TransactionAwareConnectionFactoryProxy
 * JD-Core Version:    0.7.0.1
 */