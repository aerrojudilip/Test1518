/*   1:    */ package org.springframework.jca.endpoint;
/*   2:    */ 
/*   3:    */ import java.lang.reflect.Method;
/*   4:    */ import javax.resource.ResourceException;
/*   5:    */ import javax.resource.spi.ApplicationServerInternalException;
/*   6:    */ import javax.resource.spi.UnavailableException;
/*   7:    */ import javax.resource.spi.endpoint.MessageEndpoint;
/*   8:    */ import javax.resource.spi.endpoint.MessageEndpointFactory;
/*   9:    */ import javax.transaction.Transaction;
/*  10:    */ import javax.transaction.TransactionManager;
/*  11:    */ import javax.transaction.xa.XAResource;
/*  12:    */ import org.apache.commons.logging.Log;
/*  13:    */ import org.apache.commons.logging.LogFactory;
/*  14:    */ import org.springframework.transaction.jta.SimpleTransactionFactory;
/*  15:    */ import org.springframework.transaction.jta.TransactionFactory;
/*  16:    */ 
/*  17:    */ public abstract class AbstractMessageEndpointFactory
/*  18:    */   implements MessageEndpointFactory
/*  19:    */ {
/*  20:    */   protected final Log logger;
/*  21:    */   private TransactionFactory transactionFactory;
/*  22:    */   private String transactionName;
/*  23:    */   private int transactionTimeout;
/*  24:    */   
/*  25:    */   public AbstractMessageEndpointFactory()
/*  26:    */   {
/*  27: 48 */     this.logger = LogFactory.getLog(getClass());
/*  28:    */     
/*  29:    */ 
/*  30:    */ 
/*  31:    */ 
/*  32:    */ 
/*  33: 54 */     this.transactionTimeout = -1;
/*  34:    */   }
/*  35:    */   
/*  36:    */   public void setTransactionManager(Object transactionManager)
/*  37:    */   {
/*  38: 71 */     if ((transactionManager instanceof TransactionFactory)) {
/*  39: 72 */       this.transactionFactory = ((TransactionFactory)transactionManager);
/*  40: 74 */     } else if ((transactionManager instanceof TransactionManager)) {
/*  41: 75 */       this.transactionFactory = new SimpleTransactionFactory((TransactionManager)transactionManager);
/*  42:    */     } else {
/*  43: 78 */       throw new IllegalArgumentException("Transaction manager [" + transactionManager + "] is neither a [org.springframework.transaction.jta.TransactionFactory} nor a " + "[javax.transaction.TransactionManager]");
/*  44:    */     }
/*  45:    */   }
/*  46:    */   
/*  47:    */   public void setTransactionFactory(TransactionFactory transactionFactory)
/*  48:    */   {
/*  49: 97 */     this.transactionFactory = transactionFactory;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public void setTransactionName(String transactionName)
/*  53:    */   {
/*  54:106 */     this.transactionName = transactionName;
/*  55:    */   }
/*  56:    */   
/*  57:    */   public void setTransactionTimeout(int transactionTimeout)
/*  58:    */   {
/*  59:116 */     this.transactionTimeout = transactionTimeout;
/*  60:    */   }
/*  61:    */   
/*  62:    */   public boolean isDeliveryTransacted(Method method)
/*  63:    */     throws NoSuchMethodException
/*  64:    */   {
/*  65:127 */     return this.transactionFactory != null;
/*  66:    */   }
/*  67:    */   
/*  68:    */   public MessageEndpoint createEndpoint(XAResource xaResource)
/*  69:    */     throws UnavailableException
/*  70:    */   {
/*  71:136 */     AbstractMessageEndpoint endpoint = createEndpointInternal();
/*  72:137 */     endpoint.initXAResource(xaResource);
/*  73:138 */     return endpoint;
/*  74:    */   }
/*  75:    */   
/*  76:    */   public MessageEndpoint createEndpoint(XAResource xaResource, long timeout)
/*  77:    */     throws UnavailableException
/*  78:    */   {
/*  79:147 */     AbstractMessageEndpoint endpoint = createEndpointInternal();
/*  80:148 */     endpoint.initXAResource(xaResource);
/*  81:149 */     return endpoint;
/*  82:    */   }
/*  83:    */   
/*  84:    */   protected abstract AbstractMessageEndpoint createEndpointInternal()
/*  85:    */     throws UnavailableException;
/*  86:    */   
/*  87:    */   protected abstract class AbstractMessageEndpoint
/*  88:    */     implements MessageEndpoint
/*  89:    */   {
/*  90:    */     private AbstractMessageEndpointFactory.TransactionDelegate transactionDelegate;
/*  91:170 */     private boolean beforeDeliveryCalled = false;
/*  92:    */     private ClassLoader previousContextClassLoader;
/*  93:    */     
/*  94:    */     protected AbstractMessageEndpoint() {}
/*  95:    */     
/*  96:    */     void initXAResource(XAResource xaResource)
/*  97:    */     {
/*  98:179 */       this.transactionDelegate = new AbstractMessageEndpointFactory.TransactionDelegate(AbstractMessageEndpointFactory.this, xaResource);
/*  99:    */     }
/* 100:    */     
/* 101:    */     public void beforeDelivery(Method method)
/* 102:    */       throws ResourceException
/* 103:    */     {
/* 104:193 */       this.beforeDeliveryCalled = true;
/* 105:    */       try
/* 106:    */       {
/* 107:195 */         this.transactionDelegate.beginTransaction();
/* 108:    */       }
/* 109:    */       catch (Throwable ex)
/* 110:    */       {
/* 111:198 */         throw new ApplicationServerInternalException("Failed to begin transaction", ex);
/* 112:    */       }
/* 113:200 */       Thread currentThread = Thread.currentThread();
/* 114:201 */       this.previousContextClassLoader = currentThread.getContextClassLoader();
/* 115:202 */       currentThread.setContextClassLoader(getEndpointClassLoader());
/* 116:    */     }
/* 117:    */     
/* 118:    */     protected abstract ClassLoader getEndpointClassLoader();
/* 119:    */     
/* 120:    */     protected final boolean hasBeforeDeliveryBeenCalled()
/* 121:    */     {
/* 122:218 */       return this.beforeDeliveryCalled;
/* 123:    */     }
/* 124:    */     
/* 125:    */     protected final void onEndpointException(Throwable ex)
/* 126:    */     {
/* 127:229 */       this.transactionDelegate.setRollbackOnly();
/* 128:    */     }
/* 129:    */     
/* 130:    */     public void afterDelivery()
/* 131:    */       throws ResourceException
/* 132:    */     {
/* 133:240 */       this.beforeDeliveryCalled = false;
/* 134:241 */       Thread.currentThread().setContextClassLoader(this.previousContextClassLoader);
/* 135:242 */       this.previousContextClassLoader = null;
/* 136:    */       try
/* 137:    */       {
/* 138:244 */         this.transactionDelegate.endTransaction();
/* 139:    */       }
/* 140:    */       catch (Throwable ex)
/* 141:    */       {
/* 142:247 */         throw new ApplicationServerInternalException("Failed to complete transaction", ex);
/* 143:    */       }
/* 144:    */     }
/* 145:    */     
/* 146:    */     public void release()
/* 147:    */     {
/* 148:    */       try
/* 149:    */       {
/* 150:253 */         this.transactionDelegate.setRollbackOnly();
/* 151:254 */         this.transactionDelegate.endTransaction();
/* 152:    */       }
/* 153:    */       catch (Throwable ex)
/* 154:    */       {
/* 155:257 */         AbstractMessageEndpointFactory.this.logger.error("Could not complete unfinished transaction on endpoint release", ex);
/* 156:    */       }
/* 157:    */     }
/* 158:    */   }
/* 159:    */   
/* 160:    */   private class TransactionDelegate
/* 161:    */   {
/* 162:    */     private final XAResource xaResource;
/* 163:    */     private Transaction transaction;
/* 164:    */     private boolean rollbackOnly;
/* 165:    */     
/* 166:    */     public TransactionDelegate(XAResource xaResource)
/* 167:    */     {
/* 168:276 */       if ((xaResource == null) && 
/* 169:277 */         (AbstractMessageEndpointFactory.this.transactionFactory != null) && (!AbstractMessageEndpointFactory.this.transactionFactory.supportsResourceAdapterManagedTransactions())) {
/* 170:278 */         throw new IllegalStateException("ResourceAdapter-provided XAResource is required for transaction management. Check your ResourceAdapter's configuration.");
/* 171:    */       }
/* 172:282 */       this.xaResource = xaResource;
/* 173:    */     }
/* 174:    */     
/* 175:    */     public void beginTransaction()
/* 176:    */       throws Exception
/* 177:    */     {
/* 178:286 */       if ((AbstractMessageEndpointFactory.this.transactionFactory != null) && (this.xaResource != null))
/* 179:    */       {
/* 180:287 */         this.transaction = AbstractMessageEndpointFactory.this.transactionFactory.createTransaction(AbstractMessageEndpointFactory.this.transactionName, AbstractMessageEndpointFactory.this.transactionTimeout);
/* 181:288 */         this.transaction.enlistResource(this.xaResource);
/* 182:    */       }
/* 183:    */     }
/* 184:    */     
/* 185:    */     public void setRollbackOnly()
/* 186:    */     {
/* 187:293 */       if (this.transaction != null) {
/* 188:294 */         this.rollbackOnly = true;
/* 189:    */       }
/* 190:    */     }
/* 191:    */     
/* 192:    */     public void endTransaction()
/* 193:    */       throws Exception
/* 194:    */     {
/* 195:299 */       if (this.transaction != null) {
/* 196:    */         try
/* 197:    */         {
/* 198:301 */           if (this.rollbackOnly) {
/* 199:302 */             this.transaction.rollback();
/* 200:    */           } else {
/* 201:305 */             this.transaction.commit();
/* 202:    */           }
/* 203:    */         }
/* 204:    */         finally
/* 205:    */         {
/* 206:309 */           this.transaction = null;
/* 207:310 */           this.rollbackOnly = false;
/* 208:    */         }
/* 209:    */       }
/* 210:    */     }
/* 211:    */   }
/* 212:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jca.endpoint.AbstractMessageEndpointFactory
 * JD-Core Version:    0.7.0.1
 */