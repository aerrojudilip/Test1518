/*   1:    */ package org.springframework.dao.support;
/*   2:    */ 
/*   3:    */ import java.util.Map;
/*   4:    */ import org.aopalliance.intercept.MethodInterceptor;
/*   5:    */ import org.aopalliance.intercept.MethodInvocation;
/*   6:    */ import org.springframework.beans.BeansException;
/*   7:    */ import org.springframework.beans.factory.BeanFactory;
/*   8:    */ import org.springframework.beans.factory.BeanFactoryAware;
/*   9:    */ import org.springframework.beans.factory.BeanFactoryUtils;
/*  10:    */ import org.springframework.beans.factory.InitializingBean;
/*  11:    */ import org.springframework.beans.factory.ListableBeanFactory;
/*  12:    */ import org.springframework.util.Assert;
/*  13:    */ import org.springframework.util.ReflectionUtils;
/*  14:    */ 
/*  15:    */ public class PersistenceExceptionTranslationInterceptor
/*  16:    */   implements MethodInterceptor, BeanFactoryAware, InitializingBean
/*  17:    */ {
/*  18:    */   private PersistenceExceptionTranslator persistenceExceptionTranslator;
/*  19: 52 */   private boolean alwaysTranslate = false;
/*  20:    */   
/*  21:    */   public PersistenceExceptionTranslationInterceptor() {}
/*  22:    */   
/*  23:    */   public PersistenceExceptionTranslationInterceptor(PersistenceExceptionTranslator persistenceExceptionTranslator)
/*  24:    */   {
/*  25: 69 */     setPersistenceExceptionTranslator(persistenceExceptionTranslator);
/*  26:    */   }
/*  27:    */   
/*  28:    */   public PersistenceExceptionTranslationInterceptor(ListableBeanFactory beanFactory)
/*  29:    */   {
/*  30: 79 */     this.persistenceExceptionTranslator = detectPersistenceExceptionTranslators(beanFactory);
/*  31:    */   }
/*  32:    */   
/*  33:    */   public void setPersistenceExceptionTranslator(PersistenceExceptionTranslator pet)
/*  34:    */   {
/*  35: 90 */     Assert.notNull(pet, "PersistenceExceptionTranslator must not be null");
/*  36: 91 */     this.persistenceExceptionTranslator = pet;
/*  37:    */   }
/*  38:    */   
/*  39:    */   public void setAlwaysTranslate(boolean alwaysTranslate)
/*  40:    */   {
/*  41:107 */     this.alwaysTranslate = alwaysTranslate;
/*  42:    */   }
/*  43:    */   
/*  44:    */   public void setBeanFactory(BeanFactory beanFactory)
/*  45:    */     throws BeansException
/*  46:    */   {
/*  47:111 */     if (this.persistenceExceptionTranslator == null)
/*  48:    */     {
/*  49:113 */       if (!(beanFactory instanceof ListableBeanFactory)) {
/*  50:114 */         throw new IllegalArgumentException("Cannot use PersistenceExceptionTranslator autodetection without ListableBeanFactory");
/*  51:    */       }
/*  52:117 */       this.persistenceExceptionTranslator = detectPersistenceExceptionTranslators((ListableBeanFactory)beanFactory);
/*  53:    */     }
/*  54:    */   }
/*  55:    */   
/*  56:    */   public void afterPropertiesSet()
/*  57:    */   {
/*  58:123 */     if (this.persistenceExceptionTranslator == null) {
/*  59:124 */       throw new IllegalArgumentException("Property 'persistenceExceptionTranslator' is required");
/*  60:    */     }
/*  61:    */   }
/*  62:    */   
/*  63:    */   protected PersistenceExceptionTranslator detectPersistenceExceptionTranslators(ListableBeanFactory beanFactory)
/*  64:    */   {
/*  65:139 */     Map<String, PersistenceExceptionTranslator> pets = BeanFactoryUtils.beansOfTypeIncludingAncestors(beanFactory, PersistenceExceptionTranslator.class, false, false);
/*  66:141 */     if (pets.isEmpty()) {
/*  67:142 */       throw new IllegalStateException("No persistence exception translators found in bean factory. Cannot perform exception translation.");
/*  68:    */     }
/*  69:145 */     ChainedPersistenceExceptionTranslator cpet = new ChainedPersistenceExceptionTranslator();
/*  70:146 */     for (PersistenceExceptionTranslator pet : pets.values()) {
/*  71:147 */       cpet.addDelegate(pet);
/*  72:    */     }
/*  73:149 */     return cpet;
/*  74:    */   }
/*  75:    */   
/*  76:    */   public Object invoke(MethodInvocation mi)
/*  77:    */     throws Throwable
/*  78:    */   {
/*  79:    */     try
/*  80:    */     {
/*  81:155 */       return mi.proceed();
/*  82:    */     }
/*  83:    */     catch (RuntimeException ex)
/*  84:    */     {
/*  85:159 */       if ((!this.alwaysTranslate) && (ReflectionUtils.declaresException(mi.getMethod(), ex.getClass()))) {
/*  86:160 */         throw ex;
/*  87:    */       }
/*  88:163 */       throw DataAccessUtils.translateIfNecessary(ex, this.persistenceExceptionTranslator);
/*  89:    */     }
/*  90:    */   }
/*  91:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.dao.support.PersistenceExceptionTranslationInterceptor
 * JD-Core Version:    0.7.0.1
 */