/*  1:   */ package org.springframework.dao.annotation;
/*  2:   */ 
/*  3:   */ import java.lang.annotation.Annotation;
/*  4:   */ import org.springframework.aop.framework.AbstractAdvisingBeanPostProcessor;
/*  5:   */ import org.springframework.beans.factory.BeanFactory;
/*  6:   */ import org.springframework.beans.factory.BeanFactoryAware;
/*  7:   */ import org.springframework.beans.factory.ListableBeanFactory;
/*  8:   */ import org.springframework.stereotype.Repository;
/*  9:   */ import org.springframework.util.Assert;
/* 10:   */ 
/* 11:   */ public class PersistenceExceptionTranslationPostProcessor
/* 12:   */   extends AbstractAdvisingBeanPostProcessor
/* 13:   */   implements BeanFactoryAware
/* 14:   */ {
/* 15:64 */   private Class<? extends Annotation> repositoryAnnotationType = Repository.class;
/* 16:   */   
/* 17:   */   public void setRepositoryAnnotationType(Class<? extends Annotation> repositoryAnnotationType)
/* 18:   */   {
/* 19:76 */     Assert.notNull(repositoryAnnotationType, "'repositoryAnnotationType' must not be null");
/* 20:77 */     this.repositoryAnnotationType = repositoryAnnotationType;
/* 21:   */   }
/* 22:   */   
/* 23:   */   public void setBeanFactory(BeanFactory beanFactory)
/* 24:   */   {
/* 25:81 */     if (!(beanFactory instanceof ListableBeanFactory)) {
/* 26:82 */       throw new IllegalArgumentException("Cannot use PersistenceExceptionTranslator autodetection without ListableBeanFactory");
/* 27:   */     }
/* 28:85 */     this.advisor = new PersistenceExceptionTranslationAdvisor((ListableBeanFactory)beanFactory, this.repositoryAnnotationType);
/* 29:   */   }
/* 30:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.dao.annotation.PersistenceExceptionTranslationPostProcessor
 * JD-Core Version:    0.7.0.1
 */