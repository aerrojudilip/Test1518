/*  1:   */ package org.springframework.dao;
/*  2:   */ 
/*  3:   */ public class DataIntegrityViolationException
/*  4:   */   extends NonTransientDataAccessException
/*  5:   */ {
/*  6:   */   public DataIntegrityViolationException(String msg)
/*  7:   */   {
/*  8:34 */     super(msg);
/*  9:   */   }
/* 10:   */   
/* 11:   */   public DataIntegrityViolationException(String msg, Throwable cause)
/* 12:   */   {
/* 13:43 */     super(msg, cause);
/* 14:   */   }
/* 15:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.dao.DataIntegrityViolationException
 * JD-Core Version:    0.7.0.1
 */