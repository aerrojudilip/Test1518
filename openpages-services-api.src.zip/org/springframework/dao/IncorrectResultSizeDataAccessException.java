/*   1:    */ package org.springframework.dao;
/*   2:    */ 
/*   3:    */ public class IncorrectResultSizeDataAccessException
/*   4:    */   extends DataRetrievalFailureException
/*   5:    */ {
/*   6:    */   private int expectedSize;
/*   7:    */   private int actualSize;
/*   8:    */   
/*   9:    */   public IncorrectResultSizeDataAccessException(int expectedSize)
/*  10:    */   {
/*  11: 41 */     super("Incorrect result size: expected " + expectedSize);
/*  12: 42 */     this.expectedSize = expectedSize;
/*  13: 43 */     this.actualSize = -1;
/*  14:    */   }
/*  15:    */   
/*  16:    */   public IncorrectResultSizeDataAccessException(int expectedSize, int actualSize)
/*  17:    */   {
/*  18: 52 */     super("Incorrect result size: expected " + expectedSize + ", actual " + actualSize);
/*  19: 53 */     this.expectedSize = expectedSize;
/*  20: 54 */     this.actualSize = actualSize;
/*  21:    */   }
/*  22:    */   
/*  23:    */   public IncorrectResultSizeDataAccessException(String msg, int expectedSize)
/*  24:    */   {
/*  25: 63 */     super(msg);
/*  26: 64 */     this.expectedSize = expectedSize;
/*  27: 65 */     this.actualSize = -1;
/*  28:    */   }
/*  29:    */   
/*  30:    */   public IncorrectResultSizeDataAccessException(String msg, int expectedSize, Throwable ex)
/*  31:    */   {
/*  32: 75 */     super(msg, ex);
/*  33: 76 */     this.expectedSize = expectedSize;
/*  34: 77 */     this.actualSize = -1;
/*  35:    */   }
/*  36:    */   
/*  37:    */   public IncorrectResultSizeDataAccessException(String msg, int expectedSize, int actualSize)
/*  38:    */   {
/*  39: 87 */     super(msg);
/*  40: 88 */     this.expectedSize = expectedSize;
/*  41: 89 */     this.actualSize = actualSize;
/*  42:    */   }
/*  43:    */   
/*  44:    */   public IncorrectResultSizeDataAccessException(String msg, int expectedSize, int actualSize, Throwable ex)
/*  45:    */   {
/*  46:100 */     super(msg, ex);
/*  47:101 */     this.expectedSize = expectedSize;
/*  48:102 */     this.actualSize = actualSize;
/*  49:    */   }
/*  50:    */   
/*  51:    */   public int getExpectedSize()
/*  52:    */   {
/*  53:110 */     return this.expectedSize;
/*  54:    */   }
/*  55:    */   
/*  56:    */   public int getActualSize()
/*  57:    */   {
/*  58:117 */     return this.actualSize;
/*  59:    */   }
/*  60:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.dao.IncorrectResultSizeDataAccessException
 * JD-Core Version:    0.7.0.1
 */