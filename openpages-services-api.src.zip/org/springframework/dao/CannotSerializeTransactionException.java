/*  1:   */ package org.springframework.dao;
/*  2:   */ 
/*  3:   */ public class CannotSerializeTransactionException
/*  4:   */   extends PessimisticLockingFailureException
/*  5:   */ {
/*  6:   */   public CannotSerializeTransactionException(String msg)
/*  7:   */   {
/*  8:32 */     super(msg);
/*  9:   */   }
/* 10:   */   
/* 11:   */   public CannotSerializeTransactionException(String msg, Throwable cause)
/* 12:   */   {
/* 13:41 */     super(msg, cause);
/* 14:   */   }
/* 15:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.dao.CannotSerializeTransactionException
 * JD-Core Version:    0.7.0.1
 */