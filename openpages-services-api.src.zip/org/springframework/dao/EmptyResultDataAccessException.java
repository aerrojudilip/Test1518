/*  1:   */ package org.springframework.dao;
/*  2:   */ 
/*  3:   */ public class EmptyResultDataAccessException
/*  4:   */   extends IncorrectResultSizeDataAccessException
/*  5:   */ {
/*  6:   */   public EmptyResultDataAccessException(int expectedSize)
/*  7:   */   {
/*  8:34 */     super(expectedSize, 0);
/*  9:   */   }
/* 10:   */   
/* 11:   */   public EmptyResultDataAccessException(String msg, int expectedSize)
/* 12:   */   {
/* 13:43 */     super(msg, expectedSize, 0);
/* 14:   */   }
/* 15:   */   
/* 16:   */   public EmptyResultDataAccessException(String msg, int expectedSize, Throwable ex)
/* 17:   */   {
/* 18:53 */     super(msg, expectedSize, 0, ex);
/* 19:   */   }
/* 20:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.dao.EmptyResultDataAccessException
 * JD-Core Version:    0.7.0.1
 */