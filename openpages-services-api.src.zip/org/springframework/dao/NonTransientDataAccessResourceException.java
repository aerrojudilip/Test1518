/*  1:   */ package org.springframework.dao;
/*  2:   */ 
/*  3:   */ public class NonTransientDataAccessResourceException
/*  4:   */   extends NonTransientDataAccessException
/*  5:   */ {
/*  6:   */   public NonTransientDataAccessResourceException(String msg)
/*  7:   */   {
/*  8:33 */     super(msg);
/*  9:   */   }
/* 10:   */   
/* 11:   */   public NonTransientDataAccessResourceException(String msg, Throwable cause)
/* 12:   */   {
/* 13:42 */     super(msg, cause);
/* 14:   */   }
/* 15:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.dao.NonTransientDataAccessResourceException
 * JD-Core Version:    0.7.0.1
 */