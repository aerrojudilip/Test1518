/*  1:   */ package org.springframework.dao;
/*  2:   */ 
/*  3:   */ import org.springframework.core.NestedRuntimeException;
/*  4:   */ 
/*  5:   */ public abstract class DataAccessException
/*  6:   */   extends NestedRuntimeException
/*  7:   */ {
/*  8:   */   public DataAccessException(String msg)
/*  9:   */   {
/* 10:45 */     super(msg);
/* 11:   */   }
/* 12:   */   
/* 13:   */   public DataAccessException(String msg, Throwable cause)
/* 14:   */   {
/* 15:55 */     super(msg, cause);
/* 16:   */   }
/* 17:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.dao.DataAccessException
 * JD-Core Version:    0.7.0.1
 */