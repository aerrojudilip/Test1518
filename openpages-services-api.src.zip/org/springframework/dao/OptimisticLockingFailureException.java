/*  1:   */ package org.springframework.dao;
/*  2:   */ 
/*  3:   */ public class OptimisticLockingFailureException
/*  4:   */   extends ConcurrencyFailureException
/*  5:   */ {
/*  6:   */   public OptimisticLockingFailureException(String msg)
/*  7:   */   {
/*  8:36 */     super(msg);
/*  9:   */   }
/* 10:   */   
/* 11:   */   public OptimisticLockingFailureException(String msg, Throwable cause)
/* 12:   */   {
/* 13:45 */     super(msg, cause);
/* 14:   */   }
/* 15:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.dao.OptimisticLockingFailureException
 * JD-Core Version:    0.7.0.1
 */