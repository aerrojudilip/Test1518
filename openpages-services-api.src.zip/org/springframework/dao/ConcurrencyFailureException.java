/*  1:   */ package org.springframework.dao;
/*  2:   */ 
/*  3:   */ public class ConcurrencyFailureException
/*  4:   */   extends TransientDataAccessException
/*  5:   */ {
/*  6:   */   public ConcurrencyFailureException(String msg)
/*  7:   */   {
/*  8:39 */     super(msg);
/*  9:   */   }
/* 10:   */   
/* 11:   */   public ConcurrencyFailureException(String msg, Throwable cause)
/* 12:   */   {
/* 13:48 */     super(msg, cause);
/* 14:   */   }
/* 15:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.dao.ConcurrencyFailureException
 * JD-Core Version:    0.7.0.1
 */