/*   1:    */ package org.springframework.jdbc.support;
/*   2:    */ 
/*   3:    */ import java.sql.SQLDataException;
/*   4:    */ import java.sql.SQLException;
/*   5:    */ import java.sql.SQLFeatureNotSupportedException;
/*   6:    */ import java.sql.SQLIntegrityConstraintViolationException;
/*   7:    */ import java.sql.SQLInvalidAuthorizationSpecException;
/*   8:    */ import java.sql.SQLNonTransientConnectionException;
/*   9:    */ import java.sql.SQLNonTransientException;
/*  10:    */ import java.sql.SQLRecoverableException;
/*  11:    */ import java.sql.SQLSyntaxErrorException;
/*  12:    */ import java.sql.SQLTimeoutException;
/*  13:    */ import java.sql.SQLTransactionRollbackException;
/*  14:    */ import java.sql.SQLTransientConnectionException;
/*  15:    */ import java.sql.SQLTransientException;
/*  16:    */ import org.springframework.dao.ConcurrencyFailureException;
/*  17:    */ import org.springframework.dao.DataAccessException;
/*  18:    */ import org.springframework.dao.DataAccessResourceFailureException;
/*  19:    */ import org.springframework.dao.DataIntegrityViolationException;
/*  20:    */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*  21:    */ import org.springframework.dao.PermissionDeniedDataAccessException;
/*  22:    */ import org.springframework.dao.QueryTimeoutException;
/*  23:    */ import org.springframework.dao.RecoverableDataAccessException;
/*  24:    */ import org.springframework.dao.TransientDataAccessResourceException;
/*  25:    */ import org.springframework.jdbc.BadSqlGrammarException;
/*  26:    */ 
/*  27:    */ public class SQLExceptionSubclassTranslator
/*  28:    */   extends AbstractFallbackSQLExceptionTranslator
/*  29:    */ {
/*  30:    */   public SQLExceptionSubclassTranslator()
/*  31:    */   {
/*  32: 62 */     setFallbackTranslator(new SQLStateSQLExceptionTranslator());
/*  33:    */   }
/*  34:    */   
/*  35:    */   protected DataAccessException doTranslate(String task, String sql, SQLException ex)
/*  36:    */   {
/*  37: 67 */     if ((ex instanceof SQLTransientException))
/*  38:    */     {
/*  39: 68 */       if ((ex instanceof SQLTransactionRollbackException)) {
/*  40: 69 */         return new ConcurrencyFailureException(buildMessage(task, sql, ex), ex);
/*  41:    */       }
/*  42: 71 */       if ((ex instanceof SQLTransientConnectionException)) {
/*  43: 72 */         return new TransientDataAccessResourceException(buildMessage(task, sql, ex), ex);
/*  44:    */       }
/*  45: 74 */       if ((ex instanceof SQLTimeoutException)) {
/*  46: 75 */         return new QueryTimeoutException(buildMessage(task, sql, ex), ex);
/*  47:    */       }
/*  48:    */     }
/*  49: 78 */     else if ((ex instanceof SQLNonTransientException))
/*  50:    */     {
/*  51: 79 */       if ((ex instanceof SQLDataException)) {
/*  52: 80 */         return new DataIntegrityViolationException(buildMessage(task, sql, ex), ex);
/*  53:    */       }
/*  54: 82 */       if ((ex instanceof SQLFeatureNotSupportedException)) {
/*  55: 83 */         return new InvalidDataAccessApiUsageException(buildMessage(task, sql, ex), ex);
/*  56:    */       }
/*  57: 85 */       if ((ex instanceof SQLIntegrityConstraintViolationException)) {
/*  58: 86 */         return new DataIntegrityViolationException(buildMessage(task, sql, ex), ex);
/*  59:    */       }
/*  60: 88 */       if ((ex instanceof SQLInvalidAuthorizationSpecException)) {
/*  61: 89 */         return new PermissionDeniedDataAccessException(buildMessage(task, sql, ex), ex);
/*  62:    */       }
/*  63: 91 */       if ((ex instanceof SQLNonTransientConnectionException)) {
/*  64: 92 */         return new DataAccessResourceFailureException(buildMessage(task, sql, ex), ex);
/*  65:    */       }
/*  66: 94 */       if ((ex instanceof SQLSyntaxErrorException)) {
/*  67: 95 */         return new BadSqlGrammarException(task, sql, ex);
/*  68:    */       }
/*  69:    */     }
/*  70: 98 */     else if ((ex instanceof SQLRecoverableException))
/*  71:    */     {
/*  72: 99 */       return new RecoverableDataAccessException(buildMessage(task, sql, ex), ex);
/*  73:    */     }
/*  74:103 */     return null;
/*  75:    */   }
/*  76:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.support.SQLExceptionSubclassTranslator
 * JD-Core Version:    0.7.0.1
 */