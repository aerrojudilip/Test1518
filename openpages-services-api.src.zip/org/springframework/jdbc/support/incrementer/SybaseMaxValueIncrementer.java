/*   1:    */ package org.springframework.jdbc.support.incrementer;
/*   2:    */ 
/*   3:    */ import java.sql.Connection;
/*   4:    */ import java.sql.ResultSet;
/*   5:    */ import java.sql.SQLException;
/*   6:    */ import java.sql.Statement;
/*   7:    */ import javax.sql.DataSource;
/*   8:    */ import org.springframework.dao.DataAccessException;
/*   9:    */ import org.springframework.dao.DataAccessResourceFailureException;
/*  10:    */ import org.springframework.jdbc.datasource.DataSourceUtils;
/*  11:    */ import org.springframework.jdbc.support.JdbcUtils;
/*  12:    */ 
/*  13:    */ public class SybaseMaxValueIncrementer
/*  14:    */   extends AbstractColumnMaxValueIncrementer
/*  15:    */ {
/*  16:    */   private long[] valueCache;
/*  17: 70 */   private int nextValueIndex = -1;
/*  18:    */   
/*  19:    */   public SybaseMaxValueIncrementer() {}
/*  20:    */   
/*  21:    */   public SybaseMaxValueIncrementer(DataSource dataSource, String incrementerName, String columnName)
/*  22:    */   {
/*  23: 89 */     super(dataSource, incrementerName, columnName);
/*  24:    */   }
/*  25:    */   
/*  26:    */   protected synchronized long getNextKey()
/*  27:    */     throws DataAccessException
/*  28:    */   {
/*  29: 95 */     if ((this.nextValueIndex < 0) || (this.nextValueIndex >= getCacheSize()))
/*  30:    */     {
/*  31:101 */       Connection con = DataSourceUtils.getConnection(getDataSource());
/*  32:102 */       Statement stmt = null;
/*  33:    */       try
/*  34:    */       {
/*  35:104 */         stmt = con.createStatement();
/*  36:105 */         DataSourceUtils.applyTransactionTimeout(stmt, getDataSource());
/*  37:106 */         this.valueCache = new long[getCacheSize()];
/*  38:107 */         this.nextValueIndex = 0;
/*  39:108 */         for (int i = 0; i < getCacheSize(); i++)
/*  40:    */         {
/*  41:109 */           stmt.executeUpdate(getIncrementStatement());
/*  42:110 */           ResultSet rs = stmt.executeQuery("select @@identity");
/*  43:    */           try
/*  44:    */           {
/*  45:112 */             if (!rs.next()) {
/*  46:113 */               throw new DataAccessResourceFailureException("@@identity failed after executing an update");
/*  47:    */             }
/*  48:115 */             this.valueCache[i] = rs.getLong(1);
/*  49:    */           }
/*  50:    */           finally
/*  51:    */           {
/*  52:118 */             JdbcUtils.closeResultSet(rs);
/*  53:    */           }
/*  54:    */         }
/*  55:121 */         long maxValue = this.valueCache[(this.valueCache.length - 1)];
/*  56:122 */         stmt.executeUpdate("delete from " + getIncrementerName() + " where " + getColumnName() + " < " + maxValue);
/*  57:    */       }
/*  58:    */       catch (SQLException ex)
/*  59:    */       {
/*  60:125 */         throw new DataAccessResourceFailureException("Could not increment identity", ex);
/*  61:    */       }
/*  62:    */       finally
/*  63:    */       {
/*  64:128 */         JdbcUtils.closeStatement(stmt);
/*  65:129 */         DataSourceUtils.releaseConnection(con, getDataSource());
/*  66:    */       }
/*  67:    */     }
/*  68:132 */     return this.valueCache[(this.nextValueIndex++)];
/*  69:    */   }
/*  70:    */   
/*  71:    */   protected String getIncrementStatement()
/*  72:    */   {
/*  73:140 */     return "insert into " + getIncrementerName() + " values()";
/*  74:    */   }
/*  75:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.support.incrementer.SybaseMaxValueIncrementer
 * JD-Core Version:    0.7.0.1
 */