package org.springframework.jdbc.support.incrementer;

import org.springframework.dao.DataAccessException;

public abstract interface DataFieldMaxValueIncrementer
{
  public abstract int nextIntValue()
    throws DataAccessException;
  
  public abstract long nextLongValue()
    throws DataAccessException;
  
  public abstract String nextStringValue()
    throws DataAccessException;
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.support.incrementer.DataFieldMaxValueIncrementer
 * JD-Core Version:    0.7.0.1
 */