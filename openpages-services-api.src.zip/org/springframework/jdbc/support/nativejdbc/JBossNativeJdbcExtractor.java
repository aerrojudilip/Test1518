/*   1:    */ package org.springframework.jdbc.support.nativejdbc;
/*   2:    */ 
/*   3:    */ import java.lang.reflect.Method;
/*   4:    */ import java.sql.CallableStatement;
/*   5:    */ import java.sql.Connection;
/*   6:    */ import java.sql.PreparedStatement;
/*   7:    */ import java.sql.ResultSet;
/*   8:    */ import java.sql.SQLException;
/*   9:    */ import java.sql.Statement;
/*  10:    */ import org.springframework.util.ReflectionUtils;
/*  11:    */ 
/*  12:    */ public class JBossNativeJdbcExtractor
/*  13:    */   extends NativeJdbcExtractorAdapter
/*  14:    */ {
/*  15:    */   private static final String JBOSS_JCA_PREFIX = "org.jboss.jca.adapters.jdbc.";
/*  16:    */   private static final String JBOSS_RESOURCE_PREFIX = "org.jboss.resource.adapter.jdbc.";
/*  17:    */   private Class wrappedConnectionClass;
/*  18:    */   private Class wrappedStatementClass;
/*  19:    */   private Class wrappedResultSetClass;
/*  20:    */   private Method getUnderlyingConnectionMethod;
/*  21:    */   private Method getUnderlyingStatementMethod;
/*  22:    */   private Method getUnderlyingResultSetMethod;
/*  23:    */   
/*  24:    */   public JBossNativeJdbcExtractor()
/*  25:    */   {
/*  26: 76 */     String prefix = "org.jboss.jca.adapters.jdbc.";
/*  27:    */     try
/*  28:    */     {
/*  29: 79 */       this.wrappedConnectionClass = getClass().getClassLoader().loadClass(prefix + "WrappedConnection");
/*  30:    */     }
/*  31:    */     catch (ClassNotFoundException ex)
/*  32:    */     {
/*  33: 83 */       prefix = "org.jboss.resource.adapter.jdbc.";
/*  34:    */       try
/*  35:    */       {
/*  36: 85 */         this.wrappedConnectionClass = getClass().getClassLoader().loadClass(prefix + "WrappedConnection");
/*  37:    */       }
/*  38:    */       catch (ClassNotFoundException ex2)
/*  39:    */       {
/*  40: 88 */         throw new IllegalStateException("Could not initialize JBossNativeJdbcExtractor: neither JBoss 7's [org.jboss.jca.adapters.jdbc..WrappedConnection] nor traditional JBoss [org.jboss.resource.adapter.jdbc..WrappedConnection] found");
/*  41:    */       }
/*  42:    */     }
/*  43:    */     try
/*  44:    */     {
/*  45: 94 */       this.wrappedStatementClass = getClass().getClassLoader().loadClass(prefix + "WrappedStatement");
/*  46: 95 */       this.wrappedResultSetClass = getClass().getClassLoader().loadClass(prefix + "WrappedResultSet");
/*  47: 96 */       this.getUnderlyingConnectionMethod = this.wrappedConnectionClass.getMethod("getUnderlyingConnection", (Class[])null);
/*  48:    */       
/*  49: 98 */       this.getUnderlyingStatementMethod = this.wrappedStatementClass.getMethod("getUnderlyingStatement", (Class[])null);
/*  50:    */       
/*  51:100 */       this.getUnderlyingResultSetMethod = this.wrappedResultSetClass.getMethod("getUnderlyingResultSet", (Class[])null);
/*  52:    */     }
/*  53:    */     catch (Exception ex)
/*  54:    */     {
/*  55:104 */       throw new IllegalStateException("Could not initialize JBossNativeJdbcExtractor because of missing JBoss API methods/classes: " + ex);
/*  56:    */     }
/*  57:    */   }
/*  58:    */   
/*  59:    */   protected Connection doGetNativeConnection(Connection con)
/*  60:    */     throws SQLException
/*  61:    */   {
/*  62:115 */     if (this.wrappedConnectionClass.isAssignableFrom(con.getClass())) {
/*  63:116 */       return (Connection)ReflectionUtils.invokeJdbcMethod(this.getUnderlyingConnectionMethod, con);
/*  64:    */     }
/*  65:118 */     return con;
/*  66:    */   }
/*  67:    */   
/*  68:    */   public Statement getNativeStatement(Statement stmt)
/*  69:    */     throws SQLException
/*  70:    */   {
/*  71:126 */     if (this.wrappedStatementClass.isAssignableFrom(stmt.getClass())) {
/*  72:127 */       return (Statement)ReflectionUtils.invokeJdbcMethod(this.getUnderlyingStatementMethod, stmt);
/*  73:    */     }
/*  74:129 */     return stmt;
/*  75:    */   }
/*  76:    */   
/*  77:    */   public PreparedStatement getNativePreparedStatement(PreparedStatement ps)
/*  78:    */     throws SQLException
/*  79:    */   {
/*  80:137 */     return (PreparedStatement)getNativeStatement(ps);
/*  81:    */   }
/*  82:    */   
/*  83:    */   public CallableStatement getNativeCallableStatement(CallableStatement cs)
/*  84:    */     throws SQLException
/*  85:    */   {
/*  86:145 */     return (CallableStatement)getNativeStatement(cs);
/*  87:    */   }
/*  88:    */   
/*  89:    */   public ResultSet getNativeResultSet(ResultSet rs)
/*  90:    */     throws SQLException
/*  91:    */   {
/*  92:153 */     if (this.wrappedResultSetClass.isAssignableFrom(rs.getClass())) {
/*  93:154 */       return (ResultSet)ReflectionUtils.invokeJdbcMethod(this.getUnderlyingResultSetMethod, rs);
/*  94:    */     }
/*  95:156 */     return rs;
/*  96:    */   }
/*  97:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.support.nativejdbc.JBossNativeJdbcExtractor
 * JD-Core Version:    0.7.0.1
 */