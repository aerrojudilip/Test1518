/*   1:    */ package org.springframework.jdbc.support.nativejdbc;
/*   2:    */ 
/*   3:    */ import java.lang.reflect.Method;
/*   4:    */ import java.sql.Connection;
/*   5:    */ import java.sql.SQLException;
/*   6:    */ import org.springframework.util.ReflectionUtils;
/*   7:    */ 
/*   8:    */ public class WebSphereNativeJdbcExtractor
/*   9:    */   extends NativeJdbcExtractorAdapter
/*  10:    */ {
/*  11:    */   private static final String JDBC_ADAPTER_CONNECTION_NAME_5 = "com.ibm.ws.rsadapter.jdbc.WSJdbcConnection";
/*  12:    */   private static final String JDBC_ADAPTER_UTIL_NAME_5 = "com.ibm.ws.rsadapter.jdbc.WSJdbcUtil";
/*  13:    */   private Class webSphere5ConnectionClass;
/*  14:    */   private Method webSphere5NativeConnectionMethod;
/*  15:    */   
/*  16:    */   public WebSphereNativeJdbcExtractor()
/*  17:    */   {
/*  18:    */     try
/*  19:    */     {
/*  20: 59 */       this.webSphere5ConnectionClass = getClass().getClassLoader().loadClass("com.ibm.ws.rsadapter.jdbc.WSJdbcConnection");
/*  21: 60 */       Class jdbcAdapterUtilClass = getClass().getClassLoader().loadClass("com.ibm.ws.rsadapter.jdbc.WSJdbcUtil");
/*  22: 61 */       this.webSphere5NativeConnectionMethod = jdbcAdapterUtilClass.getMethod("getNativeConnection", new Class[] { this.webSphere5ConnectionClass });
/*  23:    */     }
/*  24:    */     catch (Exception ex)
/*  25:    */     {
/*  26: 65 */       throw new IllegalStateException("Could not initialize WebSphereNativeJdbcExtractor because WebSphere API classes are not available: " + ex);
/*  27:    */     }
/*  28:    */   }
/*  29:    */   
/*  30:    */   public boolean isNativeConnectionNecessaryForNativeStatements()
/*  31:    */   {
/*  32: 76 */     return true;
/*  33:    */   }
/*  34:    */   
/*  35:    */   public boolean isNativeConnectionNecessaryForNativePreparedStatements()
/*  36:    */   {
/*  37: 84 */     return true;
/*  38:    */   }
/*  39:    */   
/*  40:    */   public boolean isNativeConnectionNecessaryForNativeCallableStatements()
/*  41:    */   {
/*  42: 92 */     return true;
/*  43:    */   }
/*  44:    */   
/*  45:    */   protected Connection doGetNativeConnection(Connection con)
/*  46:    */     throws SQLException
/*  47:    */   {
/*  48:100 */     if (this.webSphere5ConnectionClass.isAssignableFrom(con.getClass())) {
/*  49:101 */       return (Connection)ReflectionUtils.invokeJdbcMethod(this.webSphere5NativeConnectionMethod, null, new Object[] { con });
/*  50:    */     }
/*  51:104 */     return con;
/*  52:    */   }
/*  53:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.support.nativejdbc.WebSphereNativeJdbcExtractor
 * JD-Core Version:    0.7.0.1
 */