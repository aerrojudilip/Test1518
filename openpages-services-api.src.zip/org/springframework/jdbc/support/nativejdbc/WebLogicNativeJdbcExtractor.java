/*   1:    */ package org.springframework.jdbc.support.nativejdbc;
/*   2:    */ 
/*   3:    */ import java.lang.reflect.Method;
/*   4:    */ import java.sql.Connection;
/*   5:    */ import java.sql.SQLException;
/*   6:    */ import org.springframework.util.ReflectionUtils;
/*   7:    */ 
/*   8:    */ public class WebLogicNativeJdbcExtractor
/*   9:    */   extends NativeJdbcExtractorAdapter
/*  10:    */ {
/*  11:    */   private static final String JDBC_EXTENSION_NAME = "weblogic.jdbc.extensions.WLConnection";
/*  12:    */   private final Class jdbcExtensionClass;
/*  13:    */   private final Method getVendorConnectionMethod;
/*  14:    */   
/*  15:    */   public WebLogicNativeJdbcExtractor()
/*  16:    */   {
/*  17:    */     try
/*  18:    */     {
/*  19: 60 */       this.jdbcExtensionClass = getClass().getClassLoader().loadClass("weblogic.jdbc.extensions.WLConnection");
/*  20: 61 */       this.getVendorConnectionMethod = this.jdbcExtensionClass.getMethod("getVendorConnection", (Class[])null);
/*  21:    */     }
/*  22:    */     catch (Exception ex)
/*  23:    */     {
/*  24: 64 */       throw new IllegalStateException("Could not initialize WebLogicNativeJdbcExtractor because WebLogic API classes are not available: " + ex);
/*  25:    */     }
/*  26:    */   }
/*  27:    */   
/*  28:    */   public boolean isNativeConnectionNecessaryForNativeStatements()
/*  29:    */   {
/*  30: 75 */     return true;
/*  31:    */   }
/*  32:    */   
/*  33:    */   public boolean isNativeConnectionNecessaryForNativePreparedStatements()
/*  34:    */   {
/*  35: 83 */     return true;
/*  36:    */   }
/*  37:    */   
/*  38:    */   public boolean isNativeConnectionNecessaryForNativeCallableStatements()
/*  39:    */   {
/*  40: 91 */     return true;
/*  41:    */   }
/*  42:    */   
/*  43:    */   protected Connection doGetNativeConnection(Connection con)
/*  44:    */     throws SQLException
/*  45:    */   {
/*  46: 99 */     if (this.jdbcExtensionClass.isAssignableFrom(con.getClass())) {
/*  47:100 */       return (Connection)ReflectionUtils.invokeJdbcMethod(this.getVendorConnectionMethod, con);
/*  48:    */     }
/*  49:102 */     return con;
/*  50:    */   }
/*  51:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.support.nativejdbc.WebLogicNativeJdbcExtractor
 * JD-Core Version:    0.7.0.1
 */