/*   1:    */ package org.springframework.jdbc.support;
/*   2:    */ 
/*   3:    */ import java.lang.reflect.Constructor;
/*   4:    */ import java.sql.BatchUpdateException;
/*   5:    */ import java.sql.SQLException;
/*   6:    */ import java.util.Arrays;
/*   7:    */ import javax.sql.DataSource;
/*   8:    */ import org.apache.commons.logging.Log;
/*   9:    */ import org.springframework.core.JdkVersion;
/*  10:    */ import org.springframework.dao.CannotAcquireLockException;
/*  11:    */ import org.springframework.dao.CannotSerializeTransactionException;
/*  12:    */ import org.springframework.dao.DataAccessException;
/*  13:    */ import org.springframework.dao.DataAccessResourceFailureException;
/*  14:    */ import org.springframework.dao.DataIntegrityViolationException;
/*  15:    */ import org.springframework.dao.DeadlockLoserDataAccessException;
/*  16:    */ import org.springframework.dao.DuplicateKeyException;
/*  17:    */ import org.springframework.dao.PermissionDeniedDataAccessException;
/*  18:    */ import org.springframework.dao.TransientDataAccessResourceException;
/*  19:    */ import org.springframework.jdbc.BadSqlGrammarException;
/*  20:    */ import org.springframework.jdbc.InvalidResultSetAccessException;
/*  21:    */ 
/*  22:    */ public class SQLErrorCodeSQLExceptionTranslator
/*  23:    */   extends AbstractFallbackSQLExceptionTranslator
/*  24:    */ {
/*  25:    */   private static final int MESSAGE_ONLY_CONSTRUCTOR = 1;
/*  26:    */   private static final int MESSAGE_THROWABLE_CONSTRUCTOR = 2;
/*  27:    */   private static final int MESSAGE_SQLEX_CONSTRUCTOR = 3;
/*  28:    */   private static final int MESSAGE_SQL_THROWABLE_CONSTRUCTOR = 4;
/*  29:    */   private static final int MESSAGE_SQL_SQLEX_CONSTRUCTOR = 5;
/*  30:    */   private SQLErrorCodes sqlErrorCodes;
/*  31:    */   
/*  32:    */   public SQLErrorCodeSQLExceptionTranslator()
/*  33:    */   {
/*  34: 86 */     if (JdkVersion.getMajorJavaVersion() >= 3) {
/*  35: 87 */       setFallbackTranslator(new SQLExceptionSubclassTranslator());
/*  36:    */     } else {
/*  37: 90 */       setFallbackTranslator(new SQLStateSQLExceptionTranslator());
/*  38:    */     }
/*  39:    */   }
/*  40:    */   
/*  41:    */   public SQLErrorCodeSQLExceptionTranslator(DataSource dataSource)
/*  42:    */   {
/*  43:103 */     this();
/*  44:104 */     setDataSource(dataSource);
/*  45:    */   }
/*  46:    */   
/*  47:    */   public SQLErrorCodeSQLExceptionTranslator(String dbName)
/*  48:    */   {
/*  49:116 */     this();
/*  50:117 */     setDatabaseProductName(dbName);
/*  51:    */   }
/*  52:    */   
/*  53:    */   public SQLErrorCodeSQLExceptionTranslator(SQLErrorCodes sec)
/*  54:    */   {
/*  55:126 */     this();
/*  56:127 */     this.sqlErrorCodes = sec;
/*  57:    */   }
/*  58:    */   
/*  59:    */   public void setDataSource(DataSource dataSource)
/*  60:    */   {
/*  61:141 */     this.sqlErrorCodes = SQLErrorCodesFactory.getInstance().getErrorCodes(dataSource);
/*  62:    */   }
/*  63:    */   
/*  64:    */   public void setDatabaseProductName(String dbName)
/*  65:    */   {
/*  66:153 */     this.sqlErrorCodes = SQLErrorCodesFactory.getInstance().getErrorCodes(dbName);
/*  67:    */   }
/*  68:    */   
/*  69:    */   public void setSqlErrorCodes(SQLErrorCodes sec)
/*  70:    */   {
/*  71:161 */     this.sqlErrorCodes = sec;
/*  72:    */   }
/*  73:    */   
/*  74:    */   public SQLErrorCodes getSqlErrorCodes()
/*  75:    */   {
/*  76:170 */     return this.sqlErrorCodes;
/*  77:    */   }
/*  78:    */   
/*  79:    */   protected DataAccessException doTranslate(String task, String sql, SQLException ex)
/*  80:    */   {
/*  81:176 */     SQLException sqlEx = ex;
/*  82:177 */     if (((sqlEx instanceof BatchUpdateException)) && (sqlEx.getNextException() != null))
/*  83:    */     {
/*  84:178 */       SQLException nestedSqlEx = sqlEx.getNextException();
/*  85:179 */       if ((nestedSqlEx.getErrorCode() > 0) || (nestedSqlEx.getSQLState() != null))
/*  86:    */       {
/*  87:180 */         this.logger.debug("Using nested SQLException from the BatchUpdateException");
/*  88:181 */         sqlEx = nestedSqlEx;
/*  89:    */       }
/*  90:    */     }
/*  91:186 */     DataAccessException dex = customTranslate(task, sql, sqlEx);
/*  92:187 */     if (dex != null) {
/*  93:188 */       return dex;
/*  94:    */     }
/*  95:192 */     if (this.sqlErrorCodes != null)
/*  96:    */     {
/*  97:193 */       SQLExceptionTranslator customTranslator = this.sqlErrorCodes.getCustomSqlExceptionTranslator();
/*  98:194 */       if (customTranslator != null)
/*  99:    */       {
/* 100:195 */         DataAccessException customDex = customTranslator.translate(task, sql, sqlEx);
/* 101:196 */         if (customDex != null) {
/* 102:197 */           return customDex;
/* 103:    */         }
/* 104:    */       }
/* 105:    */     }
/* 106:203 */     if (this.sqlErrorCodes != null)
/* 107:    */     {
/* 108:204 */       String errorCode = null;
/* 109:205 */       if (this.sqlErrorCodes.isUseSqlStateForTranslation()) {
/* 110:206 */         errorCode = sqlEx.getSQLState();
/* 111:    */       } else {
/* 112:209 */         errorCode = Integer.toString(sqlEx.getErrorCode());
/* 113:    */       }
/* 114:212 */       if (errorCode != null)
/* 115:    */       {
/* 116:214 */         CustomSQLErrorCodesTranslation[] customTranslations = this.sqlErrorCodes.getCustomTranslations();
/* 117:215 */         if (customTranslations != null) {
/* 118:216 */           for (int i = 0; i < customTranslations.length; i++)
/* 119:    */           {
/* 120:217 */             CustomSQLErrorCodesTranslation customTranslation = customTranslations[i];
/* 121:218 */             if ((Arrays.binarySearch(customTranslation.getErrorCodes(), errorCode) >= 0) && 
/* 122:219 */               (customTranslation.getExceptionClass() != null))
/* 123:    */             {
/* 124:220 */               DataAccessException customException = createCustomException(task, sql, sqlEx, customTranslation.getExceptionClass());
/* 125:222 */               if (customException != null)
/* 126:    */               {
/* 127:223 */                 logTranslation(task, sql, sqlEx, true);
/* 128:224 */                 return customException;
/* 129:    */               }
/* 130:    */             }
/* 131:    */           }
/* 132:    */         }
/* 133:231 */         if (Arrays.binarySearch(this.sqlErrorCodes.getBadSqlGrammarCodes(), errorCode) >= 0)
/* 134:    */         {
/* 135:232 */           logTranslation(task, sql, sqlEx, false);
/* 136:233 */           return new BadSqlGrammarException(task, sql, sqlEx);
/* 137:    */         }
/* 138:235 */         if (Arrays.binarySearch(this.sqlErrorCodes.getInvalidResultSetAccessCodes(), errorCode) >= 0)
/* 139:    */         {
/* 140:236 */           logTranslation(task, sql, sqlEx, false);
/* 141:237 */           return new InvalidResultSetAccessException(task, sql, sqlEx);
/* 142:    */         }
/* 143:239 */         if (Arrays.binarySearch(this.sqlErrorCodes.getDuplicateKeyCodes(), errorCode) >= 0)
/* 144:    */         {
/* 145:240 */           logTranslation(task, sql, sqlEx, false);
/* 146:241 */           return new DuplicateKeyException(buildMessage(task, sql, sqlEx), sqlEx);
/* 147:    */         }
/* 148:243 */         if (Arrays.binarySearch(this.sqlErrorCodes.getDataIntegrityViolationCodes(), errorCode) >= 0)
/* 149:    */         {
/* 150:244 */           logTranslation(task, sql, sqlEx, false);
/* 151:245 */           return new DataIntegrityViolationException(buildMessage(task, sql, sqlEx), sqlEx);
/* 152:    */         }
/* 153:247 */         if (Arrays.binarySearch(this.sqlErrorCodes.getPermissionDeniedCodes(), errorCode) >= 0)
/* 154:    */         {
/* 155:248 */           logTranslation(task, sql, sqlEx, false);
/* 156:249 */           return new PermissionDeniedDataAccessException(buildMessage(task, sql, sqlEx), sqlEx);
/* 157:    */         }
/* 158:251 */         if (Arrays.binarySearch(this.sqlErrorCodes.getDataAccessResourceFailureCodes(), errorCode) >= 0)
/* 159:    */         {
/* 160:252 */           logTranslation(task, sql, sqlEx, false);
/* 161:253 */           return new DataAccessResourceFailureException(buildMessage(task, sql, sqlEx), sqlEx);
/* 162:    */         }
/* 163:255 */         if (Arrays.binarySearch(this.sqlErrorCodes.getTransientDataAccessResourceCodes(), errorCode) >= 0)
/* 164:    */         {
/* 165:256 */           logTranslation(task, sql, sqlEx, false);
/* 166:257 */           return new TransientDataAccessResourceException(buildMessage(task, sql, sqlEx), sqlEx);
/* 167:    */         }
/* 168:259 */         if (Arrays.binarySearch(this.sqlErrorCodes.getCannotAcquireLockCodes(), errorCode) >= 0)
/* 169:    */         {
/* 170:260 */           logTranslation(task, sql, sqlEx, false);
/* 171:261 */           return new CannotAcquireLockException(buildMessage(task, sql, sqlEx), sqlEx);
/* 172:    */         }
/* 173:263 */         if (Arrays.binarySearch(this.sqlErrorCodes.getDeadlockLoserCodes(), errorCode) >= 0)
/* 174:    */         {
/* 175:264 */           logTranslation(task, sql, sqlEx, false);
/* 176:265 */           return new DeadlockLoserDataAccessException(buildMessage(task, sql, sqlEx), sqlEx);
/* 177:    */         }
/* 178:267 */         if (Arrays.binarySearch(this.sqlErrorCodes.getCannotSerializeTransactionCodes(), errorCode) >= 0)
/* 179:    */         {
/* 180:268 */           logTranslation(task, sql, sqlEx, false);
/* 181:269 */           return new CannotSerializeTransactionException(buildMessage(task, sql, sqlEx), sqlEx);
/* 182:    */         }
/* 183:    */       }
/* 184:    */     }
/* 185:275 */     if (this.logger.isDebugEnabled())
/* 186:    */     {
/* 187:276 */       String codes = null;
/* 188:277 */       if ((this.sqlErrorCodes != null) && (this.sqlErrorCodes.isUseSqlStateForTranslation())) {
/* 189:278 */         codes = "SQL state '" + sqlEx.getSQLState() + "', error code '" + sqlEx.getErrorCode();
/* 190:    */       } else {
/* 191:281 */         codes = "Error code '" + sqlEx.getErrorCode() + "'";
/* 192:    */       }
/* 193:283 */       this.logger.debug("Unable to translate SQLException with " + codes + ", will now try the fallback translator");
/* 194:    */     }
/* 195:286 */     return null;
/* 196:    */   }
/* 197:    */   
/* 198:    */   protected DataAccessException customTranslate(String task, String sql, SQLException sqlEx)
/* 199:    */   {
/* 200:301 */     return null;
/* 201:    */   }
/* 202:    */   
/* 203:    */   protected DataAccessException createCustomException(String task, String sql, SQLException sqlEx, Class exceptionClass)
/* 204:    */   {
/* 205:    */     try
/* 206:    */     {
/* 207:322 */       int constructorType = 0;
/* 208:323 */       Constructor[] constructors = exceptionClass.getConstructors();
/* 209:324 */       for (int i = 0; i < constructors.length; i++)
/* 210:    */       {
/* 211:325 */         Class[] parameterTypes = constructors[i].getParameterTypes();
/* 212:326 */         if ((parameterTypes.length == 1) && (parameterTypes[0].equals(String.class)) && 
/* 213:327 */           (constructorType < 1)) {
/* 214:328 */           constructorType = 1;
/* 215:    */         }
/* 216:330 */         if ((parameterTypes.length == 2) && (parameterTypes[0].equals(String.class)) && (parameterTypes[1].equals(Throwable.class))) {
/* 217:332 */           if (constructorType < 2) {
/* 218:333 */             constructorType = 2;
/* 219:    */           }
/* 220:    */         }
/* 221:335 */         if ((parameterTypes.length == 2) && (parameterTypes[0].equals(String.class)) && (parameterTypes[1].equals(SQLException.class))) {
/* 222:337 */           if (constructorType < 3) {
/* 223:338 */             constructorType = 3;
/* 224:    */           }
/* 225:    */         }
/* 226:340 */         if ((parameterTypes.length == 3) && (parameterTypes[0].equals(String.class)) && (parameterTypes[1].equals(String.class)) && (parameterTypes[2].equals(Throwable.class))) {
/* 227:342 */           if (constructorType < 4) {
/* 228:343 */             constructorType = 4;
/* 229:    */           }
/* 230:    */         }
/* 231:345 */         if ((parameterTypes.length == 3) && (parameterTypes[0].equals(String.class)) && (parameterTypes[1].equals(String.class)) && (parameterTypes[2].equals(SQLException.class))) {
/* 232:347 */           if (constructorType < 5) {
/* 233:348 */             constructorType = 5;
/* 234:    */           }
/* 235:    */         }
/* 236:    */       }
/* 237:353 */       Constructor exceptionConstructor = null;
/* 238:354 */       switch (constructorType)
/* 239:    */       {
/* 240:    */       case 5: 
/* 241:356 */         Class[] messageAndSqlAndSqlExArgsClass = { String.class, String.class, SQLException.class };
/* 242:357 */         Object[] messageAndSqlAndSqlExArgs = { task, sql, sqlEx };
/* 243:358 */         exceptionConstructor = exceptionClass.getConstructor(messageAndSqlAndSqlExArgsClass);
/* 244:359 */         return (DataAccessException)exceptionConstructor.newInstance(messageAndSqlAndSqlExArgs);
/* 245:    */       case 4: 
/* 246:361 */         Class[] messageAndSqlAndThrowableArgsClass = { String.class, String.class, Throwable.class };
/* 247:362 */         Object[] messageAndSqlAndThrowableArgs = { task, sql, sqlEx };
/* 248:363 */         exceptionConstructor = exceptionClass.getConstructor(messageAndSqlAndThrowableArgsClass);
/* 249:364 */         return (DataAccessException)exceptionConstructor.newInstance(messageAndSqlAndThrowableArgs);
/* 250:    */       case 3: 
/* 251:366 */         Class[] messageAndSqlExArgsClass = { String.class, SQLException.class };
/* 252:367 */         Object[] messageAndSqlExArgs = { task + ": " + sqlEx.getMessage(), sqlEx };
/* 253:368 */         exceptionConstructor = exceptionClass.getConstructor(messageAndSqlExArgsClass);
/* 254:369 */         return (DataAccessException)exceptionConstructor.newInstance(messageAndSqlExArgs);
/* 255:    */       case 2: 
/* 256:371 */         Class[] messageAndThrowableArgsClass = { String.class, Throwable.class };
/* 257:372 */         Object[] messageAndThrowableArgs = { task + ": " + sqlEx.getMessage(), sqlEx };
/* 258:373 */         exceptionConstructor = exceptionClass.getConstructor(messageAndThrowableArgsClass);
/* 259:374 */         return (DataAccessException)exceptionConstructor.newInstance(messageAndThrowableArgs);
/* 260:    */       case 1: 
/* 261:376 */         Class[] messageOnlyArgsClass = { String.class };
/* 262:377 */         Object[] messageOnlyArgs = { task + ": " + sqlEx.getMessage() };
/* 263:378 */         exceptionConstructor = exceptionClass.getConstructor(messageOnlyArgsClass);
/* 264:379 */         return (DataAccessException)exceptionConstructor.newInstance(messageOnlyArgs);
/* 265:    */       }
/* 266:381 */       if (this.logger.isWarnEnabled()) {
/* 267:382 */         this.logger.warn("Unable to find appropriate constructor of custom exception class [" + exceptionClass.getName() + "]");
/* 268:    */       }
/* 269:385 */       return null;
/* 270:    */     }
/* 271:    */     catch (Throwable ex)
/* 272:    */     {
/* 273:389 */       if (this.logger.isWarnEnabled()) {
/* 274:390 */         this.logger.warn("Unable to instantiate custom exception class [" + exceptionClass.getName() + "]", ex);
/* 275:    */       }
/* 276:    */     }
/* 277:392 */     return null;
/* 278:    */   }
/* 279:    */   
/* 280:    */   private void logTranslation(String task, String sql, SQLException sqlEx, boolean custom)
/* 281:    */   {
/* 282:397 */     if (this.logger.isDebugEnabled())
/* 283:    */     {
/* 284:398 */       String intro = custom ? "Custom translation of" : "Translating";
/* 285:399 */       this.logger.debug(intro + " SQLException with SQL state '" + sqlEx.getSQLState() + "', error code '" + sqlEx.getErrorCode() + "', message [" + sqlEx.getMessage() + "]; SQL was [" + sql + "] for task [" + task + "]");
/* 286:    */     }
/* 287:    */   }
/* 288:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.support.SQLErrorCodeSQLExceptionTranslator
 * JD-Core Version:    0.7.0.1
 */