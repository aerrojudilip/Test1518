/*  1:   */ package org.springframework.jdbc.support;
/*  2:   */ 
/*  3:   */ import org.springframework.dao.DataAccessException;
/*  4:   */ import org.springframework.util.StringUtils;
/*  5:   */ 
/*  6:   */ public class CustomSQLErrorCodesTranslation
/*  7:   */ {
/*  8:33 */   private String[] errorCodes = new String[0];
/*  9:   */   private Class exceptionClass;
/* 10:   */   
/* 11:   */   public void setErrorCodes(String[] errorCodes)
/* 12:   */   {
/* 13:42 */     this.errorCodes = StringUtils.sortStringArray(errorCodes);
/* 14:   */   }
/* 15:   */   
/* 16:   */   public String[] getErrorCodes()
/* 17:   */   {
/* 18:49 */     return this.errorCodes;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public void setExceptionClass(Class exceptionClass)
/* 22:   */   {
/* 23:56 */     if (!DataAccessException.class.isAssignableFrom(exceptionClass)) {
/* 24:57 */       throw new IllegalArgumentException("Invalid exception class [" + exceptionClass + "]: needs to be a subclass of [org.springframework.dao.DataAccessException]");
/* 25:   */     }
/* 26:60 */     this.exceptionClass = exceptionClass;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public Class getExceptionClass()
/* 30:   */   {
/* 31:67 */     return this.exceptionClass;
/* 32:   */   }
/* 33:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.support.CustomSQLErrorCodesTranslation
 * JD-Core Version:    0.7.0.1
 */