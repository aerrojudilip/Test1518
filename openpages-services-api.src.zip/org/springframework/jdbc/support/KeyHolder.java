package org.springframework.jdbc.support;

import java.util.List;
import java.util.Map;
import org.springframework.dao.InvalidDataAccessApiUsageException;

public abstract interface KeyHolder
{
  public abstract Number getKey()
    throws InvalidDataAccessApiUsageException;
  
  public abstract Map<String, Object> getKeys()
    throws InvalidDataAccessApiUsageException;
  
  public abstract List<Map<String, Object>> getKeyList();
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.support.KeyHolder
 * JD-Core Version:    0.7.0.1
 */