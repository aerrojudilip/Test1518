/*   1:    */ package org.springframework.jdbc.support.lob;
/*   2:    */ 
/*   3:    */ import java.io.InputStream;
/*   4:    */ import java.io.OutputStream;
/*   5:    */ import java.io.Reader;
/*   6:    */ import java.io.Writer;
/*   7:    */ import java.lang.reflect.Field;
/*   8:    */ import java.lang.reflect.InvocationTargetException;
/*   9:    */ import java.lang.reflect.Method;
/*  10:    */ import java.sql.Blob;
/*  11:    */ import java.sql.Clob;
/*  12:    */ import java.sql.Connection;
/*  13:    */ import java.sql.PreparedStatement;
/*  14:    */ import java.sql.ResultSet;
/*  15:    */ import java.sql.SQLException;
/*  16:    */ import java.sql.Statement;
/*  17:    */ import java.util.HashMap;
/*  18:    */ import java.util.Iterator;
/*  19:    */ import java.util.LinkedList;
/*  20:    */ import java.util.List;
/*  21:    */ import java.util.Map;
/*  22:    */ import org.apache.commons.logging.Log;
/*  23:    */ import org.apache.commons.logging.LogFactory;
/*  24:    */ import org.springframework.dao.DataAccessResourceFailureException;
/*  25:    */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*  26:    */ import org.springframework.jdbc.support.nativejdbc.NativeJdbcExtractor;
/*  27:    */ import org.springframework.util.FileCopyUtils;
/*  28:    */ 
/*  29:    */ public class OracleLobHandler
/*  30:    */   extends AbstractLobHandler
/*  31:    */ {
/*  32:    */   private static final String BLOB_CLASS_NAME = "oracle.sql.BLOB";
/*  33:    */   private static final String CLOB_CLASS_NAME = "oracle.sql.CLOB";
/*  34:    */   private static final String DURATION_SESSION_FIELD_NAME = "DURATION_SESSION";
/*  35:    */   private static final String MODE_READWRITE_FIELD_NAME = "MODE_READWRITE";
/*  36:    */   private static final String MODE_READONLY_FIELD_NAME = "MODE_READONLY";
/*  37:    */   protected final Log logger;
/*  38:    */   private NativeJdbcExtractor nativeJdbcExtractor;
/*  39:    */   private Boolean cache;
/*  40:    */   private Boolean releaseResourcesAfterRead;
/*  41:    */   private Class blobClass;
/*  42:    */   private Class clobClass;
/*  43:    */   private final Map<Class, Integer> durationSessionConstants;
/*  44:    */   private final Map<Class, Integer> modeReadWriteConstants;
/*  45:    */   private final Map<Class, Integer> modeReadOnlyConstants;
/*  46:    */   
/*  47:    */   public OracleLobHandler()
/*  48:    */   {
/*  49: 90 */     this.logger = LogFactory.getLog(getClass());
/*  50:    */     
/*  51:    */ 
/*  52:    */ 
/*  53: 94 */     this.cache = Boolean.TRUE;
/*  54:    */     
/*  55: 96 */     this.releaseResourcesAfterRead = Boolean.FALSE;
/*  56:    */     
/*  57:    */ 
/*  58:    */ 
/*  59:    */ 
/*  60:    */ 
/*  61:102 */     this.durationSessionConstants = new HashMap(2);
/*  62:    */     
/*  63:104 */     this.modeReadWriteConstants = new HashMap(2);
/*  64:    */     
/*  65:106 */     this.modeReadOnlyConstants = new HashMap(2);
/*  66:    */   }
/*  67:    */   
/*  68:    */   public void setNativeJdbcExtractor(NativeJdbcExtractor nativeJdbcExtractor)
/*  69:    */   {
/*  70:128 */     this.nativeJdbcExtractor = nativeJdbcExtractor;
/*  71:    */   }
/*  72:    */   
/*  73:    */   public void setCache(boolean cache)
/*  74:    */   {
/*  75:142 */     this.cache = Boolean.valueOf(cache);
/*  76:    */   }
/*  77:    */   
/*  78:    */   public void setReleaseResourcesAfterRead(boolean releaseResources)
/*  79:    */   {
/*  80:164 */     this.releaseResourcesAfterRead = Boolean.valueOf(releaseResources);
/*  81:    */   }
/*  82:    */   
/*  83:    */   protected synchronized void initOracleDriverClasses(Connection con)
/*  84:    */   {
/*  85:185 */     if (this.blobClass == null) {
/*  86:    */       try
/*  87:    */       {
/*  88:188 */         this.blobClass = con.getClass().getClassLoader().loadClass("oracle.sql.BLOB");
/*  89:189 */         this.durationSessionConstants.put(this.blobClass, Integer.valueOf(this.blobClass.getField("DURATION_SESSION").getInt(null)));
/*  90:    */         
/*  91:191 */         this.modeReadWriteConstants.put(this.blobClass, Integer.valueOf(this.blobClass.getField("MODE_READWRITE").getInt(null)));
/*  92:    */         
/*  93:193 */         this.modeReadOnlyConstants.put(this.blobClass, Integer.valueOf(this.blobClass.getField("MODE_READONLY").getInt(null)));
/*  94:    */         
/*  95:    */ 
/*  96:    */ 
/*  97:197 */         this.clobClass = con.getClass().getClassLoader().loadClass("oracle.sql.CLOB");
/*  98:198 */         this.durationSessionConstants.put(this.clobClass, Integer.valueOf(this.clobClass.getField("DURATION_SESSION").getInt(null)));
/*  99:    */         
/* 100:200 */         this.modeReadWriteConstants.put(this.clobClass, Integer.valueOf(this.clobClass.getField("MODE_READWRITE").getInt(null)));
/* 101:    */         
/* 102:202 */         this.modeReadOnlyConstants.put(this.clobClass, Integer.valueOf(this.clobClass.getField("MODE_READONLY").getInt(null)));
/* 103:    */       }
/* 104:    */       catch (Exception ex)
/* 105:    */       {
/* 106:206 */         throw new InvalidDataAccessApiUsageException("Couldn't initialize OracleLobHandler because Oracle driver classes are not available. Note that OracleLobHandler requires Oracle JDBC driver 9i or higher!", ex);
/* 107:    */       }
/* 108:    */     }
/* 109:    */   }
/* 110:    */   
/* 111:    */   public byte[] getBlobAsBytes(ResultSet rs, int columnIndex)
/* 112:    */     throws SQLException
/* 113:    */   {
/* 114:215 */     this.logger.debug("Returning Oracle BLOB as bytes");
/* 115:216 */     Blob blob = rs.getBlob(columnIndex);
/* 116:217 */     initializeResourcesBeforeRead(rs.getStatement().getConnection(), blob);
/* 117:218 */     byte[] retVal = blob != null ? blob.getBytes(1L, (int)blob.length()) : null;
/* 118:219 */     releaseResourcesAfterRead(rs.getStatement().getConnection(), blob);
/* 119:220 */     return retVal;
/* 120:    */   }
/* 121:    */   
/* 122:    */   public InputStream getBlobAsBinaryStream(ResultSet rs, int columnIndex)
/* 123:    */     throws SQLException
/* 124:    */   {
/* 125:224 */     this.logger.debug("Returning Oracle BLOB as binary stream");
/* 126:225 */     Blob blob = rs.getBlob(columnIndex);
/* 127:226 */     initializeResourcesBeforeRead(rs.getStatement().getConnection(), blob);
/* 128:227 */     InputStream retVal = blob != null ? blob.getBinaryStream() : null;
/* 129:228 */     releaseResourcesAfterRead(rs.getStatement().getConnection(), blob);
/* 130:229 */     return retVal;
/* 131:    */   }
/* 132:    */   
/* 133:    */   public String getClobAsString(ResultSet rs, int columnIndex)
/* 134:    */     throws SQLException
/* 135:    */   {
/* 136:233 */     this.logger.debug("Returning Oracle CLOB as string");
/* 137:234 */     Clob clob = rs.getClob(columnIndex);
/* 138:235 */     initializeResourcesBeforeRead(rs.getStatement().getConnection(), clob);
/* 139:236 */     String retVal = clob != null ? clob.getSubString(1L, (int)clob.length()) : null;
/* 140:237 */     releaseResourcesAfterRead(rs.getStatement().getConnection(), clob);
/* 141:238 */     return retVal;
/* 142:    */   }
/* 143:    */   
/* 144:    */   public InputStream getClobAsAsciiStream(ResultSet rs, int columnIndex)
/* 145:    */     throws SQLException
/* 146:    */   {
/* 147:242 */     this.logger.debug("Returning Oracle CLOB as ASCII stream");
/* 148:243 */     Clob clob = rs.getClob(columnIndex);
/* 149:244 */     initializeResourcesBeforeRead(rs.getStatement().getConnection(), clob);
/* 150:245 */     InputStream retVal = clob != null ? clob.getAsciiStream() : null;
/* 151:246 */     releaseResourcesAfterRead(rs.getStatement().getConnection(), clob);
/* 152:247 */     return retVal;
/* 153:    */   }
/* 154:    */   
/* 155:    */   public Reader getClobAsCharacterStream(ResultSet rs, int columnIndex)
/* 156:    */     throws SQLException
/* 157:    */   {
/* 158:251 */     this.logger.debug("Returning Oracle CLOB as character stream");
/* 159:252 */     Clob clob = rs.getClob(columnIndex);
/* 160:253 */     initializeResourcesBeforeRead(rs.getStatement().getConnection(), clob);
/* 161:254 */     Reader retVal = clob != null ? clob.getCharacterStream() : null;
/* 162:255 */     releaseResourcesAfterRead(rs.getStatement().getConnection(), clob);
/* 163:256 */     return retVal;
/* 164:    */   }
/* 165:    */   
/* 166:    */   public LobCreator getLobCreator()
/* 167:    */   {
/* 168:260 */     return new OracleLobCreator();
/* 169:    */   }
/* 170:    */   
/* 171:    */   protected void initializeResourcesBeforeRead(Connection con, Object lob)
/* 172:    */   {
/* 173:273 */     if (this.releaseResourcesAfterRead.booleanValue())
/* 174:    */     {
/* 175:274 */       initOracleDriverClasses(con);
/* 176:    */       try
/* 177:    */       {
/* 178:279 */         Method isTemporary = lob.getClass().getMethod("isTemporary", new Class[0]);
/* 179:280 */         Boolean temporary = (Boolean)isTemporary.invoke(lob, new Object[0]);
/* 180:281 */         if (!temporary.booleanValue())
/* 181:    */         {
/* 182:285 */           Method open = lob.getClass().getMethod("open", new Class[] { Integer.TYPE });
/* 183:286 */           open.invoke(lob, new Object[] { this.modeReadOnlyConstants.get(lob.getClass()) });
/* 184:    */         }
/* 185:    */       }
/* 186:    */       catch (InvocationTargetException ex)
/* 187:    */       {
/* 188:290 */         this.logger.error("Could not open Oracle LOB", ex.getTargetException());
/* 189:    */       }
/* 190:    */       catch (Exception ex)
/* 191:    */       {
/* 192:293 */         throw new DataAccessResourceFailureException("Could not open Oracle LOB", ex);
/* 193:    */       }
/* 194:    */     }
/* 195:    */   }
/* 196:    */   
/* 197:    */   protected void releaseResourcesAfterRead(Connection con, Object lob)
/* 198:    */   {
/* 199:311 */     if (this.releaseResourcesAfterRead.booleanValue())
/* 200:    */     {
/* 201:312 */       initOracleDriverClasses(con);
/* 202:313 */       Boolean temporary = Boolean.FALSE;
/* 203:    */       try
/* 204:    */       {
/* 205:318 */         Method isTemporary = lob.getClass().getMethod("isTemporary", new Class[0]);
/* 206:319 */         temporary = (Boolean)isTemporary.invoke(lob, new Object[0]);
/* 207:320 */         if (temporary.booleanValue())
/* 208:    */         {
/* 209:324 */           Method freeTemporary = lob.getClass().getMethod("freeTemporary", new Class[0]);
/* 210:325 */           freeTemporary.invoke(lob, new Object[0]);
/* 211:    */         }
/* 212:    */         else
/* 213:    */         {
/* 214:331 */           Method isOpen = lob.getClass().getMethod("isOpen", new Class[0]);
/* 215:332 */           Boolean open = (Boolean)isOpen.invoke(lob, new Object[0]);
/* 216:333 */           if (open.booleanValue())
/* 217:    */           {
/* 218:337 */             Method close = lob.getClass().getMethod("close", new Class[0]);
/* 219:338 */             close.invoke(lob, new Object[0]);
/* 220:    */           }
/* 221:    */         }
/* 222:    */       }
/* 223:    */       catch (InvocationTargetException ex)
/* 224:    */       {
/* 225:343 */         if (temporary.booleanValue()) {
/* 226:344 */           this.logger.error("Could not free Oracle LOB", ex.getTargetException());
/* 227:    */         } else {
/* 228:347 */           this.logger.error("Could not close Oracle LOB", ex.getTargetException());
/* 229:    */         }
/* 230:    */       }
/* 231:    */       catch (Exception ex)
/* 232:    */       {
/* 233:351 */         if (temporary.booleanValue()) {
/* 234:352 */           throw new DataAccessResourceFailureException("Could not free Oracle LOB", ex);
/* 235:    */         }
/* 236:355 */         throw new DataAccessResourceFailureException("Could not close Oracle LOB", ex);
/* 237:    */       }
/* 238:    */     }
/* 239:    */   }
/* 240:    */   
/* 241:    */   protected static abstract interface LobCallback
/* 242:    */   {
/* 243:    */     public abstract void populateLob(Object paramObject)
/* 244:    */       throws Exception;
/* 245:    */   }
/* 246:    */   
/* 247:    */   protected class OracleLobCreator
/* 248:    */     implements LobCreator
/* 249:    */   {
/* 250:369 */     private final List createdLobs = new LinkedList();
/* 251:    */     
/* 252:    */     protected OracleLobCreator() {}
/* 253:    */     
/* 254:    */     public void setBlobAsBytes(PreparedStatement ps, int paramIndex, final byte[] content)
/* 255:    */       throws SQLException
/* 256:    */     {
/* 257:374 */       if (content != null)
/* 258:    */       {
/* 259:375 */         Blob blob = (Blob)createLob(ps, false, new OracleLobHandler.LobCallback()
/* 260:    */         {
/* 261:    */           public void populateLob(Object lob)
/* 262:    */             throws Exception
/* 263:    */           {
/* 264:377 */             Method methodToInvoke = lob.getClass().getMethod("getBinaryOutputStream", new Class[0]);
/* 265:378 */             OutputStream out = (OutputStream)methodToInvoke.invoke(lob, new Object[0]);
/* 266:379 */             FileCopyUtils.copy(content, out);
/* 267:    */           }
/* 268:381 */         });
/* 269:382 */         ps.setBlob(paramIndex, blob);
/* 270:383 */         if (OracleLobHandler.this.logger.isDebugEnabled()) {
/* 271:384 */           OracleLobHandler.this.logger.debug("Set bytes for Oracle BLOB with length " + blob.length());
/* 272:    */         }
/* 273:    */       }
/* 274:    */       else
/* 275:    */       {
/* 276:388 */         ps.setBlob(paramIndex, (Blob)null);
/* 277:389 */         OracleLobHandler.this.logger.debug("Set Oracle BLOB to null");
/* 278:    */       }
/* 279:    */     }
/* 280:    */     
/* 281:    */     public void setBlobAsBinaryStream(PreparedStatement ps, int paramIndex, final InputStream binaryStream, int contentLength)
/* 282:    */       throws SQLException
/* 283:    */     {
/* 284:397 */       if (binaryStream != null)
/* 285:    */       {
/* 286:398 */         Blob blob = (Blob)createLob(ps, false, new OracleLobHandler.LobCallback()
/* 287:    */         {
/* 288:    */           public void populateLob(Object lob)
/* 289:    */             throws Exception
/* 290:    */           {
/* 291:400 */             Method methodToInvoke = lob.getClass().getMethod("getBinaryOutputStream", (Class[])null);
/* 292:401 */             OutputStream out = (OutputStream)methodToInvoke.invoke(lob, (Object[])null);
/* 293:402 */             FileCopyUtils.copy(binaryStream, out);
/* 294:    */           }
/* 295:404 */         });
/* 296:405 */         ps.setBlob(paramIndex, blob);
/* 297:406 */         if (OracleLobHandler.this.logger.isDebugEnabled()) {
/* 298:407 */           OracleLobHandler.this.logger.debug("Set binary stream for Oracle BLOB with length " + blob.length());
/* 299:    */         }
/* 300:    */       }
/* 301:    */       else
/* 302:    */       {
/* 303:411 */         ps.setBlob(paramIndex, (Blob)null);
/* 304:412 */         OracleLobHandler.this.logger.debug("Set Oracle BLOB to null");
/* 305:    */       }
/* 306:    */     }
/* 307:    */     
/* 308:    */     public void setClobAsString(PreparedStatement ps, int paramIndex, final String content)
/* 309:    */       throws SQLException
/* 310:    */     {
/* 311:419 */       if (content != null)
/* 312:    */       {
/* 313:420 */         Clob clob = (Clob)createLob(ps, true, new OracleLobHandler.LobCallback()
/* 314:    */         {
/* 315:    */           public void populateLob(Object lob)
/* 316:    */             throws Exception
/* 317:    */           {
/* 318:422 */             Method methodToInvoke = lob.getClass().getMethod("getCharacterOutputStream", (Class[])null);
/* 319:423 */             Writer writer = (Writer)methodToInvoke.invoke(lob, (Object[])null);
/* 320:424 */             FileCopyUtils.copy(content, writer);
/* 321:    */           }
/* 322:426 */         });
/* 323:427 */         ps.setClob(paramIndex, clob);
/* 324:428 */         if (OracleLobHandler.this.logger.isDebugEnabled()) {
/* 325:429 */           OracleLobHandler.this.logger.debug("Set string for Oracle CLOB with length " + clob.length());
/* 326:    */         }
/* 327:    */       }
/* 328:    */       else
/* 329:    */       {
/* 330:433 */         ps.setClob(paramIndex, (Clob)null);
/* 331:434 */         OracleLobHandler.this.logger.debug("Set Oracle CLOB to null");
/* 332:    */       }
/* 333:    */     }
/* 334:    */     
/* 335:    */     public void setClobAsAsciiStream(PreparedStatement ps, int paramIndex, final InputStream asciiStream, int contentLength)
/* 336:    */       throws SQLException
/* 337:    */     {
/* 338:442 */       if (asciiStream != null)
/* 339:    */       {
/* 340:443 */         Clob clob = (Clob)createLob(ps, true, new OracleLobHandler.LobCallback()
/* 341:    */         {
/* 342:    */           public void populateLob(Object lob)
/* 343:    */             throws Exception
/* 344:    */           {
/* 345:445 */             Method methodToInvoke = lob.getClass().getMethod("getAsciiOutputStream", (Class[])null);
/* 346:446 */             OutputStream out = (OutputStream)methodToInvoke.invoke(lob, (Object[])null);
/* 347:447 */             FileCopyUtils.copy(asciiStream, out);
/* 348:    */           }
/* 349:449 */         });
/* 350:450 */         ps.setClob(paramIndex, clob);
/* 351:451 */         if (OracleLobHandler.this.logger.isDebugEnabled()) {
/* 352:452 */           OracleLobHandler.this.logger.debug("Set ASCII stream for Oracle CLOB with length " + clob.length());
/* 353:    */         }
/* 354:    */       }
/* 355:    */       else
/* 356:    */       {
/* 357:456 */         ps.setClob(paramIndex, (Clob)null);
/* 358:457 */         OracleLobHandler.this.logger.debug("Set Oracle CLOB to null");
/* 359:    */       }
/* 360:    */     }
/* 361:    */     
/* 362:    */     public void setClobAsCharacterStream(PreparedStatement ps, int paramIndex, final Reader characterStream, int contentLength)
/* 363:    */       throws SQLException
/* 364:    */     {
/* 365:465 */       if (characterStream != null)
/* 366:    */       {
/* 367:466 */         Clob clob = (Clob)createLob(ps, true, new OracleLobHandler.LobCallback()
/* 368:    */         {
/* 369:    */           public void populateLob(Object lob)
/* 370:    */             throws Exception
/* 371:    */           {
/* 372:468 */             Method methodToInvoke = lob.getClass().getMethod("getCharacterOutputStream", (Class[])null);
/* 373:469 */             Writer writer = (Writer)methodToInvoke.invoke(lob, (Object[])null);
/* 374:470 */             FileCopyUtils.copy(characterStream, writer);
/* 375:    */           }
/* 376:472 */         });
/* 377:473 */         ps.setClob(paramIndex, clob);
/* 378:474 */         if (OracleLobHandler.this.logger.isDebugEnabled()) {
/* 379:475 */           OracleLobHandler.this.logger.debug("Set character stream for Oracle CLOB with length " + clob.length());
/* 380:    */         }
/* 381:    */       }
/* 382:    */       else
/* 383:    */       {
/* 384:479 */         ps.setClob(paramIndex, (Clob)null);
/* 385:480 */         OracleLobHandler.this.logger.debug("Set Oracle CLOB to null");
/* 386:    */       }
/* 387:    */     }
/* 388:    */     
/* 389:    */     protected Object createLob(PreparedStatement ps, boolean clob, OracleLobHandler.LobCallback callback)
/* 390:    */       throws SQLException
/* 391:    */     {
/* 392:491 */       Connection con = null;
/* 393:    */       try
/* 394:    */       {
/* 395:493 */         con = getOracleConnection(ps);
/* 396:494 */         OracleLobHandler.this.initOracleDriverClasses(con);
/* 397:495 */         Object lob = prepareLob(con, clob ? OracleLobHandler.this.clobClass : OracleLobHandler.this.blobClass);
/* 398:496 */         callback.populateLob(lob);
/* 399:497 */         lob.getClass().getMethod("close", (Class[])null).invoke(lob, (Object[])null);
/* 400:498 */         this.createdLobs.add(lob);
/* 401:499 */         if (OracleLobHandler.this.logger.isDebugEnabled()) {
/* 402:500 */           OracleLobHandler.this.logger.debug("Created new Oracle " + (clob ? "CLOB" : "BLOB"));
/* 403:    */         }
/* 404:502 */         return lob;
/* 405:    */       }
/* 406:    */       catch (SQLException ex)
/* 407:    */       {
/* 408:505 */         throw ex;
/* 409:    */       }
/* 410:    */       catch (InvocationTargetException ex)
/* 411:    */       {
/* 412:508 */         if ((ex.getTargetException() instanceof SQLException)) {
/* 413:509 */           throw ((SQLException)ex.getTargetException());
/* 414:    */         }
/* 415:511 */         if ((con != null) && ((ex.getTargetException() instanceof ClassCastException))) {
/* 416:512 */           throw new InvalidDataAccessApiUsageException("OracleLobCreator needs to work on [oracle.jdbc.OracleConnection], not on [" + con.getClass().getName() + "]: specify a corresponding NativeJdbcExtractor", ex.getTargetException());
/* 417:    */         }
/* 418:518 */         throw new DataAccessResourceFailureException("Could not create Oracle LOB", ex.getTargetException());
/* 419:    */       }
/* 420:    */       catch (Exception ex)
/* 421:    */       {
/* 422:523 */         throw new DataAccessResourceFailureException("Could not create Oracle LOB", ex);
/* 423:    */       }
/* 424:    */     }
/* 425:    */     
/* 426:    */     protected Connection getOracleConnection(PreparedStatement ps)
/* 427:    */       throws SQLException, ClassNotFoundException
/* 428:    */     {
/* 429:533 */       return OracleLobHandler.this.nativeJdbcExtractor != null ? OracleLobHandler.this.nativeJdbcExtractor.getNativeConnectionFromStatement(ps) : ps.getConnection();
/* 430:    */     }
/* 431:    */     
/* 432:    */     protected Object prepareLob(Connection con, Class lobClass)
/* 433:    */       throws Exception
/* 434:    */     {
/* 435:546 */       Method createTemporary = lobClass.getMethod("createTemporary", new Class[] { Connection.class, Boolean.TYPE, Integer.TYPE });
/* 436:    */       
/* 437:548 */       Object lob = createTemporary.invoke(null, new Object[] { con, OracleLobHandler.this.cache, OracleLobHandler.this.durationSessionConstants.get(lobClass) });
/* 438:549 */       Method open = lobClass.getMethod("open", new Class[] { Integer.TYPE });
/* 439:550 */       open.invoke(lob, new Object[] { OracleLobHandler.this.modeReadWriteConstants.get(lobClass) });
/* 440:551 */       return lob;
/* 441:    */     }
/* 442:    */     
/* 443:    */     public void close()
/* 444:    */     {
/* 445:    */       try
/* 446:    */       {
/* 447:559 */         for (it = this.createdLobs.iterator(); it.hasNext();)
/* 448:    */         {
/* 449:564 */           Object lob = it.next();
/* 450:565 */           Method freeTemporary = lob.getClass().getMethod("freeTemporary", new Class[0]);
/* 451:566 */           freeTemporary.invoke(lob, new Object[0]);
/* 452:567 */           it.remove();
/* 453:    */         }
/* 454:    */       }
/* 455:    */       catch (InvocationTargetException ex)
/* 456:    */       {
/* 457:    */         Iterator it;
/* 458:571 */         OracleLobHandler.this.logger.error("Could not free Oracle LOB", ex.getTargetException());
/* 459:    */       }
/* 460:    */       catch (Exception ex)
/* 461:    */       {
/* 462:574 */         throw new DataAccessResourceFailureException("Could not free Oracle LOB", ex);
/* 463:    */       }
/* 464:    */     }
/* 465:    */   }
/* 466:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.support.lob.OracleLobHandler
 * JD-Core Version:    0.7.0.1
 */