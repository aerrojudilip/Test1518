/*   1:    */ package org.springframework.jdbc.support.lob;
/*   2:    */ 
/*   3:    */ import java.io.ByteArrayInputStream;
/*   4:    */ import java.io.InputStream;
/*   5:    */ import java.io.InputStreamReader;
/*   6:    */ import java.io.Reader;
/*   7:    */ import java.io.StringReader;
/*   8:    */ import java.io.UnsupportedEncodingException;
/*   9:    */ import java.sql.Blob;
/*  10:    */ import java.sql.Clob;
/*  11:    */ import java.sql.PreparedStatement;
/*  12:    */ import java.sql.ResultSet;
/*  13:    */ import java.sql.SQLException;
/*  14:    */ import org.apache.commons.logging.Log;
/*  15:    */ import org.apache.commons.logging.LogFactory;
/*  16:    */ 
/*  17:    */ public class DefaultLobHandler
/*  18:    */   extends AbstractLobHandler
/*  19:    */ {
/*  20:    */   protected final Log logger;
/*  21:    */   private boolean wrapAsLob;
/*  22:    */   private boolean streamAsLob;
/*  23:    */   
/*  24:    */   public DefaultLobHandler()
/*  25:    */   {
/*  26: 72 */     this.logger = LogFactory.getLog(getClass());
/*  27:    */     
/*  28: 74 */     this.wrapAsLob = false;
/*  29:    */     
/*  30: 76 */     this.streamAsLob = false;
/*  31:    */   }
/*  32:    */   
/*  33:    */   public void setWrapAsLob(boolean wrapAsLob)
/*  34:    */   {
/*  35: 94 */     this.wrapAsLob = wrapAsLob;
/*  36:    */   }
/*  37:    */   
/*  38:    */   public void setStreamAsLob(boolean streamAsLob)
/*  39:    */   {
/*  40:112 */     this.streamAsLob = streamAsLob;
/*  41:    */   }
/*  42:    */   
/*  43:    */   public byte[] getBlobAsBytes(ResultSet rs, int columnIndex)
/*  44:    */     throws SQLException
/*  45:    */   {
/*  46:117 */     this.logger.debug("Returning BLOB as bytes");
/*  47:118 */     if (this.wrapAsLob)
/*  48:    */     {
/*  49:119 */       Blob blob = rs.getBlob(columnIndex);
/*  50:120 */       return blob.getBytes(1L, (int)blob.length());
/*  51:    */     }
/*  52:123 */     return rs.getBytes(columnIndex);
/*  53:    */   }
/*  54:    */   
/*  55:    */   public InputStream getBlobAsBinaryStream(ResultSet rs, int columnIndex)
/*  56:    */     throws SQLException
/*  57:    */   {
/*  58:128 */     this.logger.debug("Returning BLOB as binary stream");
/*  59:129 */     if (this.wrapAsLob)
/*  60:    */     {
/*  61:130 */       Blob blob = rs.getBlob(columnIndex);
/*  62:131 */       return blob.getBinaryStream();
/*  63:    */     }
/*  64:134 */     return rs.getBinaryStream(columnIndex);
/*  65:    */   }
/*  66:    */   
/*  67:    */   public String getClobAsString(ResultSet rs, int columnIndex)
/*  68:    */     throws SQLException
/*  69:    */   {
/*  70:139 */     this.logger.debug("Returning CLOB as string");
/*  71:140 */     if (this.wrapAsLob)
/*  72:    */     {
/*  73:141 */       Clob clob = rs.getClob(columnIndex);
/*  74:142 */       return clob.getSubString(1L, (int)clob.length());
/*  75:    */     }
/*  76:145 */     return rs.getString(columnIndex);
/*  77:    */   }
/*  78:    */   
/*  79:    */   public InputStream getClobAsAsciiStream(ResultSet rs, int columnIndex)
/*  80:    */     throws SQLException
/*  81:    */   {
/*  82:150 */     this.logger.debug("Returning CLOB as ASCII stream");
/*  83:151 */     if (this.wrapAsLob)
/*  84:    */     {
/*  85:152 */       Clob clob = rs.getClob(columnIndex);
/*  86:153 */       return clob.getAsciiStream();
/*  87:    */     }
/*  88:156 */     return rs.getAsciiStream(columnIndex);
/*  89:    */   }
/*  90:    */   
/*  91:    */   public Reader getClobAsCharacterStream(ResultSet rs, int columnIndex)
/*  92:    */     throws SQLException
/*  93:    */   {
/*  94:161 */     this.logger.debug("Returning CLOB as character stream");
/*  95:162 */     if (this.wrapAsLob)
/*  96:    */     {
/*  97:163 */       Clob clob = rs.getClob(columnIndex);
/*  98:164 */       return clob.getCharacterStream();
/*  99:    */     }
/* 100:167 */     return rs.getCharacterStream(columnIndex);
/* 101:    */   }
/* 102:    */   
/* 103:    */   public LobCreator getLobCreator()
/* 104:    */   {
/* 105:172 */     return new DefaultLobCreator();
/* 106:    */   }
/* 107:    */   
/* 108:    */   protected class DefaultLobCreator
/* 109:    */     implements LobCreator
/* 110:    */   {
/* 111:    */     protected DefaultLobCreator() {}
/* 112:    */     
/* 113:    */     public void setBlobAsBytes(PreparedStatement ps, int paramIndex, byte[] content)
/* 114:    */       throws SQLException
/* 115:    */     {
/* 116:185 */       if (DefaultLobHandler.this.streamAsLob)
/* 117:    */       {
/* 118:186 */         if (content != null) {
/* 119:187 */           ps.setBlob(paramIndex, new ByteArrayInputStream(content), content.length);
/* 120:    */         } else {
/* 121:190 */           ps.setBlob(paramIndex, (Blob)null);
/* 122:    */         }
/* 123:    */       }
/* 124:193 */       else if (DefaultLobHandler.this.wrapAsLob)
/* 125:    */       {
/* 126:194 */         if (content != null) {
/* 127:195 */           ps.setBlob(paramIndex, new PassThroughBlob(content));
/* 128:    */         } else {
/* 129:198 */           ps.setBlob(paramIndex, (Blob)null);
/* 130:    */         }
/* 131:    */       }
/* 132:    */       else {
/* 133:202 */         ps.setBytes(paramIndex, content);
/* 134:    */       }
/* 135:204 */       if (DefaultLobHandler.this.logger.isDebugEnabled()) {
/* 136:205 */         DefaultLobHandler.this.logger.debug(content != null ? "Set bytes for BLOB with length " + content.length : "Set BLOB to null");
/* 137:    */       }
/* 138:    */     }
/* 139:    */     
/* 140:    */     public void setBlobAsBinaryStream(PreparedStatement ps, int paramIndex, InputStream binaryStream, int contentLength)
/* 141:    */       throws SQLException
/* 142:    */     {
/* 143:214 */       if (DefaultLobHandler.this.streamAsLob)
/* 144:    */       {
/* 145:215 */         if (binaryStream != null) {
/* 146:216 */           ps.setBlob(paramIndex, binaryStream, contentLength);
/* 147:    */         } else {
/* 148:219 */           ps.setBlob(paramIndex, (Blob)null);
/* 149:    */         }
/* 150:    */       }
/* 151:222 */       else if (DefaultLobHandler.this.wrapAsLob)
/* 152:    */       {
/* 153:223 */         if (binaryStream != null) {
/* 154:224 */           ps.setBlob(paramIndex, new PassThroughBlob(binaryStream, contentLength));
/* 155:    */         } else {
/* 156:227 */           ps.setBlob(paramIndex, (Blob)null);
/* 157:    */         }
/* 158:    */       }
/* 159:    */       else {
/* 160:231 */         ps.setBinaryStream(paramIndex, binaryStream, contentLength);
/* 161:    */       }
/* 162:233 */       if (DefaultLobHandler.this.logger.isDebugEnabled()) {
/* 163:234 */         DefaultLobHandler.this.logger.debug(binaryStream != null ? "Set binary stream for BLOB with length " + contentLength : "Set BLOB to null");
/* 164:    */       }
/* 165:    */     }
/* 166:    */     
/* 167:    */     public void setClobAsString(PreparedStatement ps, int paramIndex, String content)
/* 168:    */       throws SQLException
/* 169:    */     {
/* 170:242 */       if (DefaultLobHandler.this.streamAsLob)
/* 171:    */       {
/* 172:243 */         if (content != null) {
/* 173:244 */           ps.setClob(paramIndex, new StringReader(content), content.length());
/* 174:    */         } else {
/* 175:247 */           ps.setClob(paramIndex, (Clob)null);
/* 176:    */         }
/* 177:    */       }
/* 178:250 */       else if (DefaultLobHandler.this.wrapAsLob)
/* 179:    */       {
/* 180:251 */         if (content != null) {
/* 181:252 */           ps.setClob(paramIndex, new PassThroughClob(content));
/* 182:    */         } else {
/* 183:255 */           ps.setClob(paramIndex, (Clob)null);
/* 184:    */         }
/* 185:    */       }
/* 186:    */       else {
/* 187:259 */         ps.setString(paramIndex, content);
/* 188:    */       }
/* 189:261 */       if (DefaultLobHandler.this.logger.isDebugEnabled()) {
/* 190:262 */         DefaultLobHandler.this.logger.debug(content != null ? "Set string for CLOB with length " + content.length() : "Set CLOB to null");
/* 191:    */       }
/* 192:    */     }
/* 193:    */     
/* 194:    */     public void setClobAsAsciiStream(PreparedStatement ps, int paramIndex, InputStream asciiStream, int contentLength)
/* 195:    */       throws SQLException
/* 196:    */     {
/* 197:271 */       if ((DefaultLobHandler.this.streamAsLob) || (DefaultLobHandler.this.wrapAsLob))
/* 198:    */       {
/* 199:272 */         if (asciiStream != null) {
/* 200:    */           try
/* 201:    */           {
/* 202:274 */             if (DefaultLobHandler.this.streamAsLob) {
/* 203:275 */               ps.setClob(paramIndex, new InputStreamReader(asciiStream, "US-ASCII"), contentLength);
/* 204:    */             } else {
/* 205:278 */               ps.setClob(paramIndex, new PassThroughClob(asciiStream, contentLength));
/* 206:    */             }
/* 207:    */           }
/* 208:    */           catch (UnsupportedEncodingException ex)
/* 209:    */           {
/* 210:282 */             throw new SQLException("US-ASCII encoding not supported: " + ex);
/* 211:    */           }
/* 212:    */         } else {
/* 213:286 */           ps.setClob(paramIndex, (Clob)null);
/* 214:    */         }
/* 215:    */       }
/* 216:    */       else {
/* 217:290 */         ps.setAsciiStream(paramIndex, asciiStream, contentLength);
/* 218:    */       }
/* 219:292 */       if (DefaultLobHandler.this.logger.isDebugEnabled()) {
/* 220:293 */         DefaultLobHandler.this.logger.debug(asciiStream != null ? "Set ASCII stream for CLOB with length " + contentLength : "Set CLOB to null");
/* 221:    */       }
/* 222:    */     }
/* 223:    */     
/* 224:    */     public void setClobAsCharacterStream(PreparedStatement ps, int paramIndex, Reader characterStream, int contentLength)
/* 225:    */       throws SQLException
/* 226:    */     {
/* 227:302 */       if (DefaultLobHandler.this.streamAsLob)
/* 228:    */       {
/* 229:303 */         if (characterStream != null) {
/* 230:304 */           ps.setClob(paramIndex, characterStream, contentLength);
/* 231:    */         } else {
/* 232:307 */           ps.setClob(paramIndex, (Clob)null);
/* 233:    */         }
/* 234:    */       }
/* 235:310 */       else if (DefaultLobHandler.this.wrapAsLob)
/* 236:    */       {
/* 237:311 */         if (characterStream != null) {
/* 238:312 */           ps.setClob(paramIndex, new PassThroughClob(characterStream, contentLength));
/* 239:    */         } else {
/* 240:315 */           ps.setClob(paramIndex, (Clob)null);
/* 241:    */         }
/* 242:    */       }
/* 243:    */       else {
/* 244:319 */         ps.setCharacterStream(paramIndex, characterStream, contentLength);
/* 245:    */       }
/* 246:321 */       if (DefaultLobHandler.this.logger.isDebugEnabled()) {
/* 247:322 */         DefaultLobHandler.this.logger.debug(characterStream != null ? "Set character stream for CLOB with length " + contentLength : "Set CLOB to null");
/* 248:    */       }
/* 249:    */     }
/* 250:    */     
/* 251:    */     public void close() {}
/* 252:    */   }
/* 253:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.support.lob.DefaultLobHandler
 * JD-Core Version:    0.7.0.1
 */