package org.springframework.jdbc.support.lob;

import java.io.InputStream;
import java.io.Reader;
import java.sql.ResultSet;
import java.sql.SQLException;

public abstract interface LobHandler
{
  public abstract byte[] getBlobAsBytes(ResultSet paramResultSet, String paramString)
    throws SQLException;
  
  public abstract byte[] getBlobAsBytes(ResultSet paramResultSet, int paramInt)
    throws SQLException;
  
  public abstract InputStream getBlobAsBinaryStream(ResultSet paramResultSet, String paramString)
    throws SQLException;
  
  public abstract InputStream getBlobAsBinaryStream(ResultSet paramResultSet, int paramInt)
    throws SQLException;
  
  public abstract String getClobAsString(ResultSet paramResultSet, String paramString)
    throws SQLException;
  
  public abstract String getClobAsString(ResultSet paramResultSet, int paramInt)
    throws SQLException;
  
  public abstract InputStream getClobAsAsciiStream(ResultSet paramResultSet, String paramString)
    throws SQLException;
  
  public abstract InputStream getClobAsAsciiStream(ResultSet paramResultSet, int paramInt)
    throws SQLException;
  
  public abstract Reader getClobAsCharacterStream(ResultSet paramResultSet, String paramString)
    throws SQLException;
  
  public abstract Reader getClobAsCharacterStream(ResultSet paramResultSet, int paramInt)
    throws SQLException;
  
  public abstract LobCreator getLobCreator();
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.support.lob.LobHandler
 * JD-Core Version:    0.7.0.1
 */