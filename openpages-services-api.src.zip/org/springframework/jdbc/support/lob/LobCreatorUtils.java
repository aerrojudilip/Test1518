/*  1:   */ package org.springframework.jdbc.support.lob;
/*  2:   */ 
/*  3:   */ import javax.transaction.Transaction;
/*  4:   */ import javax.transaction.TransactionManager;
/*  5:   */ import org.apache.commons.logging.Log;
/*  6:   */ import org.apache.commons.logging.LogFactory;
/*  7:   */ import org.springframework.transaction.TransactionSystemException;
/*  8:   */ import org.springframework.transaction.support.TransactionSynchronizationManager;
/*  9:   */ 
/* 10:   */ public abstract class LobCreatorUtils
/* 11:   */ {
/* 12:42 */   private static final Log logger = LogFactory.getLog(LobCreatorUtils.class);
/* 13:   */   
/* 14:   */   public static void registerTransactionSynchronization(LobCreator lobCreator, TransactionManager jtaTransactionManager)
/* 15:   */     throws IllegalStateException
/* 16:   */   {
/* 17:58 */     if (TransactionSynchronizationManager.isSynchronizationActive())
/* 18:   */     {
/* 19:59 */       logger.debug("Registering Spring transaction synchronization for LobCreator");
/* 20:60 */       TransactionSynchronizationManager.registerSynchronization(new SpringLobCreatorSynchronization(lobCreator));
/* 21:   */     }
/* 22:   */     else
/* 23:   */     {
/* 24:64 */       if (jtaTransactionManager != null) {
/* 25:   */         try
/* 26:   */         {
/* 27:66 */           int jtaStatus = jtaTransactionManager.getStatus();
/* 28:67 */           if ((jtaStatus == 0) || (jtaStatus == 1))
/* 29:   */           {
/* 30:68 */             logger.debug("Registering JTA transaction synchronization for LobCreator");
/* 31:69 */             jtaTransactionManager.getTransaction().registerSynchronization(new JtaLobCreatorSynchronization(lobCreator));
/* 32:   */             
/* 33:71 */             return;
/* 34:   */           }
/* 35:   */         }
/* 36:   */         catch (Throwable ex)
/* 37:   */         {
/* 38:75 */           throw new TransactionSystemException("Could not register synchronization with JTA TransactionManager", ex);
/* 39:   */         }
/* 40:   */       }
/* 41:79 */       throw new IllegalStateException("Active Spring transaction synchronization or active JTA transaction with specified [javax.transaction.TransactionManager] required");
/* 42:   */     }
/* 43:   */   }
/* 44:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.support.lob.LobCreatorUtils
 * JD-Core Version:    0.7.0.1
 */