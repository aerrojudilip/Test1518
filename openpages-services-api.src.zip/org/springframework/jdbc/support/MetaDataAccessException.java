/*  1:   */ package org.springframework.jdbc.support;
/*  2:   */ 
/*  3:   */ import org.springframework.core.NestedCheckedException;
/*  4:   */ 
/*  5:   */ public class MetaDataAccessException
/*  6:   */   extends NestedCheckedException
/*  7:   */ {
/*  8:   */   public MetaDataAccessException(String msg)
/*  9:   */   {
/* 10:38 */     super(msg);
/* 11:   */   }
/* 12:   */   
/* 13:   */   public MetaDataAccessException(String msg, Throwable cause)
/* 14:   */   {
/* 15:47 */     super(msg, cause);
/* 16:   */   }
/* 17:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.support.MetaDataAccessException
 * JD-Core Version:    0.7.0.1
 */