package org.springframework.jdbc.support.xml;

import java.sql.ResultSet;
import java.sql.SQLException;

public abstract interface SqlXmlObjectMappingHandler
  extends SqlXmlHandler
{
  public abstract Object getXmlAsObject(ResultSet paramResultSet, String paramString)
    throws SQLException;
  
  public abstract Object getXmlAsObject(ResultSet paramResultSet, int paramInt)
    throws SQLException;
  
  public abstract SqlXmlValue newMarshallingSqlXmlValue(Object paramObject);
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.support.xml.SqlXmlObjectMappingHandler
 * JD-Core Version:    0.7.0.1
 */