package org.springframework.jdbc.support.xml;

import java.io.IOException;
import java.io.OutputStream;

public abstract interface XmlBinaryStreamProvider
{
  public abstract void provideXml(OutputStream paramOutputStream)
    throws IOException;
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.support.xml.XmlBinaryStreamProvider
 * JD-Core Version:    0.7.0.1
 */