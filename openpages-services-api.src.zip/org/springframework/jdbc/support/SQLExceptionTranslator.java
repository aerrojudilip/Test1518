package org.springframework.jdbc.support;

import java.sql.SQLException;
import org.springframework.dao.DataAccessException;

public abstract interface SQLExceptionTranslator
{
  public abstract DataAccessException translate(String paramString1, String paramString2, SQLException paramSQLException);
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.support.SQLExceptionTranslator
 * JD-Core Version:    0.7.0.1
 */