package org.springframework.jdbc.support;

import java.sql.DatabaseMetaData;
import java.sql.SQLException;

public abstract interface DatabaseMetaDataCallback
{
  public abstract Object processMetaData(DatabaseMetaData paramDatabaseMetaData)
    throws SQLException, MetaDataAccessException;
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.support.DatabaseMetaDataCallback
 * JD-Core Version:    0.7.0.1
 */