/*  1:   */ package org.springframework.jdbc.support;
/*  2:   */ 
/*  3:   */ import java.util.HashMap;
/*  4:   */ import java.util.Map;
/*  5:   */ import org.springframework.beans.factory.InitializingBean;
/*  6:   */ 
/*  7:   */ public class CustomSQLExceptionTranslatorRegistrar
/*  8:   */   implements InitializingBean
/*  9:   */ {
/* 10:38 */   private final Map<String, SQLExceptionTranslator> translators = new HashMap();
/* 11:   */   
/* 12:   */   public void setTranslators(Map<String, SQLExceptionTranslator> translators)
/* 13:   */   {
/* 14:48 */     this.translators.putAll(translators);
/* 15:   */   }
/* 16:   */   
/* 17:   */   public void afterPropertiesSet()
/* 18:   */   {
/* 19:52 */     for (String dbName : this.translators.keySet()) {
/* 20:53 */       CustomSQLExceptionTranslatorRegistry.getInstance().registerTranslator(dbName, (SQLExceptionTranslator)this.translators.get(dbName));
/* 21:   */     }
/* 22:   */   }
/* 23:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.support.CustomSQLExceptionTranslatorRegistrar
 * JD-Core Version:    0.7.0.1
 */