/*   1:    */ package org.springframework.jdbc.support;
/*   2:    */ 
/*   3:    */ import java.util.Collections;
/*   4:    */ import java.util.Map;
/*   5:    */ import java.util.WeakHashMap;
/*   6:    */ import javax.sql.DataSource;
/*   7:    */ import org.apache.commons.logging.Log;
/*   8:    */ import org.apache.commons.logging.LogFactory;
/*   9:    */ import org.springframework.beans.BeansException;
/*  10:    */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*  11:    */ import org.springframework.beans.factory.xml.XmlBeanDefinitionReader;
/*  12:    */ import org.springframework.core.io.ClassPathResource;
/*  13:    */ import org.springframework.core.io.Resource;
/*  14:    */ import org.springframework.util.Assert;
/*  15:    */ import org.springframework.util.PatternMatchUtils;
/*  16:    */ 
/*  17:    */ public class SQLErrorCodesFactory
/*  18:    */ {
/*  19:    */   public static final String SQL_ERROR_CODE_OVERRIDE_PATH = "sql-error-codes.xml";
/*  20:    */   public static final String SQL_ERROR_CODE_DEFAULT_PATH = "org/springframework/jdbc/support/sql-error-codes.xml";
/*  21: 63 */   private static final Log logger = LogFactory.getLog(SQLErrorCodesFactory.class);
/*  22: 68 */   private static final SQLErrorCodesFactory instance = new SQLErrorCodesFactory();
/*  23:    */   private final Map<String, SQLErrorCodes> errorCodesMap;
/*  24:    */   
/*  25:    */   public static SQLErrorCodesFactory getInstance()
/*  26:    */   {
/*  27: 75 */     return instance;
/*  28:    */   }
/*  29:    */   
/*  30: 88 */   private final Map<DataSource, SQLErrorCodes> dataSourceCache = new WeakHashMap(16);
/*  31:    */   
/*  32:    */   protected SQLErrorCodesFactory()
/*  33:    */   {
/*  34:    */     Map<String, SQLErrorCodes> errorCodes;
/*  35:    */     try
/*  36:    */     {
/*  37:103 */       DefaultListableBeanFactory lbf = new DefaultListableBeanFactory();
/*  38:104 */       lbf.setBeanClassLoader(getClass().getClassLoader());
/*  39:105 */       XmlBeanDefinitionReader bdr = new XmlBeanDefinitionReader(lbf);
/*  40:    */       
/*  41:    */ 
/*  42:108 */       Resource resource = loadResource("org/springframework/jdbc/support/sql-error-codes.xml");
/*  43:109 */       if ((resource != null) && (resource.exists())) {
/*  44:110 */         bdr.loadBeanDefinitions(resource);
/*  45:    */       } else {
/*  46:113 */         logger.warn("Default sql-error-codes.xml not found (should be included in spring.jar)");
/*  47:    */       }
/*  48:117 */       resource = loadResource("sql-error-codes.xml");
/*  49:118 */       if ((resource != null) && (resource.exists()))
/*  50:    */       {
/*  51:119 */         bdr.loadBeanDefinitions(resource);
/*  52:120 */         logger.info("Found custom sql-error-codes.xml file at the root of the classpath");
/*  53:    */       }
/*  54:124 */       errorCodes = lbf.getBeansOfType(SQLErrorCodes.class, true, false);
/*  55:125 */       if (logger.isInfoEnabled()) {
/*  56:126 */         logger.info("SQLErrorCodes loaded: " + errorCodes.keySet());
/*  57:    */       }
/*  58:    */     }
/*  59:    */     catch (BeansException ex)
/*  60:    */     {
/*  61:130 */       logger.warn("Error loading SQL error codes from config file", ex);
/*  62:131 */       errorCodes = Collections.emptyMap();
/*  63:    */     }
/*  64:134 */     this.errorCodesMap = errorCodes;
/*  65:    */   }
/*  66:    */   
/*  67:    */   protected Resource loadResource(String path)
/*  68:    */   {
/*  69:149 */     return new ClassPathResource(path, getClass().getClassLoader());
/*  70:    */   }
/*  71:    */   
/*  72:    */   public SQLErrorCodes getErrorCodes(String dbName)
/*  73:    */   {
/*  74:161 */     Assert.notNull(dbName, "Database product name must not be null");
/*  75:    */     
/*  76:163 */     SQLErrorCodes sec = (SQLErrorCodes)this.errorCodesMap.get(dbName);
/*  77:164 */     if (sec == null) {
/*  78:165 */       for (SQLErrorCodes candidate : this.errorCodesMap.values()) {
/*  79:166 */         if (PatternMatchUtils.simpleMatch(candidate.getDatabaseProductNames(), dbName))
/*  80:    */         {
/*  81:167 */           sec = candidate;
/*  82:168 */           break;
/*  83:    */         }
/*  84:    */       }
/*  85:    */     }
/*  86:172 */     if (sec != null)
/*  87:    */     {
/*  88:173 */       checkCustomTranslatorRegistry(dbName, sec);
/*  89:174 */       if (logger.isDebugEnabled()) {
/*  90:175 */         logger.debug("SQL error codes for '" + dbName + "' found");
/*  91:    */       }
/*  92:177 */       return sec;
/*  93:    */     }
/*  94:181 */     if (logger.isDebugEnabled()) {
/*  95:182 */       logger.debug("SQL error codes for '" + dbName + "' not found");
/*  96:    */     }
/*  97:184 */     return new SQLErrorCodes();
/*  98:    */   }
/*  99:    */   
/* 100:    */   public SQLErrorCodes getErrorCodes(DataSource dataSource)
/* 101:    */   {
/* 102:197 */     Assert.notNull(dataSource, "DataSource must not be null");
/* 103:198 */     if (logger.isDebugEnabled()) {
/* 104:199 */       logger.debug("Looking up default SQLErrorCodes for DataSource [" + dataSource + "]");
/* 105:    */     }
/* 106:202 */     synchronized (this.dataSourceCache)
/* 107:    */     {
/* 108:204 */       SQLErrorCodes sec = (SQLErrorCodes)this.dataSourceCache.get(dataSource);
/* 109:205 */       if (sec != null)
/* 110:    */       {
/* 111:206 */         if (logger.isDebugEnabled()) {
/* 112:207 */           logger.debug("SQLErrorCodes found in cache for DataSource [" + dataSource.getClass().getName() + '@' + Integer.toHexString(dataSource.hashCode()) + "]");
/* 113:    */         }
/* 114:210 */         return sec;
/* 115:    */       }
/* 116:    */       try
/* 117:    */       {
/* 118:214 */         String dbName = (String)JdbcUtils.extractDatabaseMetaData(dataSource, "getDatabaseProductName");
/* 119:215 */         if (dbName != null)
/* 120:    */         {
/* 121:216 */           if (logger.isDebugEnabled()) {
/* 122:217 */             logger.debug("Database product name cached for DataSource [" + dataSource.getClass().getName() + '@' + Integer.toHexString(dataSource.hashCode()) + "]: name is '" + dbName + "'");
/* 123:    */           }
/* 124:221 */           sec = getErrorCodes(dbName);
/* 125:222 */           this.dataSourceCache.put(dataSource, sec);
/* 126:223 */           return sec;
/* 127:    */         }
/* 128:    */       }
/* 129:    */       catch (MetaDataAccessException ex)
/* 130:    */       {
/* 131:227 */         logger.warn("Error while extracting database product name - falling back to empty error codes", ex);
/* 132:    */       }
/* 133:    */     }
/* 134:232 */     return new SQLErrorCodes();
/* 135:    */   }
/* 136:    */   
/* 137:    */   public SQLErrorCodes registerDatabase(DataSource dataSource, String dbName)
/* 138:    */   {
/* 139:243 */     synchronized (this.dataSourceCache)
/* 140:    */     {
/* 141:244 */       SQLErrorCodes sec = getErrorCodes(dbName);
/* 142:245 */       this.dataSourceCache.put(dataSource, sec);
/* 143:246 */       return sec;
/* 144:    */     }
/* 145:    */   }
/* 146:    */   
/* 147:    */   private void checkCustomTranslatorRegistry(String dbName, SQLErrorCodes dbCodes)
/* 148:    */   {
/* 149:254 */     SQLExceptionTranslator customTranslator = CustomSQLExceptionTranslatorRegistry.getInstance().findTranslatorForDatabase(dbName);
/* 150:256 */     if (customTranslator != null)
/* 151:    */     {
/* 152:257 */       if (dbCodes.getCustomSqlExceptionTranslator() != null) {
/* 153:258 */         logger.warn("Overriding already defined custom translator '" + dbCodes.getCustomSqlExceptionTranslator().getClass().getSimpleName() + " with '" + customTranslator.getClass().getSimpleName() + "' found in the CustomSQLExceptionTranslatorRegistry for database " + dbName);
/* 154:    */       } else {
/* 155:264 */         logger.info("Using custom translator '" + customTranslator.getClass().getSimpleName() + "' found in the CustomSQLExceptionTranslatorRegistry for database " + dbName);
/* 156:    */       }
/* 157:267 */       dbCodes.setCustomSqlExceptionTranslator(customTranslator);
/* 158:    */     }
/* 159:    */   }
/* 160:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.support.SQLErrorCodesFactory
 * JD-Core Version:    0.7.0.1
 */