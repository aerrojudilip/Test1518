/*  1:   */ package org.springframework.jdbc.support;
/*  2:   */ 
/*  3:   */ import java.util.HashMap;
/*  4:   */ import java.util.Map;
/*  5:   */ import org.apache.commons.logging.Log;
/*  6:   */ import org.apache.commons.logging.LogFactory;
/*  7:   */ 
/*  8:   */ public class CustomSQLExceptionTranslatorRegistry
/*  9:   */ {
/* 10:36 */   private static final Log logger = LogFactory.getLog(CustomSQLExceptionTranslatorRegistry.class);
/* 11:41 */   private static final CustomSQLExceptionTranslatorRegistry instance = new CustomSQLExceptionTranslatorRegistry();
/* 12:   */   
/* 13:   */   public static CustomSQLExceptionTranslatorRegistry getInstance()
/* 14:   */   {
/* 15:48 */     return instance;
/* 16:   */   }
/* 17:   */   
/* 18:57 */   private final Map<String, SQLExceptionTranslator> translatorMap = new HashMap();
/* 19:   */   
/* 20:   */   public void registerTranslator(String dbName, SQLExceptionTranslator translator)
/* 21:   */   {
/* 22:73 */     SQLExceptionTranslator replaced = (SQLExceptionTranslator)this.translatorMap.put(dbName, translator);
/* 23:74 */     if (replaced != null) {
/* 24:75 */       logger.warn("Replacing custom translator [" + replaced + "] for database '" + dbName + "' with [" + translator + "]");
/* 25:   */     } else {
/* 26:79 */       logger.info("Adding custom translator of type [" + translator.getClass().getName() + "] for database '" + dbName + "'");
/* 27:   */     }
/* 28:   */   }
/* 29:   */   
/* 30:   */   public SQLExceptionTranslator findTranslatorForDatabase(String dbName)
/* 31:   */   {
/* 32:90 */     return (SQLExceptionTranslator)this.translatorMap.get(dbName);
/* 33:   */   }
/* 34:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.support.CustomSQLExceptionTranslatorRegistry
 * JD-Core Version:    0.7.0.1
 */