/*   1:    */ package org.springframework.jdbc.support;
/*   2:    */ 
/*   3:    */ import java.lang.reflect.InvocationTargetException;
/*   4:    */ import java.lang.reflect.Method;
/*   5:    */ import java.math.BigDecimal;
/*   6:    */ import java.sql.Blob;
/*   7:    */ import java.sql.Clob;
/*   8:    */ import java.sql.Connection;
/*   9:    */ import java.sql.DatabaseMetaData;
/*  10:    */ import java.sql.ResultSet;
/*  11:    */ import java.sql.ResultSetMetaData;
/*  12:    */ import java.sql.SQLException;
/*  13:    */ import java.sql.Statement;
/*  14:    */ import java.sql.Time;
/*  15:    */ import java.sql.Timestamp;
/*  16:    */ import javax.sql.DataSource;
/*  17:    */ import org.apache.commons.logging.Log;
/*  18:    */ import org.apache.commons.logging.LogFactory;
/*  19:    */ import org.springframework.jdbc.CannotGetJdbcConnectionException;
/*  20:    */ import org.springframework.jdbc.datasource.DataSourceUtils;
/*  21:    */ 
/*  22:    */ public abstract class JdbcUtils
/*  23:    */ {
/*  24:    */   public static final int TYPE_UNKNOWN = -2147483648;
/*  25: 56 */   private static final Log logger = LogFactory.getLog(JdbcUtils.class);
/*  26:    */   
/*  27:    */   public static void closeConnection(Connection con)
/*  28:    */   {
/*  29: 65 */     if (con != null) {
/*  30:    */       try
/*  31:    */       {
/*  32: 67 */         con.close();
/*  33:    */       }
/*  34:    */       catch (SQLException ex)
/*  35:    */       {
/*  36: 70 */         logger.debug("Could not close JDBC Connection", ex);
/*  37:    */       }
/*  38:    */       catch (Throwable ex)
/*  39:    */       {
/*  40: 74 */         logger.debug("Unexpected exception on closing JDBC Connection", ex);
/*  41:    */       }
/*  42:    */     }
/*  43:    */   }
/*  44:    */   
/*  45:    */   public static void closeStatement(Statement stmt)
/*  46:    */   {
/*  47: 85 */     if (stmt != null) {
/*  48:    */       try
/*  49:    */       {
/*  50: 87 */         stmt.close();
/*  51:    */       }
/*  52:    */       catch (SQLException ex)
/*  53:    */       {
/*  54: 90 */         logger.trace("Could not close JDBC Statement", ex);
/*  55:    */       }
/*  56:    */       catch (Throwable ex)
/*  57:    */       {
/*  58: 94 */         logger.trace("Unexpected exception on closing JDBC Statement", ex);
/*  59:    */       }
/*  60:    */     }
/*  61:    */   }
/*  62:    */   
/*  63:    */   public static void closeResultSet(ResultSet rs)
/*  64:    */   {
/*  65:105 */     if (rs != null) {
/*  66:    */       try
/*  67:    */       {
/*  68:107 */         rs.close();
/*  69:    */       }
/*  70:    */       catch (SQLException ex)
/*  71:    */       {
/*  72:110 */         logger.trace("Could not close JDBC ResultSet", ex);
/*  73:    */       }
/*  74:    */       catch (Throwable ex)
/*  75:    */       {
/*  76:114 */         logger.trace("Unexpected exception on closing JDBC ResultSet", ex);
/*  77:    */       }
/*  78:    */     }
/*  79:    */   }
/*  80:    */   
/*  81:    */   public static Object getResultSetValue(ResultSet rs, int index, Class requiredType)
/*  82:    */     throws SQLException
/*  83:    */   {
/*  84:133 */     if (requiredType == null) {
/*  85:134 */       return getResultSetValue(rs, index);
/*  86:    */     }
/*  87:137 */     Object value = null;
/*  88:138 */     boolean wasNullCheck = false;
/*  89:141 */     if (String.class.equals(requiredType))
/*  90:    */     {
/*  91:142 */       value = rs.getString(index);
/*  92:    */     }
/*  93:144 */     else if ((Boolean.TYPE.equals(requiredType)) || (Boolean.class.equals(requiredType)))
/*  94:    */     {
/*  95:145 */       value = Boolean.valueOf(rs.getBoolean(index));
/*  96:146 */       wasNullCheck = true;
/*  97:    */     }
/*  98:148 */     else if ((Byte.TYPE.equals(requiredType)) || (Byte.class.equals(requiredType)))
/*  99:    */     {
/* 100:149 */       value = Byte.valueOf(rs.getByte(index));
/* 101:150 */       wasNullCheck = true;
/* 102:    */     }
/* 103:152 */     else if ((Short.TYPE.equals(requiredType)) || (Short.class.equals(requiredType)))
/* 104:    */     {
/* 105:153 */       value = Short.valueOf(rs.getShort(index));
/* 106:154 */       wasNullCheck = true;
/* 107:    */     }
/* 108:156 */     else if ((Integer.TYPE.equals(requiredType)) || (Integer.class.equals(requiredType)))
/* 109:    */     {
/* 110:157 */       value = Integer.valueOf(rs.getInt(index));
/* 111:158 */       wasNullCheck = true;
/* 112:    */     }
/* 113:160 */     else if ((Long.TYPE.equals(requiredType)) || (Long.class.equals(requiredType)))
/* 114:    */     {
/* 115:161 */       value = Long.valueOf(rs.getLong(index));
/* 116:162 */       wasNullCheck = true;
/* 117:    */     }
/* 118:164 */     else if ((Float.TYPE.equals(requiredType)) || (Float.class.equals(requiredType)))
/* 119:    */     {
/* 120:165 */       value = Float.valueOf(rs.getFloat(index));
/* 121:166 */       wasNullCheck = true;
/* 122:    */     }
/* 123:168 */     else if ((Double.TYPE.equals(requiredType)) || (Double.class.equals(requiredType)) || (Number.class.equals(requiredType)))
/* 124:    */     {
/* 125:170 */       value = Double.valueOf(rs.getDouble(index));
/* 126:171 */       wasNullCheck = true;
/* 127:    */     }
/* 128:173 */     else if ([B.class.equals(requiredType))
/* 129:    */     {
/* 130:174 */       value = rs.getBytes(index);
/* 131:    */     }
/* 132:176 */     else if (java.sql.Date.class.equals(requiredType))
/* 133:    */     {
/* 134:177 */       value = rs.getDate(index);
/* 135:    */     }
/* 136:179 */     else if (Time.class.equals(requiredType))
/* 137:    */     {
/* 138:180 */       value = rs.getTime(index);
/* 139:    */     }
/* 140:182 */     else if ((Timestamp.class.equals(requiredType)) || (java.util.Date.class.equals(requiredType)))
/* 141:    */     {
/* 142:183 */       value = rs.getTimestamp(index);
/* 143:    */     }
/* 144:185 */     else if (BigDecimal.class.equals(requiredType))
/* 145:    */     {
/* 146:186 */       value = rs.getBigDecimal(index);
/* 147:    */     }
/* 148:188 */     else if (Blob.class.equals(requiredType))
/* 149:    */     {
/* 150:189 */       value = rs.getBlob(index);
/* 151:    */     }
/* 152:191 */     else if (Clob.class.equals(requiredType))
/* 153:    */     {
/* 154:192 */       value = rs.getClob(index);
/* 155:    */     }
/* 156:    */     else
/* 157:    */     {
/* 158:196 */       value = getResultSetValue(rs, index);
/* 159:    */     }
/* 160:201 */     if ((wasNullCheck) && (value != null) && (rs.wasNull())) {
/* 161:202 */       value = null;
/* 162:    */     }
/* 163:204 */     return value;
/* 164:    */   }
/* 165:    */   
/* 166:    */   public static Object getResultSetValue(ResultSet rs, int index)
/* 167:    */     throws SQLException
/* 168:    */   {
/* 169:226 */     Object obj = rs.getObject(index);
/* 170:227 */     String className = null;
/* 171:228 */     if (obj != null) {
/* 172:229 */       className = obj.getClass().getName();
/* 173:    */     }
/* 174:231 */     if ((obj instanceof Blob))
/* 175:    */     {
/* 176:232 */       obj = rs.getBytes(index);
/* 177:    */     }
/* 178:234 */     else if ((obj instanceof Clob))
/* 179:    */     {
/* 180:235 */       obj = rs.getString(index);
/* 181:    */     }
/* 182:237 */     else if ((className != null) && (("oracle.sql.TIMESTAMP".equals(className)) || ("oracle.sql.TIMESTAMPTZ".equals(className))))
/* 183:    */     {
/* 184:240 */       obj = rs.getTimestamp(index);
/* 185:    */     }
/* 186:242 */     else if ((className != null) && (className.startsWith("oracle.sql.DATE")))
/* 187:    */     {
/* 188:243 */       String metaDataClassName = rs.getMetaData().getColumnClassName(index);
/* 189:244 */       if (("java.sql.Timestamp".equals(metaDataClassName)) || ("oracle.sql.TIMESTAMP".equals(metaDataClassName))) {
/* 190:246 */         obj = rs.getTimestamp(index);
/* 191:    */       } else {
/* 192:249 */         obj = rs.getDate(index);
/* 193:    */       }
/* 194:    */     }
/* 195:252 */     else if ((obj != null) && ((obj instanceof java.sql.Date)) && 
/* 196:253 */       ("java.sql.Timestamp".equals(rs.getMetaData().getColumnClassName(index))))
/* 197:    */     {
/* 198:254 */       obj = rs.getTimestamp(index);
/* 199:    */     }
/* 200:257 */     return obj;
/* 201:    */   }
/* 202:    */   
/* 203:    */   public static Object extractDatabaseMetaData(DataSource dataSource, DatabaseMetaDataCallback action)
/* 204:    */     throws MetaDataAccessException
/* 205:    */   {
/* 206:278 */     Connection con = null;
/* 207:    */     try
/* 208:    */     {
/* 209:280 */       con = DataSourceUtils.getConnection(dataSource);
/* 210:281 */       if (con == null) {
/* 211:283 */         throw new MetaDataAccessException("Connection returned by DataSource [" + dataSource + "] was null");
/* 212:    */       }
/* 213:285 */       DatabaseMetaData metaData = con.getMetaData();
/* 214:286 */       if (metaData == null) {
/* 215:288 */         throw new MetaDataAccessException("DatabaseMetaData returned by Connection [" + con + "] was null");
/* 216:    */       }
/* 217:290 */       return action.processMetaData(metaData);
/* 218:    */     }
/* 219:    */     catch (CannotGetJdbcConnectionException ex)
/* 220:    */     {
/* 221:293 */       throw new MetaDataAccessException("Could not get Connection for extracting meta data", ex);
/* 222:    */     }
/* 223:    */     catch (SQLException ex)
/* 224:    */     {
/* 225:296 */       throw new MetaDataAccessException("Error while extracting DatabaseMetaData", ex);
/* 226:    */     }
/* 227:    */     catch (AbstractMethodError err)
/* 228:    */     {
/* 229:299 */       throw new MetaDataAccessException("JDBC DatabaseMetaData method not implemented by JDBC driver - upgrade your driver", err);
/* 230:    */     }
/* 231:    */     finally
/* 232:    */     {
/* 233:303 */       DataSourceUtils.releaseConnection(con, dataSource);
/* 234:    */     }
/* 235:    */   }
/* 236:    */   
/* 237:    */   public static Object extractDatabaseMetaData(DataSource dataSource, String metaDataMethodName)
/* 238:    */     throws MetaDataAccessException
/* 239:    */   {
/* 240:320 */     extractDatabaseMetaData(dataSource, new DatabaseMetaDataCallback()
/* 241:    */     {
/* 242:    */       public Object processMetaData(DatabaseMetaData dbmd)
/* 243:    */         throws SQLException, MetaDataAccessException
/* 244:    */       {
/* 245:    */         try
/* 246:    */         {
/* 247:324 */           Method method = DatabaseMetaData.class.getMethod(this.val$metaDataMethodName, (Class[])null);
/* 248:325 */           return method.invoke(dbmd, (Object[])null);
/* 249:    */         }
/* 250:    */         catch (NoSuchMethodException ex)
/* 251:    */         {
/* 252:328 */           throw new MetaDataAccessException("No method named '" + this.val$metaDataMethodName + "' found on DatabaseMetaData instance [" + dbmd + "]", ex);
/* 253:    */         }
/* 254:    */         catch (IllegalAccessException ex)
/* 255:    */         {
/* 256:332 */           throw new MetaDataAccessException("Could not access DatabaseMetaData method '" + this.val$metaDataMethodName + "'", ex);
/* 257:    */         }
/* 258:    */         catch (InvocationTargetException ex)
/* 259:    */         {
/* 260:336 */           if ((ex.getTargetException() instanceof SQLException)) {
/* 261:337 */             throw ((SQLException)ex.getTargetException());
/* 262:    */           }
/* 263:339 */           throw new MetaDataAccessException("Invocation of DatabaseMetaData method '" + this.val$metaDataMethodName + "' failed", ex);
/* 264:    */         }
/* 265:    */       }
/* 266:    */     });
/* 267:    */   }
/* 268:    */   
/* 269:    */   public static boolean supportsBatchUpdates(Connection con)
/* 270:    */   {
/* 271:    */     try
/* 272:    */     {
/* 273:359 */       DatabaseMetaData dbmd = con.getMetaData();
/* 274:360 */       if (dbmd != null)
/* 275:    */       {
/* 276:361 */         if (dbmd.supportsBatchUpdates())
/* 277:    */         {
/* 278:362 */           logger.debug("JDBC driver supports batch updates");
/* 279:363 */           return true;
/* 280:    */         }
/* 281:366 */         logger.debug("JDBC driver does not support batch updates");
/* 282:    */       }
/* 283:    */     }
/* 284:    */     catch (SQLException ex)
/* 285:    */     {
/* 286:371 */       logger.debug("JDBC driver 'supportsBatchUpdates' method threw exception", ex);
/* 287:    */     }
/* 288:    */     catch (AbstractMethodError err)
/* 289:    */     {
/* 290:374 */       logger.debug("JDBC driver does not support JDBC 2.0 'supportsBatchUpdates' method", err);
/* 291:    */     }
/* 292:376 */     return false;
/* 293:    */   }
/* 294:    */   
/* 295:    */   public static String commonDatabaseName(String source)
/* 296:    */   {
/* 297:385 */     String name = source;
/* 298:386 */     if ((source != null) && (source.startsWith("DB2"))) {
/* 299:387 */       name = "DB2";
/* 300:389 */     } else if (("Sybase SQL Server".equals(source)) || ("Adaptive Server Enterprise".equals(source)) || ("ASE".equals(source)) || ("sql server".equalsIgnoreCase(source))) {
/* 301:393 */       name = "Sybase";
/* 302:    */     }
/* 303:395 */     return name;
/* 304:    */   }
/* 305:    */   
/* 306:    */   public static boolean isNumeric(int sqlType)
/* 307:    */   {
/* 308:404 */     return (-7 == sqlType) || (-5 == sqlType) || (3 == sqlType) || (8 == sqlType) || (6 == sqlType) || (4 == sqlType) || (2 == sqlType) || (7 == sqlType) || (5 == sqlType) || (-6 == sqlType);
/* 309:    */   }
/* 310:    */   
/* 311:    */   public static String lookupColumnName(ResultSetMetaData resultSetMetaData, int columnIndex)
/* 312:    */     throws SQLException
/* 313:    */   {
/* 314:423 */     String name = resultSetMetaData.getColumnLabel(columnIndex);
/* 315:424 */     if ((name == null) || (name.length() < 1)) {
/* 316:425 */       name = resultSetMetaData.getColumnName(columnIndex);
/* 317:    */     }
/* 318:427 */     return name;
/* 319:    */   }
/* 320:    */   
/* 321:    */   public static String convertUnderscoreNameToPropertyName(String name)
/* 322:    */   {
/* 323:437 */     StringBuilder result = new StringBuilder();
/* 324:438 */     boolean nextIsUpper = false;
/* 325:439 */     if ((name != null) && (name.length() > 0))
/* 326:    */     {
/* 327:440 */       if ((name.length() > 1) && (name.substring(1, 2).equals("_"))) {
/* 328:441 */         result.append(name.substring(0, 1).toUpperCase());
/* 329:    */       } else {
/* 330:444 */         result.append(name.substring(0, 1).toLowerCase());
/* 331:    */       }
/* 332:446 */       for (int i = 1; i < name.length(); i++)
/* 333:    */       {
/* 334:447 */         String s = name.substring(i, i + 1);
/* 335:448 */         if (s.equals("_"))
/* 336:    */         {
/* 337:449 */           nextIsUpper = true;
/* 338:    */         }
/* 339:452 */         else if (nextIsUpper)
/* 340:    */         {
/* 341:453 */           result.append(s.toUpperCase());
/* 342:454 */           nextIsUpper = false;
/* 343:    */         }
/* 344:    */         else
/* 345:    */         {
/* 346:457 */           result.append(s.toLowerCase());
/* 347:    */         }
/* 348:    */       }
/* 349:    */     }
/* 350:462 */     return result.toString();
/* 351:    */   }
/* 352:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.support.JdbcUtils
 * JD-Core Version:    0.7.0.1
 */