/*   1:    */ package org.springframework.jdbc.support;
/*   2:    */ 
/*   3:    */ import org.springframework.util.StringUtils;
/*   4:    */ 
/*   5:    */ public class SQLErrorCodes
/*   6:    */ {
/*   7:    */   private String[] databaseProductNames;
/*   8: 38 */   private boolean useSqlStateForTranslation = false;
/*   9: 40 */   private String[] badSqlGrammarCodes = new String[0];
/*  10: 42 */   private String[] invalidResultSetAccessCodes = new String[0];
/*  11: 44 */   private String[] duplicateKeyCodes = new String[0];
/*  12: 46 */   private String[] dataIntegrityViolationCodes = new String[0];
/*  13: 48 */   private String[] permissionDeniedCodes = new String[0];
/*  14: 50 */   private String[] dataAccessResourceFailureCodes = new String[0];
/*  15: 52 */   private String[] transientDataAccessResourceCodes = new String[0];
/*  16: 54 */   private String[] cannotAcquireLockCodes = new String[0];
/*  17: 56 */   private String[] deadlockLoserCodes = new String[0];
/*  18: 58 */   private String[] cannotSerializeTransactionCodes = new String[0];
/*  19:    */   private CustomSQLErrorCodesTranslation[] customTranslations;
/*  20:    */   private SQLExceptionTranslator customSqlExceptionTranslator;
/*  21:    */   
/*  22:    */   public void setDatabaseProductName(String databaseProductName)
/*  23:    */   {
/*  24: 70 */     this.databaseProductNames = new String[] { databaseProductName };
/*  25:    */   }
/*  26:    */   
/*  27:    */   public String getDatabaseProductName()
/*  28:    */   {
/*  29: 74 */     return (this.databaseProductNames != null) && (this.databaseProductNames.length > 0) ? this.databaseProductNames[0] : null;
/*  30:    */   }
/*  31:    */   
/*  32:    */   public void setDatabaseProductNames(String[] databaseProductNames)
/*  33:    */   {
/*  34: 83 */     this.databaseProductNames = databaseProductNames;
/*  35:    */   }
/*  36:    */   
/*  37:    */   public String[] getDatabaseProductNames()
/*  38:    */   {
/*  39: 87 */     return this.databaseProductNames;
/*  40:    */   }
/*  41:    */   
/*  42:    */   public void setUseSqlStateForTranslation(boolean useStateCodeForTranslation)
/*  43:    */   {
/*  44: 95 */     this.useSqlStateForTranslation = useStateCodeForTranslation;
/*  45:    */   }
/*  46:    */   
/*  47:    */   public boolean isUseSqlStateForTranslation()
/*  48:    */   {
/*  49: 99 */     return this.useSqlStateForTranslation;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public void setBadSqlGrammarCodes(String[] badSqlGrammarCodes)
/*  53:    */   {
/*  54:103 */     this.badSqlGrammarCodes = StringUtils.sortStringArray(badSqlGrammarCodes);
/*  55:    */   }
/*  56:    */   
/*  57:    */   public String[] getBadSqlGrammarCodes()
/*  58:    */   {
/*  59:107 */     return this.badSqlGrammarCodes;
/*  60:    */   }
/*  61:    */   
/*  62:    */   public void setInvalidResultSetAccessCodes(String[] invalidResultSetAccessCodes)
/*  63:    */   {
/*  64:111 */     this.invalidResultSetAccessCodes = StringUtils.sortStringArray(invalidResultSetAccessCodes);
/*  65:    */   }
/*  66:    */   
/*  67:    */   public String[] getInvalidResultSetAccessCodes()
/*  68:    */   {
/*  69:115 */     return this.invalidResultSetAccessCodes;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public String[] getDuplicateKeyCodes()
/*  73:    */   {
/*  74:119 */     return this.duplicateKeyCodes;
/*  75:    */   }
/*  76:    */   
/*  77:    */   public void setDuplicateKeyCodes(String[] duplicateKeyCodes)
/*  78:    */   {
/*  79:123 */     this.duplicateKeyCodes = duplicateKeyCodes;
/*  80:    */   }
/*  81:    */   
/*  82:    */   public void setDataIntegrityViolationCodes(String[] dataIntegrityViolationCodes)
/*  83:    */   {
/*  84:127 */     this.dataIntegrityViolationCodes = StringUtils.sortStringArray(dataIntegrityViolationCodes);
/*  85:    */   }
/*  86:    */   
/*  87:    */   public String[] getDataIntegrityViolationCodes()
/*  88:    */   {
/*  89:131 */     return this.dataIntegrityViolationCodes;
/*  90:    */   }
/*  91:    */   
/*  92:    */   public void setPermissionDeniedCodes(String[] permissionDeniedCodes)
/*  93:    */   {
/*  94:135 */     this.permissionDeniedCodes = StringUtils.sortStringArray(permissionDeniedCodes);
/*  95:    */   }
/*  96:    */   
/*  97:    */   public String[] getPermissionDeniedCodes()
/*  98:    */   {
/*  99:139 */     return this.permissionDeniedCodes;
/* 100:    */   }
/* 101:    */   
/* 102:    */   public void setDataAccessResourceFailureCodes(String[] dataAccessResourceFailureCodes)
/* 103:    */   {
/* 104:143 */     this.dataAccessResourceFailureCodes = StringUtils.sortStringArray(dataAccessResourceFailureCodes);
/* 105:    */   }
/* 106:    */   
/* 107:    */   public String[] getDataAccessResourceFailureCodes()
/* 108:    */   {
/* 109:147 */     return this.dataAccessResourceFailureCodes;
/* 110:    */   }
/* 111:    */   
/* 112:    */   public void setTransientDataAccessResourceCodes(String[] transientDataAccessResourceCodes)
/* 113:    */   {
/* 114:151 */     this.transientDataAccessResourceCodes = StringUtils.sortStringArray(transientDataAccessResourceCodes);
/* 115:    */   }
/* 116:    */   
/* 117:    */   public String[] getTransientDataAccessResourceCodes()
/* 118:    */   {
/* 119:155 */     return this.transientDataAccessResourceCodes;
/* 120:    */   }
/* 121:    */   
/* 122:    */   public void setCannotAcquireLockCodes(String[] cannotAcquireLockCodes)
/* 123:    */   {
/* 124:159 */     this.cannotAcquireLockCodes = StringUtils.sortStringArray(cannotAcquireLockCodes);
/* 125:    */   }
/* 126:    */   
/* 127:    */   public String[] getCannotAcquireLockCodes()
/* 128:    */   {
/* 129:163 */     return this.cannotAcquireLockCodes;
/* 130:    */   }
/* 131:    */   
/* 132:    */   public void setDeadlockLoserCodes(String[] deadlockLoserCodes)
/* 133:    */   {
/* 134:167 */     this.deadlockLoserCodes = StringUtils.sortStringArray(deadlockLoserCodes);
/* 135:    */   }
/* 136:    */   
/* 137:    */   public String[] getDeadlockLoserCodes()
/* 138:    */   {
/* 139:171 */     return this.deadlockLoserCodes;
/* 140:    */   }
/* 141:    */   
/* 142:    */   public void setCannotSerializeTransactionCodes(String[] cannotSerializeTransactionCodes)
/* 143:    */   {
/* 144:175 */     this.cannotSerializeTransactionCodes = StringUtils.sortStringArray(cannotSerializeTransactionCodes);
/* 145:    */   }
/* 146:    */   
/* 147:    */   public String[] getCannotSerializeTransactionCodes()
/* 148:    */   {
/* 149:179 */     return this.cannotSerializeTransactionCodes;
/* 150:    */   }
/* 151:    */   
/* 152:    */   public void setCustomTranslations(CustomSQLErrorCodesTranslation[] customTranslations)
/* 153:    */   {
/* 154:183 */     this.customTranslations = customTranslations;
/* 155:    */   }
/* 156:    */   
/* 157:    */   public CustomSQLErrorCodesTranslation[] getCustomTranslations()
/* 158:    */   {
/* 159:187 */     return this.customTranslations;
/* 160:    */   }
/* 161:    */   
/* 162:    */   public void setCustomSqlExceptionTranslatorClass(Class<? extends SQLExceptionTranslator> customTranslatorClass)
/* 163:    */   {
/* 164:191 */     if (customTranslatorClass != null) {
/* 165:    */       try
/* 166:    */       {
/* 167:193 */         this.customSqlExceptionTranslator = ((SQLExceptionTranslator)customTranslatorClass.newInstance());
/* 168:    */       }
/* 169:    */       catch (Exception ex)
/* 170:    */       {
/* 171:196 */         throw new IllegalStateException("Unable to instantiate custom translator", ex);
/* 172:    */       }
/* 173:    */     } else {
/* 174:200 */       this.customSqlExceptionTranslator = null;
/* 175:    */     }
/* 176:    */   }
/* 177:    */   
/* 178:    */   public void setCustomSqlExceptionTranslator(SQLExceptionTranslator customSqlExceptionTranslator)
/* 179:    */   {
/* 180:205 */     this.customSqlExceptionTranslator = customSqlExceptionTranslator;
/* 181:    */   }
/* 182:    */   
/* 183:    */   public SQLExceptionTranslator getCustomSqlExceptionTranslator()
/* 184:    */   {
/* 185:209 */     return this.customSqlExceptionTranslator;
/* 186:    */   }
/* 187:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.support.SQLErrorCodes
 * JD-Core Version:    0.7.0.1
 */