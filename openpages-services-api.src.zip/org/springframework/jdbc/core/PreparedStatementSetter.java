package org.springframework.jdbc.core;

import java.sql.PreparedStatement;
import java.sql.SQLException;

public abstract interface PreparedStatementSetter
{
  public abstract void setValues(PreparedStatement paramPreparedStatement)
    throws SQLException;
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.core.PreparedStatementSetter
 * JD-Core Version:    0.7.0.1
 */