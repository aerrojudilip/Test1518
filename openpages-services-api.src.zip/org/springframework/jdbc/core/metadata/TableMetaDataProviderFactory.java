/*   1:    */ package org.springframework.jdbc.core.metadata;
/*   2:    */ 
/*   3:    */ import java.sql.DatabaseMetaData;
/*   4:    */ import java.sql.SQLException;
/*   5:    */ import javax.sql.DataSource;
/*   6:    */ import org.apache.commons.logging.Log;
/*   7:    */ import org.apache.commons.logging.LogFactory;
/*   8:    */ import org.springframework.dao.DataAccessResourceFailureException;
/*   9:    */ import org.springframework.jdbc.support.DatabaseMetaDataCallback;
/*  10:    */ import org.springframework.jdbc.support.JdbcUtils;
/*  11:    */ import org.springframework.jdbc.support.MetaDataAccessException;
/*  12:    */ import org.springframework.jdbc.support.nativejdbc.NativeJdbcExtractor;
/*  13:    */ 
/*  14:    */ public class TableMetaDataProviderFactory
/*  15:    */ {
/*  16: 40 */   private static final Log logger = LogFactory.getLog(TableMetaDataProviderFactory.class);
/*  17:    */   
/*  18:    */   public static TableMetaDataProvider createMetaDataProvider(DataSource dataSource, TableMetaDataContext context)
/*  19:    */   {
/*  20: 50 */     return createMetaDataProvider(dataSource, context, null);
/*  21:    */   }
/*  22:    */   
/*  23:    */   public static TableMetaDataProvider createMetaDataProvider(DataSource dataSource, TableMetaDataContext context, final NativeJdbcExtractor nativeJdbcExtractor)
/*  24:    */   {
/*  25:    */     try
/*  26:    */     {
/*  27: 63 */       (TableMetaDataProvider)JdbcUtils.extractDatabaseMetaData(dataSource, new DatabaseMetaDataCallback()
/*  28:    */       {
/*  29:    */         public Object processMetaData(DatabaseMetaData databaseMetaData)
/*  30:    */           throws SQLException
/*  31:    */         {
/*  32: 66 */           String databaseProductName = JdbcUtils.commonDatabaseName(databaseMetaData.getDatabaseProductName());
/*  33:    */           
/*  34: 68 */           boolean accessTableColumnMetaData = this.val$context.isAccessTableColumnMetaData();
/*  35:    */           TableMetaDataProvider provider;
/*  36:    */           TableMetaDataProvider provider;
/*  37: 70 */           if ("Oracle".equals(databaseProductName))
/*  38:    */           {
/*  39: 71 */             provider = new OracleTableMetaDataProvider(databaseMetaData, this.val$context.isOverrideIncludeSynonymsDefault());
/*  40:    */           }
/*  41:    */           else
/*  42:    */           {
/*  43:    */             TableMetaDataProvider provider;
/*  44: 74 */             if ("HSQL Database Engine".equals(databaseProductName))
/*  45:    */             {
/*  46: 75 */               provider = new HsqlTableMetaDataProvider(databaseMetaData);
/*  47:    */             }
/*  48:    */             else
/*  49:    */             {
/*  50:    */               TableMetaDataProvider provider;
/*  51: 77 */               if ("PostgreSQL".equals(databaseProductName))
/*  52:    */               {
/*  53: 78 */                 provider = new PostgresTableMetaDataProvider(databaseMetaData);
/*  54:    */               }
/*  55:    */               else
/*  56:    */               {
/*  57:    */                 TableMetaDataProvider provider;
/*  58: 80 */                 if ("Apache Derby".equals(databaseProductName)) {
/*  59: 81 */                   provider = new DerbyTableMetaDataProvider(databaseMetaData);
/*  60:    */                 } else {
/*  61: 84 */                   provider = new GenericTableMetaDataProvider(databaseMetaData);
/*  62:    */                 }
/*  63:    */               }
/*  64:    */             }
/*  65:    */           }
/*  66: 86 */           if (nativeJdbcExtractor != null) {
/*  67: 87 */             provider.setNativeJdbcExtractor(nativeJdbcExtractor);
/*  68:    */           }
/*  69: 89 */           if (TableMetaDataProviderFactory.logger.isDebugEnabled()) {
/*  70: 90 */             TableMetaDataProviderFactory.logger.debug("Using " + provider.getClass().getSimpleName());
/*  71:    */           }
/*  72: 92 */           provider.initializeWithMetaData(databaseMetaData);
/*  73: 93 */           if (accessTableColumnMetaData) {
/*  74: 94 */             provider.initializeWithTableColumnMetaData(databaseMetaData, this.val$context.getCatalogName(), this.val$context.getSchemaName(), this.val$context.getTableName());
/*  75:    */           }
/*  76: 97 */           return provider;
/*  77:    */         }
/*  78:    */       });
/*  79:    */     }
/*  80:    */     catch (MetaDataAccessException ex)
/*  81:    */     {
/*  82:102 */       throw new DataAccessResourceFailureException("Error retrieving database metadata", ex);
/*  83:    */     }
/*  84:    */   }
/*  85:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.core.metadata.TableMetaDataProviderFactory
 * JD-Core Version:    0.7.0.1
 */