/*  1:   */ package org.springframework.jdbc.core.metadata;
/*  2:   */ 
/*  3:   */ import java.sql.DatabaseMetaData;
/*  4:   */ import java.sql.SQLException;
/*  5:   */ 
/*  6:   */ public class HsqlTableMetaDataProvider
/*  7:   */   extends GenericTableMetaDataProvider
/*  8:   */ {
/*  9:   */   public HsqlTableMetaDataProvider(DatabaseMetaData databaseMetaData)
/* 10:   */     throws SQLException
/* 11:   */   {
/* 12:32 */     super(databaseMetaData);
/* 13:   */   }
/* 14:   */   
/* 15:   */   public boolean isGetGeneratedKeysSimulated()
/* 16:   */   {
/* 17:38 */     return true;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public String getSimpleQueryForGetGeneratedKey(String tableName, String keyColumnName)
/* 21:   */   {
/* 22:44 */     return "select max(identity()) from " + tableName;
/* 23:   */   }
/* 24:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.core.metadata.HsqlTableMetaDataProvider
 * JD-Core Version:    0.7.0.1
 */