/*   1:    */ package org.springframework.jdbc.core.metadata;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.HashMap;
/*   5:    */ import java.util.HashSet;
/*   6:    */ import java.util.LinkedHashMap;
/*   7:    */ import java.util.List;
/*   8:    */ import java.util.Locale;
/*   9:    */ import java.util.Map;
/*  10:    */ import java.util.Set;
/*  11:    */ import javax.sql.DataSource;
/*  12:    */ import org.apache.commons.logging.Log;
/*  13:    */ import org.apache.commons.logging.LogFactory;
/*  14:    */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*  15:    */ import org.springframework.jdbc.core.RowMapper;
/*  16:    */ import org.springframework.jdbc.core.SqlOutParameter;
/*  17:    */ import org.springframework.jdbc.core.SqlParameter;
/*  18:    */ import org.springframework.jdbc.core.SqlParameterValue;
/*  19:    */ import org.springframework.jdbc.core.SqlReturnResultSet;
/*  20:    */ import org.springframework.jdbc.core.namedparam.SqlParameterSource;
/*  21:    */ import org.springframework.jdbc.core.namedparam.SqlParameterSourceUtils;
/*  22:    */ import org.springframework.jdbc.support.JdbcUtils;
/*  23:    */ import org.springframework.util.StringUtils;
/*  24:    */ 
/*  25:    */ public class CallMetaDataContext
/*  26:    */ {
/*  27: 54 */   protected final Log logger = LogFactory.getLog(getClass());
/*  28:    */   private String procedureName;
/*  29:    */   private String catalogName;
/*  30:    */   private String schemaName;
/*  31: 66 */   private List<SqlParameter> callParameters = new ArrayList();
/*  32: 69 */   private String defaultFunctionReturnName = "return";
/*  33: 72 */   private String actualFunctionReturnName = null;
/*  34: 75 */   private Set<String> limitedInParameterNames = new HashSet();
/*  35: 78 */   private List<String> outParameterNames = new ArrayList();
/*  36: 81 */   private boolean accessCallParameterMetaData = true;
/*  37:    */   private boolean function;
/*  38:    */   private boolean returnValueRequired;
/*  39:    */   private CallMetaDataProvider metaDataProvider;
/*  40:    */   
/*  41:    */   public void setFunctionReturnName(String functionReturnName)
/*  42:    */   {
/*  43: 97 */     this.actualFunctionReturnName = functionReturnName;
/*  44:    */   }
/*  45:    */   
/*  46:    */   public String getFunctionReturnName()
/*  47:    */   {
/*  48:104 */     return this.actualFunctionReturnName != null ? this.actualFunctionReturnName : this.defaultFunctionReturnName;
/*  49:    */   }
/*  50:    */   
/*  51:    */   public void setLimitedInParameterNames(Set<String> limitedInParameterNames)
/*  52:    */   {
/*  53:111 */     this.limitedInParameterNames = limitedInParameterNames;
/*  54:    */   }
/*  55:    */   
/*  56:    */   public Set<String> getLimitedInParameterNames()
/*  57:    */   {
/*  58:118 */     return this.limitedInParameterNames;
/*  59:    */   }
/*  60:    */   
/*  61:    */   public void setOutParameterNames(List<String> outParameterNames)
/*  62:    */   {
/*  63:125 */     this.outParameterNames = outParameterNames;
/*  64:    */   }
/*  65:    */   
/*  66:    */   public List<String> getOutParameterNames()
/*  67:    */   {
/*  68:132 */     return this.outParameterNames;
/*  69:    */   }
/*  70:    */   
/*  71:    */   public void setProcedureName(String procedureName)
/*  72:    */   {
/*  73:139 */     this.procedureName = procedureName;
/*  74:    */   }
/*  75:    */   
/*  76:    */   public String getProcedureName()
/*  77:    */   {
/*  78:146 */     return this.procedureName;
/*  79:    */   }
/*  80:    */   
/*  81:    */   public void setCatalogName(String catalogName)
/*  82:    */   {
/*  83:153 */     this.catalogName = catalogName;
/*  84:    */   }
/*  85:    */   
/*  86:    */   public String getCatalogName()
/*  87:    */   {
/*  88:160 */     return this.catalogName;
/*  89:    */   }
/*  90:    */   
/*  91:    */   public void setSchemaName(String schemaName)
/*  92:    */   {
/*  93:167 */     this.schemaName = schemaName;
/*  94:    */   }
/*  95:    */   
/*  96:    */   public String getSchemaName()
/*  97:    */   {
/*  98:174 */     return this.schemaName;
/*  99:    */   }
/* 100:    */   
/* 101:    */   public void setFunction(boolean function)
/* 102:    */   {
/* 103:181 */     this.function = function;
/* 104:    */   }
/* 105:    */   
/* 106:    */   public boolean isFunction()
/* 107:    */   {
/* 108:188 */     return this.function;
/* 109:    */   }
/* 110:    */   
/* 111:    */   public void setReturnValueRequired(boolean returnValueRequired)
/* 112:    */   {
/* 113:195 */     this.returnValueRequired = returnValueRequired;
/* 114:    */   }
/* 115:    */   
/* 116:    */   public boolean isReturnValueRequired()
/* 117:    */   {
/* 118:202 */     return this.returnValueRequired;
/* 119:    */   }
/* 120:    */   
/* 121:    */   public void setAccessCallParameterMetaData(boolean accessCallParameterMetaData)
/* 122:    */   {
/* 123:209 */     this.accessCallParameterMetaData = accessCallParameterMetaData;
/* 124:    */   }
/* 125:    */   
/* 126:    */   public boolean isAccessCallParameterMetaData()
/* 127:    */   {
/* 128:216 */     return this.accessCallParameterMetaData;
/* 129:    */   }
/* 130:    */   
/* 131:    */   public SqlParameter createReturnResultSetParameter(String parameterName, RowMapper rowMapper)
/* 132:    */   {
/* 133:228 */     if (this.metaDataProvider.isReturnResultSetSupported()) {
/* 134:229 */       return new SqlReturnResultSet(parameterName, rowMapper);
/* 135:    */     }
/* 136:232 */     if (this.metaDataProvider.isRefCursorSupported()) {
/* 137:233 */       return new SqlOutParameter(parameterName, this.metaDataProvider.getRefCursorSqlType(), rowMapper);
/* 138:    */     }
/* 139:236 */     throw new InvalidDataAccessApiUsageException("Return of a ResultSet from a stored procedure is not supported.");
/* 140:    */   }
/* 141:    */   
/* 142:    */   public String getScalarOutParameterName()
/* 143:    */   {
/* 144:246 */     if (isFunction()) {
/* 145:247 */       return getFunctionReturnName();
/* 146:    */     }
/* 147:250 */     if (this.outParameterNames.size() > 1) {
/* 148:251 */       this.logger.warn("Accessing single output value when procedure has more than one output parameter");
/* 149:    */     }
/* 150:253 */     return this.outParameterNames.size() > 0 ? (String)this.outParameterNames.get(0) : null;
/* 151:    */   }
/* 152:    */   
/* 153:    */   public List<SqlParameter> getCallParameters()
/* 154:    */   {
/* 155:261 */     return this.callParameters;
/* 156:    */   }
/* 157:    */   
/* 158:    */   public void initializeMetaData(DataSource dataSource)
/* 159:    */   {
/* 160:269 */     this.metaDataProvider = CallMetaDataProviderFactory.createMetaDataProvider(dataSource, this);
/* 161:    */   }
/* 162:    */   
/* 163:    */   public void processParameters(List<SqlParameter> parameters)
/* 164:    */   {
/* 165:279 */     this.callParameters = reconcileParameters(parameters);
/* 166:    */   }
/* 167:    */   
/* 168:    */   protected List<SqlParameter> reconcileParameters(List<SqlParameter> parameters)
/* 169:    */   {
/* 170:286 */     List<SqlParameter> declaredReturnParameters = new ArrayList();
/* 171:287 */     Map<String, SqlParameter> declaredParameters = new LinkedHashMap();
/* 172:288 */     boolean returnDeclared = false;
/* 173:289 */     List<String> outParameterNames = new ArrayList();
/* 174:290 */     List<String> metaDataParameterNames = new ArrayList();
/* 175:293 */     for (CallParameterMetaData meta : this.metaDataProvider.getCallParameterMetaData()) {
/* 176:294 */       if (meta.getParameterType() != 5) {
/* 177:295 */         metaDataParameterNames.add(meta.getParameterName().toLowerCase());
/* 178:    */       }
/* 179:    */     }
/* 180:300 */     for (SqlParameter parameter : parameters) {
/* 181:301 */       if (parameter.isResultsParameter())
/* 182:    */       {
/* 183:302 */         declaredReturnParameters.add(parameter);
/* 184:    */       }
/* 185:    */       else
/* 186:    */       {
/* 187:305 */         String parameterNameToMatch = this.metaDataProvider.parameterNameToUse(parameter.getName()).toLowerCase();
/* 188:306 */         declaredParameters.put(parameterNameToMatch, parameter);
/* 189:307 */         if ((parameter instanceof SqlOutParameter))
/* 190:    */         {
/* 191:308 */           outParameterNames.add(parameter.getName());
/* 192:309 */           if ((isFunction()) && (!metaDataParameterNames.contains(parameterNameToMatch)) && 
/* 193:310 */             (!returnDeclared))
/* 194:    */           {
/* 195:311 */             if (this.logger.isDebugEnabled()) {
/* 196:312 */               this.logger.debug("Using declared out parameter '" + parameter.getName() + "' for function return value");
/* 197:    */             }
/* 198:314 */             setFunctionReturnName(parameter.getName());
/* 199:315 */             returnDeclared = true;
/* 200:    */           }
/* 201:    */         }
/* 202:    */       }
/* 203:    */     }
/* 204:321 */     setOutParameterNames(outParameterNames);
/* 205:    */     
/* 206:323 */     List<SqlParameter> workParameters = new ArrayList();
/* 207:324 */     workParameters.addAll(declaredReturnParameters);
/* 208:326 */     if (!this.metaDataProvider.isProcedureColumnMetaDataUsed())
/* 209:    */     {
/* 210:327 */       workParameters.addAll(declaredParameters.values());
/* 211:328 */       return workParameters;
/* 212:    */     }
/* 213:331 */     Map<String, String> limitedInParamNamesMap = new HashMap(this.limitedInParameterNames.size());
/* 214:332 */     for (String limitedParameterName : this.limitedInParameterNames) {
/* 215:333 */       limitedInParamNamesMap.put(this.metaDataProvider.parameterNameToUse(limitedParameterName).toLowerCase(), limitedParameterName);
/* 216:    */     }
/* 217:337 */     for (CallParameterMetaData meta : this.metaDataProvider.getCallParameterMetaData())
/* 218:    */     {
/* 219:338 */       String parNameToCheck = null;
/* 220:339 */       if (meta.getParameterName() != null) {
/* 221:340 */         parNameToCheck = this.metaDataProvider.parameterNameToUse(meta.getParameterName()).toLowerCase();
/* 222:    */       }
/* 223:342 */       String parNameToUse = this.metaDataProvider.parameterNameToUse(meta.getParameterName());
/* 224:343 */       if ((declaredParameters.containsKey(parNameToCheck)) || ((meta.getParameterType() == 5) && (returnDeclared)))
/* 225:    */       {
/* 226:    */         SqlParameter parameter;
/* 227:346 */         if (meta.getParameterType() == 5)
/* 228:    */         {
/* 229:347 */           SqlParameter parameter = (SqlParameter)declaredParameters.get(getFunctionReturnName());
/* 230:348 */           if ((parameter == null) && (getOutParameterNames().size() > 0)) {
/* 231:349 */             parameter = (SqlParameter)declaredParameters.get(((String)getOutParameterNames().get(0)).toLowerCase());
/* 232:    */           }
/* 233:351 */           if (parameter == null) {
/* 234:352 */             throw new InvalidDataAccessApiUsageException("Unable to locate declared parameter for function return value -  add a SqlOutParameter with name \"" + getFunctionReturnName() + "\"");
/* 235:    */           }
/* 236:357 */           setFunctionReturnName(parameter.getName());
/* 237:    */         }
/* 238:    */         else
/* 239:    */         {
/* 240:361 */           parameter = (SqlParameter)declaredParameters.get(parNameToCheck);
/* 241:    */         }
/* 242:363 */         if (parameter != null)
/* 243:    */         {
/* 244:364 */           workParameters.add(parameter);
/* 245:365 */           if (this.logger.isDebugEnabled()) {
/* 246:366 */             this.logger.debug("Using declared parameter for: " + (parNameToUse == null ? getFunctionReturnName() : parNameToUse));
/* 247:    */           }
/* 248:    */         }
/* 249:    */       }
/* 250:372 */       else if (meta.getParameterType() == 5)
/* 251:    */       {
/* 252:373 */         if ((!isFunction()) && (!isReturnValueRequired()) && (this.metaDataProvider.byPassReturnParameter(meta.getParameterName())))
/* 253:    */         {
/* 254:375 */           if (this.logger.isDebugEnabled()) {
/* 255:376 */             this.logger.debug("Bypassing metadata return parameter for: " + meta.getParameterName());
/* 256:    */           }
/* 257:    */         }
/* 258:    */         else
/* 259:    */         {
/* 260:380 */           String returnNameToUse = StringUtils.hasLength(meta.getParameterName()) ? parNameToUse : getFunctionReturnName();
/* 261:    */           
/* 262:382 */           workParameters.add(new SqlOutParameter(returnNameToUse, meta.getSqlType()));
/* 263:383 */           if (isFunction())
/* 264:    */           {
/* 265:384 */             setFunctionReturnName(returnNameToUse);
/* 266:385 */             outParameterNames.add(returnNameToUse);
/* 267:    */           }
/* 268:387 */           if (this.logger.isDebugEnabled()) {
/* 269:388 */             this.logger.debug("Added metadata return parameter for: " + returnNameToUse);
/* 270:    */           }
/* 271:    */         }
/* 272:    */       }
/* 273:393 */       else if (meta.getParameterType() == 4)
/* 274:    */       {
/* 275:394 */         workParameters.add(this.metaDataProvider.createDefaultOutParameter(parNameToUse, meta));
/* 276:395 */         outParameterNames.add(parNameToUse);
/* 277:396 */         if (this.logger.isDebugEnabled()) {
/* 278:397 */           this.logger.debug("Added metadata out parameter for: " + parNameToUse);
/* 279:    */         }
/* 280:    */       }
/* 281:400 */       else if (meta.getParameterType() == 2)
/* 282:    */       {
/* 283:401 */         workParameters.add(this.metaDataProvider.createDefaultInOutParameter(parNameToUse, meta));
/* 284:402 */         outParameterNames.add(parNameToUse);
/* 285:403 */         if (this.logger.isDebugEnabled()) {
/* 286:404 */           this.logger.debug("Added metadata in out parameter for: " + parNameToUse);
/* 287:    */         }
/* 288:    */       }
/* 289:408 */       else if ((this.limitedInParameterNames.isEmpty()) || (limitedInParamNamesMap.containsKey(parNameToUse.toLowerCase())))
/* 290:    */       {
/* 291:410 */         workParameters.add(this.metaDataProvider.createDefaultInParameter(parNameToUse, meta));
/* 292:411 */         if (this.logger.isDebugEnabled()) {
/* 293:412 */           this.logger.debug("Added metadata in parameter for: " + parNameToUse);
/* 294:    */         }
/* 295:    */       }
/* 296:416 */       else if (this.logger.isDebugEnabled())
/* 297:    */       {
/* 298:417 */         this.logger.debug("Limited set of parameters " + limitedInParamNamesMap.keySet() + " skipped parameter for: " + parNameToUse);
/* 299:    */       }
/* 300:    */     }
/* 301:426 */     return workParameters;
/* 302:    */   }
/* 303:    */   
/* 304:    */   public Map<String, Object> matchInParameterValuesWithCallParameters(SqlParameterSource parameterSource)
/* 305:    */   {
/* 306:437 */     Map caseInsensitiveParameterNames = SqlParameterSourceUtils.extractCaseInsensitiveParameterNames(parameterSource);
/* 307:    */     
/* 308:    */ 
/* 309:440 */     Map<String, String> callParameterNames = new HashMap(this.callParameters.size());
/* 310:441 */     Map<String, Object> matchedParameters = new HashMap(this.callParameters.size());
/* 311:442 */     for (SqlParameter parameter : this.callParameters) {
/* 312:443 */       if (parameter.isInputValueProvided())
/* 313:    */       {
/* 314:444 */         String parameterName = parameter.getName();
/* 315:445 */         String parameterNameToMatch = this.metaDataProvider.parameterNameToUse(parameterName);
/* 316:446 */         if (parameterNameToMatch != null) {
/* 317:447 */           callParameterNames.put(parameterNameToMatch.toLowerCase(), parameterName);
/* 318:    */         }
/* 319:449 */         if (parameterName != null) {
/* 320:450 */           if (parameterSource.hasValue(parameterName))
/* 321:    */           {
/* 322:451 */             matchedParameters.put(parameterName, SqlParameterSourceUtils.getTypedValue(parameterSource, parameterName));
/* 323:    */           }
/* 324:    */           else
/* 325:    */           {
/* 326:454 */             String lowerCaseName = parameterName.toLowerCase();
/* 327:455 */             if (parameterSource.hasValue(lowerCaseName))
/* 328:    */             {
/* 329:456 */               matchedParameters.put(parameterName, SqlParameterSourceUtils.getTypedValue(parameterSource, lowerCaseName));
/* 330:    */             }
/* 331:    */             else
/* 332:    */             {
/* 333:459 */               String englishLowerCaseName = parameterName.toLowerCase(Locale.ENGLISH);
/* 334:460 */               if (parameterSource.hasValue(englishLowerCaseName))
/* 335:    */               {
/* 336:461 */                 matchedParameters.put(parameterName, SqlParameterSourceUtils.getTypedValue(parameterSource, englishLowerCaseName));
/* 337:    */               }
/* 338:    */               else
/* 339:    */               {
/* 340:464 */                 String propertyName = JdbcUtils.convertUnderscoreNameToPropertyName(parameterName);
/* 341:465 */                 if (parameterSource.hasValue(propertyName))
/* 342:    */                 {
/* 343:466 */                   matchedParameters.put(parameterName, SqlParameterSourceUtils.getTypedValue(parameterSource, propertyName));
/* 344:    */                 }
/* 345:469 */                 else if (caseInsensitiveParameterNames.containsKey(lowerCaseName))
/* 346:    */                 {
/* 347:470 */                   String sourceName = (String)caseInsensitiveParameterNames.get(lowerCaseName);
/* 348:471 */                   matchedParameters.put(parameterName, SqlParameterSourceUtils.getTypedValue(parameterSource, sourceName));
/* 349:    */                 }
/* 350:    */                 else
/* 351:    */                 {
/* 352:474 */                   this.logger.warn("Unable to locate the corresponding parameter value for '" + parameterName + "' within the parameter values provided: " + caseInsensitiveParameterNames.values());
/* 353:    */                 }
/* 354:    */               }
/* 355:    */             }
/* 356:    */           }
/* 357:    */         }
/* 358:    */       }
/* 359:    */     }
/* 360:485 */     if (this.logger.isDebugEnabled())
/* 361:    */     {
/* 362:486 */       this.logger.debug("Matching " + caseInsensitiveParameterNames.values() + " with " + callParameterNames.values());
/* 363:487 */       this.logger.debug("Found match for " + matchedParameters.keySet());
/* 364:    */     }
/* 365:489 */     return matchedParameters;
/* 366:    */   }
/* 367:    */   
/* 368:    */   public Map<String, ?> matchInParameterValuesWithCallParameters(Map<String, ?> inParameters)
/* 369:    */   {
/* 370:498 */     if (!this.metaDataProvider.isProcedureColumnMetaDataUsed()) {
/* 371:499 */       return inParameters;
/* 372:    */     }
/* 373:501 */     Map<String, String> callParameterNames = new HashMap(this.callParameters.size());
/* 374:502 */     for (SqlParameter parameter : this.callParameters) {
/* 375:503 */       if (parameter.isInputValueProvided())
/* 376:    */       {
/* 377:504 */         String parameterName = parameter.getName();
/* 378:505 */         String parameterNameToMatch = this.metaDataProvider.parameterNameToUse(parameterName);
/* 379:506 */         if (parameterNameToMatch != null) {
/* 380:507 */           callParameterNames.put(parameterNameToMatch.toLowerCase(), parameterName);
/* 381:    */         }
/* 382:    */       }
/* 383:    */     }
/* 384:511 */     Map<String, Object> matchedParameters = new HashMap(inParameters.size());
/* 385:512 */     for (String parameterName : inParameters.keySet())
/* 386:    */     {
/* 387:513 */       String parameterNameToMatch = this.metaDataProvider.parameterNameToUse(parameterName);
/* 388:514 */       String callParameterName = (String)callParameterNames.get(parameterNameToMatch.toLowerCase());
/* 389:515 */       if (callParameterName == null)
/* 390:    */       {
/* 391:516 */         if (this.logger.isDebugEnabled())
/* 392:    */         {
/* 393:517 */           Object value = inParameters.get(parameterName);
/* 394:518 */           if ((value instanceof SqlParameterValue)) {
/* 395:519 */             value = ((SqlParameterValue)value).getValue();
/* 396:    */           }
/* 397:521 */           if (value != null) {
/* 398:522 */             this.logger.debug("Unable to locate the corresponding IN or IN-OUT parameter for \"" + parameterName + "\" in the parameters used: " + callParameterNames.keySet());
/* 399:    */           }
/* 400:    */         }
/* 401:    */       }
/* 402:    */       else {
/* 403:528 */         matchedParameters.put(callParameterName, inParameters.get(parameterName));
/* 404:    */       }
/* 405:    */     }
/* 406:531 */     if (matchedParameters.size() < callParameterNames.size()) {
/* 407:532 */       for (String parameterName : callParameterNames.keySet())
/* 408:    */       {
/* 409:533 */         String parameterNameToMatch = this.metaDataProvider.parameterNameToUse(parameterName);
/* 410:534 */         String callParameterName = (String)callParameterNames.get(parameterNameToMatch.toLowerCase());
/* 411:535 */         if (!matchedParameters.containsKey(callParameterName)) {
/* 412:536 */           this.logger.warn("Unable to locate the corresponding parameter value for '" + parameterName + "' within the parameter values provided: " + inParameters.keySet());
/* 413:    */         }
/* 414:    */       }
/* 415:    */     }
/* 416:541 */     if (this.logger.isDebugEnabled())
/* 417:    */     {
/* 418:542 */       this.logger.debug("Matching " + inParameters.keySet() + " with " + callParameterNames.values());
/* 419:543 */       this.logger.debug("Found match for " + matchedParameters.keySet());
/* 420:    */     }
/* 421:545 */     return matchedParameters;
/* 422:    */   }
/* 423:    */   
/* 424:    */   public Map<String, ?> matchInParameterValuesWithCallParameters(Object[] parameterValues)
/* 425:    */   {
/* 426:549 */     Map<String, Object> matchedParameters = new HashMap(parameterValues.length);
/* 427:550 */     int i = 0;
/* 428:551 */     for (SqlParameter parameter : this.callParameters) {
/* 429:552 */       if (parameter.isInputValueProvided())
/* 430:    */       {
/* 431:553 */         String parameterName = parameter.getName();
/* 432:554 */         matchedParameters.put(parameterName, parameterValues[(i++)]);
/* 433:    */       }
/* 434:    */     }
/* 435:557 */     return matchedParameters;
/* 436:    */   }
/* 437:    */   
/* 438:    */   public String createCallString()
/* 439:    */   {
/* 440:566 */     int parameterCount = 0;
/* 441:    */     String catalogNameToUse;
/* 442:    */     String catalogNameToUse;
/* 443:    */     String schemaNameToUse;
/* 444:572 */     if ((this.metaDataProvider.isSupportsSchemasInProcedureCalls()) && (!this.metaDataProvider.isSupportsCatalogsInProcedureCalls()))
/* 445:    */     {
/* 446:574 */       String schemaNameToUse = this.metaDataProvider.catalogNameToUse(getCatalogName());
/* 447:575 */       catalogNameToUse = this.metaDataProvider.schemaNameToUse(getSchemaName());
/* 448:    */     }
/* 449:    */     else
/* 450:    */     {
/* 451:578 */       catalogNameToUse = this.metaDataProvider.catalogNameToUse(getCatalogName());
/* 452:579 */       schemaNameToUse = this.metaDataProvider.schemaNameToUse(getSchemaName());
/* 453:    */     }
/* 454:581 */     String procedureNameToUse = this.metaDataProvider.procedureNameToUse(getProcedureName());
/* 455:582 */     if ((isFunction()) || (isReturnValueRequired()))
/* 456:    */     {
/* 457:583 */       String callString = "{? = call " + (StringUtils.hasLength(catalogNameToUse) ? catalogNameToUse + "." : "") + (StringUtils.hasLength(schemaNameToUse) ? schemaNameToUse + "." : "") + procedureNameToUse + "(";
/* 458:    */       
/* 459:    */ 
/* 460:    */ 
/* 461:587 */       parameterCount = -1;
/* 462:    */     }
/* 463:    */     else
/* 464:    */     {
/* 465:590 */       callString = "{call " + (StringUtils.hasLength(catalogNameToUse) ? catalogNameToUse + "." : "") + (StringUtils.hasLength(schemaNameToUse) ? schemaNameToUse + "." : "") + procedureNameToUse + "(";
/* 466:    */     }
/* 467:595 */     for (SqlParameter parameter : this.callParameters) {
/* 468:596 */       if (!parameter.isResultsParameter())
/* 469:    */       {
/* 470:597 */         if (parameterCount > 0) {
/* 471:598 */           callString = callString + ", ";
/* 472:    */         }
/* 473:600 */         if (parameterCount >= 0) {
/* 474:601 */           callString = callString + "?";
/* 475:    */         }
/* 476:603 */         parameterCount++;
/* 477:    */       }
/* 478:    */     }
/* 479:606 */     String callString = callString + ")}";
/* 480:    */     
/* 481:608 */     return callString;
/* 482:    */   }
/* 483:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.core.metadata.CallMetaDataContext
 * JD-Core Version:    0.7.0.1
 */