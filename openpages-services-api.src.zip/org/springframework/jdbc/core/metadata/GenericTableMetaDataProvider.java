/*   1:    */ package org.springframework.jdbc.core.metadata;
/*   2:    */ 
/*   3:    */ import java.sql.DatabaseMetaData;
/*   4:    */ import java.sql.ResultSet;
/*   5:    */ import java.sql.SQLException;
/*   6:    */ import java.util.ArrayList;
/*   7:    */ import java.util.Arrays;
/*   8:    */ import java.util.HashMap;
/*   9:    */ import java.util.List;
/*  10:    */ import java.util.Map;
/*  11:    */ import org.apache.commons.logging.Log;
/*  12:    */ import org.apache.commons.logging.LogFactory;
/*  13:    */ import org.springframework.dao.DataAccessResourceFailureException;
/*  14:    */ import org.springframework.jdbc.support.nativejdbc.NativeJdbcExtractor;
/*  15:    */ 
/*  16:    */ public class GenericTableMetaDataProvider
/*  17:    */   implements TableMetaDataProvider
/*  18:    */ {
/*  19: 45 */   protected static final Log logger = LogFactory.getLog(TableMetaDataProvider.class);
/*  20: 48 */   private boolean tableColumnMetaDataUsed = false;
/*  21:    */   private String databaseVersion;
/*  22:    */   private String userName;
/*  23: 57 */   private boolean storesUpperCaseIdentifiers = true;
/*  24: 60 */   private boolean storesLowerCaseIdentifiers = false;
/*  25: 63 */   private boolean getGeneratedKeysSupported = true;
/*  26: 66 */   private boolean generatedKeysColumnNameArraySupported = true;
/*  27: 69 */   private List<String> productsNotSupportingGeneratedKeysColumnNameArray = Arrays.asList(new String[] { "Apache Derby", "HSQL Database Engine" });
/*  28: 73 */   private List<TableParameterMetaData> insertParameterMetaData = new ArrayList();
/*  29:    */   private NativeJdbcExtractor nativeJdbcExtractor;
/*  30:    */   
/*  31:    */   protected GenericTableMetaDataProvider(DatabaseMetaData databaseMetaData)
/*  32:    */     throws SQLException
/*  33:    */   {
/*  34: 84 */     this.userName = databaseMetaData.getUserName();
/*  35:    */   }
/*  36:    */   
/*  37:    */   public void setStoresUpperCaseIdentifiers(boolean storesUpperCaseIdentifiers)
/*  38:    */   {
/*  39: 92 */     this.storesUpperCaseIdentifiers = storesUpperCaseIdentifiers;
/*  40:    */   }
/*  41:    */   
/*  42:    */   public boolean isStoresUpperCaseIdentifiers()
/*  43:    */   {
/*  44: 99 */     return this.storesUpperCaseIdentifiers;
/*  45:    */   }
/*  46:    */   
/*  47:    */   public void setStoresLowerCaseIdentifiers(boolean storesLowerCaseIdentifiers)
/*  48:    */   {
/*  49:106 */     this.storesLowerCaseIdentifiers = storesLowerCaseIdentifiers;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public boolean isStoresLowerCaseIdentifiers()
/*  53:    */   {
/*  54:113 */     return this.storesLowerCaseIdentifiers;
/*  55:    */   }
/*  56:    */   
/*  57:    */   public boolean isTableColumnMetaDataUsed()
/*  58:    */   {
/*  59:117 */     return this.tableColumnMetaDataUsed;
/*  60:    */   }
/*  61:    */   
/*  62:    */   public List<TableParameterMetaData> getTableParameterMetaData()
/*  63:    */   {
/*  64:121 */     return this.insertParameterMetaData;
/*  65:    */   }
/*  66:    */   
/*  67:    */   public boolean isGetGeneratedKeysSupported()
/*  68:    */   {
/*  69:125 */     return this.getGeneratedKeysSupported;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public boolean isGetGeneratedKeysSimulated()
/*  73:    */   {
/*  74:129 */     return false;
/*  75:    */   }
/*  76:    */   
/*  77:    */   public String getSimpleQueryForGetGeneratedKey(String tableName, String keyColumnName)
/*  78:    */   {
/*  79:133 */     return null;
/*  80:    */   }
/*  81:    */   
/*  82:    */   public void setGetGeneratedKeysSupported(boolean getGeneratedKeysSupported)
/*  83:    */   {
/*  84:140 */     this.getGeneratedKeysSupported = getGeneratedKeysSupported;
/*  85:    */   }
/*  86:    */   
/*  87:    */   public void setGeneratedKeysColumnNameArraySupported(boolean generatedKeysColumnNameArraySupported)
/*  88:    */   {
/*  89:147 */     this.generatedKeysColumnNameArraySupported = generatedKeysColumnNameArraySupported;
/*  90:    */   }
/*  91:    */   
/*  92:    */   public boolean isGeneratedKeysColumnNameArraySupported()
/*  93:    */   {
/*  94:151 */     return this.generatedKeysColumnNameArraySupported;
/*  95:    */   }
/*  96:    */   
/*  97:    */   public void setNativeJdbcExtractor(NativeJdbcExtractor nativeJdbcExtractor)
/*  98:    */   {
/*  99:155 */     this.nativeJdbcExtractor = nativeJdbcExtractor;
/* 100:    */   }
/* 101:    */   
/* 102:    */   protected NativeJdbcExtractor getNativeJdbcExtractor()
/* 103:    */   {
/* 104:159 */     return this.nativeJdbcExtractor;
/* 105:    */   }
/* 106:    */   
/* 107:    */   public void initializeWithMetaData(DatabaseMetaData databaseMetaData)
/* 108:    */     throws SQLException
/* 109:    */   {
/* 110:    */     try
/* 111:    */     {
/* 112:165 */       if (databaseMetaData.supportsGetGeneratedKeys())
/* 113:    */       {
/* 114:166 */         logger.debug("GetGeneratedKeys is supported");
/* 115:167 */         setGetGeneratedKeysSupported(true);
/* 116:    */       }
/* 117:    */       else
/* 118:    */       {
/* 119:170 */         logger.debug("GetGeneratedKeys is not supported");
/* 120:171 */         setGetGeneratedKeysSupported(false);
/* 121:    */       }
/* 122:    */     }
/* 123:    */     catch (SQLException se)
/* 124:    */     {
/* 125:175 */       logger.warn("Error retrieving 'DatabaseMetaData.getGeneratedKeys' - " + se.getMessage());
/* 126:    */     }
/* 127:    */     try
/* 128:    */     {
/* 129:178 */       String databaseProductName = databaseMetaData.getDatabaseProductName();
/* 130:179 */       if (this.productsNotSupportingGeneratedKeysColumnNameArray.contains(databaseProductName))
/* 131:    */       {
/* 132:180 */         logger.debug("GeneratedKeysColumnNameArray is not supported for " + databaseProductName);
/* 133:181 */         setGeneratedKeysColumnNameArraySupported(false);
/* 134:    */       }
/* 135:184 */       else if (isGetGeneratedKeysSupported())
/* 136:    */       {
/* 137:185 */         logger.debug("GeneratedKeysColumnNameArray is supported for " + databaseProductName);
/* 138:186 */         setGeneratedKeysColumnNameArraySupported(true);
/* 139:    */       }
/* 140:    */       else
/* 141:    */       {
/* 142:189 */         setGeneratedKeysColumnNameArraySupported(false);
/* 143:    */       }
/* 144:    */     }
/* 145:    */     catch (SQLException se)
/* 146:    */     {
/* 147:194 */       logger.warn("Error retrieving 'DatabaseMetaData.getDatabaseProductName' - " + se.getMessage());
/* 148:    */     }
/* 149:    */     try
/* 150:    */     {
/* 151:197 */       this.databaseVersion = databaseMetaData.getDatabaseProductVersion();
/* 152:    */     }
/* 153:    */     catch (SQLException se)
/* 154:    */     {
/* 155:200 */       logger.warn("Error retrieving 'DatabaseMetaData.getDatabaseProductVersion' - " + se.getMessage());
/* 156:    */     }
/* 157:    */     try
/* 158:    */     {
/* 159:203 */       setStoresUpperCaseIdentifiers(databaseMetaData.storesUpperCaseIdentifiers());
/* 160:    */     }
/* 161:    */     catch (SQLException se)
/* 162:    */     {
/* 163:206 */       logger.warn("Error retrieving 'DatabaseMetaData.storesUpperCaseIdentifiers' - " + se.getMessage());
/* 164:    */     }
/* 165:    */     try
/* 166:    */     {
/* 167:209 */       setStoresLowerCaseIdentifiers(databaseMetaData.storesLowerCaseIdentifiers());
/* 168:    */     }
/* 169:    */     catch (SQLException se)
/* 170:    */     {
/* 171:212 */       logger.warn("Error retrieving 'DatabaseMetaData.storesLowerCaseIdentifiers' - " + se.getMessage());
/* 172:    */     }
/* 173:    */   }
/* 174:    */   
/* 175:    */   public void initializeWithTableColumnMetaData(DatabaseMetaData databaseMetaData, String catalogName, String schemaName, String tableName)
/* 176:    */     throws SQLException
/* 177:    */   {
/* 178:220 */     this.tableColumnMetaDataUsed = true;
/* 179:221 */     locateTableAndProcessMetaData(databaseMetaData, catalogName, schemaName, tableName);
/* 180:    */   }
/* 181:    */   
/* 182:    */   public String tableNameToUse(String tableName)
/* 183:    */   {
/* 184:225 */     if (tableName == null) {
/* 185:226 */       return null;
/* 186:    */     }
/* 187:228 */     if (isStoresUpperCaseIdentifiers()) {
/* 188:229 */       return tableName.toUpperCase();
/* 189:    */     }
/* 190:231 */     if (isStoresLowerCaseIdentifiers()) {
/* 191:232 */       return tableName.toLowerCase();
/* 192:    */     }
/* 193:235 */     return tableName;
/* 194:    */   }
/* 195:    */   
/* 196:    */   public String catalogNameToUse(String catalogName)
/* 197:    */   {
/* 198:240 */     if (catalogName == null) {
/* 199:241 */       return null;
/* 200:    */     }
/* 201:243 */     if (isStoresUpperCaseIdentifiers()) {
/* 202:244 */       return catalogName.toUpperCase();
/* 203:    */     }
/* 204:246 */     if (isStoresLowerCaseIdentifiers()) {
/* 205:247 */       return catalogName.toLowerCase();
/* 206:    */     }
/* 207:250 */     return catalogName;
/* 208:    */   }
/* 209:    */   
/* 210:    */   public String schemaNameToUse(String schemaName)
/* 211:    */   {
/* 212:255 */     if (schemaName == null) {
/* 213:256 */       return null;
/* 214:    */     }
/* 215:258 */     if (isStoresUpperCaseIdentifiers()) {
/* 216:259 */       return schemaName.toUpperCase();
/* 217:    */     }
/* 218:261 */     if (isStoresLowerCaseIdentifiers()) {
/* 219:262 */       return schemaName.toLowerCase();
/* 220:    */     }
/* 221:265 */     return schemaName;
/* 222:    */   }
/* 223:    */   
/* 224:    */   public String metaDataCatalogNameToUse(String catalogName)
/* 225:    */   {
/* 226:270 */     return catalogNameToUse(catalogName);
/* 227:    */   }
/* 228:    */   
/* 229:    */   public String metaDataSchemaNameToUse(String schemaName)
/* 230:    */   {
/* 231:274 */     if (schemaName == null) {
/* 232:275 */       return schemaNameToUse(getDefaultSchema());
/* 233:    */     }
/* 234:277 */     return schemaNameToUse(schemaName);
/* 235:    */   }
/* 236:    */   
/* 237:    */   protected String getDefaultSchema()
/* 238:    */   {
/* 239:284 */     return this.userName;
/* 240:    */   }
/* 241:    */   
/* 242:    */   protected String getDatabaseVersion()
/* 243:    */   {
/* 244:291 */     return this.databaseVersion;
/* 245:    */   }
/* 246:    */   
/* 247:    */   private void locateTableAndProcessMetaData(DatabaseMetaData databaseMetaData, String catalogName, String schemaName, String tableName)
/* 248:    */   {
/* 249:300 */     Map<String, TableMetaData> tableMeta = new HashMap();
/* 250:301 */     ResultSet tables = null;
/* 251:    */     try
/* 252:    */     {
/* 253:303 */       tables = databaseMetaData.getTables(catalogNameToUse(catalogName), schemaNameToUse(schemaName), tableNameToUse(tableName), null);
/* 254:308 */       while ((tables != null) && (tables.next()))
/* 255:    */       {
/* 256:309 */         TableMetaData tmd = new TableMetaData(null);
/* 257:310 */         tmd.setCatalogName(tables.getString("TABLE_CAT"));
/* 258:311 */         tmd.setSchemaName(tables.getString("TABLE_SCHEM"));
/* 259:312 */         tmd.setTableName(tables.getString("TABLE_NAME"));
/* 260:313 */         tmd.setType(tables.getString("TABLE_TYPE"));
/* 261:314 */         if (tmd.getSchemaName() == null) {
/* 262:315 */           tableMeta.put(this.userName != null ? this.userName.toUpperCase() : "", tmd);
/* 263:    */         } else {
/* 264:318 */           tableMeta.put(tmd.getSchemaName().toUpperCase(), tmd);
/* 265:    */         }
/* 266:    */       }
/* 267:326 */       if (tables != null) {
/* 268:    */         try
/* 269:    */         {
/* 270:328 */           tables.close();
/* 271:    */         }
/* 272:    */         catch (SQLException e)
/* 273:    */         {
/* 274:330 */           logger.warn("Error while closing table meta data reults" + e.getMessage());
/* 275:    */         }
/* 276:    */       }
/* 277:335 */       if (tableMeta.size() >= 1) {
/* 278:    */         break label414;
/* 279:    */       }
/* 280:    */     }
/* 281:    */     catch (SQLException se)
/* 282:    */     {
/* 283:323 */       logger.warn("Error while accessing table meta data results" + se.getMessage());
/* 284:    */     }
/* 285:    */     finally
/* 286:    */     {
/* 287:326 */       if (tables != null) {
/* 288:    */         try
/* 289:    */         {
/* 290:328 */           tables.close();
/* 291:    */         }
/* 292:    */         catch (SQLException e)
/* 293:    */         {
/* 294:330 */           logger.warn("Error while closing table meta data reults" + e.getMessage());
/* 295:    */         }
/* 296:    */       }
/* 297:    */     }
/* 298:336 */     logger.warn("Unable to locate table meta data for '" + tableName + "' -- column names must be provided"); return;
/* 299:    */     label414:
/* 300:    */     TableMetaData tmd;
/* 301:340 */     if (schemaName == null)
/* 302:    */     {
/* 303:341 */       TableMetaData tmd = (TableMetaData)tableMeta.get(getDefaultSchema());
/* 304:342 */       if (tmd == null) {
/* 305:343 */         tmd = (TableMetaData)tableMeta.get(this.userName != null ? this.userName.toUpperCase() : "");
/* 306:    */       }
/* 307:345 */       if (tmd == null) {
/* 308:346 */         tmd = (TableMetaData)tableMeta.get("PUBLIC");
/* 309:    */       }
/* 310:348 */       if (tmd == null) {
/* 311:349 */         tmd = (TableMetaData)tableMeta.get("DBO");
/* 312:    */       }
/* 313:351 */       if (tmd == null) {
/* 314:352 */         throw new DataAccessResourceFailureException("Unable to locate table meta data for '" + tableName + "' in the default schema");
/* 315:    */       }
/* 316:    */     }
/* 317:    */     else
/* 318:    */     {
/* 319:357 */       tmd = (TableMetaData)tableMeta.get(schemaName.toUpperCase());
/* 320:358 */       if (tmd == null) {
/* 321:359 */         throw new DataAccessResourceFailureException("Unable to locate table meta data for '" + tableName + "' in the '" + schemaName + "' schema");
/* 322:    */       }
/* 323:    */     }
/* 324:364 */     processTableColumns(databaseMetaData, tmd);
/* 325:    */   }
/* 326:    */   
/* 327:    */   private void processTableColumns(DatabaseMetaData databaseMetaData, TableMetaData tmd)
/* 328:    */   {
/* 329:372 */     ResultSet tableColumns = null;
/* 330:373 */     String metaDataCatalogName = metaDataCatalogNameToUse(tmd.getCatalogName());
/* 331:374 */     String metaDataSchemaName = metaDataSchemaNameToUse(tmd.getSchemaName());
/* 332:375 */     String metaDataTableName = tableNameToUse(tmd.getTableName());
/* 333:376 */     if (logger.isDebugEnabled()) {
/* 334:377 */       logger.debug("Retrieving metadata for " + metaDataCatalogName + "/" + metaDataSchemaName + "/" + metaDataTableName);
/* 335:    */     }
/* 336:    */     try
/* 337:    */     {
/* 338:381 */       tableColumns = databaseMetaData.getColumns(metaDataCatalogName, metaDataSchemaName, metaDataTableName, null);
/* 339:386 */       while (tableColumns.next())
/* 340:    */       {
/* 341:387 */         String columnName = tableColumns.getString("COLUMN_NAME");
/* 342:388 */         int dataType = tableColumns.getInt("DATA_TYPE");
/* 343:389 */         if (dataType == 3)
/* 344:    */         {
/* 345:390 */           String typeName = tableColumns.getString("TYPE_NAME");
/* 346:391 */           int decimalDigits = tableColumns.getInt("DECIMAL_DIGITS");
/* 347:395 */           if (("NUMBER".equals(typeName)) && (decimalDigits == 0))
/* 348:    */           {
/* 349:396 */             dataType = 2;
/* 350:397 */             if (logger.isDebugEnabled()) {
/* 351:398 */               logger.debug("Overriding metadata: " + columnName + " now using NUMERIC instead of DECIMAL");
/* 352:    */             }
/* 353:    */           }
/* 354:    */         }
/* 355:405 */         boolean nullable = tableColumns.getBoolean("NULLABLE");
/* 356:406 */         TableParameterMetaData meta = new TableParameterMetaData(columnName, dataType, nullable);
/* 357:    */         
/* 358:    */ 
/* 359:    */ 
/* 360:    */ 
/* 361:411 */         this.insertParameterMetaData.add(meta);
/* 362:412 */         if (logger.isDebugEnabled()) {
/* 363:413 */           logger.debug("Retrieved metadata: " + meta.getParameterName() + " " + meta.getSqlType() + " " + meta.isNullable());
/* 364:    */         }
/* 365:    */       }
/* 366:    */       return;
/* 367:    */     }
/* 368:    */     catch (SQLException se)
/* 369:    */     {
/* 370:422 */       logger.warn("Error while retrieving metadata for table columns: " + se.getMessage());
/* 371:    */     }
/* 372:    */     finally
/* 373:    */     {
/* 374:    */       try
/* 375:    */       {
/* 376:426 */         if (tableColumns != null) {
/* 377:427 */           tableColumns.close();
/* 378:    */         }
/* 379:    */       }
/* 380:    */       catch (SQLException se)
/* 381:    */       {
/* 382:430 */         logger.warn("Problem closing ResultSet for table column metadata " + se.getMessage());
/* 383:    */       }
/* 384:    */     }
/* 385:    */   }
/* 386:    */   
/* 387:    */   private static class TableMetaData
/* 388:    */   {
/* 389:    */     private String catalogName;
/* 390:    */     private String schemaName;
/* 391:    */     private String tableName;
/* 392:    */     private String type;
/* 393:    */     
/* 394:    */     public void setCatalogName(String catalogName)
/* 395:    */     {
/* 396:451 */       this.catalogName = catalogName;
/* 397:    */     }
/* 398:    */     
/* 399:    */     public String getCatalogName()
/* 400:    */     {
/* 401:455 */       return this.catalogName;
/* 402:    */     }
/* 403:    */     
/* 404:    */     public void setSchemaName(String schemaName)
/* 405:    */     {
/* 406:459 */       this.schemaName = schemaName;
/* 407:    */     }
/* 408:    */     
/* 409:    */     public String getSchemaName()
/* 410:    */     {
/* 411:463 */       return this.schemaName;
/* 412:    */     }
/* 413:    */     
/* 414:    */     public void setTableName(String tableName)
/* 415:    */     {
/* 416:467 */       this.tableName = tableName;
/* 417:    */     }
/* 418:    */     
/* 419:    */     public String getTableName()
/* 420:    */     {
/* 421:471 */       return this.tableName;
/* 422:    */     }
/* 423:    */     
/* 424:    */     public void setType(String type)
/* 425:    */     {
/* 426:475 */       this.type = type;
/* 427:    */     }
/* 428:    */     
/* 429:    */     public String getType()
/* 430:    */     {
/* 431:480 */       return this.type;
/* 432:    */     }
/* 433:    */   }
/* 434:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.core.metadata.GenericTableMetaDataProvider
 * JD-Core Version:    0.7.0.1
 */