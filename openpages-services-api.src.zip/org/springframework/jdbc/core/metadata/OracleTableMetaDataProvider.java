/*   1:    */ package org.springframework.jdbc.core.metadata;
/*   2:    */ 
/*   3:    */ import java.lang.reflect.Method;
/*   4:    */ import java.sql.CallableStatement;
/*   5:    */ import java.sql.Connection;
/*   6:    */ import java.sql.DatabaseMetaData;
/*   7:    */ import java.sql.SQLException;
/*   8:    */ import org.apache.commons.logging.Log;
/*   9:    */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*  10:    */ import org.springframework.jdbc.support.nativejdbc.NativeJdbcExtractor;
/*  11:    */ import org.springframework.util.ReflectionUtils;
/*  12:    */ 
/*  13:    */ public class OracleTableMetaDataProvider
/*  14:    */   extends GenericTableMetaDataProvider
/*  15:    */ {
/*  16:    */   private final boolean includeSynonyms;
/*  17:    */   private String defaultSchema;
/*  18:    */   
/*  19:    */   public OracleTableMetaDataProvider(DatabaseMetaData databaseMetaData)
/*  20:    */     throws SQLException
/*  21:    */   {
/*  22: 50 */     this(databaseMetaData, false);
/*  23:    */   }
/*  24:    */   
/*  25:    */   public OracleTableMetaDataProvider(DatabaseMetaData databaseMetaData, boolean includeSynonyms)
/*  26:    */     throws SQLException
/*  27:    */   {
/*  28: 54 */     super(databaseMetaData);
/*  29: 55 */     this.includeSynonyms = includeSynonyms;
/*  30: 56 */     lookupDefaultSchema(databaseMetaData);
/*  31:    */   }
/*  32:    */   
/*  33:    */   protected String getDefaultSchema()
/*  34:    */   {
/*  35: 61 */     if (this.defaultSchema != null) {
/*  36: 62 */       return this.defaultSchema;
/*  37:    */     }
/*  38: 64 */     return super.getDefaultSchema();
/*  39:    */   }
/*  40:    */   
/*  41:    */   public void initializeWithTableColumnMetaData(DatabaseMetaData databaseMetaData, String catalogName, String schemaName, String tableName)
/*  42:    */     throws SQLException
/*  43:    */   {
/*  44: 71 */     if (!this.includeSynonyms)
/*  45:    */     {
/*  46: 72 */       logger.debug("Defaulting to no synonyms in table metadata lookup");
/*  47: 73 */       super.initializeWithTableColumnMetaData(databaseMetaData, catalogName, schemaName, tableName);
/*  48: 74 */       return;
/*  49:    */     }
/*  50: 77 */     Connection con = databaseMetaData.getConnection();
/*  51: 78 */     NativeJdbcExtractor nativeJdbcExtractor = getNativeJdbcExtractor();
/*  52: 79 */     if (nativeJdbcExtractor != null) {
/*  53: 80 */       con = nativeJdbcExtractor.getNativeConnection(con);
/*  54:    */     }
/*  55:    */     boolean isOracleCon;
/*  56:    */     try
/*  57:    */     {
/*  58: 84 */       Class<?> oracleConClass = getClass().getClassLoader().loadClass("oracle.jdbc.OracleConnection");
/*  59: 85 */       isOracleCon = oracleConClass.isInstance(con);
/*  60:    */     }
/*  61:    */     catch (ClassNotFoundException ex)
/*  62:    */     {
/*  63: 88 */       if (logger.isInfoEnabled()) {
/*  64: 89 */         logger.info("Couldn't find Oracle JDBC API: " + ex);
/*  65:    */       }
/*  66: 91 */       isOracleCon = false;
/*  67:    */     }
/*  68: 94 */     if (!isOracleCon)
/*  69:    */     {
/*  70: 95 */       logger.warn("Unable to include synonyms in table metadata lookup. Connection used for DatabaseMetaData is not recognized as an Oracle connection: " + con);
/*  71:    */       
/*  72: 97 */       super.initializeWithTableColumnMetaData(databaseMetaData, catalogName, schemaName, tableName);
/*  73: 98 */       return;
/*  74:    */     }
/*  75:101 */     logger.debug("Including synonyms in table metadata lookup");
/*  76:    */     Boolean originalValueForIncludeSynonyms;
/*  77:    */     Method setIncludeSynonyms;
/*  78:    */     try
/*  79:    */     {
/*  80:106 */       Method getIncludeSynonyms = con.getClass().getMethod("getIncludeSynonyms", (Class[])null);
/*  81:107 */       ReflectionUtils.makeAccessible(getIncludeSynonyms);
/*  82:108 */       originalValueForIncludeSynonyms = (Boolean)getIncludeSynonyms.invoke(con, new Object[0]);
/*  83:    */       
/*  84:110 */       setIncludeSynonyms = con.getClass().getMethod("setIncludeSynonyms", new Class[] { Boolean.TYPE });
/*  85:111 */       ReflectionUtils.makeAccessible(setIncludeSynonyms);
/*  86:112 */       setIncludeSynonyms.invoke(con, new Object[] { Boolean.TRUE });
/*  87:    */     }
/*  88:    */     catch (Exception ex)
/*  89:    */     {
/*  90:115 */       throw new InvalidDataAccessApiUsageException("Couldn't prepare Oracle Connection", ex);
/*  91:    */     }
/*  92:118 */     super.initializeWithTableColumnMetaData(databaseMetaData, catalogName, schemaName, tableName);
/*  93:    */     try
/*  94:    */     {
/*  95:121 */       setIncludeSynonyms.invoke(con, new Object[] { originalValueForIncludeSynonyms });
/*  96:    */     }
/*  97:    */     catch (Exception ex)
/*  98:    */     {
/*  99:124 */       throw new InvalidDataAccessApiUsageException("Couldn't reset Oracle Connection", ex);
/* 100:    */     }
/* 101:    */   }
/* 102:    */   
/* 103:    */   private void lookupDefaultSchema(DatabaseMetaData databaseMetaData)
/* 104:    */   {
/* 105:    */     try
/* 106:    */     {
/* 107:135 */       CallableStatement cstmt = null;
/* 108:    */       try
/* 109:    */       {
/* 110:137 */         cstmt = databaseMetaData.getConnection().prepareCall("{? = call sys_context('USERENV', 'CURRENT_SCHEMA')}");
/* 111:138 */         cstmt.registerOutParameter(1, 12);
/* 112:139 */         cstmt.execute();
/* 113:140 */         this.defaultSchema = cstmt.getString(1);
/* 114:    */       }
/* 115:    */       finally
/* 116:    */       {
/* 117:143 */         if (cstmt != null) {
/* 118:144 */           cstmt.close();
/* 119:    */         }
/* 120:    */       }
/* 121:    */     }
/* 122:    */     catch (Exception ignore) {}
/* 123:    */   }
/* 124:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.core.metadata.OracleTableMetaDataProvider
 * JD-Core Version:    0.7.0.1
 */