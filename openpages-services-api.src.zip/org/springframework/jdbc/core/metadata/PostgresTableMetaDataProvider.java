/*  1:   */ package org.springframework.jdbc.core.metadata;
/*  2:   */ 
/*  3:   */ import java.sql.DatabaseMetaData;
/*  4:   */ import java.sql.SQLException;
/*  5:   */ import org.apache.commons.logging.Log;
/*  6:   */ 
/*  7:   */ public class PostgresTableMetaDataProvider
/*  8:   */   extends GenericTableMetaDataProvider
/*  9:   */ {
/* 10:   */   public PostgresTableMetaDataProvider(DatabaseMetaData databaseMetaData)
/* 11:   */     throws SQLException
/* 12:   */   {
/* 13:32 */     super(databaseMetaData);
/* 14:   */   }
/* 15:   */   
/* 16:   */   public boolean isGetGeneratedKeysSimulated()
/* 17:   */   {
/* 18:37 */     if (getDatabaseVersion().compareTo("8.2.0") >= 0) {
/* 19:38 */       return true;
/* 20:   */     }
/* 21:41 */     logger.warn("PostgreSQL does not support getGeneratedKeys or INSERT ... RETURNING in version " + getDatabaseVersion());
/* 22:42 */     return false;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public String getSimpleQueryForGetGeneratedKey(String tableName, String keyColumnName)
/* 26:   */   {
/* 27:48 */     return "RETURNING " + keyColumnName;
/* 28:   */   }
/* 29:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.core.metadata.PostgresTableMetaDataProvider
 * JD-Core Version:    0.7.0.1
 */