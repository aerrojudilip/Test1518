/*   1:    */ package org.springframework.jdbc.core.metadata;
/*   2:    */ 
/*   3:    */ import java.sql.DatabaseMetaData;
/*   4:    */ import java.sql.ResultSet;
/*   5:    */ import java.sql.SQLException;
/*   6:    */ import java.util.ArrayList;
/*   7:    */ import java.util.List;
/*   8:    */ import org.apache.commons.logging.Log;
/*   9:    */ import org.apache.commons.logging.LogFactory;
/*  10:    */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*  11:    */ import org.springframework.jdbc.core.SqlInOutParameter;
/*  12:    */ import org.springframework.jdbc.core.SqlOutParameter;
/*  13:    */ import org.springframework.jdbc.core.SqlParameter;
/*  14:    */ import org.springframework.util.StringUtils;
/*  15:    */ 
/*  16:    */ public class GenericCallMetaDataProvider
/*  17:    */   implements CallMetaDataProvider
/*  18:    */ {
/*  19: 45 */   protected static final Log logger = LogFactory.getLog(CallMetaDataProvider.class);
/*  20: 47 */   private boolean procedureColumnMetaDataUsed = false;
/*  21:    */   private String userName;
/*  22: 51 */   private boolean supportsCatalogsInProcedureCalls = true;
/*  23: 53 */   private boolean supportsSchemasInProcedureCalls = true;
/*  24: 55 */   private boolean storesUpperCaseIdentifiers = true;
/*  25: 57 */   private boolean storesLowerCaseIdentifiers = false;
/*  26: 59 */   private List<CallParameterMetaData> callParameterMetaData = new ArrayList();
/*  27:    */   
/*  28:    */   protected GenericCallMetaDataProvider(DatabaseMetaData databaseMetaData)
/*  29:    */     throws SQLException
/*  30:    */   {
/*  31: 67 */     this.userName = databaseMetaData.getUserName();
/*  32:    */   }
/*  33:    */   
/*  34:    */   public void initializeWithMetaData(DatabaseMetaData databaseMetaData)
/*  35:    */     throws SQLException
/*  36:    */   {
/*  37:    */     try
/*  38:    */     {
/*  39: 73 */       setSupportsCatalogsInProcedureCalls(databaseMetaData.supportsCatalogsInProcedureCalls());
/*  40:    */     }
/*  41:    */     catch (SQLException se)
/*  42:    */     {
/*  43: 76 */       logger.warn("Error retrieving 'DatabaseMetaData.supportsCatalogsInProcedureCalls' - " + se.getMessage());
/*  44:    */     }
/*  45:    */     try
/*  46:    */     {
/*  47: 79 */       setSupportsSchemasInProcedureCalls(databaseMetaData.supportsSchemasInProcedureCalls());
/*  48:    */     }
/*  49:    */     catch (SQLException se)
/*  50:    */     {
/*  51: 82 */       logger.warn("Error retrieving 'DatabaseMetaData.supportsSchemasInProcedureCalls' - " + se.getMessage());
/*  52:    */     }
/*  53:    */     try
/*  54:    */     {
/*  55: 85 */       setStoresUpperCaseIdentifiers(databaseMetaData.storesUpperCaseIdentifiers());
/*  56:    */     }
/*  57:    */     catch (SQLException se)
/*  58:    */     {
/*  59: 88 */       logger.warn("Error retrieving 'DatabaseMetaData.storesUpperCaseIdentifiers' - " + se.getMessage());
/*  60:    */     }
/*  61:    */     try
/*  62:    */     {
/*  63: 91 */       setStoresLowerCaseIdentifiers(databaseMetaData.storesLowerCaseIdentifiers());
/*  64:    */     }
/*  65:    */     catch (SQLException se)
/*  66:    */     {
/*  67: 94 */       logger.warn("Error retrieving 'DatabaseMetaData.storesLowerCaseIdentifiers' - " + se.getMessage());
/*  68:    */     }
/*  69:    */   }
/*  70:    */   
/*  71:    */   public void initializeWithProcedureColumnMetaData(DatabaseMetaData databaseMetaData, String catalogName, String schemaName, String procedureName)
/*  72:    */     throws SQLException
/*  73:    */   {
/*  74:101 */     this.procedureColumnMetaDataUsed = true;
/*  75:102 */     processProcedureColumns(databaseMetaData, catalogName, schemaName, procedureName);
/*  76:    */   }
/*  77:    */   
/*  78:    */   public List<CallParameterMetaData> getCallParameterMetaData()
/*  79:    */   {
/*  80:106 */     return this.callParameterMetaData;
/*  81:    */   }
/*  82:    */   
/*  83:    */   public String procedureNameToUse(String procedureName)
/*  84:    */   {
/*  85:110 */     if (procedureName == null) {
/*  86:111 */       return null;
/*  87:    */     }
/*  88:113 */     if (isStoresUpperCaseIdentifiers()) {
/*  89:114 */       return procedureName.toUpperCase();
/*  90:    */     }
/*  91:116 */     if (isStoresLowerCaseIdentifiers()) {
/*  92:117 */       return procedureName.toLowerCase();
/*  93:    */     }
/*  94:120 */     return procedureName;
/*  95:    */   }
/*  96:    */   
/*  97:    */   public String catalogNameToUse(String catalogName)
/*  98:    */   {
/*  99:125 */     if (catalogName == null) {
/* 100:126 */       return null;
/* 101:    */     }
/* 102:128 */     if (isStoresUpperCaseIdentifiers()) {
/* 103:129 */       return catalogName.toUpperCase();
/* 104:    */     }
/* 105:131 */     if (isStoresLowerCaseIdentifiers()) {
/* 106:132 */       return catalogName.toLowerCase();
/* 107:    */     }
/* 108:135 */     return catalogName;
/* 109:    */   }
/* 110:    */   
/* 111:    */   public String schemaNameToUse(String schemaName)
/* 112:    */   {
/* 113:140 */     if (schemaName == null) {
/* 114:141 */       return null;
/* 115:    */     }
/* 116:143 */     if (isStoresUpperCaseIdentifiers()) {
/* 117:144 */       return schemaName.toUpperCase();
/* 118:    */     }
/* 119:146 */     if (isStoresLowerCaseIdentifiers()) {
/* 120:147 */       return schemaName.toLowerCase();
/* 121:    */     }
/* 122:150 */     return schemaName;
/* 123:    */   }
/* 124:    */   
/* 125:    */   public String metaDataCatalogNameToUse(String catalogName)
/* 126:    */   {
/* 127:155 */     if (isSupportsCatalogsInProcedureCalls()) {
/* 128:156 */       return catalogNameToUse(catalogName);
/* 129:    */     }
/* 130:159 */     return null;
/* 131:    */   }
/* 132:    */   
/* 133:    */   public String metaDataSchemaNameToUse(String schemaName)
/* 134:    */   {
/* 135:164 */     if (isSupportsSchemasInProcedureCalls()) {
/* 136:165 */       return schemaNameToUse(schemaName);
/* 137:    */     }
/* 138:168 */     return null;
/* 139:    */   }
/* 140:    */   
/* 141:    */   public String parameterNameToUse(String parameterName)
/* 142:    */   {
/* 143:173 */     if (parameterName == null) {
/* 144:174 */       return null;
/* 145:    */     }
/* 146:176 */     if (isStoresUpperCaseIdentifiers()) {
/* 147:177 */       return parameterName.toUpperCase();
/* 148:    */     }
/* 149:179 */     if (isStoresLowerCaseIdentifiers()) {
/* 150:180 */       return parameterName.toLowerCase();
/* 151:    */     }
/* 152:183 */     return parameterName;
/* 153:    */   }
/* 154:    */   
/* 155:    */   public boolean byPassReturnParameter(String parameterName)
/* 156:    */   {
/* 157:188 */     return false;
/* 158:    */   }
/* 159:    */   
/* 160:    */   public SqlParameter createDefaultOutParameter(String parameterName, CallParameterMetaData meta)
/* 161:    */   {
/* 162:192 */     return new SqlOutParameter(parameterName, meta.getSqlType());
/* 163:    */   }
/* 164:    */   
/* 165:    */   public SqlParameter createDefaultInOutParameter(String parameterName, CallParameterMetaData meta)
/* 166:    */   {
/* 167:196 */     return new SqlInOutParameter(parameterName, meta.getSqlType());
/* 168:    */   }
/* 169:    */   
/* 170:    */   public SqlParameter createDefaultInParameter(String parameterName, CallParameterMetaData meta)
/* 171:    */   {
/* 172:200 */     return new SqlParameter(parameterName, meta.getSqlType());
/* 173:    */   }
/* 174:    */   
/* 175:    */   public String getUserName()
/* 176:    */   {
/* 177:204 */     return this.userName;
/* 178:    */   }
/* 179:    */   
/* 180:    */   public boolean isReturnResultSetSupported()
/* 181:    */   {
/* 182:208 */     return true;
/* 183:    */   }
/* 184:    */   
/* 185:    */   public boolean isRefCursorSupported()
/* 186:    */   {
/* 187:212 */     return false;
/* 188:    */   }
/* 189:    */   
/* 190:    */   public int getRefCursorSqlType()
/* 191:    */   {
/* 192:216 */     return 1111;
/* 193:    */   }
/* 194:    */   
/* 195:    */   public boolean isProcedureColumnMetaDataUsed()
/* 196:    */   {
/* 197:220 */     return this.procedureColumnMetaDataUsed;
/* 198:    */   }
/* 199:    */   
/* 200:    */   protected void setSupportsCatalogsInProcedureCalls(boolean supportsCatalogsInProcedureCalls)
/* 201:    */   {
/* 202:228 */     this.supportsCatalogsInProcedureCalls = supportsCatalogsInProcedureCalls;
/* 203:    */   }
/* 204:    */   
/* 205:    */   public boolean isSupportsCatalogsInProcedureCalls()
/* 206:    */   {
/* 207:235 */     return this.supportsCatalogsInProcedureCalls;
/* 208:    */   }
/* 209:    */   
/* 210:    */   protected void setSupportsSchemasInProcedureCalls(boolean supportsSchemasInProcedureCalls)
/* 211:    */   {
/* 212:242 */     this.supportsSchemasInProcedureCalls = supportsSchemasInProcedureCalls;
/* 213:    */   }
/* 214:    */   
/* 215:    */   public boolean isSupportsSchemasInProcedureCalls()
/* 216:    */   {
/* 217:249 */     return this.supportsSchemasInProcedureCalls;
/* 218:    */   }
/* 219:    */   
/* 220:    */   protected void setStoresUpperCaseIdentifiers(boolean storesUpperCaseIdentifiers)
/* 221:    */   {
/* 222:256 */     this.storesUpperCaseIdentifiers = storesUpperCaseIdentifiers;
/* 223:    */   }
/* 224:    */   
/* 225:    */   protected boolean isStoresUpperCaseIdentifiers()
/* 226:    */   {
/* 227:263 */     return this.storesUpperCaseIdentifiers;
/* 228:    */   }
/* 229:    */   
/* 230:    */   protected void setStoresLowerCaseIdentifiers(boolean storesLowerCaseIdentifiers)
/* 231:    */   {
/* 232:270 */     this.storesLowerCaseIdentifiers = storesLowerCaseIdentifiers;
/* 233:    */   }
/* 234:    */   
/* 235:    */   protected boolean isStoresLowerCaseIdentifiers()
/* 236:    */   {
/* 237:277 */     return this.storesLowerCaseIdentifiers;
/* 238:    */   }
/* 239:    */   
/* 240:    */   private void processProcedureColumns(DatabaseMetaData databaseMetaData, String catalogName, String schemaName, String procedureName)
/* 241:    */   {
/* 242:285 */     ResultSet procs = null;
/* 243:286 */     String metaDataCatalogName = metaDataCatalogNameToUse(catalogName);
/* 244:287 */     String metaDataSchemaName = metaDataSchemaNameToUse(schemaName);
/* 245:288 */     String metaDataProcedureName = procedureNameToUse(procedureName);
/* 246:289 */     if (logger.isDebugEnabled()) {
/* 247:290 */       logger.debug("Retrieving metadata for " + metaDataCatalogName + "/" + metaDataSchemaName + "/" + metaDataProcedureName);
/* 248:    */     }
/* 249:    */     try
/* 250:    */     {
/* 251:294 */       procs = databaseMetaData.getProcedures(metaDataCatalogName, metaDataSchemaName, metaDataProcedureName);
/* 252:295 */       List<String> found = new ArrayList();
/* 253:296 */       while (procs.next()) {
/* 254:297 */         found.add(procs.getString("PROCEDURE_CAT") + "." + procs.getString("PROCEDURE_SCHEM") + "." + procs.getString("PROCEDURE_NAME"));
/* 255:    */       }
/* 256:300 */       procs.close();
/* 257:301 */       if (found.size() > 1) {
/* 258:302 */         throw new InvalidDataAccessApiUsageException("Unable to determine the correct call signature - multiple procedures/functions/signatures for " + metaDataProcedureName + " found " + found);
/* 259:    */       }
/* 260:305 */       if ((found.size() < 1) && 
/* 261:306 */         (metaDataProcedureName.contains(".")) && (!StringUtils.hasText(metaDataCatalogName)))
/* 262:    */       {
/* 263:307 */         String packageName = metaDataProcedureName.substring(0, metaDataProcedureName.indexOf("."));
/* 264:308 */         throw new InvalidDataAccessApiUsageException("Unable to determine the correct call signature for " + metaDataProcedureName + " - package name should be specified separately using " + "'.withCatalogName(\"" + packageName + "\")'");
/* 265:    */       }
/* 266:314 */       procs = databaseMetaData.getProcedureColumns(metaDataCatalogName, metaDataSchemaName, metaDataProcedureName, null);
/* 267:316 */       while (procs.next())
/* 268:    */       {
/* 269:317 */         String columnName = procs.getString("COLUMN_NAME");
/* 270:318 */         int columnType = procs.getInt("COLUMN_TYPE");
/* 271:319 */         if ((columnName == null) && ((columnType == 1) || (columnType == 2) || (columnType == 4)))
/* 272:    */         {
/* 273:323 */           if (logger.isDebugEnabled()) {
/* 274:324 */             logger.debug("Skipping metadata for: " + columnName + " " + columnType + " " + procs.getInt("DATA_TYPE") + " " + procs.getString("TYPE_NAME") + " " + procs.getBoolean("NULLABLE") + " (probably a member of a collection)");
/* 275:    */           }
/* 276:    */         }
/* 277:    */         else
/* 278:    */         {
/* 279:335 */           CallParameterMetaData meta = new CallParameterMetaData(columnName, columnType, procs.getInt("DATA_TYPE"), procs.getString("TYPE_NAME"), procs.getBoolean("NULLABLE"));
/* 280:    */           
/* 281:    */ 
/* 282:338 */           this.callParameterMetaData.add(meta);
/* 283:339 */           if (logger.isDebugEnabled()) {
/* 284:340 */             logger.debug("Retrieved metadata: " + meta.getParameterName() + " " + meta.getParameterType() + " " + meta.getSqlType() + " " + meta.getTypeName() + " " + meta.isNullable());
/* 285:    */           }
/* 286:    */         }
/* 287:    */       }
/* 288:    */       return;
/* 289:    */     }
/* 290:    */     catch (SQLException ex)
/* 291:    */     {
/* 292:349 */       logger.warn("Error while retrieving metadata for procedure columns: " + ex);
/* 293:    */     }
/* 294:    */     finally
/* 295:    */     {
/* 296:    */       try
/* 297:    */       {
/* 298:353 */         if (procs != null) {
/* 299:354 */           procs.close();
/* 300:    */         }
/* 301:    */       }
/* 302:    */       catch (SQLException ex)
/* 303:    */       {
/* 304:358 */         logger.warn("Problem closing ResultSet for procedure column metadata: " + ex);
/* 305:    */       }
/* 306:    */     }
/* 307:    */   }
/* 308:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.core.metadata.GenericCallMetaDataProvider
 * JD-Core Version:    0.7.0.1
 */