/*   1:    */ package org.springframework.jdbc.core.metadata;
/*   2:    */ 
/*   3:    */ import java.sql.DatabaseMetaData;
/*   4:    */ import java.sql.SQLException;
/*   5:    */ import java.util.Arrays;
/*   6:    */ import java.util.List;
/*   7:    */ import javax.sql.DataSource;
/*   8:    */ import org.apache.commons.logging.Log;
/*   9:    */ import org.apache.commons.logging.LogFactory;
/*  10:    */ import org.springframework.dao.DataAccessResourceFailureException;
/*  11:    */ import org.springframework.jdbc.support.DatabaseMetaDataCallback;
/*  12:    */ import org.springframework.jdbc.support.JdbcUtils;
/*  13:    */ import org.springframework.jdbc.support.MetaDataAccessException;
/*  14:    */ 
/*  15:    */ public class CallMetaDataProviderFactory
/*  16:    */ {
/*  17: 43 */   private static final Log logger = LogFactory.getLog(CallMetaDataProviderFactory.class);
/*  18: 46 */   public static final List<String> supportedDatabaseProductsForProcedures = Arrays.asList(new String[] { "Apache Derby", "DB2", "MySQL", "Microsoft SQL Server", "Oracle", "PostgreSQL", "Sybase" });
/*  19: 56 */   public static final List<String> supportedDatabaseProductsForFunctions = Arrays.asList(new String[] { "MySQL", "Microsoft SQL Server", "Oracle", "PostgreSQL" });
/*  20:    */   
/*  21:    */   public static CallMetaDataProvider createMetaDataProvider(DataSource dataSource, CallMetaDataContext context)
/*  22:    */   {
/*  23:    */     try
/*  24:    */     {
/*  25: 71 */       (CallMetaDataProvider)JdbcUtils.extractDatabaseMetaData(dataSource, new DatabaseMetaDataCallback()
/*  26:    */       {
/*  27:    */         public Object processMetaData(DatabaseMetaData databaseMetaData)
/*  28:    */           throws SQLException, MetaDataAccessException
/*  29:    */         {
/*  30: 73 */           String databaseProductName = JdbcUtils.commonDatabaseName(databaseMetaData.getDatabaseProductName());
/*  31: 74 */           boolean accessProcedureColumnMetaData = this.val$context.isAccessCallParameterMetaData();
/*  32: 75 */           if (this.val$context.isFunction())
/*  33:    */           {
/*  34: 76 */             if (!CallMetaDataProviderFactory.supportedDatabaseProductsForFunctions.contains(databaseProductName))
/*  35:    */             {
/*  36: 77 */               if (CallMetaDataProviderFactory.logger.isWarnEnabled()) {
/*  37: 78 */                 CallMetaDataProviderFactory.logger.warn(databaseProductName + " is not one of the databases fully supported for function calls " + "-- supported are: " + CallMetaDataProviderFactory.supportedDatabaseProductsForFunctions);
/*  38:    */               }
/*  39: 81 */               if (accessProcedureColumnMetaData)
/*  40:    */               {
/*  41: 82 */                 CallMetaDataProviderFactory.logger.warn("Metadata processing disabled - you must specify all parameters explicitly");
/*  42: 83 */                 accessProcedureColumnMetaData = false;
/*  43:    */               }
/*  44:    */             }
/*  45:    */           }
/*  46: 88 */           else if (!CallMetaDataProviderFactory.supportedDatabaseProductsForProcedures.contains(databaseProductName))
/*  47:    */           {
/*  48: 89 */             if (CallMetaDataProviderFactory.logger.isWarnEnabled()) {
/*  49: 90 */               CallMetaDataProviderFactory.logger.warn(databaseProductName + " is not one of the databases fully supported for procedure calls " + "-- supported are: " + CallMetaDataProviderFactory.supportedDatabaseProductsForProcedures);
/*  50:    */             }
/*  51: 93 */             if (accessProcedureColumnMetaData)
/*  52:    */             {
/*  53: 94 */               CallMetaDataProviderFactory.logger.warn("Metadata processing disabled - you must specify all parameters explicitly");
/*  54: 95 */               accessProcedureColumnMetaData = false;
/*  55:    */             }
/*  56:    */           }
/*  57:    */           CallMetaDataProvider provider;
/*  58:    */           CallMetaDataProvider provider;
/*  59:101 */           if ("Oracle".equals(databaseProductName))
/*  60:    */           {
/*  61:102 */             provider = new OracleCallMetaDataProvider(databaseMetaData);
/*  62:    */           }
/*  63:    */           else
/*  64:    */           {
/*  65:    */             CallMetaDataProvider provider;
/*  66:104 */             if ("DB2".equals(databaseProductName))
/*  67:    */             {
/*  68:105 */               provider = new Db2CallMetaDataProvider(databaseMetaData);
/*  69:    */             }
/*  70:    */             else
/*  71:    */             {
/*  72:    */               CallMetaDataProvider provider;
/*  73:107 */               if ("Apache Derby".equals(databaseProductName))
/*  74:    */               {
/*  75:108 */                 provider = new DerbyCallMetaDataProvider(databaseMetaData);
/*  76:    */               }
/*  77:    */               else
/*  78:    */               {
/*  79:    */                 CallMetaDataProvider provider;
/*  80:110 */                 if ("PostgreSQL".equals(databaseProductName))
/*  81:    */                 {
/*  82:111 */                   provider = new PostgresCallMetaDataProvider(databaseMetaData);
/*  83:    */                 }
/*  84:    */                 else
/*  85:    */                 {
/*  86:    */                   CallMetaDataProvider provider;
/*  87:113 */                   if ("Sybase".equals(databaseProductName))
/*  88:    */                   {
/*  89:114 */                     provider = new SybaseCallMetaDataProvider(databaseMetaData);
/*  90:    */                   }
/*  91:    */                   else
/*  92:    */                   {
/*  93:    */                     CallMetaDataProvider provider;
/*  94:116 */                     if ("Microsoft SQL Server".equals(databaseProductName)) {
/*  95:117 */                       provider = new SqlServerCallMetaDataProvider(databaseMetaData);
/*  96:    */                     } else {
/*  97:120 */                       provider = new GenericCallMetaDataProvider(databaseMetaData);
/*  98:    */                     }
/*  99:    */                   }
/* 100:    */                 }
/* 101:    */               }
/* 102:    */             }
/* 103:    */           }
/* 104:122 */           if (CallMetaDataProviderFactory.logger.isDebugEnabled()) {
/* 105:123 */             CallMetaDataProviderFactory.logger.debug("Using " + provider.getClass().getName());
/* 106:    */           }
/* 107:125 */           provider.initializeWithMetaData(databaseMetaData);
/* 108:126 */           if (accessProcedureColumnMetaData) {
/* 109:127 */             provider.initializeWithProcedureColumnMetaData(databaseMetaData, this.val$context.getCatalogName(), this.val$context.getSchemaName(), this.val$context.getProcedureName());
/* 110:    */           }
/* 111:130 */           return provider;
/* 112:    */         }
/* 113:    */       });
/* 114:    */     }
/* 115:    */     catch (MetaDataAccessException ex)
/* 116:    */     {
/* 117:135 */       throw new DataAccessResourceFailureException("Error retreiving database metadata", ex);
/* 118:    */     }
/* 119:    */   }
/* 120:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.core.metadata.CallMetaDataProviderFactory
 * JD-Core Version:    0.7.0.1
 */