/*   1:    */ package org.springframework.jdbc.core.metadata;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.HashMap;
/*   5:    */ import java.util.HashSet;
/*   6:    */ import java.util.List;
/*   7:    */ import java.util.Map;
/*   8:    */ import java.util.Set;
/*   9:    */ import javax.sql.DataSource;
/*  10:    */ import org.apache.commons.logging.Log;
/*  11:    */ import org.apache.commons.logging.LogFactory;
/*  12:    */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*  13:    */ import org.springframework.jdbc.core.namedparam.SqlParameterSource;
/*  14:    */ import org.springframework.jdbc.core.namedparam.SqlParameterSourceUtils;
/*  15:    */ import org.springframework.jdbc.support.JdbcUtils;
/*  16:    */ import org.springframework.jdbc.support.nativejdbc.NativeJdbcExtractor;
/*  17:    */ 
/*  18:    */ public class TableMetaDataContext
/*  19:    */ {
/*  20: 48 */   protected final Log logger = LogFactory.getLog(getClass());
/*  21:    */   private String tableName;
/*  22:    */   private String catalogName;
/*  23:    */   private String schemaName;
/*  24: 60 */   private List<String> tableColumns = new ArrayList();
/*  25: 63 */   private boolean accessTableColumnMetaData = true;
/*  26: 66 */   private boolean overrideIncludeSynonymsDefault = false;
/*  27:    */   private TableMetaDataProvider metaDataProvider;
/*  28: 72 */   private boolean generatedKeyColumnsUsed = false;
/*  29:    */   NativeJdbcExtractor nativeJdbcExtractor;
/*  30:    */   
/*  31:    */   public void setTableName(String tableName)
/*  32:    */   {
/*  33: 82 */     this.tableName = tableName;
/*  34:    */   }
/*  35:    */   
/*  36:    */   public String getTableName()
/*  37:    */   {
/*  38: 89 */     return this.tableName;
/*  39:    */   }
/*  40:    */   
/*  41:    */   public void setCatalogName(String catalogName)
/*  42:    */   {
/*  43: 96 */     this.catalogName = catalogName;
/*  44:    */   }
/*  45:    */   
/*  46:    */   public String getCatalogName()
/*  47:    */   {
/*  48:103 */     return this.catalogName;
/*  49:    */   }
/*  50:    */   
/*  51:    */   public void setSchemaName(String schemaName)
/*  52:    */   {
/*  53:110 */     this.schemaName = schemaName;
/*  54:    */   }
/*  55:    */   
/*  56:    */   public String getSchemaName()
/*  57:    */   {
/*  58:117 */     return this.schemaName;
/*  59:    */   }
/*  60:    */   
/*  61:    */   public void setAccessTableColumnMetaData(boolean accessTableColumnMetaData)
/*  62:    */   {
/*  63:124 */     this.accessTableColumnMetaData = accessTableColumnMetaData;
/*  64:    */   }
/*  65:    */   
/*  66:    */   public boolean isAccessTableColumnMetaData()
/*  67:    */   {
/*  68:131 */     return this.accessTableColumnMetaData;
/*  69:    */   }
/*  70:    */   
/*  71:    */   public void setOverrideIncludeSynonymsDefault(boolean override)
/*  72:    */   {
/*  73:139 */     this.overrideIncludeSynonymsDefault = override;
/*  74:    */   }
/*  75:    */   
/*  76:    */   public boolean isOverrideIncludeSynonymsDefault()
/*  77:    */   {
/*  78:146 */     return this.overrideIncludeSynonymsDefault;
/*  79:    */   }
/*  80:    */   
/*  81:    */   public List<String> getTableColumns()
/*  82:    */   {
/*  83:153 */     return this.tableColumns;
/*  84:    */   }
/*  85:    */   
/*  86:    */   public boolean isGetGeneratedKeysSupported()
/*  87:    */   {
/*  88:161 */     return this.metaDataProvider.isGetGeneratedKeysSupported();
/*  89:    */   }
/*  90:    */   
/*  91:    */   public boolean isGetGeneratedKeysSimulated()
/*  92:    */   {
/*  93:170 */     return this.metaDataProvider.isGetGeneratedKeysSimulated();
/*  94:    */   }
/*  95:    */   
/*  96:    */   public String getSimulationQueryForGetGeneratedKey(String tableName, String keyColumnName)
/*  97:    */   {
/*  98:179 */     return this.metaDataProvider.getSimpleQueryForGetGeneratedKey(tableName, keyColumnName);
/*  99:    */   }
/* 100:    */   
/* 101:    */   public boolean isGeneratedKeysColumnNameArraySupported()
/* 102:    */   {
/* 103:187 */     return this.metaDataProvider.isGeneratedKeysColumnNameArraySupported();
/* 104:    */   }
/* 105:    */   
/* 106:    */   public void setNativeJdbcExtractor(NativeJdbcExtractor nativeJdbcExtractor)
/* 107:    */   {
/* 108:194 */     this.nativeJdbcExtractor = nativeJdbcExtractor;
/* 109:    */   }
/* 110:    */   
/* 111:    */   public void processMetaData(DataSource dataSource, List<String> declaredColumns, String[] generatedKeyNames)
/* 112:    */   {
/* 113:205 */     this.metaDataProvider = TableMetaDataProviderFactory.createMetaDataProvider(dataSource, this, this.nativeJdbcExtractor);
/* 114:206 */     this.tableColumns = reconcileColumnsToUse(declaredColumns, generatedKeyNames);
/* 115:    */   }
/* 116:    */   
/* 117:    */   protected List<String> reconcileColumnsToUse(List<String> declaredColumns, String[] generatedKeyNames)
/* 118:    */   {
/* 119:215 */     if (generatedKeyNames.length > 0) {
/* 120:216 */       this.generatedKeyColumnsUsed = true;
/* 121:    */     }
/* 122:218 */     if (declaredColumns.size() > 0) {
/* 123:219 */       return new ArrayList(declaredColumns);
/* 124:    */     }
/* 125:221 */     Set<String> keys = new HashSet(generatedKeyNames.length);
/* 126:222 */     for (String key : generatedKeyNames) {
/* 127:223 */       keys.add(key.toUpperCase());
/* 128:    */     }
/* 129:225 */     List<String> columns = new ArrayList();
/* 130:226 */     for (TableParameterMetaData meta : this.metaDataProvider.getTableParameterMetaData()) {
/* 131:227 */       if (!keys.contains(meta.getParameterName().toUpperCase())) {
/* 132:228 */         columns.add(meta.getParameterName());
/* 133:    */       }
/* 134:    */     }
/* 135:231 */     return columns;
/* 136:    */   }
/* 137:    */   
/* 138:    */   public List<Object> matchInParameterValuesWithInsertColumns(SqlParameterSource parameterSource)
/* 139:    */   {
/* 140:239 */     List<Object> values = new ArrayList();
/* 141:    */     
/* 142:    */ 
/* 143:242 */     Map caseInsensitiveParameterNames = SqlParameterSourceUtils.extractCaseInsensitiveParameterNames(parameterSource);
/* 144:244 */     for (String column : this.tableColumns) {
/* 145:245 */       if (parameterSource.hasValue(column))
/* 146:    */       {
/* 147:246 */         values.add(SqlParameterSourceUtils.getTypedValue(parameterSource, column));
/* 148:    */       }
/* 149:    */       else
/* 150:    */       {
/* 151:249 */         String lowerCaseName = column.toLowerCase();
/* 152:250 */         if (parameterSource.hasValue(lowerCaseName))
/* 153:    */         {
/* 154:251 */           values.add(SqlParameterSourceUtils.getTypedValue(parameterSource, lowerCaseName));
/* 155:    */         }
/* 156:    */         else
/* 157:    */         {
/* 158:254 */           String propertyName = JdbcUtils.convertUnderscoreNameToPropertyName(column);
/* 159:255 */           if (parameterSource.hasValue(propertyName)) {
/* 160:256 */             values.add(SqlParameterSourceUtils.getTypedValue(parameterSource, propertyName));
/* 161:259 */           } else if (caseInsensitiveParameterNames.containsKey(lowerCaseName)) {
/* 162:260 */             values.add(SqlParameterSourceUtils.getTypedValue(parameterSource, (String)caseInsensitiveParameterNames.get(lowerCaseName)));
/* 163:    */           } else {
/* 164:265 */             values.add(null);
/* 165:    */           }
/* 166:    */         }
/* 167:    */       }
/* 168:    */     }
/* 169:271 */     return values;
/* 170:    */   }
/* 171:    */   
/* 172:    */   public List<Object> matchInParameterValuesWithInsertColumns(Map<String, Object> inParameters)
/* 173:    */   {
/* 174:279 */     List<Object> values = new ArrayList();
/* 175:280 */     Map<String, Object> source = new HashMap();
/* 176:281 */     for (String key : inParameters.keySet()) {
/* 177:282 */       source.put(key.toLowerCase(), inParameters.get(key));
/* 178:    */     }
/* 179:284 */     for (String column : this.tableColumns) {
/* 180:285 */       values.add(source.get(column.toLowerCase()));
/* 181:    */     }
/* 182:287 */     return values;
/* 183:    */   }
/* 184:    */   
/* 185:    */   public String createInsertString(String[] generatedKeyNames)
/* 186:    */   {
/* 187:296 */     HashSet<String> keys = new HashSet(generatedKeyNames.length);
/* 188:297 */     for (String key : generatedKeyNames) {
/* 189:298 */       keys.add(key.toUpperCase());
/* 190:    */     }
/* 191:300 */     StringBuilder insertStatement = new StringBuilder();
/* 192:301 */     insertStatement.append("INSERT INTO ");
/* 193:302 */     if (getSchemaName() != null)
/* 194:    */     {
/* 195:303 */       insertStatement.append(getSchemaName());
/* 196:304 */       insertStatement.append(".");
/* 197:    */     }
/* 198:306 */     insertStatement.append(getTableName());
/* 199:307 */     insertStatement.append(" (");
/* 200:308 */     int columnCount = 0;
/* 201:309 */     for (String columnName : getTableColumns()) {
/* 202:310 */       if (!keys.contains(columnName.toUpperCase()))
/* 203:    */       {
/* 204:311 */         columnCount++;
/* 205:312 */         if (columnCount > 1) {
/* 206:313 */           insertStatement.append(", ");
/* 207:    */         }
/* 208:315 */         insertStatement.append(columnName);
/* 209:    */       }
/* 210:    */     }
/* 211:318 */     insertStatement.append(") VALUES(");
/* 212:319 */     if (columnCount < 1) {
/* 213:320 */       if (this.generatedKeyColumnsUsed) {
/* 214:321 */         this.logger.info("Unable to locate non-key columns for table '" + getTableName() + "' so an empty insert statement is generated");
/* 215:    */       } else {
/* 216:325 */         throw new InvalidDataAccessApiUsageException("Unable to locate columns for table '" + getTableName() + "' so an insert statement can't be generated");
/* 217:    */       }
/* 218:    */     }
/* 219:329 */     for (int i = 0; i < columnCount; i++)
/* 220:    */     {
/* 221:330 */       if (i > 0) {
/* 222:331 */         insertStatement.append(", ");
/* 223:    */       }
/* 224:333 */       insertStatement.append("?");
/* 225:    */     }
/* 226:335 */     insertStatement.append(")");
/* 227:336 */     return insertStatement.toString();
/* 228:    */   }
/* 229:    */   
/* 230:    */   public int[] createInsertTypes()
/* 231:    */   {
/* 232:344 */     int[] types = new int[getTableColumns().size()];
/* 233:345 */     List<TableParameterMetaData> parameters = this.metaDataProvider.getTableParameterMetaData();
/* 234:346 */     Map<String, TableParameterMetaData> parameterMap = new HashMap(parameters.size());
/* 235:347 */     for (TableParameterMetaData tpmd : parameters) {
/* 236:348 */       parameterMap.put(tpmd.getParameterName().toUpperCase(), tpmd);
/* 237:    */     }
/* 238:350 */     int typeIndx = 0;
/* 239:351 */     for (String column : getTableColumns())
/* 240:    */     {
/* 241:352 */       if (column == null)
/* 242:    */       {
/* 243:353 */         types[typeIndx] = -2147483648;
/* 244:    */       }
/* 245:    */       else
/* 246:    */       {
/* 247:356 */         TableParameterMetaData tpmd = (TableParameterMetaData)parameterMap.get(column.toUpperCase());
/* 248:357 */         if (tpmd != null) {
/* 249:358 */           types[typeIndx] = tpmd.getSqlType();
/* 250:    */         } else {
/* 251:361 */           types[typeIndx] = -2147483648;
/* 252:    */         }
/* 253:    */       }
/* 254:364 */       typeIndx++;
/* 255:    */     }
/* 256:366 */     return types;
/* 257:    */   }
/* 258:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.core.metadata.TableMetaDataContext
 * JD-Core Version:    0.7.0.1
 */