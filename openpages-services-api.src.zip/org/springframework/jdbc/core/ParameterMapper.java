package org.springframework.jdbc.core;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Map;

public abstract interface ParameterMapper
{
  public abstract Map<String, ?> createMap(Connection paramConnection)
    throws SQLException;
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.core.ParameterMapper
 * JD-Core Version:    0.7.0.1
 */