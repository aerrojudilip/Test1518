package org.springframework.jdbc.core;

import java.sql.CallableStatement;
import java.sql.SQLException;

public abstract interface SqlReturnType
{
  public static final int TYPE_UNKNOWN = -2147483648;
  
  public abstract Object getTypeValue(CallableStatement paramCallableStatement, int paramInt1, int paramInt2, String paramString)
    throws SQLException;
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.core.SqlReturnType
 * JD-Core Version:    0.7.0.1
 */