/*  1:   */ package org.springframework.jdbc.core;
/*  2:   */ 
/*  3:   */ import java.sql.PreparedStatement;
/*  4:   */ import java.sql.SQLException;
/*  5:   */ import java.util.List;
/*  6:   */ 
/*  7:   */ public abstract class BatchUpdateUtils
/*  8:   */ {
/*  9:   */   public static int[] executeBatchUpdate(String sql, List<Object[]> batchValues, final int[] columnTypes, JdbcOperations jdbcOperations)
/* 10:   */   {
/* 11:32 */     jdbcOperations.batchUpdate(sql, new BatchPreparedStatementSetter()
/* 12:   */     {
/* 13:   */       public void setValues(PreparedStatement ps, int i)
/* 14:   */         throws SQLException
/* 15:   */       {
/* 16:37 */         Object[] values = (Object[])this.val$batchValues.get(i);
/* 17:38 */         BatchUpdateUtils.setStatementParameters(values, ps, columnTypes);
/* 18:   */       }
/* 19:   */       
/* 20:   */       public int getBatchSize()
/* 21:   */       {
/* 22:42 */         return this.val$batchValues.size();
/* 23:   */       }
/* 24:   */     });
/* 25:   */   }
/* 26:   */   
/* 27:   */   protected static void setStatementParameters(Object[] values, PreparedStatement ps, int[] columnTypes)
/* 28:   */     throws SQLException
/* 29:   */   {
/* 30:48 */     int colIndex = 0;
/* 31:49 */     for (Object value : values)
/* 32:   */     {
/* 33:50 */       colIndex++;
/* 34:51 */       if ((value instanceof SqlParameterValue))
/* 35:   */       {
/* 36:52 */         SqlParameterValue paramValue = (SqlParameterValue)value;
/* 37:53 */         StatementCreatorUtils.setParameterValue(ps, colIndex, paramValue, paramValue.getValue());
/* 38:   */       }
/* 39:   */       else
/* 40:   */       {
/* 41:   */         int colType;
/* 42:   */         int colType;
/* 43:57 */         if ((columnTypes == null) || (columnTypes.length < colIndex)) {
/* 44:58 */           colType = -2147483648;
/* 45:   */         } else {
/* 46:61 */           colType = columnTypes[(colIndex - 1)];
/* 47:   */         }
/* 48:63 */         StatementCreatorUtils.setParameterValue(ps, colIndex, colType, value);
/* 49:   */       }
/* 50:   */     }
/* 51:   */   }
/* 52:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.core.BatchUpdateUtils
 * JD-Core Version:    0.7.0.1
 */