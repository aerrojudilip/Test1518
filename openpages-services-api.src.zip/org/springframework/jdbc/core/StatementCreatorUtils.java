/*   1:    */ package org.springframework.jdbc.core;
/*   2:    */ 
/*   3:    */ import java.io.StringWriter;
/*   4:    */ import java.math.BigDecimal;
/*   5:    */ import java.math.BigInteger;
/*   6:    */ import java.sql.Blob;
/*   7:    */ import java.sql.Clob;
/*   8:    */ import java.sql.Connection;
/*   9:    */ import java.sql.DatabaseMetaData;
/*  10:    */ import java.sql.PreparedStatement;
/*  11:    */ import java.sql.SQLException;
/*  12:    */ import java.sql.Time;
/*  13:    */ import java.sql.Timestamp;
/*  14:    */ import java.util.Arrays;
/*  15:    */ import java.util.Calendar;
/*  16:    */ import java.util.Collection;
/*  17:    */ import java.util.HashMap;
/*  18:    */ import java.util.Map;
/*  19:    */ import org.apache.commons.logging.Log;
/*  20:    */ import org.apache.commons.logging.LogFactory;
/*  21:    */ import org.springframework.jdbc.support.SqlValue;
/*  22:    */ 
/*  23:    */ public abstract class StatementCreatorUtils
/*  24:    */ {
/*  25: 61 */   private static final Log logger = LogFactory.getLog(StatementCreatorUtils.class);
/*  26: 63 */   private static Map<Class, Integer> javaTypeToSqlTypeMap = new HashMap(32);
/*  27:    */   
/*  28:    */   static
/*  29:    */   {
/*  30: 70 */     javaTypeToSqlTypeMap.put(Byte.TYPE, Integer.valueOf(-6));
/*  31: 71 */     javaTypeToSqlTypeMap.put(Byte.class, Integer.valueOf(-6));
/*  32: 72 */     javaTypeToSqlTypeMap.put(Short.TYPE, Integer.valueOf(5));
/*  33: 73 */     javaTypeToSqlTypeMap.put(Short.class, Integer.valueOf(5));
/*  34: 74 */     javaTypeToSqlTypeMap.put(Integer.TYPE, Integer.valueOf(4));
/*  35: 75 */     javaTypeToSqlTypeMap.put(Integer.class, Integer.valueOf(4));
/*  36: 76 */     javaTypeToSqlTypeMap.put(Long.TYPE, Integer.valueOf(-5));
/*  37: 77 */     javaTypeToSqlTypeMap.put(Long.class, Integer.valueOf(-5));
/*  38: 78 */     javaTypeToSqlTypeMap.put(BigInteger.class, Integer.valueOf(-5));
/*  39: 79 */     javaTypeToSqlTypeMap.put(Float.TYPE, Integer.valueOf(6));
/*  40: 80 */     javaTypeToSqlTypeMap.put(Float.class, Integer.valueOf(6));
/*  41: 81 */     javaTypeToSqlTypeMap.put(Double.TYPE, Integer.valueOf(8));
/*  42: 82 */     javaTypeToSqlTypeMap.put(Double.class, Integer.valueOf(8));
/*  43: 83 */     javaTypeToSqlTypeMap.put(BigDecimal.class, Integer.valueOf(3));
/*  44: 84 */     javaTypeToSqlTypeMap.put(java.sql.Date.class, Integer.valueOf(91));
/*  45: 85 */     javaTypeToSqlTypeMap.put(Time.class, Integer.valueOf(92));
/*  46: 86 */     javaTypeToSqlTypeMap.put(Timestamp.class, Integer.valueOf(93));
/*  47: 87 */     javaTypeToSqlTypeMap.put(Blob.class, Integer.valueOf(2004));
/*  48: 88 */     javaTypeToSqlTypeMap.put(Clob.class, Integer.valueOf(2005));
/*  49:    */   }
/*  50:    */   
/*  51:    */   public static int javaTypeToSqlParameterType(Class javaType)
/*  52:    */   {
/*  53: 98 */     Integer sqlType = (Integer)javaTypeToSqlTypeMap.get(javaType);
/*  54: 99 */     if (sqlType != null) {
/*  55:100 */       return sqlType.intValue();
/*  56:    */     }
/*  57:102 */     if (Number.class.isAssignableFrom(javaType)) {
/*  58:103 */       return 2;
/*  59:    */     }
/*  60:105 */     if (isStringValue(javaType)) {
/*  61:106 */       return 12;
/*  62:    */     }
/*  63:108 */     if ((isDateValue(javaType)) || (Calendar.class.isAssignableFrom(javaType))) {
/*  64:109 */       return 93;
/*  65:    */     }
/*  66:111 */     return -2147483648;
/*  67:    */   }
/*  68:    */   
/*  69:    */   public static void setParameterValue(PreparedStatement ps, int paramIndex, SqlParameter param, Object inValue)
/*  70:    */     throws SQLException
/*  71:    */   {
/*  72:127 */     setParameterValueInternal(ps, paramIndex, param.getSqlType(), param.getTypeName(), param.getScale(), inValue);
/*  73:    */   }
/*  74:    */   
/*  75:    */   public static void setParameterValue(PreparedStatement ps, int paramIndex, int sqlType, Object inValue)
/*  76:    */     throws SQLException
/*  77:    */   {
/*  78:144 */     setParameterValueInternal(ps, paramIndex, sqlType, null, null, inValue);
/*  79:    */   }
/*  80:    */   
/*  81:    */   public static void setParameterValue(PreparedStatement ps, int paramIndex, int sqlType, String typeName, Object inValue)
/*  82:    */     throws SQLException
/*  83:    */   {
/*  84:163 */     setParameterValueInternal(ps, paramIndex, sqlType, typeName, null, inValue);
/*  85:    */   }
/*  86:    */   
/*  87:    */   private static void setParameterValueInternal(PreparedStatement ps, int paramIndex, int sqlType, String typeName, Integer scale, Object inValue)
/*  88:    */     throws SQLException
/*  89:    */   {
/*  90:184 */     String typeNameToUse = typeName;
/*  91:185 */     int sqlTypeToUse = sqlType;
/*  92:186 */     Object inValueToUse = inValue;
/*  93:189 */     if ((inValue instanceof SqlParameterValue))
/*  94:    */     {
/*  95:190 */       SqlParameterValue parameterValue = (SqlParameterValue)inValue;
/*  96:191 */       if (logger.isDebugEnabled()) {
/*  97:192 */         logger.debug("Overriding typeinfo with runtime info from SqlParameterValue: column index " + paramIndex + ", SQL type " + parameterValue.getSqlType() + ", Type name " + parameterValue.getTypeName());
/*  98:    */       }
/*  99:196 */       if (parameterValue.getSqlType() != -2147483648) {
/* 100:197 */         sqlTypeToUse = parameterValue.getSqlType();
/* 101:    */       }
/* 102:199 */       if (parameterValue.getTypeName() != null) {
/* 103:200 */         typeNameToUse = parameterValue.getTypeName();
/* 104:    */       }
/* 105:202 */       inValueToUse = parameterValue.getValue();
/* 106:    */     }
/* 107:205 */     if (logger.isTraceEnabled()) {
/* 108:206 */       logger.trace("Setting SQL statement parameter value: column index " + paramIndex + ", parameter value [" + inValueToUse + "], value class [" + (inValueToUse != null ? inValueToUse.getClass().getName() : "null") + "], SQL type " + (sqlTypeToUse == -2147483648 ? "unknown" : Integer.toString(sqlTypeToUse)));
/* 109:    */     }
/* 110:212 */     if (inValueToUse == null) {
/* 111:213 */       setNull(ps, paramIndex, sqlTypeToUse, typeNameToUse);
/* 112:    */     } else {
/* 113:216 */       setValue(ps, paramIndex, sqlTypeToUse, typeNameToUse, scale, inValueToUse);
/* 114:    */     }
/* 115:    */   }
/* 116:    */   
/* 117:    */   private static void setNull(PreparedStatement ps, int paramIndex, int sqlType, String typeName)
/* 118:    */     throws SQLException
/* 119:    */   {
/* 120:227 */     if (sqlType == -2147483648)
/* 121:    */     {
/* 122:228 */       boolean useSetObject = false;
/* 123:229 */       sqlType = 0;
/* 124:    */       try
/* 125:    */       {
/* 126:231 */         DatabaseMetaData dbmd = ps.getConnection().getMetaData();
/* 127:232 */         String databaseProductName = dbmd.getDatabaseProductName();
/* 128:233 */         String jdbcDriverName = dbmd.getDriverName();
/* 129:234 */         if ((databaseProductName.startsWith("Informix")) || (jdbcDriverName.startsWith("Microsoft SQL Server"))) {
/* 130:236 */           useSetObject = true;
/* 131:238 */         } else if ((databaseProductName.startsWith("DB2")) || (jdbcDriverName.startsWith("jConnect")) || (jdbcDriverName.startsWith("SQLServer")) || (jdbcDriverName.startsWith("Apache Derby"))) {
/* 132:242 */           sqlType = 12;
/* 133:    */         }
/* 134:    */       }
/* 135:    */       catch (Throwable ex)
/* 136:    */       {
/* 137:246 */         logger.debug("Could not check database or driver name", ex);
/* 138:    */       }
/* 139:248 */       if (useSetObject) {
/* 140:249 */         ps.setObject(paramIndex, null);
/* 141:    */       } else {
/* 142:252 */         ps.setNull(paramIndex, sqlType);
/* 143:    */       }
/* 144:    */     }
/* 145:255 */     else if (typeName != null)
/* 146:    */     {
/* 147:256 */       ps.setNull(paramIndex, sqlType, typeName);
/* 148:    */     }
/* 149:    */     else
/* 150:    */     {
/* 151:259 */       ps.setNull(paramIndex, sqlType);
/* 152:    */     }
/* 153:    */   }
/* 154:    */   
/* 155:    */   private static void setValue(PreparedStatement ps, int paramIndex, int sqlType, String typeName, Integer scale, Object inValue)
/* 156:    */     throws SQLException
/* 157:    */   {
/* 158:266 */     if ((inValue instanceof SqlTypeValue)) {
/* 159:267 */       ((SqlTypeValue)inValue).setTypeValue(ps, paramIndex, sqlType, typeName);
/* 160:269 */     } else if ((inValue instanceof SqlValue)) {
/* 161:270 */       ((SqlValue)inValue).setValue(ps, paramIndex);
/* 162:272 */     } else if ((sqlType == 12) || (sqlType == -1) || ((sqlType == 2005) && (isStringValue(inValue.getClass())))) {
/* 163:274 */       ps.setString(paramIndex, inValue.toString());
/* 164:276 */     } else if ((sqlType == 3) || (sqlType == 2))
/* 165:    */     {
/* 166:277 */       if ((inValue instanceof BigDecimal)) {
/* 167:278 */         ps.setBigDecimal(paramIndex, (BigDecimal)inValue);
/* 168:280 */       } else if (scale != null) {
/* 169:281 */         ps.setObject(paramIndex, inValue, sqlType, scale.intValue());
/* 170:    */       } else {
/* 171:284 */         ps.setObject(paramIndex, inValue, sqlType);
/* 172:    */       }
/* 173:    */     }
/* 174:287 */     else if (sqlType == 91)
/* 175:    */     {
/* 176:288 */       if ((inValue instanceof java.util.Date))
/* 177:    */       {
/* 178:289 */         if ((inValue instanceof java.sql.Date)) {
/* 179:290 */           ps.setDate(paramIndex, (java.sql.Date)inValue);
/* 180:    */         } else {
/* 181:293 */           ps.setDate(paramIndex, new java.sql.Date(((java.util.Date)inValue).getTime()));
/* 182:    */         }
/* 183:    */       }
/* 184:296 */       else if ((inValue instanceof Calendar))
/* 185:    */       {
/* 186:297 */         Calendar cal = (Calendar)inValue;
/* 187:298 */         ps.setDate(paramIndex, new java.sql.Date(cal.getTime().getTime()), cal);
/* 188:    */       }
/* 189:    */       else
/* 190:    */       {
/* 191:301 */         ps.setObject(paramIndex, inValue, 91);
/* 192:    */       }
/* 193:    */     }
/* 194:304 */     else if (sqlType == 92)
/* 195:    */     {
/* 196:305 */       if ((inValue instanceof java.util.Date))
/* 197:    */       {
/* 198:306 */         if ((inValue instanceof Time)) {
/* 199:307 */           ps.setTime(paramIndex, (Time)inValue);
/* 200:    */         } else {
/* 201:310 */           ps.setTime(paramIndex, new Time(((java.util.Date)inValue).getTime()));
/* 202:    */         }
/* 203:    */       }
/* 204:313 */       else if ((inValue instanceof Calendar))
/* 205:    */       {
/* 206:314 */         Calendar cal = (Calendar)inValue;
/* 207:315 */         ps.setTime(paramIndex, new Time(cal.getTime().getTime()), cal);
/* 208:    */       }
/* 209:    */       else
/* 210:    */       {
/* 211:318 */         ps.setObject(paramIndex, inValue, 92);
/* 212:    */       }
/* 213:    */     }
/* 214:321 */     else if (sqlType == 93)
/* 215:    */     {
/* 216:322 */       if ((inValue instanceof java.util.Date))
/* 217:    */       {
/* 218:323 */         if ((inValue instanceof Timestamp)) {
/* 219:324 */           ps.setTimestamp(paramIndex, (Timestamp)inValue);
/* 220:    */         } else {
/* 221:327 */           ps.setTimestamp(paramIndex, new Timestamp(((java.util.Date)inValue).getTime()));
/* 222:    */         }
/* 223:    */       }
/* 224:330 */       else if ((inValue instanceof Calendar))
/* 225:    */       {
/* 226:331 */         Calendar cal = (Calendar)inValue;
/* 227:332 */         ps.setTimestamp(paramIndex, new Timestamp(cal.getTime().getTime()), cal);
/* 228:    */       }
/* 229:    */       else
/* 230:    */       {
/* 231:335 */         ps.setObject(paramIndex, inValue, 93);
/* 232:    */       }
/* 233:    */     }
/* 234:338 */     else if (sqlType == -2147483648)
/* 235:    */     {
/* 236:339 */       if (isStringValue(inValue.getClass()))
/* 237:    */       {
/* 238:340 */         ps.setString(paramIndex, inValue.toString());
/* 239:    */       }
/* 240:342 */       else if (isDateValue(inValue.getClass()))
/* 241:    */       {
/* 242:343 */         ps.setTimestamp(paramIndex, new Timestamp(((java.util.Date)inValue).getTime()));
/* 243:    */       }
/* 244:345 */       else if ((inValue instanceof Calendar))
/* 245:    */       {
/* 246:346 */         Calendar cal = (Calendar)inValue;
/* 247:347 */         ps.setTimestamp(paramIndex, new Timestamp(cal.getTime().getTime()), cal);
/* 248:    */       }
/* 249:    */       else
/* 250:    */       {
/* 251:351 */         ps.setObject(paramIndex, inValue);
/* 252:    */       }
/* 253:    */     }
/* 254:    */     else {
/* 255:356 */       ps.setObject(paramIndex, inValue, sqlType);
/* 256:    */     }
/* 257:    */   }
/* 258:    */   
/* 259:    */   private static boolean isStringValue(Class inValueType)
/* 260:    */   {
/* 261:365 */     return (CharSequence.class.isAssignableFrom(inValueType)) || (StringWriter.class.isAssignableFrom(inValueType));
/* 262:    */   }
/* 263:    */   
/* 264:    */   private static boolean isDateValue(Class inValueType)
/* 265:    */   {
/* 266:374 */     return (java.util.Date.class.isAssignableFrom(inValueType)) && (!java.sql.Date.class.isAssignableFrom(inValueType)) && (!Time.class.isAssignableFrom(inValueType)) && (!Timestamp.class.isAssignableFrom(inValueType));
/* 267:    */   }
/* 268:    */   
/* 269:    */   public static void cleanupParameters(Object[] paramValues)
/* 270:    */   {
/* 271:388 */     if (paramValues != null) {
/* 272:389 */       cleanupParameters(Arrays.asList(paramValues));
/* 273:    */     }
/* 274:    */   }
/* 275:    */   
/* 276:    */   public static void cleanupParameters(Collection paramValues)
/* 277:    */   {
/* 278:401 */     if (paramValues != null) {
/* 279:402 */       for (Object inValue : paramValues) {
/* 280:403 */         if ((inValue instanceof DisposableSqlTypeValue)) {
/* 281:404 */           ((DisposableSqlTypeValue)inValue).cleanup();
/* 282:406 */         } else if ((inValue instanceof SqlValue)) {
/* 283:407 */           ((SqlValue)inValue).cleanup();
/* 284:    */         }
/* 285:    */       }
/* 286:    */     }
/* 287:    */   }
/* 288:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.core.StatementCreatorUtils
 * JD-Core Version:    0.7.0.1
 */