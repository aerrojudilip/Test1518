/*   1:    */ package org.springframework.jdbc.core;
/*   2:    */ 
/*   3:    */ import com.sun.rowset.CachedRowSetImpl;
/*   4:    */ import java.sql.ResultSet;
/*   5:    */ import java.sql.SQLException;
/*   6:    */ import javax.sql.rowset.CachedRowSet;
/*   7:    */ import javax.sql.rowset.RowSetFactory;
/*   8:    */ import javax.sql.rowset.RowSetProvider;
/*   9:    */ import org.springframework.core.JdkVersion;
/*  10:    */ import org.springframework.jdbc.support.rowset.ResultSetWrappingSqlRowSet;
/*  11:    */ import org.springframework.jdbc.support.rowset.SqlRowSet;
/*  12:    */ 
/*  13:    */ public class SqlRowSetResultSetExtractor
/*  14:    */   implements ResultSetExtractor<SqlRowSet>
/*  15:    */ {
/*  16:    */   private static final CachedRowSetFactory cachedRowSetFactory;
/*  17:    */   
/*  18:    */   static
/*  19:    */   {
/*  20: 50 */     if (JdkVersion.getMajorJavaVersion() >= 4) {
/*  21: 52 */       cachedRowSetFactory = new StandardCachedRowSetFactory();
/*  22:    */     } else {
/*  23: 56 */       cachedRowSetFactory = new SunCachedRowSetFactory(null);
/*  24:    */     }
/*  25:    */   }
/*  26:    */   
/*  27:    */   public SqlRowSet extractData(ResultSet rs)
/*  28:    */     throws SQLException
/*  29:    */   {
/*  30: 62 */     return createSqlRowSet(rs);
/*  31:    */   }
/*  32:    */   
/*  33:    */   protected SqlRowSet createSqlRowSet(ResultSet rs)
/*  34:    */     throws SQLException
/*  35:    */   {
/*  36: 78 */     CachedRowSet rowSet = newCachedRowSet();
/*  37: 79 */     rowSet.populate(rs);
/*  38: 80 */     return new ResultSetWrappingSqlRowSet(rowSet);
/*  39:    */   }
/*  40:    */   
/*  41:    */   protected CachedRowSet newCachedRowSet()
/*  42:    */     throws SQLException
/*  43:    */   {
/*  44: 94 */     return cachedRowSetFactory.createCachedRowSet();
/*  45:    */   }
/*  46:    */   
/*  47:    */   private static abstract interface CachedRowSetFactory
/*  48:    */   {
/*  49:    */     public abstract CachedRowSet createCachedRowSet()
/*  50:    */       throws SQLException;
/*  51:    */   }
/*  52:    */   
/*  53:    */   private static class StandardCachedRowSetFactory
/*  54:    */     implements SqlRowSetResultSetExtractor.CachedRowSetFactory
/*  55:    */   {
/*  56:    */     private final RowSetFactory rowSetFactory;
/*  57:    */     
/*  58:    */     public StandardCachedRowSetFactory()
/*  59:    */     {
/*  60:    */       try
/*  61:    */       {
/*  62:116 */         this.rowSetFactory = RowSetProvider.newFactory();
/*  63:    */       }
/*  64:    */       catch (SQLException ex)
/*  65:    */       {
/*  66:119 */         throw new IllegalStateException("Cannot create RowSetFactory through RowSetProvider", ex);
/*  67:    */       }
/*  68:    */     }
/*  69:    */     
/*  70:    */     public CachedRowSet createCachedRowSet()
/*  71:    */       throws SQLException
/*  72:    */     {
/*  73:124 */       return this.rowSetFactory.createCachedRowSet();
/*  74:    */     }
/*  75:    */   }
/*  76:    */   
/*  77:    */   private static class SunCachedRowSetFactory
/*  78:    */     implements SqlRowSetResultSetExtractor.CachedRowSetFactory
/*  79:    */   {
/*  80:    */     public CachedRowSet createCachedRowSet()
/*  81:    */       throws SQLException
/*  82:    */     {
/*  83:135 */       return new CachedRowSetImpl();
/*  84:    */     }
/*  85:    */   }
/*  86:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.core.SqlRowSetResultSetExtractor
 * JD-Core Version:    0.7.0.1
 */