package org.springframework.jdbc.core.simple;

import org.springframework.jdbc.core.RowMapper;

public abstract interface ParameterizedRowMapper<T>
  extends RowMapper<T>
{}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.core.simple.ParameterizedRowMapper
 * JD-Core Version:    0.7.0.1
 */