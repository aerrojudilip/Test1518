/*   1:    */ package org.springframework.jdbc.core.simple;
/*   2:    */ 
/*   3:    */ import java.util.Arrays;
/*   4:    */ import java.util.HashSet;
/*   5:    */ import java.util.Map;
/*   6:    */ import javax.sql.DataSource;
/*   7:    */ import org.springframework.jdbc.core.JdbcTemplate;
/*   8:    */ import org.springframework.jdbc.core.RowMapper;
/*   9:    */ import org.springframework.jdbc.core.SqlParameter;
/*  10:    */ import org.springframework.jdbc.core.namedparam.SqlParameterSource;
/*  11:    */ 
/*  12:    */ public class SimpleJdbcCall
/*  13:    */   extends AbstractJdbcCall
/*  14:    */   implements SimpleJdbcCallOperations
/*  15:    */ {
/*  16:    */   public SimpleJdbcCall(DataSource dataSource)
/*  17:    */   {
/*  18: 69 */     super(dataSource);
/*  19:    */   }
/*  20:    */   
/*  21:    */   public SimpleJdbcCall(JdbcTemplate jdbcTemplate)
/*  22:    */   {
/*  23: 78 */     super(jdbcTemplate);
/*  24:    */   }
/*  25:    */   
/*  26:    */   public SimpleJdbcCall withProcedureName(String procedureName)
/*  27:    */   {
/*  28: 83 */     setProcedureName(procedureName);
/*  29: 84 */     setFunction(false);
/*  30: 85 */     return this;
/*  31:    */   }
/*  32:    */   
/*  33:    */   public SimpleJdbcCall withFunctionName(String functionName)
/*  34:    */   {
/*  35: 89 */     setProcedureName(functionName);
/*  36: 90 */     setFunction(true);
/*  37: 91 */     return this;
/*  38:    */   }
/*  39:    */   
/*  40:    */   public SimpleJdbcCall withSchemaName(String schemaName)
/*  41:    */   {
/*  42: 95 */     setSchemaName(schemaName);
/*  43: 96 */     return this;
/*  44:    */   }
/*  45:    */   
/*  46:    */   public SimpleJdbcCall withCatalogName(String catalogName)
/*  47:    */   {
/*  48:100 */     setCatalogName(catalogName);
/*  49:101 */     return this;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public SimpleJdbcCall withReturnValue()
/*  53:    */   {
/*  54:105 */     setReturnValueRequired(true);
/*  55:106 */     return this;
/*  56:    */   }
/*  57:    */   
/*  58:    */   public SimpleJdbcCall declareParameters(SqlParameter... sqlParameters)
/*  59:    */   {
/*  60:110 */     for (SqlParameter sqlParameter : sqlParameters) {
/*  61:111 */       if (sqlParameter != null) {
/*  62:112 */         addDeclaredParameter(sqlParameter);
/*  63:    */       }
/*  64:    */     }
/*  65:115 */     return this;
/*  66:    */   }
/*  67:    */   
/*  68:    */   public SimpleJdbcCall useInParameterNames(String... inParameterNames)
/*  69:    */   {
/*  70:119 */     setInParameterNames(new HashSet(Arrays.asList(inParameterNames)));
/*  71:120 */     return this;
/*  72:    */   }
/*  73:    */   
/*  74:    */   public SimpleJdbcCall returningResultSet(String parameterName, RowMapper rowMapper)
/*  75:    */   {
/*  76:124 */     addDeclaredRowMapper(parameterName, rowMapper);
/*  77:125 */     return this;
/*  78:    */   }
/*  79:    */   
/*  80:    */   @Deprecated
/*  81:    */   public SimpleJdbcCall returningResultSet(String parameterName, ParameterizedRowMapper rowMapper)
/*  82:    */   {
/*  83:133 */     addDeclaredRowMapper(parameterName, rowMapper);
/*  84:134 */     return this;
/*  85:    */   }
/*  86:    */   
/*  87:    */   public SimpleJdbcCall withoutProcedureColumnMetaDataAccess()
/*  88:    */   {
/*  89:138 */     setAccessCallParameterMetaData(false);
/*  90:139 */     return this;
/*  91:    */   }
/*  92:    */   
/*  93:    */   public <T> T executeFunction(Class<T> returnType, Object... args)
/*  94:    */   {
/*  95:144 */     return doExecute(args).get(getScalarOutParameterName());
/*  96:    */   }
/*  97:    */   
/*  98:    */   public <T> T executeFunction(Class<T> returnType, Map<String, ?> args)
/*  99:    */   {
/* 100:149 */     return doExecute(args).get(getScalarOutParameterName());
/* 101:    */   }
/* 102:    */   
/* 103:    */   public <T> T executeFunction(Class<T> returnType, SqlParameterSource args)
/* 104:    */   {
/* 105:154 */     return doExecute(args).get(getScalarOutParameterName());
/* 106:    */   }
/* 107:    */   
/* 108:    */   public <T> T executeObject(Class<T> returnType, Object... args)
/* 109:    */   {
/* 110:159 */     return doExecute(args).get(getScalarOutParameterName());
/* 111:    */   }
/* 112:    */   
/* 113:    */   public <T> T executeObject(Class<T> returnType, Map<String, ?> args)
/* 114:    */   {
/* 115:164 */     return doExecute(args).get(getScalarOutParameterName());
/* 116:    */   }
/* 117:    */   
/* 118:    */   public <T> T executeObject(Class<T> returnType, SqlParameterSource args)
/* 119:    */   {
/* 120:169 */     return doExecute(args).get(getScalarOutParameterName());
/* 121:    */   }
/* 122:    */   
/* 123:    */   public Map<String, Object> execute(Object... args)
/* 124:    */   {
/* 125:173 */     return doExecute(args);
/* 126:    */   }
/* 127:    */   
/* 128:    */   public Map<String, Object> execute(Map<String, ?> args)
/* 129:    */   {
/* 130:177 */     return doExecute(args);
/* 131:    */   }
/* 132:    */   
/* 133:    */   public Map<String, Object> execute(SqlParameterSource parameterSource)
/* 134:    */   {
/* 135:181 */     return doExecute(parameterSource);
/* 136:    */   }
/* 137:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.core.simple.SimpleJdbcCall
 * JD-Core Version:    0.7.0.1
 */