/*   1:    */ package org.springframework.jdbc.core.simple;
/*   2:    */ 
/*   3:    */ import java.sql.Connection;
/*   4:    */ import java.sql.PreparedStatement;
/*   5:    */ import java.sql.ResultSet;
/*   6:    */ import java.sql.SQLException;
/*   7:    */ import java.sql.Statement;
/*   8:    */ import java.util.ArrayList;
/*   9:    */ import java.util.Arrays;
/*  10:    */ import java.util.Collections;
/*  11:    */ import java.util.HashMap;
/*  12:    */ import java.util.List;
/*  13:    */ import java.util.Map;
/*  14:    */ import javax.sql.DataSource;
/*  15:    */ import org.apache.commons.logging.Log;
/*  16:    */ import org.apache.commons.logging.LogFactory;
/*  17:    */ import org.springframework.dao.DataAccessException;
/*  18:    */ import org.springframework.dao.DataIntegrityViolationException;
/*  19:    */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*  20:    */ import org.springframework.dao.InvalidDataAccessResourceUsageException;
/*  21:    */ import org.springframework.jdbc.core.BatchPreparedStatementSetter;
/*  22:    */ import org.springframework.jdbc.core.ConnectionCallback;
/*  23:    */ import org.springframework.jdbc.core.JdbcTemplate;
/*  24:    */ import org.springframework.jdbc.core.PreparedStatementCreator;
/*  25:    */ import org.springframework.jdbc.core.StatementCreatorUtils;
/*  26:    */ import org.springframework.jdbc.core.metadata.TableMetaDataContext;
/*  27:    */ import org.springframework.jdbc.core.namedparam.SqlParameterSource;
/*  28:    */ import org.springframework.jdbc.support.GeneratedKeyHolder;
/*  29:    */ import org.springframework.jdbc.support.JdbcUtils;
/*  30:    */ import org.springframework.jdbc.support.KeyHolder;
/*  31:    */ import org.springframework.jdbc.support.nativejdbc.NativeJdbcExtractor;
/*  32:    */ import org.springframework.util.Assert;
/*  33:    */ 
/*  34:    */ public abstract class AbstractJdbcInsert
/*  35:    */ {
/*  36: 65 */   protected final Log logger = LogFactory.getLog(getClass());
/*  37:    */   private final JdbcTemplate jdbcTemplate;
/*  38: 71 */   private final TableMetaDataContext tableMetaDataContext = new TableMetaDataContext();
/*  39: 74 */   private final List<String> declaredColumns = new ArrayList();
/*  40: 81 */   private boolean compiled = false;
/*  41:    */   private String insertString;
/*  42:    */   private int[] insertTypes;
/*  43: 90 */   private String[] generatedKeyNames = new String[0];
/*  44:    */   
/*  45:    */   protected AbstractJdbcInsert(DataSource dataSource)
/*  46:    */   {
/*  47: 97 */     this.jdbcTemplate = new JdbcTemplate(dataSource);
/*  48:    */   }
/*  49:    */   
/*  50:    */   protected AbstractJdbcInsert(JdbcTemplate jdbcTemplate)
/*  51:    */   {
/*  52:104 */     Assert.notNull(jdbcTemplate, "JdbcTemplate must not be null");
/*  53:105 */     this.jdbcTemplate = jdbcTemplate;
/*  54:106 */     setNativeJdbcExtractor(jdbcTemplate.getNativeJdbcExtractor());
/*  55:    */   }
/*  56:    */   
/*  57:    */   public void setTableName(String tableName)
/*  58:    */   {
/*  59:118 */     checkIfConfigurationModificationIsAllowed();
/*  60:119 */     this.tableMetaDataContext.setTableName(tableName);
/*  61:    */   }
/*  62:    */   
/*  63:    */   public String getTableName()
/*  64:    */   {
/*  65:126 */     return this.tableMetaDataContext.getTableName();
/*  66:    */   }
/*  67:    */   
/*  68:    */   public void setSchemaName(String schemaName)
/*  69:    */   {
/*  70:133 */     checkIfConfigurationModificationIsAllowed();
/*  71:134 */     this.tableMetaDataContext.setSchemaName(schemaName);
/*  72:    */   }
/*  73:    */   
/*  74:    */   public String getSchemaName()
/*  75:    */   {
/*  76:141 */     return this.tableMetaDataContext.getSchemaName();
/*  77:    */   }
/*  78:    */   
/*  79:    */   public void setCatalogName(String catalogName)
/*  80:    */   {
/*  81:148 */     checkIfConfigurationModificationIsAllowed();
/*  82:149 */     this.tableMetaDataContext.setCatalogName(catalogName);
/*  83:    */   }
/*  84:    */   
/*  85:    */   public String getCatalogName()
/*  86:    */   {
/*  87:156 */     return this.tableMetaDataContext.getCatalogName();
/*  88:    */   }
/*  89:    */   
/*  90:    */   public void setColumnNames(List<String> columnNames)
/*  91:    */   {
/*  92:163 */     checkIfConfigurationModificationIsAllowed();
/*  93:164 */     this.declaredColumns.clear();
/*  94:165 */     this.declaredColumns.addAll(columnNames);
/*  95:    */   }
/*  96:    */   
/*  97:    */   public List<String> getColumnNames()
/*  98:    */   {
/*  99:172 */     return Collections.unmodifiableList(this.declaredColumns);
/* 100:    */   }
/* 101:    */   
/* 102:    */   public String[] getGeneratedKeyNames()
/* 103:    */   {
/* 104:179 */     return this.generatedKeyNames;
/* 105:    */   }
/* 106:    */   
/* 107:    */   public void setGeneratedKeyNames(String[] generatedKeyNames)
/* 108:    */   {
/* 109:186 */     checkIfConfigurationModificationIsAllowed();
/* 110:187 */     this.generatedKeyNames = generatedKeyNames;
/* 111:    */   }
/* 112:    */   
/* 113:    */   public void setGeneratedKeyName(String generatedKeyName)
/* 114:    */   {
/* 115:194 */     checkIfConfigurationModificationIsAllowed();
/* 116:195 */     this.generatedKeyNames = new String[] { generatedKeyName };
/* 117:    */   }
/* 118:    */   
/* 119:    */   public void setAccessTableColumnMetaData(boolean accessTableColumnMetaData)
/* 120:    */   {
/* 121:202 */     this.tableMetaDataContext.setAccessTableColumnMetaData(accessTableColumnMetaData);
/* 122:    */   }
/* 123:    */   
/* 124:    */   public void setOverrideIncludeSynonymsDefault(boolean override)
/* 125:    */   {
/* 126:209 */     this.tableMetaDataContext.setOverrideIncludeSynonymsDefault(override);
/* 127:    */   }
/* 128:    */   
/* 129:    */   public void setNativeJdbcExtractor(NativeJdbcExtractor nativeJdbcExtractor)
/* 130:    */   {
/* 131:216 */     this.tableMetaDataContext.setNativeJdbcExtractor(nativeJdbcExtractor);
/* 132:    */   }
/* 133:    */   
/* 134:    */   public String getInsertString()
/* 135:    */   {
/* 136:223 */     return this.insertString;
/* 137:    */   }
/* 138:    */   
/* 139:    */   public int[] getInsertTypes()
/* 140:    */   {
/* 141:230 */     return this.insertTypes;
/* 142:    */   }
/* 143:    */   
/* 144:    */   protected JdbcTemplate getJdbcTemplate()
/* 145:    */   {
/* 146:237 */     return this.jdbcTemplate;
/* 147:    */   }
/* 148:    */   
/* 149:    */   public final synchronized void compile()
/* 150:    */     throws InvalidDataAccessApiUsageException
/* 151:    */   {
/* 152:253 */     if (!isCompiled())
/* 153:    */     {
/* 154:254 */       if (getTableName() == null) {
/* 155:255 */         throw new InvalidDataAccessApiUsageException("Table name is required");
/* 156:    */       }
/* 157:    */       try
/* 158:    */       {
/* 159:259 */         this.jdbcTemplate.afterPropertiesSet();
/* 160:    */       }
/* 161:    */       catch (IllegalArgumentException ex)
/* 162:    */       {
/* 163:262 */         throw new InvalidDataAccessApiUsageException(ex.getMessage());
/* 164:    */       }
/* 165:265 */       compileInternal();
/* 166:266 */       this.compiled = true;
/* 167:268 */       if (this.logger.isDebugEnabled()) {
/* 168:269 */         this.logger.debug("JdbcInsert for table [" + getTableName() + "] compiled");
/* 169:    */       }
/* 170:    */     }
/* 171:    */   }
/* 172:    */   
/* 173:    */   protected void compileInternal()
/* 174:    */   {
/* 175:280 */     this.tableMetaDataContext.processMetaData(getJdbcTemplate().getDataSource(), getColumnNames(), getGeneratedKeyNames());
/* 176:    */     
/* 177:282 */     this.insertString = this.tableMetaDataContext.createInsertString(getGeneratedKeyNames());
/* 178:    */     
/* 179:284 */     this.insertTypes = this.tableMetaDataContext.createInsertTypes();
/* 180:286 */     if (this.logger.isDebugEnabled()) {
/* 181:287 */       this.logger.debug("Compiled JdbcInsert. Insert string is [" + getInsertString() + "]");
/* 182:    */     }
/* 183:290 */     onCompileInternal();
/* 184:    */   }
/* 185:    */   
/* 186:    */   protected void onCompileInternal() {}
/* 187:    */   
/* 188:    */   public boolean isCompiled()
/* 189:    */   {
/* 190:305 */     return this.compiled;
/* 191:    */   }
/* 192:    */   
/* 193:    */   protected void checkCompiled()
/* 194:    */   {
/* 195:314 */     if (!isCompiled())
/* 196:    */     {
/* 197:315 */       this.logger.debug("JdbcInsert not compiled before execution - invoking compile");
/* 198:316 */       compile();
/* 199:    */     }
/* 200:    */   }
/* 201:    */   
/* 202:    */   protected void checkIfConfigurationModificationIsAllowed()
/* 203:    */   {
/* 204:325 */     if (isCompiled()) {
/* 205:326 */       throw new InvalidDataAccessApiUsageException("Configuration can't be altered once the class has been compiled or used.");
/* 206:    */     }
/* 207:    */   }
/* 208:    */   
/* 209:    */   protected int doExecute(Map<String, Object> args)
/* 210:    */   {
/* 211:342 */     checkCompiled();
/* 212:343 */     List<Object> values = matchInParameterValuesWithInsertColumns(args);
/* 213:344 */     return executeInsertInternal(values);
/* 214:    */   }
/* 215:    */   
/* 216:    */   protected int doExecute(SqlParameterSource parameterSource)
/* 217:    */   {
/* 218:354 */     checkCompiled();
/* 219:355 */     List<Object> values = matchInParameterValuesWithInsertColumns(parameterSource);
/* 220:356 */     return executeInsertInternal(values);
/* 221:    */   }
/* 222:    */   
/* 223:    */   private int executeInsertInternal(List<Object> values)
/* 224:    */   {
/* 225:363 */     if (this.logger.isDebugEnabled()) {
/* 226:364 */       this.logger.debug("The following parameters are used for insert " + getInsertString() + " with: " + values);
/* 227:    */     }
/* 228:366 */     int updateCount = this.jdbcTemplate.update(getInsertString(), values.toArray(), getInsertTypes());
/* 229:367 */     return updateCount;
/* 230:    */   }
/* 231:    */   
/* 232:    */   protected Number doExecuteAndReturnKey(Map<String, Object> args)
/* 233:    */   {
/* 234:378 */     checkCompiled();
/* 235:379 */     List<Object> values = matchInParameterValuesWithInsertColumns(args);
/* 236:380 */     return executeInsertAndReturnKeyInternal(values);
/* 237:    */   }
/* 238:    */   
/* 239:    */   protected Number doExecuteAndReturnKey(SqlParameterSource parameterSource)
/* 240:    */   {
/* 241:391 */     checkCompiled();
/* 242:392 */     List<Object> values = matchInParameterValuesWithInsertColumns(parameterSource);
/* 243:393 */     return executeInsertAndReturnKeyInternal(values);
/* 244:    */   }
/* 245:    */   
/* 246:    */   protected KeyHolder doExecuteAndReturnKeyHolder(Map<String, Object> args)
/* 247:    */   {
/* 248:404 */     checkCompiled();
/* 249:405 */     List<Object> values = matchInParameterValuesWithInsertColumns(args);
/* 250:406 */     return executeInsertAndReturnKeyHolderInternal(values);
/* 251:    */   }
/* 252:    */   
/* 253:    */   protected KeyHolder doExecuteAndReturnKeyHolder(SqlParameterSource parameterSource)
/* 254:    */   {
/* 255:417 */     checkCompiled();
/* 256:418 */     List<Object> values = matchInParameterValuesWithInsertColumns(parameterSource);
/* 257:419 */     return executeInsertAndReturnKeyHolderInternal(values);
/* 258:    */   }
/* 259:    */   
/* 260:    */   private Number executeInsertAndReturnKeyInternal(List<Object> values)
/* 261:    */   {
/* 262:426 */     KeyHolder kh = executeInsertAndReturnKeyHolderInternal(values);
/* 263:427 */     if ((kh != null) && (kh.getKey() != null)) {
/* 264:428 */       return kh.getKey();
/* 265:    */     }
/* 266:431 */     throw new DataIntegrityViolationException("Unable to retrieve the generated key for the insert: " + getInsertString());
/* 267:    */   }
/* 268:    */   
/* 269:    */   private KeyHolder executeInsertAndReturnKeyHolderInternal(final List<Object> values)
/* 270:    */   {
/* 271:440 */     if (this.logger.isDebugEnabled()) {
/* 272:441 */       this.logger.debug("The following parameters are used for call " + getInsertString() + " with: " + values);
/* 273:    */     }
/* 274:443 */     final KeyHolder keyHolder = new GeneratedKeyHolder();
/* 275:444 */     if (this.tableMetaDataContext.isGetGeneratedKeysSupported())
/* 276:    */     {
/* 277:445 */       this.jdbcTemplate.update(new PreparedStatementCreator()
/* 278:    */       {
/* 279:    */         public PreparedStatement createPreparedStatement(Connection con)
/* 280:    */           throws SQLException
/* 281:    */         {
/* 282:448 */           PreparedStatement ps = AbstractJdbcInsert.this.prepareStatementForGeneratedKeys(con);
/* 283:449 */           AbstractJdbcInsert.this.setParameterValues(ps, values, AbstractJdbcInsert.this.getInsertTypes());
/* 284:450 */           return ps;
/* 285:    */         }
/* 286:450 */       }, keyHolder);
/* 287:    */     }
/* 288:    */     else
/* 289:    */     {
/* 290:456 */       if (!this.tableMetaDataContext.isGetGeneratedKeysSimulated()) {
/* 291:457 */         throw new InvalidDataAccessResourceUsageException("The getGeneratedKeys feature is not supported by this database");
/* 292:    */       }
/* 293:460 */       if (getGeneratedKeyNames().length < 1) {
/* 294:461 */         throw new InvalidDataAccessApiUsageException("Generated Key Name(s) not specificed. Using the generated keys features requires specifying the name(s) of the generated column(s)");
/* 295:    */       }
/* 296:464 */       if (getGeneratedKeyNames().length > 1) {
/* 297:465 */         throw new InvalidDataAccessApiUsageException("Current database only supports retreiving the key for a single column. There are " + getGeneratedKeyNames().length + " columns specified: " + Arrays.asList(getGeneratedKeyNames()));
/* 298:    */       }
/* 299:472 */       final String keyQuery = this.tableMetaDataContext.getSimulationQueryForGetGeneratedKey(this.tableMetaDataContext.getTableName(), getGeneratedKeyNames()[0]);
/* 300:    */       
/* 301:    */ 
/* 302:475 */       Assert.notNull(keyQuery, "Query for simulating get generated keys can't be null");
/* 303:476 */       if (keyQuery.toUpperCase().startsWith("RETURNING"))
/* 304:    */       {
/* 305:477 */         Long key = Long.valueOf(this.jdbcTemplate.queryForLong(getInsertString() + " " + keyQuery, values.toArray(new Object[values.size()])));
/* 306:    */         
/* 307:    */ 
/* 308:480 */         HashMap keys = new HashMap(1);
/* 309:481 */         keys.put(getGeneratedKeyNames()[0], key);
/* 310:482 */         keyHolder.getKeyList().add(keys);
/* 311:    */       }
/* 312:    */       else
/* 313:    */       {
/* 314:485 */         this.jdbcTemplate.execute(new ConnectionCallback()
/* 315:    */         {
/* 316:    */           public Object doInConnection(Connection con)
/* 317:    */             throws SQLException, DataAccessException
/* 318:    */           {
/* 319:488 */             PreparedStatement ps = null;
/* 320:    */             try
/* 321:    */             {
/* 322:490 */               ps = con.prepareStatement(AbstractJdbcInsert.this.getInsertString());
/* 323:491 */               AbstractJdbcInsert.this.setParameterValues(ps, values, AbstractJdbcInsert.this.getInsertTypes());
/* 324:492 */               ps.executeUpdate();
/* 325:    */             }
/* 326:    */             finally
/* 327:    */             {
/* 328:494 */               JdbcUtils.closeStatement(ps);
/* 329:    */             }
/* 330:497 */             Statement keyStmt = null;
/* 331:498 */             ResultSet rs = null;
/* 332:499 */             HashMap keys = new HashMap(1);
/* 333:    */             try
/* 334:    */             {
/* 335:501 */               keyStmt = con.createStatement();
/* 336:502 */               rs = keyStmt.executeQuery(keyQuery);
/* 337:503 */               if (rs.next())
/* 338:    */               {
/* 339:504 */                 long key = rs.getLong(1);
/* 340:505 */                 keys.put(AbstractJdbcInsert.this.getGeneratedKeyNames()[0], Long.valueOf(key));
/* 341:506 */                 keyHolder.getKeyList().add(keys);
/* 342:    */               }
/* 343:    */             }
/* 344:    */             finally
/* 345:    */             {
/* 346:509 */               JdbcUtils.closeResultSet(rs);
/* 347:510 */               JdbcUtils.closeStatement(keyStmt);
/* 348:    */             }
/* 349:512 */             return null;
/* 350:    */           }
/* 351:    */         });
/* 352:    */       }
/* 353:516 */       return keyHolder;
/* 354:    */     }
/* 355:518 */     return keyHolder;
/* 356:    */   }
/* 357:    */   
/* 358:    */   private PreparedStatement prepareStatementForGeneratedKeys(Connection con)
/* 359:    */     throws SQLException
/* 360:    */   {
/* 361:529 */     if (getGeneratedKeyNames().length < 1) {
/* 362:530 */       throw new InvalidDataAccessApiUsageException("Generated Key Name(s) not specificed. Using the generated keys features requires specifying the name(s) of the generated column(s)");
/* 363:    */     }
/* 364:    */     PreparedStatement ps;
/* 365:    */     PreparedStatement ps;
/* 366:534 */     if (this.tableMetaDataContext.isGeneratedKeysColumnNameArraySupported())
/* 367:    */     {
/* 368:535 */       if (this.logger.isDebugEnabled()) {
/* 369:536 */         this.logger.debug("Using generated keys support with array of column names.");
/* 370:    */       }
/* 371:538 */       ps = con.prepareStatement(getInsertString(), getGeneratedKeyNames());
/* 372:    */     }
/* 373:    */     else
/* 374:    */     {
/* 375:541 */       if (this.logger.isDebugEnabled()) {
/* 376:542 */         this.logger.debug("Using generated keys support with Statement.RETURN_GENERATED_KEYS.");
/* 377:    */       }
/* 378:544 */       ps = con.prepareStatement(getInsertString(), 1);
/* 379:    */     }
/* 380:546 */     return ps;
/* 381:    */   }
/* 382:    */   
/* 383:    */   protected int[] doExecuteBatch(Map<String, Object>[] batch)
/* 384:    */   {
/* 385:556 */     checkCompiled();
/* 386:557 */     List[] batchValues = new ArrayList[batch.length];
/* 387:558 */     int i = 0;
/* 388:559 */     for (Map<String, Object> args : batch)
/* 389:    */     {
/* 390:560 */       List<Object> values = matchInParameterValuesWithInsertColumns(args);
/* 391:561 */       batchValues[(i++)] = values;
/* 392:    */     }
/* 393:563 */     return executeBatchInternal(batchValues);
/* 394:    */   }
/* 395:    */   
/* 396:    */   protected int[] doExecuteBatch(SqlParameterSource[] batch)
/* 397:    */   {
/* 398:573 */     checkCompiled();
/* 399:574 */     List[] batchValues = new ArrayList[batch.length];
/* 400:575 */     int i = 0;
/* 401:576 */     for (SqlParameterSource parameterSource : batch)
/* 402:    */     {
/* 403:577 */       List<Object> values = matchInParameterValuesWithInsertColumns(parameterSource);
/* 404:578 */       batchValues[(i++)] = values;
/* 405:    */     }
/* 406:580 */     return executeBatchInternal(batchValues);
/* 407:    */   }
/* 408:    */   
/* 409:    */   private int[] executeBatchInternal(final List<Object>[] batchValues)
/* 410:    */   {
/* 411:588 */     if (this.logger.isDebugEnabled()) {
/* 412:589 */       this.logger.debug("Executing statement " + getInsertString() + " with batch of size: " + batchValues.length);
/* 413:    */     }
/* 414:591 */     int[] updateCounts = this.jdbcTemplate.batchUpdate(getInsertString(), new BatchPreparedStatementSetter()
/* 415:    */     {
/* 416:    */       public void setValues(PreparedStatement ps, int i)
/* 417:    */         throws SQLException
/* 418:    */       {
/* 419:596 */         List<Object> values = batchValues[i];
/* 420:597 */         AbstractJdbcInsert.this.setParameterValues(ps, values, AbstractJdbcInsert.this.getInsertTypes());
/* 421:    */       }
/* 422:    */       
/* 423:    */       public int getBatchSize()
/* 424:    */       {
/* 425:601 */         return batchValues.length;
/* 426:    */       }
/* 427:603 */     });
/* 428:604 */     return updateCounts;
/* 429:    */   }
/* 430:    */   
/* 431:    */   private void setParameterValues(PreparedStatement preparedStatement, List<Object> values, int[] columnTypes)
/* 432:    */     throws SQLException
/* 433:    */   {
/* 434:614 */     int colIndex = 0;
/* 435:615 */     for (Object value : values)
/* 436:    */     {
/* 437:616 */       colIndex++;
/* 438:617 */       if ((columnTypes == null) || (colIndex > columnTypes.length)) {
/* 439:618 */         StatementCreatorUtils.setParameterValue(preparedStatement, colIndex, -2147483648, value);
/* 440:    */       } else {
/* 441:621 */         StatementCreatorUtils.setParameterValue(preparedStatement, colIndex, columnTypes[(colIndex - 1)], value);
/* 442:    */       }
/* 443:    */     }
/* 444:    */   }
/* 445:    */   
/* 446:    */   protected List<Object> matchInParameterValuesWithInsertColumns(SqlParameterSource parameterSource)
/* 447:    */   {
/* 448:634 */     return this.tableMetaDataContext.matchInParameterValuesWithInsertColumns(parameterSource);
/* 449:    */   }
/* 450:    */   
/* 451:    */   protected List<Object> matchInParameterValuesWithInsertColumns(Map<String, Object> args)
/* 452:    */   {
/* 453:645 */     return this.tableMetaDataContext.matchInParameterValuesWithInsertColumns(args);
/* 454:    */   }
/* 455:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.core.simple.AbstractJdbcInsert
 * JD-Core Version:    0.7.0.1
 */