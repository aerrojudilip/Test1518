/*   1:    */ package org.springframework.jdbc.core.simple;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.LinkedHashMap;
/*   5:    */ import java.util.List;
/*   6:    */ import java.util.Map;
/*   7:    */ import java.util.Map.Entry;
/*   8:    */ import java.util.Set;
/*   9:    */ import javax.sql.DataSource;
/*  10:    */ import org.apache.commons.logging.Log;
/*  11:    */ import org.apache.commons.logging.LogFactory;
/*  12:    */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*  13:    */ import org.springframework.jdbc.core.CallableStatementCreator;
/*  14:    */ import org.springframework.jdbc.core.CallableStatementCreatorFactory;
/*  15:    */ import org.springframework.jdbc.core.JdbcTemplate;
/*  16:    */ import org.springframework.jdbc.core.RowMapper;
/*  17:    */ import org.springframework.jdbc.core.SqlParameter;
/*  18:    */ import org.springframework.jdbc.core.metadata.CallMetaDataContext;
/*  19:    */ import org.springframework.jdbc.core.namedparam.SqlParameterSource;
/*  20:    */ import org.springframework.util.Assert;
/*  21:    */ import org.springframework.util.StringUtils;
/*  22:    */ 
/*  23:    */ public abstract class AbstractJdbcCall
/*  24:    */ {
/*  25: 51 */   protected final Log logger = LogFactory.getLog(getClass());
/*  26:    */   private final JdbcTemplate jdbcTemplate;
/*  27: 57 */   private final List<SqlParameter> declaredParameters = new ArrayList();
/*  28: 60 */   private final Map<String, RowMapper> declaredRowMappers = new LinkedHashMap();
/*  29: 67 */   private boolean compiled = false;
/*  30:    */   private String callString;
/*  31: 73 */   private CallMetaDataContext callMetaDataContext = new CallMetaDataContext();
/*  32:    */   private CallableStatementCreatorFactory callableStatementFactory;
/*  33:    */   
/*  34:    */   protected AbstractJdbcCall(DataSource dataSource)
/*  35:    */   {
/*  36: 87 */     this.jdbcTemplate = new JdbcTemplate(dataSource);
/*  37:    */   }
/*  38:    */   
/*  39:    */   protected AbstractJdbcCall(JdbcTemplate jdbcTemplate)
/*  40:    */   {
/*  41: 95 */     this.jdbcTemplate = jdbcTemplate;
/*  42:    */   }
/*  43:    */   
/*  44:    */   public JdbcTemplate getJdbcTemplate()
/*  45:    */   {
/*  46:103 */     return this.jdbcTemplate;
/*  47:    */   }
/*  48:    */   
/*  49:    */   protected CallableStatementCreatorFactory getCallableStatementFactory()
/*  50:    */   {
/*  51:110 */     return this.callableStatementFactory;
/*  52:    */   }
/*  53:    */   
/*  54:    */   public void setProcedureName(String procedureName)
/*  55:    */   {
/*  56:118 */     this.callMetaDataContext.setProcedureName(procedureName);
/*  57:    */   }
/*  58:    */   
/*  59:    */   public String getProcedureName()
/*  60:    */   {
/*  61:125 */     return this.callMetaDataContext.getProcedureName();
/*  62:    */   }
/*  63:    */   
/*  64:    */   public void setInParameterNames(Set<String> inParameterNames)
/*  65:    */   {
/*  66:132 */     this.callMetaDataContext.setLimitedInParameterNames(inParameterNames);
/*  67:    */   }
/*  68:    */   
/*  69:    */   public Set<String> getInParameterNames()
/*  70:    */   {
/*  71:139 */     return this.callMetaDataContext.getLimitedInParameterNames();
/*  72:    */   }
/*  73:    */   
/*  74:    */   public void setCatalogName(String catalogName)
/*  75:    */   {
/*  76:146 */     this.callMetaDataContext.setCatalogName(catalogName);
/*  77:    */   }
/*  78:    */   
/*  79:    */   public String getCatalogName()
/*  80:    */   {
/*  81:153 */     return this.callMetaDataContext.getCatalogName();
/*  82:    */   }
/*  83:    */   
/*  84:    */   public void setSchemaName(String schemaName)
/*  85:    */   {
/*  86:160 */     this.callMetaDataContext.setSchemaName(schemaName);
/*  87:    */   }
/*  88:    */   
/*  89:    */   public String getSchemaName()
/*  90:    */   {
/*  91:167 */     return this.callMetaDataContext.getSchemaName();
/*  92:    */   }
/*  93:    */   
/*  94:    */   public void setFunction(boolean function)
/*  95:    */   {
/*  96:174 */     this.callMetaDataContext.setFunction(function);
/*  97:    */   }
/*  98:    */   
/*  99:    */   public boolean isFunction()
/* 100:    */   {
/* 101:181 */     return this.callMetaDataContext.isFunction();
/* 102:    */   }
/* 103:    */   
/* 104:    */   public void setReturnValueRequired(boolean b)
/* 105:    */   {
/* 106:188 */     this.callMetaDataContext.setReturnValueRequired(b);
/* 107:    */   }
/* 108:    */   
/* 109:    */   public boolean isReturnValueRequired()
/* 110:    */   {
/* 111:195 */     return this.callMetaDataContext.isReturnValueRequired();
/* 112:    */   }
/* 113:    */   
/* 114:    */   public void addDeclaredParameter(SqlParameter parameter)
/* 115:    */   {
/* 116:207 */     Assert.notNull(parameter, "The supplied parameter must not be null");
/* 117:208 */     if (!StringUtils.hasText(parameter.getName())) {
/* 118:209 */       throw new InvalidDataAccessApiUsageException("You must specify a parameter name when declaring parameters for \"" + getProcedureName() + "\"");
/* 119:    */     }
/* 120:212 */     this.declaredParameters.add(parameter);
/* 121:213 */     if (this.logger.isDebugEnabled()) {
/* 122:214 */       this.logger.debug("Added declared parameter for [" + getProcedureName() + "]: " + parameter.getName());
/* 123:    */     }
/* 124:    */   }
/* 125:    */   
/* 126:    */   public void addDeclaredRowMapper(String parameterName, RowMapper rowMapper)
/* 127:    */   {
/* 128:224 */     this.declaredRowMappers.put(parameterName, rowMapper);
/* 129:225 */     if (this.logger.isDebugEnabled()) {
/* 130:226 */       this.logger.debug("Added row mapper for [" + getProcedureName() + "]: " + parameterName);
/* 131:    */     }
/* 132:    */   }
/* 133:    */   
/* 134:    */   @Deprecated
/* 135:    */   public void addDeclaredRowMapper(String parameterName, ParameterizedRowMapper rowMapper)
/* 136:    */   {
/* 137:236 */     addDeclaredRowMapper(parameterName, rowMapper);
/* 138:    */   }
/* 139:    */   
/* 140:    */   public String getCallString()
/* 141:    */   {
/* 142:243 */     return this.callString;
/* 143:    */   }
/* 144:    */   
/* 145:    */   public void setAccessCallParameterMetaData(boolean accessCallParameterMetaData)
/* 146:    */   {
/* 147:250 */     this.callMetaDataContext.setAccessCallParameterMetaData(accessCallParameterMetaData);
/* 148:    */   }
/* 149:    */   
/* 150:    */   public final synchronized void compile()
/* 151:    */     throws InvalidDataAccessApiUsageException
/* 152:    */   {
/* 153:266 */     if (!isCompiled())
/* 154:    */     {
/* 155:267 */       if (getProcedureName() == null) {
/* 156:268 */         throw new InvalidDataAccessApiUsageException("Procedure or Function name is required");
/* 157:    */       }
/* 158:    */       try
/* 159:    */       {
/* 160:271 */         this.jdbcTemplate.afterPropertiesSet();
/* 161:    */       }
/* 162:    */       catch (IllegalArgumentException ex)
/* 163:    */       {
/* 164:274 */         throw new InvalidDataAccessApiUsageException(ex.getMessage());
/* 165:    */       }
/* 166:276 */       compileInternal();
/* 167:277 */       this.compiled = true;
/* 168:278 */       if (this.logger.isDebugEnabled()) {
/* 169:279 */         this.logger.debug("SqlCall for " + (isFunction() ? "function" : "procedure") + " [" + getProcedureName() + "] compiled");
/* 170:    */       }
/* 171:    */     }
/* 172:    */   }
/* 173:    */   
/* 174:    */   protected void compileInternal()
/* 175:    */   {
/* 176:289 */     this.callMetaDataContext.initializeMetaData(getJdbcTemplate().getDataSource());
/* 177:292 */     for (Map.Entry<String, RowMapper> entry : this.declaredRowMappers.entrySet())
/* 178:    */     {
/* 179:293 */       SqlParameter resultSetParameter = this.callMetaDataContext.createReturnResultSetParameter((String)entry.getKey(), (RowMapper)entry.getValue());
/* 180:    */       
/* 181:295 */       this.declaredParameters.add(resultSetParameter);
/* 182:    */     }
/* 183:297 */     this.callMetaDataContext.processParameters(this.declaredParameters);
/* 184:    */     
/* 185:299 */     this.callString = this.callMetaDataContext.createCallString();
/* 186:300 */     if (this.logger.isDebugEnabled()) {
/* 187:301 */       this.logger.debug("Compiled stored procedure. Call string is [" + this.callString + "]");
/* 188:    */     }
/* 189:304 */     this.callableStatementFactory = new CallableStatementCreatorFactory(getCallString(), this.callMetaDataContext.getCallParameters());
/* 190:    */     
/* 191:306 */     this.callableStatementFactory.setNativeJdbcExtractor(getJdbcTemplate().getNativeJdbcExtractor());
/* 192:    */     
/* 193:308 */     onCompileInternal();
/* 194:    */   }
/* 195:    */   
/* 196:    */   protected void onCompileInternal() {}
/* 197:    */   
/* 198:    */   public boolean isCompiled()
/* 199:    */   {
/* 200:323 */     return this.compiled;
/* 201:    */   }
/* 202:    */   
/* 203:    */   protected void checkCompiled()
/* 204:    */   {
/* 205:332 */     if (!isCompiled())
/* 206:    */     {
/* 207:333 */       this.logger.debug("JdbcCall call not compiled before execution - invoking compile");
/* 208:334 */       compile();
/* 209:    */     }
/* 210:    */   }
/* 211:    */   
/* 212:    */   protected Map<String, Object> doExecute(SqlParameterSource parameterSource)
/* 213:    */   {
/* 214:349 */     checkCompiled();
/* 215:350 */     Map<String, Object> params = matchInParameterValuesWithCallParameters(parameterSource);
/* 216:351 */     return executeCallInternal(params);
/* 217:    */   }
/* 218:    */   
/* 219:    */   protected Map<String, Object> doExecute(Object[] args)
/* 220:    */   {
/* 221:360 */     checkCompiled();
/* 222:361 */     Map<String, ?> params = matchInParameterValuesWithCallParameters(args);
/* 223:362 */     return executeCallInternal(params);
/* 224:    */   }
/* 225:    */   
/* 226:    */   protected Map<String, Object> doExecute(Map<String, ?> args)
/* 227:    */   {
/* 228:371 */     checkCompiled();
/* 229:372 */     Map<String, ?> params = matchInParameterValuesWithCallParameters(args);
/* 230:373 */     return executeCallInternal(params);
/* 231:    */   }
/* 232:    */   
/* 233:    */   private Map<String, Object> executeCallInternal(Map<String, ?> params)
/* 234:    */   {
/* 235:380 */     CallableStatementCreator csc = getCallableStatementFactory().newCallableStatementCreator(params);
/* 236:    */     int i;
/* 237:381 */     if (this.logger.isDebugEnabled())
/* 238:    */     {
/* 239:382 */       this.logger.debug("The following parameters are used for call " + getCallString() + " with: " + params);
/* 240:383 */       i = 1;
/* 241:384 */       for (SqlParameter p : getCallParameters()) {
/* 242:385 */         this.logger.debug(i++ + ": " + p.getName() + " SQL Type " + p.getSqlType() + " Type Name " + p.getTypeName() + " " + p.getClass().getName());
/* 243:    */       }
/* 244:    */     }
/* 245:388 */     return getJdbcTemplate().call(csc, getCallParameters());
/* 246:    */   }
/* 247:    */   
/* 248:    */   protected String getScalarOutParameterName()
/* 249:    */   {
/* 250:396 */     return this.callMetaDataContext.getScalarOutParameterName();
/* 251:    */   }
/* 252:    */   
/* 253:    */   protected Map<String, Object> matchInParameterValuesWithCallParameters(SqlParameterSource parameterSource)
/* 254:    */   {
/* 255:406 */     return this.callMetaDataContext.matchInParameterValuesWithCallParameters(parameterSource);
/* 256:    */   }
/* 257:    */   
/* 258:    */   private Map<String, ?> matchInParameterValuesWithCallParameters(Object[] args)
/* 259:    */   {
/* 260:416 */     return this.callMetaDataContext.matchInParameterValuesWithCallParameters(args);
/* 261:    */   }
/* 262:    */   
/* 263:    */   protected Map<String, ?> matchInParameterValuesWithCallParameters(Map<String, ?> args)
/* 264:    */   {
/* 265:426 */     return this.callMetaDataContext.matchInParameterValuesWithCallParameters(args);
/* 266:    */   }
/* 267:    */   
/* 268:    */   protected List<SqlParameter> getCallParameters()
/* 269:    */   {
/* 270:434 */     return this.callMetaDataContext.getCallParameters();
/* 271:    */   }
/* 272:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.core.simple.AbstractJdbcCall
 * JD-Core Version:    0.7.0.1
 */