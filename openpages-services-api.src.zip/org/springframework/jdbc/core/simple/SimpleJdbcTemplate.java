/*   1:    */ package org.springframework.jdbc.core.simple;
/*   2:    */ 
/*   3:    */ import java.util.List;
/*   4:    */ import java.util.Map;
/*   5:    */ import javax.sql.DataSource;
/*   6:    */ import org.springframework.dao.DataAccessException;
/*   7:    */ import org.springframework.jdbc.core.BatchUpdateUtils;
/*   8:    */ import org.springframework.jdbc.core.JdbcOperations;
/*   9:    */ import org.springframework.jdbc.core.RowMapper;
/*  10:    */ import org.springframework.jdbc.core.namedparam.NamedParameterJdbcOperations;
/*  11:    */ import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
/*  12:    */ import org.springframework.jdbc.core.namedparam.SqlParameterSource;
/*  13:    */ import org.springframework.util.ObjectUtils;
/*  14:    */ 
/*  15:    */ @Deprecated
/*  16:    */ public class SimpleJdbcTemplate
/*  17:    */   implements SimpleJdbcOperations
/*  18:    */ {
/*  19:    */   private final NamedParameterJdbcOperations namedParameterJdbcOperations;
/*  20:    */   
/*  21:    */   public SimpleJdbcTemplate(DataSource dataSource)
/*  22:    */   {
/*  23: 70 */     this.namedParameterJdbcOperations = new NamedParameterJdbcTemplate(dataSource);
/*  24:    */   }
/*  25:    */   
/*  26:    */   public SimpleJdbcTemplate(JdbcOperations classicJdbcTemplate)
/*  27:    */   {
/*  28: 78 */     this.namedParameterJdbcOperations = new NamedParameterJdbcTemplate(classicJdbcTemplate);
/*  29:    */   }
/*  30:    */   
/*  31:    */   public SimpleJdbcTemplate(NamedParameterJdbcOperations namedParameterJdbcTemplate)
/*  32:    */   {
/*  33: 86 */     this.namedParameterJdbcOperations = namedParameterJdbcTemplate;
/*  34:    */   }
/*  35:    */   
/*  36:    */   public JdbcOperations getJdbcOperations()
/*  37:    */   {
/*  38: 95 */     return this.namedParameterJdbcOperations.getJdbcOperations();
/*  39:    */   }
/*  40:    */   
/*  41:    */   public NamedParameterJdbcOperations getNamedParameterJdbcOperations()
/*  42:    */   {
/*  43:103 */     return this.namedParameterJdbcOperations;
/*  44:    */   }
/*  45:    */   
/*  46:    */   public int queryForInt(String sql, Map<String, ?> args)
/*  47:    */     throws DataAccessException
/*  48:    */   {
/*  49:108 */     return getNamedParameterJdbcOperations().queryForInt(sql, args);
/*  50:    */   }
/*  51:    */   
/*  52:    */   public int queryForInt(String sql, SqlParameterSource args)
/*  53:    */     throws DataAccessException
/*  54:    */   {
/*  55:112 */     return getNamedParameterJdbcOperations().queryForInt(sql, args);
/*  56:    */   }
/*  57:    */   
/*  58:    */   public int queryForInt(String sql, Object... args)
/*  59:    */     throws DataAccessException
/*  60:    */   {
/*  61:116 */     return ObjectUtils.isEmpty(args) ? getJdbcOperations().queryForInt(sql) : getJdbcOperations().queryForInt(sql, getArguments(args));
/*  62:    */   }
/*  63:    */   
/*  64:    */   public long queryForLong(String sql, Map<String, ?> args)
/*  65:    */     throws DataAccessException
/*  66:    */   {
/*  67:122 */     return getNamedParameterJdbcOperations().queryForLong(sql, args);
/*  68:    */   }
/*  69:    */   
/*  70:    */   public long queryForLong(String sql, SqlParameterSource args)
/*  71:    */     throws DataAccessException
/*  72:    */   {
/*  73:126 */     return getNamedParameterJdbcOperations().queryForLong(sql, args);
/*  74:    */   }
/*  75:    */   
/*  76:    */   public long queryForLong(String sql, Object... args)
/*  77:    */     throws DataAccessException
/*  78:    */   {
/*  79:130 */     return ObjectUtils.isEmpty(args) ? getJdbcOperations().queryForLong(sql) : getJdbcOperations().queryForLong(sql, getArguments(args));
/*  80:    */   }
/*  81:    */   
/*  82:    */   public <T> T queryForObject(String sql, Class<T> requiredType, Map<String, ?> args)
/*  83:    */     throws DataAccessException
/*  84:    */   {
/*  85:136 */     return getNamedParameterJdbcOperations().queryForObject(sql, args, requiredType);
/*  86:    */   }
/*  87:    */   
/*  88:    */   public <T> T queryForObject(String sql, Class<T> requiredType, SqlParameterSource args)
/*  89:    */     throws DataAccessException
/*  90:    */   {
/*  91:141 */     return getNamedParameterJdbcOperations().queryForObject(sql, args, requiredType);
/*  92:    */   }
/*  93:    */   
/*  94:    */   public <T> T queryForObject(String sql, Class<T> requiredType, Object... args)
/*  95:    */     throws DataAccessException
/*  96:    */   {
/*  97:145 */     return ObjectUtils.isEmpty(args) ? getJdbcOperations().queryForObject(sql, requiredType) : getJdbcOperations().queryForObject(sql, getArguments(args), requiredType);
/*  98:    */   }
/*  99:    */   
/* 100:    */   public <T> T queryForObject(String sql, RowMapper<T> rm, Map<String, ?> args)
/* 101:    */     throws DataAccessException
/* 102:    */   {
/* 103:151 */     return getNamedParameterJdbcOperations().queryForObject(sql, args, rm);
/* 104:    */   }
/* 105:    */   
/* 106:    */   @Deprecated
/* 107:    */   public <T> T queryForObject(String sql, ParameterizedRowMapper<T> rm, Map<String, ?> args)
/* 108:    */     throws DataAccessException
/* 109:    */   {
/* 110:156 */     return queryForObject(sql, rm, args);
/* 111:    */   }
/* 112:    */   
/* 113:    */   public <T> T queryForObject(String sql, RowMapper<T> rm, SqlParameterSource args)
/* 114:    */     throws DataAccessException
/* 115:    */   {
/* 116:161 */     return getNamedParameterJdbcOperations().queryForObject(sql, args, rm);
/* 117:    */   }
/* 118:    */   
/* 119:    */   @Deprecated
/* 120:    */   public <T> T queryForObject(String sql, ParameterizedRowMapper<T> rm, SqlParameterSource args)
/* 121:    */     throws DataAccessException
/* 122:    */   {
/* 123:167 */     return queryForObject(sql, rm, args);
/* 124:    */   }
/* 125:    */   
/* 126:    */   public <T> T queryForObject(String sql, RowMapper<T> rm, Object... args)
/* 127:    */     throws DataAccessException
/* 128:    */   {
/* 129:171 */     return ObjectUtils.isEmpty(args) ? getJdbcOperations().queryForObject(sql, rm) : getJdbcOperations().queryForObject(sql, getArguments(args), rm);
/* 130:    */   }
/* 131:    */   
/* 132:    */   @Deprecated
/* 133:    */   public <T> T queryForObject(String sql, ParameterizedRowMapper<T> rm, Object... args)
/* 134:    */     throws DataAccessException
/* 135:    */   {
/* 136:178 */     return queryForObject(sql, rm, args);
/* 137:    */   }
/* 138:    */   
/* 139:    */   public <T> List<T> query(String sql, RowMapper<T> rm, Map<String, ?> args)
/* 140:    */     throws DataAccessException
/* 141:    */   {
/* 142:182 */     return getNamedParameterJdbcOperations().query(sql, args, rm);
/* 143:    */   }
/* 144:    */   
/* 145:    */   @Deprecated
/* 146:    */   public <T> List<T> query(String sql, ParameterizedRowMapper<T> rm, Map<String, ?> args)
/* 147:    */     throws DataAccessException
/* 148:    */   {
/* 149:187 */     return query(sql, rm, args);
/* 150:    */   }
/* 151:    */   
/* 152:    */   public <T> List<T> query(String sql, RowMapper<T> rm, SqlParameterSource args)
/* 153:    */     throws DataAccessException
/* 154:    */   {
/* 155:192 */     return getNamedParameterJdbcOperations().query(sql, args, rm);
/* 156:    */   }
/* 157:    */   
/* 158:    */   @Deprecated
/* 159:    */   public <T> List<T> query(String sql, ParameterizedRowMapper<T> rm, SqlParameterSource args)
/* 160:    */     throws DataAccessException
/* 161:    */   {
/* 162:198 */     return query(sql, rm, args);
/* 163:    */   }
/* 164:    */   
/* 165:    */   public <T> List<T> query(String sql, RowMapper<T> rm, Object... args)
/* 166:    */     throws DataAccessException
/* 167:    */   {
/* 168:202 */     return ObjectUtils.isEmpty(args) ? getJdbcOperations().query(sql, rm) : getJdbcOperations().query(sql, getArguments(args), rm);
/* 169:    */   }
/* 170:    */   
/* 171:    */   @Deprecated
/* 172:    */   public <T> List<T> query(String sql, ParameterizedRowMapper<T> rm, Object... args)
/* 173:    */     throws DataAccessException
/* 174:    */   {
/* 175:209 */     return query(sql, rm, args);
/* 176:    */   }
/* 177:    */   
/* 178:    */   public Map<String, Object> queryForMap(String sql, Map<String, ?> args)
/* 179:    */     throws DataAccessException
/* 180:    */   {
/* 181:213 */     return getNamedParameterJdbcOperations().queryForMap(sql, args);
/* 182:    */   }
/* 183:    */   
/* 184:    */   public Map<String, Object> queryForMap(String sql, SqlParameterSource args)
/* 185:    */     throws DataAccessException
/* 186:    */   {
/* 187:218 */     return getNamedParameterJdbcOperations().queryForMap(sql, args);
/* 188:    */   }
/* 189:    */   
/* 190:    */   public Map<String, Object> queryForMap(String sql, Object... args)
/* 191:    */     throws DataAccessException
/* 192:    */   {
/* 193:222 */     return ObjectUtils.isEmpty(args) ? getJdbcOperations().queryForMap(sql) : getJdbcOperations().queryForMap(sql, getArguments(args));
/* 194:    */   }
/* 195:    */   
/* 196:    */   public List<Map<String, Object>> queryForList(String sql, Map<String, ?> args)
/* 197:    */     throws DataAccessException
/* 198:    */   {
/* 199:228 */     return getNamedParameterJdbcOperations().queryForList(sql, args);
/* 200:    */   }
/* 201:    */   
/* 202:    */   public List<Map<String, Object>> queryForList(String sql, SqlParameterSource args)
/* 203:    */     throws DataAccessException
/* 204:    */   {
/* 205:233 */     return getNamedParameterJdbcOperations().queryForList(sql, args);
/* 206:    */   }
/* 207:    */   
/* 208:    */   public List<Map<String, Object>> queryForList(String sql, Object... args)
/* 209:    */     throws DataAccessException
/* 210:    */   {
/* 211:237 */     return ObjectUtils.isEmpty(args) ? getJdbcOperations().queryForList(sql) : getJdbcOperations().queryForList(sql, getArguments(args));
/* 212:    */   }
/* 213:    */   
/* 214:    */   public int update(String sql, Map<String, ?> args)
/* 215:    */     throws DataAccessException
/* 216:    */   {
/* 217:243 */     return getNamedParameterJdbcOperations().update(sql, args);
/* 218:    */   }
/* 219:    */   
/* 220:    */   public int update(String sql, SqlParameterSource args)
/* 221:    */     throws DataAccessException
/* 222:    */   {
/* 223:247 */     return getNamedParameterJdbcOperations().update(sql, args);
/* 224:    */   }
/* 225:    */   
/* 226:    */   public int update(String sql, Object... args)
/* 227:    */     throws DataAccessException
/* 228:    */   {
/* 229:251 */     return ObjectUtils.isEmpty(args) ? getJdbcOperations().update(sql) : getJdbcOperations().update(sql, getArguments(args));
/* 230:    */   }
/* 231:    */   
/* 232:    */   public int[] batchUpdate(String sql, List<Object[]> batchArgs)
/* 233:    */   {
/* 234:257 */     return batchUpdate(sql, batchArgs, new int[0]);
/* 235:    */   }
/* 236:    */   
/* 237:    */   public int[] batchUpdate(String sql, List<Object[]> batchArgs, int[] argTypes)
/* 238:    */   {
/* 239:261 */     return BatchUpdateUtils.executeBatchUpdate(sql, batchArgs, argTypes, getJdbcOperations());
/* 240:    */   }
/* 241:    */   
/* 242:    */   public int[] batchUpdate(String sql, Map<String, ?>[] batchValues)
/* 243:    */   {
/* 244:265 */     return getNamedParameterJdbcOperations().batchUpdate(sql, batchValues);
/* 245:    */   }
/* 246:    */   
/* 247:    */   public int[] batchUpdate(String sql, SqlParameterSource[] batchArgs)
/* 248:    */   {
/* 249:269 */     return getNamedParameterJdbcOperations().batchUpdate(sql, batchArgs);
/* 250:    */   }
/* 251:    */   
/* 252:    */   private Object[] getArguments(Object[] varArgs)
/* 253:    */   {
/* 254:278 */     if ((varArgs.length == 1) && ((varArgs[0] instanceof Object[]))) {
/* 255:279 */       return (Object[])varArgs[0];
/* 256:    */     }
/* 257:282 */     return varArgs;
/* 258:    */   }
/* 259:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.core.simple.SimpleJdbcTemplate
 * JD-Core Version:    0.7.0.1
 */