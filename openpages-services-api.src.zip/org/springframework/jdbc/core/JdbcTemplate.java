/*    1:     */ package org.springframework.jdbc.core;
/*    2:     */ 
/*    3:     */ import java.lang.reflect.InvocationHandler;
/*    4:     */ import java.lang.reflect.InvocationTargetException;
/*    5:     */ import java.lang.reflect.Method;
/*    6:     */ import java.lang.reflect.Proxy;
/*    7:     */ import java.sql.CallableStatement;
/*    8:     */ import java.sql.Connection;
/*    9:     */ import java.sql.PreparedStatement;
/*   10:     */ import java.sql.ResultSet;
/*   11:     */ import java.sql.SQLException;
/*   12:     */ import java.sql.SQLWarning;
/*   13:     */ import java.sql.Statement;
/*   14:     */ import java.util.ArrayList;
/*   15:     */ import java.util.Collection;
/*   16:     */ import java.util.Collections;
/*   17:     */ import java.util.HashMap;
/*   18:     */ import java.util.LinkedHashMap;
/*   19:     */ import java.util.List;
/*   20:     */ import java.util.Map;
/*   21:     */ import javax.sql.DataSource;
/*   22:     */ import org.apache.commons.logging.Log;
/*   23:     */ import org.springframework.dao.DataAccessException;
/*   24:     */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*   25:     */ import org.springframework.dao.support.DataAccessUtils;
/*   26:     */ import org.springframework.jdbc.SQLWarningException;
/*   27:     */ import org.springframework.jdbc.datasource.ConnectionProxy;
/*   28:     */ import org.springframework.jdbc.datasource.DataSourceUtils;
/*   29:     */ import org.springframework.jdbc.support.JdbcAccessor;
/*   30:     */ import org.springframework.jdbc.support.JdbcUtils;
/*   31:     */ import org.springframework.jdbc.support.KeyHolder;
/*   32:     */ import org.springframework.jdbc.support.SQLExceptionTranslator;
/*   33:     */ import org.springframework.jdbc.support.nativejdbc.NativeJdbcExtractor;
/*   34:     */ import org.springframework.jdbc.support.rowset.SqlRowSet;
/*   35:     */ import org.springframework.util.Assert;
/*   36:     */ import org.springframework.util.LinkedCaseInsensitiveMap;
/*   37:     */ 
/*   38:     */ public class JdbcTemplate
/*   39:     */   extends JdbcAccessor
/*   40:     */   implements JdbcOperations
/*   41:     */ {
/*   42:     */   private static final String RETURN_RESULT_SET_PREFIX = "#result-set-";
/*   43:     */   private static final String RETURN_UPDATE_COUNT_PREFIX = "#update-count-";
/*   44:     */   private NativeJdbcExtractor nativeJdbcExtractor;
/*   45: 107 */   private boolean ignoreWarnings = true;
/*   46: 113 */   private int fetchSize = 0;
/*   47: 119 */   private int maxRows = 0;
/*   48: 125 */   private int queryTimeout = 0;
/*   49: 132 */   private boolean skipResultsProcessing = false;
/*   50: 140 */   private boolean skipUndeclaredResults = false;
/*   51: 147 */   private boolean resultsMapCaseInsensitive = false;
/*   52:     */   
/*   53:     */   public JdbcTemplate() {}
/*   54:     */   
/*   55:     */   public JdbcTemplate(DataSource dataSource)
/*   56:     */   {
/*   57: 164 */     setDataSource(dataSource);
/*   58: 165 */     afterPropertiesSet();
/*   59:     */   }
/*   60:     */   
/*   61:     */   public JdbcTemplate(DataSource dataSource, boolean lazyInit)
/*   62:     */   {
/*   63: 176 */     setDataSource(dataSource);
/*   64: 177 */     setLazyInit(lazyInit);
/*   65: 178 */     afterPropertiesSet();
/*   66:     */   }
/*   67:     */   
/*   68:     */   public void setNativeJdbcExtractor(NativeJdbcExtractor extractor)
/*   69:     */   {
/*   70: 189 */     this.nativeJdbcExtractor = extractor;
/*   71:     */   }
/*   72:     */   
/*   73:     */   public NativeJdbcExtractor getNativeJdbcExtractor()
/*   74:     */   {
/*   75: 196 */     return this.nativeJdbcExtractor;
/*   76:     */   }
/*   77:     */   
/*   78:     */   public void setIgnoreWarnings(boolean ignoreWarnings)
/*   79:     */   {
/*   80: 208 */     this.ignoreWarnings = ignoreWarnings;
/*   81:     */   }
/*   82:     */   
/*   83:     */   public boolean isIgnoreWarnings()
/*   84:     */   {
/*   85: 215 */     return this.ignoreWarnings;
/*   86:     */   }
/*   87:     */   
/*   88:     */   public void setFetchSize(int fetchSize)
/*   89:     */   {
/*   90: 227 */     this.fetchSize = fetchSize;
/*   91:     */   }
/*   92:     */   
/*   93:     */   public int getFetchSize()
/*   94:     */   {
/*   95: 234 */     return this.fetchSize;
/*   96:     */   }
/*   97:     */   
/*   98:     */   public void setMaxRows(int maxRows)
/*   99:     */   {
/*  100: 247 */     this.maxRows = maxRows;
/*  101:     */   }
/*  102:     */   
/*  103:     */   public int getMaxRows()
/*  104:     */   {
/*  105: 254 */     return this.maxRows;
/*  106:     */   }
/*  107:     */   
/*  108:     */   public void setQueryTimeout(int queryTimeout)
/*  109:     */   {
/*  110: 266 */     this.queryTimeout = queryTimeout;
/*  111:     */   }
/*  112:     */   
/*  113:     */   public int getQueryTimeout()
/*  114:     */   {
/*  115: 273 */     return this.queryTimeout;
/*  116:     */   }
/*  117:     */   
/*  118:     */   public void setSkipResultsProcessing(boolean skipResultsProcessing)
/*  119:     */   {
/*  120: 283 */     this.skipResultsProcessing = skipResultsProcessing;
/*  121:     */   }
/*  122:     */   
/*  123:     */   public boolean isSkipResultsProcessing()
/*  124:     */   {
/*  125: 290 */     return this.skipResultsProcessing;
/*  126:     */   }
/*  127:     */   
/*  128:     */   public void setSkipUndeclaredResults(boolean skipUndeclaredResults)
/*  129:     */   {
/*  130: 297 */     this.skipUndeclaredResults = skipUndeclaredResults;
/*  131:     */   }
/*  132:     */   
/*  133:     */   public boolean isSkipUndeclaredResults()
/*  134:     */   {
/*  135: 304 */     return this.skipUndeclaredResults;
/*  136:     */   }
/*  137:     */   
/*  138:     */   public void setResultsMapCaseInsensitive(boolean resultsMapCaseInsensitive)
/*  139:     */   {
/*  140: 312 */     this.resultsMapCaseInsensitive = resultsMapCaseInsensitive;
/*  141:     */   }
/*  142:     */   
/*  143:     */   public boolean isResultsMapCaseInsensitive()
/*  144:     */   {
/*  145: 320 */     return this.resultsMapCaseInsensitive;
/*  146:     */   }
/*  147:     */   
/*  148:     */   public <T> T execute(ConnectionCallback<T> action)
/*  149:     */     throws DataAccessException
/*  150:     */   {
/*  151: 329 */     Assert.notNull(action, "Callback object must not be null");
/*  152:     */     
/*  153: 331 */     Connection con = DataSourceUtils.getConnection(getDataSource());
/*  154:     */     try
/*  155:     */     {
/*  156: 333 */       Connection conToUse = con;
/*  157: 334 */       if (this.nativeJdbcExtractor != null) {
/*  158: 336 */         conToUse = this.nativeJdbcExtractor.getNativeConnection(con);
/*  159:     */       } else {
/*  160: 340 */         conToUse = createConnectionProxy(con);
/*  161:     */       }
/*  162: 342 */       return action.doInConnection(conToUse);
/*  163:     */     }
/*  164:     */     catch (SQLException ex)
/*  165:     */     {
/*  166: 347 */       DataSourceUtils.releaseConnection(con, getDataSource());
/*  167: 348 */       con = null;
/*  168: 349 */       throw getExceptionTranslator().translate("ConnectionCallback", getSql(action), ex);
/*  169:     */     }
/*  170:     */     finally
/*  171:     */     {
/*  172: 352 */       DataSourceUtils.releaseConnection(con, getDataSource());
/*  173:     */     }
/*  174:     */   }
/*  175:     */   
/*  176:     */   protected Connection createConnectionProxy(Connection con)
/*  177:     */   {
/*  178: 368 */     return (Connection)Proxy.newProxyInstance(ConnectionProxy.class.getClassLoader(), new Class[] { ConnectionProxy.class }, new CloseSuppressingInvocationHandler(con));
/*  179:     */   }
/*  180:     */   
/*  181:     */   public <T> T execute(StatementCallback<T> action)
/*  182:     */     throws DataAccessException
/*  183:     */   {
/*  184: 380 */     Assert.notNull(action, "Callback object must not be null");
/*  185:     */     
/*  186: 382 */     Connection con = DataSourceUtils.getConnection(getDataSource());
/*  187: 383 */     Statement stmt = null;
/*  188:     */     try
/*  189:     */     {
/*  190: 385 */       Connection conToUse = con;
/*  191: 386 */       if ((this.nativeJdbcExtractor != null) && (this.nativeJdbcExtractor.isNativeConnectionNecessaryForNativeStatements())) {
/*  192: 388 */         conToUse = this.nativeJdbcExtractor.getNativeConnection(con);
/*  193:     */       }
/*  194: 390 */       stmt = conToUse.createStatement();
/*  195: 391 */       applyStatementSettings(stmt);
/*  196: 392 */       Statement stmtToUse = stmt;
/*  197: 393 */       if (this.nativeJdbcExtractor != null) {
/*  198: 394 */         stmtToUse = this.nativeJdbcExtractor.getNativeStatement(stmt);
/*  199:     */       }
/*  200: 396 */       T result = action.doInStatement(stmtToUse);
/*  201: 397 */       handleWarnings(stmt);
/*  202: 398 */       return result;
/*  203:     */     }
/*  204:     */     catch (SQLException ex)
/*  205:     */     {
/*  206: 403 */       JdbcUtils.closeStatement(stmt);
/*  207: 404 */       stmt = null;
/*  208: 405 */       DataSourceUtils.releaseConnection(con, getDataSource());
/*  209: 406 */       con = null;
/*  210: 407 */       throw getExceptionTranslator().translate("StatementCallback", getSql(action), ex);
/*  211:     */     }
/*  212:     */     finally
/*  213:     */     {
/*  214: 410 */       JdbcUtils.closeStatement(stmt);
/*  215: 411 */       DataSourceUtils.releaseConnection(con, getDataSource());
/*  216:     */     }
/*  217:     */   }
/*  218:     */   
/*  219:     */   public void execute(final String sql)
/*  220:     */     throws DataAccessException
/*  221:     */   {
/*  222: 416 */     if (this.logger.isDebugEnabled()) {
/*  223: 417 */       this.logger.debug("Executing SQL statement [" + sql + "]");
/*  224:     */     }
/*  225: 428 */     execute(new StatementCallback()
/*  226:     */     {
/*  227:     */       public Object doInStatement(Statement stmt)
/*  228:     */         throws SQLException
/*  229:     */       {
/*  230: 421 */         stmt.execute(sql);
/*  231: 422 */         return null;
/*  232:     */       }
/*  233:     */       
/*  234:     */       public String getSql()
/*  235:     */       {
/*  236: 425 */         return sql;
/*  237:     */       }
/*  238:     */     });
/*  239:     */   }
/*  240:     */   
/*  241:     */   public <T> T query(final String sql, final ResultSetExtractor<T> rse)
/*  242:     */     throws DataAccessException
/*  243:     */   {
/*  244: 432 */     Assert.notNull(sql, "SQL must not be null");
/*  245: 433 */     Assert.notNull(rse, "ResultSetExtractor must not be null");
/*  246: 434 */     if (this.logger.isDebugEnabled()) {
/*  247: 435 */       this.logger.debug("Executing SQL query [" + sql + "]");
/*  248:     */     }
/*  249: 456 */     execute(new StatementCallback()
/*  250:     */     {
/*  251:     */       public T doInStatement(Statement stmt)
/*  252:     */         throws SQLException
/*  253:     */       {
/*  254: 439 */         ResultSet rs = null;
/*  255:     */         try
/*  256:     */         {
/*  257: 441 */           rs = stmt.executeQuery(sql);
/*  258: 442 */           ResultSet rsToUse = rs;
/*  259: 443 */           if (this.this$0.nativeJdbcExtractor != null) {
/*  260: 444 */             rsToUse = this.this$0.nativeJdbcExtractor.getNativeResultSet(rs);
/*  261:     */           }
/*  262: 446 */           return rse.extractData(rsToUse);
/*  263:     */         }
/*  264:     */         finally
/*  265:     */         {
/*  266: 449 */           JdbcUtils.closeResultSet(rs);
/*  267:     */         }
/*  268:     */       }
/*  269:     */       
/*  270:     */       public String getSql()
/*  271:     */       {
/*  272: 453 */         return sql;
/*  273:     */       }
/*  274:     */     });
/*  275:     */   }
/*  276:     */   
/*  277:     */   public void query(String sql, RowCallbackHandler rch)
/*  278:     */     throws DataAccessException
/*  279:     */   {
/*  280: 460 */     query(sql, new RowCallbackHandlerResultSetExtractor(rch));
/*  281:     */   }
/*  282:     */   
/*  283:     */   public <T> List<T> query(String sql, RowMapper<T> rowMapper)
/*  284:     */     throws DataAccessException
/*  285:     */   {
/*  286: 464 */     return (List)query(sql, new RowMapperResultSetExtractor(rowMapper));
/*  287:     */   }
/*  288:     */   
/*  289:     */   public Map<String, Object> queryForMap(String sql)
/*  290:     */     throws DataAccessException
/*  291:     */   {
/*  292: 468 */     return (Map)queryForObject(sql, getColumnMapRowMapper());
/*  293:     */   }
/*  294:     */   
/*  295:     */   public <T> T queryForObject(String sql, RowMapper<T> rowMapper)
/*  296:     */     throws DataAccessException
/*  297:     */   {
/*  298: 472 */     List<T> results = query(sql, rowMapper);
/*  299: 473 */     return DataAccessUtils.requiredSingleResult(results);
/*  300:     */   }
/*  301:     */   
/*  302:     */   public <T> T queryForObject(String sql, Class<T> requiredType)
/*  303:     */     throws DataAccessException
/*  304:     */   {
/*  305: 477 */     return queryForObject(sql, getSingleColumnRowMapper(requiredType));
/*  306:     */   }
/*  307:     */   
/*  308:     */   public long queryForLong(String sql)
/*  309:     */     throws DataAccessException
/*  310:     */   {
/*  311: 481 */     Number number = (Number)queryForObject(sql, Long.class);
/*  312: 482 */     return number != null ? number.longValue() : 0L;
/*  313:     */   }
/*  314:     */   
/*  315:     */   public int queryForInt(String sql)
/*  316:     */     throws DataAccessException
/*  317:     */   {
/*  318: 486 */     Number number = (Number)queryForObject(sql, Integer.class);
/*  319: 487 */     return number != null ? number.intValue() : 0;
/*  320:     */   }
/*  321:     */   
/*  322:     */   public <T> List<T> queryForList(String sql, Class<T> elementType)
/*  323:     */     throws DataAccessException
/*  324:     */   {
/*  325: 491 */     return query(sql, getSingleColumnRowMapper(elementType));
/*  326:     */   }
/*  327:     */   
/*  328:     */   public List<Map<String, Object>> queryForList(String sql)
/*  329:     */     throws DataAccessException
/*  330:     */   {
/*  331: 495 */     return query(sql, getColumnMapRowMapper());
/*  332:     */   }
/*  333:     */   
/*  334:     */   public SqlRowSet queryForRowSet(String sql)
/*  335:     */     throws DataAccessException
/*  336:     */   {
/*  337: 499 */     return (SqlRowSet)query(sql, new SqlRowSetResultSetExtractor());
/*  338:     */   }
/*  339:     */   
/*  340:     */   public int update(final String sql)
/*  341:     */     throws DataAccessException
/*  342:     */   {
/*  343: 503 */     Assert.notNull(sql, "SQL must not be null");
/*  344: 504 */     if (this.logger.isDebugEnabled()) {
/*  345: 505 */       this.logger.debug("Executing SQL update [" + sql + "]");
/*  346:     */     }
/*  347: 519 */     ((Integer)execute(new StatementCallback()
/*  348:     */     {
/*  349:     */       public Integer doInStatement(Statement stmt)
/*  350:     */         throws SQLException
/*  351:     */       {
/*  352: 509 */         int rows = stmt.executeUpdate(sql);
/*  353: 510 */         if (this.this$0.logger.isDebugEnabled()) {
/*  354: 511 */           this.this$0.logger.debug("SQL update affected " + rows + " rows");
/*  355:     */         }
/*  356: 513 */         return Integer.valueOf(rows);
/*  357:     */       }
/*  358:     */       
/*  359:     */       public String getSql()
/*  360:     */       {
/*  361: 516 */         return sql;
/*  362:     */       }
/*  363:     */     })).intValue();
/*  364:     */   }
/*  365:     */   
/*  366:     */   public int[] batchUpdate(final String[] sql)
/*  367:     */     throws DataAccessException
/*  368:     */   {
/*  369: 523 */     Assert.notEmpty(sql, "SQL array must not be empty");
/*  370: 524 */     if (this.logger.isDebugEnabled()) {
/*  371: 525 */       this.logger.debug("Executing SQL batch update of " + sql.length + " statements");
/*  372:     */     }
/*  373: 555 */     (int[])execute(new StatementCallback()
/*  374:     */     {
/*  375:     */       private String currSql;
/*  376:     */       
/*  377:     */       public int[] doInStatement(Statement stmt)
/*  378:     */         throws SQLException, DataAccessException
/*  379:     */       {
/*  380: 530 */         int[] rowsAffected = new int[sql.length];
/*  381: 531 */         if (JdbcUtils.supportsBatchUpdates(stmt.getConnection()))
/*  382:     */         {
/*  383: 532 */           for (String sqlStmt : sql)
/*  384:     */           {
/*  385: 533 */             this.currSql = sqlStmt;
/*  386: 534 */             stmt.addBatch(sqlStmt);
/*  387:     */           }
/*  388: 536 */           rowsAffected = stmt.executeBatch();
/*  389:     */         }
/*  390:     */         else
/*  391:     */         {
/*  392: 539 */           for (int i = 0; i < sql.length; i++)
/*  393:     */           {
/*  394: 540 */             this.currSql = sql[i];
/*  395: 541 */             if (!stmt.execute(sql[i])) {
/*  396: 542 */               rowsAffected[i] = stmt.getUpdateCount();
/*  397:     */             } else {
/*  398: 545 */               throw new InvalidDataAccessApiUsageException("Invalid batch SQL statement: " + sql[i]);
/*  399:     */             }
/*  400:     */           }
/*  401:     */         }
/*  402: 549 */         return rowsAffected;
/*  403:     */       }
/*  404:     */       
/*  405:     */       public String getSql()
/*  406:     */       {
/*  407: 552 */         return this.currSql;
/*  408:     */       }
/*  409:     */     });
/*  410:     */   }
/*  411:     */   
/*  412:     */   public <T> T execute(PreparedStatementCreator psc, PreparedStatementCallback<T> action)
/*  413:     */     throws DataAccessException
/*  414:     */   {
/*  415: 566 */     Assert.notNull(psc, "PreparedStatementCreator must not be null");
/*  416: 567 */     Assert.notNull(action, "Callback object must not be null");
/*  417: 568 */     if (this.logger.isDebugEnabled())
/*  418:     */     {
/*  419: 569 */       String sql = getSql(psc);
/*  420: 570 */       this.logger.debug("Executing prepared SQL statement" + (sql != null ? " [" + sql + "]" : ""));
/*  421:     */     }
/*  422: 573 */     Connection con = DataSourceUtils.getConnection(getDataSource());
/*  423: 574 */     PreparedStatement ps = null;
/*  424:     */     try
/*  425:     */     {
/*  426: 576 */       Connection conToUse = con;
/*  427: 577 */       if ((this.nativeJdbcExtractor != null) && (this.nativeJdbcExtractor.isNativeConnectionNecessaryForNativePreparedStatements())) {
/*  428: 579 */         conToUse = this.nativeJdbcExtractor.getNativeConnection(con);
/*  429:     */       }
/*  430: 581 */       ps = psc.createPreparedStatement(conToUse);
/*  431: 582 */       applyStatementSettings(ps);
/*  432: 583 */       PreparedStatement psToUse = ps;
/*  433: 584 */       if (this.nativeJdbcExtractor != null) {
/*  434: 585 */         psToUse = this.nativeJdbcExtractor.getNativePreparedStatement(ps);
/*  435:     */       }
/*  436: 587 */       T result = action.doInPreparedStatement(psToUse);
/*  437: 588 */       handleWarnings(ps);
/*  438: 589 */       return result;
/*  439:     */     }
/*  440:     */     catch (SQLException ex)
/*  441:     */     {
/*  442: 594 */       if ((psc instanceof ParameterDisposer)) {
/*  443: 595 */         ((ParameterDisposer)psc).cleanupParameters();
/*  444:     */       }
/*  445: 597 */       String sql = getSql(psc);
/*  446: 598 */       psc = null;
/*  447: 599 */       JdbcUtils.closeStatement(ps);
/*  448: 600 */       ps = null;
/*  449: 601 */       DataSourceUtils.releaseConnection(con, getDataSource());
/*  450: 602 */       con = null;
/*  451: 603 */       throw getExceptionTranslator().translate("PreparedStatementCallback", sql, ex);
/*  452:     */     }
/*  453:     */     finally
/*  454:     */     {
/*  455: 606 */       if ((psc instanceof ParameterDisposer)) {
/*  456: 607 */         ((ParameterDisposer)psc).cleanupParameters();
/*  457:     */       }
/*  458: 609 */       JdbcUtils.closeStatement(ps);
/*  459: 610 */       DataSourceUtils.releaseConnection(con, getDataSource());
/*  460:     */     }
/*  461:     */   }
/*  462:     */   
/*  463:     */   public <T> T execute(String sql, PreparedStatementCallback<T> action)
/*  464:     */     throws DataAccessException
/*  465:     */   {
/*  466: 615 */     return execute(new SimplePreparedStatementCreator(sql), action);
/*  467:     */   }
/*  468:     */   
/*  469:     */   public <T> T query(PreparedStatementCreator psc, final PreparedStatementSetter pss, final ResultSetExtractor<T> rse)
/*  470:     */     throws DataAccessException
/*  471:     */   {
/*  472: 634 */     Assert.notNull(rse, "ResultSetExtractor must not be null");
/*  473: 635 */     this.logger.debug("Executing prepared SQL query");
/*  474:     */     
/*  475: 637 */     execute(psc, new PreparedStatementCallback()
/*  476:     */     {
/*  477:     */       public T doInPreparedStatement(PreparedStatement ps)
/*  478:     */         throws SQLException
/*  479:     */       {
/*  480: 639 */         ResultSet rs = null;
/*  481:     */         try
/*  482:     */         {
/*  483: 641 */           if (pss != null) {
/*  484: 642 */             pss.setValues(ps);
/*  485:     */           }
/*  486: 644 */           rs = ps.executeQuery();
/*  487: 645 */           ResultSet rsToUse = rs;
/*  488: 646 */           if (JdbcTemplate.this.nativeJdbcExtractor != null) {
/*  489: 647 */             rsToUse = JdbcTemplate.this.nativeJdbcExtractor.getNativeResultSet(rs);
/*  490:     */           }
/*  491: 649 */           return rse.extractData(rsToUse);
/*  492:     */         }
/*  493:     */         finally
/*  494:     */         {
/*  495: 652 */           JdbcUtils.closeResultSet(rs);
/*  496: 653 */           if ((pss instanceof ParameterDisposer)) {
/*  497: 654 */             ((ParameterDisposer)pss).cleanupParameters();
/*  498:     */           }
/*  499:     */         }
/*  500:     */       }
/*  501:     */     });
/*  502:     */   }
/*  503:     */   
/*  504:     */   public <T> T query(PreparedStatementCreator psc, ResultSetExtractor<T> rse)
/*  505:     */     throws DataAccessException
/*  506:     */   {
/*  507: 662 */     return query(psc, null, rse);
/*  508:     */   }
/*  509:     */   
/*  510:     */   public <T> T query(String sql, PreparedStatementSetter pss, ResultSetExtractor<T> rse)
/*  511:     */     throws DataAccessException
/*  512:     */   {
/*  513: 666 */     return query(new SimplePreparedStatementCreator(sql), pss, rse);
/*  514:     */   }
/*  515:     */   
/*  516:     */   public <T> T query(String sql, Object[] args, int[] argTypes, ResultSetExtractor<T> rse)
/*  517:     */     throws DataAccessException
/*  518:     */   {
/*  519: 670 */     return query(sql, newArgTypePreparedStatementSetter(args, argTypes), rse);
/*  520:     */   }
/*  521:     */   
/*  522:     */   public <T> T query(String sql, Object[] args, ResultSetExtractor<T> rse)
/*  523:     */     throws DataAccessException
/*  524:     */   {
/*  525: 674 */     return query(sql, newArgPreparedStatementSetter(args), rse);
/*  526:     */   }
/*  527:     */   
/*  528:     */   public <T> T query(String sql, ResultSetExtractor<T> rse, Object... args)
/*  529:     */     throws DataAccessException
/*  530:     */   {
/*  531: 678 */     return query(sql, newArgPreparedStatementSetter(args), rse);
/*  532:     */   }
/*  533:     */   
/*  534:     */   public void query(PreparedStatementCreator psc, RowCallbackHandler rch)
/*  535:     */     throws DataAccessException
/*  536:     */   {
/*  537: 682 */     query(psc, new RowCallbackHandlerResultSetExtractor(rch));
/*  538:     */   }
/*  539:     */   
/*  540:     */   public void query(String sql, PreparedStatementSetter pss, RowCallbackHandler rch)
/*  541:     */     throws DataAccessException
/*  542:     */   {
/*  543: 686 */     query(sql, pss, new RowCallbackHandlerResultSetExtractor(rch));
/*  544:     */   }
/*  545:     */   
/*  546:     */   public void query(String sql, Object[] args, int[] argTypes, RowCallbackHandler rch)
/*  547:     */     throws DataAccessException
/*  548:     */   {
/*  549: 690 */     query(sql, newArgTypePreparedStatementSetter(args, argTypes), rch);
/*  550:     */   }
/*  551:     */   
/*  552:     */   public void query(String sql, Object[] args, RowCallbackHandler rch)
/*  553:     */     throws DataAccessException
/*  554:     */   {
/*  555: 694 */     query(sql, newArgPreparedStatementSetter(args), rch);
/*  556:     */   }
/*  557:     */   
/*  558:     */   public void query(String sql, RowCallbackHandler rch, Object... args)
/*  559:     */     throws DataAccessException
/*  560:     */   {
/*  561: 698 */     query(sql, newArgPreparedStatementSetter(args), rch);
/*  562:     */   }
/*  563:     */   
/*  564:     */   public <T> List<T> query(PreparedStatementCreator psc, RowMapper<T> rowMapper)
/*  565:     */     throws DataAccessException
/*  566:     */   {
/*  567: 702 */     return (List)query(psc, new RowMapperResultSetExtractor(rowMapper));
/*  568:     */   }
/*  569:     */   
/*  570:     */   public <T> List<T> query(String sql, PreparedStatementSetter pss, RowMapper<T> rowMapper)
/*  571:     */     throws DataAccessException
/*  572:     */   {
/*  573: 706 */     return (List)query(sql, pss, new RowMapperResultSetExtractor(rowMapper));
/*  574:     */   }
/*  575:     */   
/*  576:     */   public <T> List<T> query(String sql, Object[] args, int[] argTypes, RowMapper<T> rowMapper)
/*  577:     */     throws DataAccessException
/*  578:     */   {
/*  579: 710 */     return (List)query(sql, args, argTypes, new RowMapperResultSetExtractor(rowMapper));
/*  580:     */   }
/*  581:     */   
/*  582:     */   public <T> List<T> query(String sql, Object[] args, RowMapper<T> rowMapper)
/*  583:     */     throws DataAccessException
/*  584:     */   {
/*  585: 714 */     return (List)query(sql, args, new RowMapperResultSetExtractor(rowMapper));
/*  586:     */   }
/*  587:     */   
/*  588:     */   public <T> List<T> query(String sql, RowMapper<T> rowMapper, Object... args)
/*  589:     */     throws DataAccessException
/*  590:     */   {
/*  591: 718 */     return (List)query(sql, args, new RowMapperResultSetExtractor(rowMapper));
/*  592:     */   }
/*  593:     */   
/*  594:     */   public <T> T queryForObject(String sql, Object[] args, int[] argTypes, RowMapper<T> rowMapper)
/*  595:     */     throws DataAccessException
/*  596:     */   {
/*  597: 724 */     List<T> results = (List)query(sql, args, argTypes, new RowMapperResultSetExtractor(rowMapper, 1));
/*  598: 725 */     return DataAccessUtils.requiredSingleResult(results);
/*  599:     */   }
/*  600:     */   
/*  601:     */   public <T> T queryForObject(String sql, Object[] args, RowMapper<T> rowMapper)
/*  602:     */     throws DataAccessException
/*  603:     */   {
/*  604: 729 */     List<T> results = (List)query(sql, args, new RowMapperResultSetExtractor(rowMapper, 1));
/*  605: 730 */     return DataAccessUtils.requiredSingleResult(results);
/*  606:     */   }
/*  607:     */   
/*  608:     */   public <T> T queryForObject(String sql, RowMapper<T> rowMapper, Object... args)
/*  609:     */     throws DataAccessException
/*  610:     */   {
/*  611: 734 */     List<T> results = (List)query(sql, args, new RowMapperResultSetExtractor(rowMapper, 1));
/*  612: 735 */     return DataAccessUtils.requiredSingleResult(results);
/*  613:     */   }
/*  614:     */   
/*  615:     */   public <T> T queryForObject(String sql, Object[] args, int[] argTypes, Class<T> requiredType)
/*  616:     */     throws DataAccessException
/*  617:     */   {
/*  618: 741 */     return queryForObject(sql, args, argTypes, getSingleColumnRowMapper(requiredType));
/*  619:     */   }
/*  620:     */   
/*  621:     */   public <T> T queryForObject(String sql, Object[] args, Class<T> requiredType)
/*  622:     */     throws DataAccessException
/*  623:     */   {
/*  624: 745 */     return queryForObject(sql, args, getSingleColumnRowMapper(requiredType));
/*  625:     */   }
/*  626:     */   
/*  627:     */   public <T> T queryForObject(String sql, Class<T> requiredType, Object... args)
/*  628:     */     throws DataAccessException
/*  629:     */   {
/*  630: 749 */     return queryForObject(sql, args, getSingleColumnRowMapper(requiredType));
/*  631:     */   }
/*  632:     */   
/*  633:     */   public Map<String, Object> queryForMap(String sql, Object[] args, int[] argTypes)
/*  634:     */     throws DataAccessException
/*  635:     */   {
/*  636: 753 */     return (Map)queryForObject(sql, args, argTypes, getColumnMapRowMapper());
/*  637:     */   }
/*  638:     */   
/*  639:     */   public Map<String, Object> queryForMap(String sql, Object... args)
/*  640:     */     throws DataAccessException
/*  641:     */   {
/*  642: 757 */     return (Map)queryForObject(sql, args, getColumnMapRowMapper());
/*  643:     */   }
/*  644:     */   
/*  645:     */   public long queryForLong(String sql, Object[] args, int[] argTypes)
/*  646:     */     throws DataAccessException
/*  647:     */   {
/*  648: 761 */     Number number = (Number)queryForObject(sql, args, argTypes, Long.class);
/*  649: 762 */     return number != null ? number.longValue() : 0L;
/*  650:     */   }
/*  651:     */   
/*  652:     */   public long queryForLong(String sql, Object... args)
/*  653:     */     throws DataAccessException
/*  654:     */   {
/*  655: 766 */     Number number = (Number)queryForObject(sql, args, Long.class);
/*  656: 767 */     return number != null ? number.longValue() : 0L;
/*  657:     */   }
/*  658:     */   
/*  659:     */   public int queryForInt(String sql, Object[] args, int[] argTypes)
/*  660:     */     throws DataAccessException
/*  661:     */   {
/*  662: 771 */     Number number = (Number)queryForObject(sql, args, argTypes, Integer.class);
/*  663: 772 */     return number != null ? number.intValue() : 0;
/*  664:     */   }
/*  665:     */   
/*  666:     */   public int queryForInt(String sql, Object... args)
/*  667:     */     throws DataAccessException
/*  668:     */   {
/*  669: 776 */     Number number = (Number)queryForObject(sql, args, Integer.class);
/*  670: 777 */     return number != null ? number.intValue() : 0;
/*  671:     */   }
/*  672:     */   
/*  673:     */   public <T> List<T> queryForList(String sql, Object[] args, int[] argTypes, Class<T> elementType)
/*  674:     */     throws DataAccessException
/*  675:     */   {
/*  676: 781 */     return query(sql, args, argTypes, getSingleColumnRowMapper(elementType));
/*  677:     */   }
/*  678:     */   
/*  679:     */   public <T> List<T> queryForList(String sql, Object[] args, Class<T> elementType)
/*  680:     */     throws DataAccessException
/*  681:     */   {
/*  682: 785 */     return query(sql, args, getSingleColumnRowMapper(elementType));
/*  683:     */   }
/*  684:     */   
/*  685:     */   public <T> List<T> queryForList(String sql, Class<T> elementType, Object... args)
/*  686:     */     throws DataAccessException
/*  687:     */   {
/*  688: 789 */     return query(sql, args, getSingleColumnRowMapper(elementType));
/*  689:     */   }
/*  690:     */   
/*  691:     */   public List<Map<String, Object>> queryForList(String sql, Object[] args, int[] argTypes)
/*  692:     */     throws DataAccessException
/*  693:     */   {
/*  694: 793 */     return query(sql, args, argTypes, getColumnMapRowMapper());
/*  695:     */   }
/*  696:     */   
/*  697:     */   public List<Map<String, Object>> queryForList(String sql, Object... args)
/*  698:     */     throws DataAccessException
/*  699:     */   {
/*  700: 797 */     return query(sql, args, getColumnMapRowMapper());
/*  701:     */   }
/*  702:     */   
/*  703:     */   public SqlRowSet queryForRowSet(String sql, Object[] args, int[] argTypes)
/*  704:     */     throws DataAccessException
/*  705:     */   {
/*  706: 801 */     return (SqlRowSet)query(sql, args, argTypes, new SqlRowSetResultSetExtractor());
/*  707:     */   }
/*  708:     */   
/*  709:     */   public SqlRowSet queryForRowSet(String sql, Object... args)
/*  710:     */     throws DataAccessException
/*  711:     */   {
/*  712: 805 */     return (SqlRowSet)query(sql, args, new SqlRowSetResultSetExtractor());
/*  713:     */   }
/*  714:     */   
/*  715:     */   protected int update(PreparedStatementCreator psc, final PreparedStatementSetter pss)
/*  716:     */     throws DataAccessException
/*  717:     */   {
/*  718: 811 */     this.logger.debug("Executing prepared SQL update");
/*  719: 812 */     ((Integer)execute(psc, new PreparedStatementCallback()
/*  720:     */     {
/*  721:     */       public Integer doInPreparedStatement(PreparedStatement ps)
/*  722:     */         throws SQLException
/*  723:     */       {
/*  724:     */         try
/*  725:     */         {
/*  726: 815 */           if (pss != null) {
/*  727: 816 */             pss.setValues(ps);
/*  728:     */           }
/*  729: 818 */           int rows = ps.executeUpdate();
/*  730: 819 */           if (JdbcTemplate.this.logger.isDebugEnabled()) {
/*  731: 820 */             JdbcTemplate.this.logger.debug("SQL update affected " + rows + " rows");
/*  732:     */           }
/*  733: 822 */           return Integer.valueOf(rows);
/*  734:     */         }
/*  735:     */         finally
/*  736:     */         {
/*  737: 825 */           if ((pss instanceof ParameterDisposer)) {
/*  738: 826 */             ((ParameterDisposer)pss).cleanupParameters();
/*  739:     */           }
/*  740:     */         }
/*  741:     */       }
/*  742:     */     })).intValue();
/*  743:     */   }
/*  744:     */   
/*  745:     */   public int update(PreparedStatementCreator psc)
/*  746:     */     throws DataAccessException
/*  747:     */   {
/*  748: 834 */     return update(psc, (PreparedStatementSetter)null);
/*  749:     */   }
/*  750:     */   
/*  751:     */   public int update(PreparedStatementCreator psc, final KeyHolder generatedKeyHolder)
/*  752:     */     throws DataAccessException
/*  753:     */   {
/*  754: 840 */     Assert.notNull(generatedKeyHolder, "KeyHolder must not be null");
/*  755: 841 */     this.logger.debug("Executing SQL update and returning generated keys");
/*  756:     */     
/*  757: 843 */     ((Integer)execute(psc, new PreparedStatementCallback()
/*  758:     */     {
/*  759:     */       public Integer doInPreparedStatement(PreparedStatement ps)
/*  760:     */         throws SQLException
/*  761:     */       {
/*  762: 845 */         int rows = ps.executeUpdate();
/*  763: 846 */         List<Map<String, Object>> generatedKeys = generatedKeyHolder.getKeyList();
/*  764: 847 */         generatedKeys.clear();
/*  765: 848 */         ResultSet keys = ps.getGeneratedKeys();
/*  766: 849 */         if (keys != null) {
/*  767:     */           try
/*  768:     */           {
/*  769: 851 */             RowMapperResultSetExtractor<Map<String, Object>> rse = new RowMapperResultSetExtractor(JdbcTemplate.this.getColumnMapRowMapper(), 1);
/*  770:     */             
/*  771: 853 */             generatedKeys.addAll(rse.extractData(keys));
/*  772:     */           }
/*  773:     */           finally
/*  774:     */           {
/*  775: 856 */             JdbcUtils.closeResultSet(keys);
/*  776:     */           }
/*  777:     */         }
/*  778: 859 */         if (JdbcTemplate.this.logger.isDebugEnabled()) {
/*  779: 860 */           JdbcTemplate.this.logger.debug("SQL update affected " + rows + " rows and returned " + generatedKeys.size() + " keys");
/*  780:     */         }
/*  781: 862 */         return Integer.valueOf(rows);
/*  782:     */       }
/*  783:     */     })).intValue();
/*  784:     */   }
/*  785:     */   
/*  786:     */   public int update(String sql, PreparedStatementSetter pss)
/*  787:     */     throws DataAccessException
/*  788:     */   {
/*  789: 868 */     return update(new SimplePreparedStatementCreator(sql), pss);
/*  790:     */   }
/*  791:     */   
/*  792:     */   public int update(String sql, Object[] args, int[] argTypes)
/*  793:     */     throws DataAccessException
/*  794:     */   {
/*  795: 872 */     return update(sql, newArgTypePreparedStatementSetter(args, argTypes));
/*  796:     */   }
/*  797:     */   
/*  798:     */   public int update(String sql, Object... args)
/*  799:     */     throws DataAccessException
/*  800:     */   {
/*  801: 876 */     return update(sql, newArgPreparedStatementSetter(args));
/*  802:     */   }
/*  803:     */   
/*  804:     */   public int[] batchUpdate(String sql, final BatchPreparedStatementSetter pss)
/*  805:     */     throws DataAccessException
/*  806:     */   {
/*  807: 880 */     if (this.logger.isDebugEnabled()) {
/*  808: 881 */       this.logger.debug("Executing SQL batch update [" + sql + "]");
/*  809:     */     }
/*  810: 884 */     (int[])execute(sql, new PreparedStatementCallback()
/*  811:     */     {
/*  812:     */       public int[] doInPreparedStatement(PreparedStatement ps)
/*  813:     */         throws SQLException
/*  814:     */       {
/*  815:     */         try
/*  816:     */         {
/*  817: 887 */           int batchSize = pss.getBatchSize();
/*  818: 888 */           InterruptibleBatchPreparedStatementSetter ipss = (pss instanceof InterruptibleBatchPreparedStatementSetter) ? (InterruptibleBatchPreparedStatementSetter)pss : null;
/*  819: 891 */           if (JdbcUtils.supportsBatchUpdates(ps.getConnection()))
/*  820:     */           {
/*  821: 892 */             for (int i = 0; i < batchSize; i++)
/*  822:     */             {
/*  823: 893 */               pss.setValues(ps, i);
/*  824: 894 */               if ((ipss != null) && (ipss.isBatchExhausted(i))) {
/*  825:     */                 break;
/*  826:     */               }
/*  827: 897 */               ps.addBatch();
/*  828:     */             }
/*  829: 899 */             return ps.executeBatch();
/*  830:     */           }
/*  831: 902 */           List<Integer> rowsAffected = new ArrayList();
/*  832: 903 */           for (int i = 0; i < batchSize; i++)
/*  833:     */           {
/*  834: 904 */             pss.setValues(ps, i);
/*  835: 905 */             if ((ipss != null) && (ipss.isBatchExhausted(i))) {
/*  836:     */               break;
/*  837:     */             }
/*  838: 908 */             rowsAffected.add(Integer.valueOf(ps.executeUpdate()));
/*  839:     */           }
/*  840: 910 */           int[] rowsAffectedArray = new int[rowsAffected.size()];
/*  841: 911 */           for (int i = 0; i < rowsAffectedArray.length; i++) {
/*  842: 912 */             rowsAffectedArray[i] = ((Integer)rowsAffected.get(i)).intValue();
/*  843:     */           }
/*  844: 914 */           return rowsAffectedArray;
/*  845:     */         }
/*  846:     */         finally
/*  847:     */         {
/*  848: 918 */           if ((pss instanceof ParameterDisposer)) {
/*  849: 919 */             ((ParameterDisposer)pss).cleanupParameters();
/*  850:     */           }
/*  851:     */         }
/*  852:     */       }
/*  853:     */     });
/*  854:     */   }
/*  855:     */   
/*  856:     */   public int[] batchUpdate(String sql, List<Object[]> batchArgs)
/*  857:     */   {
/*  858: 927 */     return batchUpdate(sql, batchArgs, new int[0]);
/*  859:     */   }
/*  860:     */   
/*  861:     */   public int[] batchUpdate(String sql, List<Object[]> batchArgs, int[] argTypes)
/*  862:     */   {
/*  863: 931 */     return BatchUpdateUtils.executeBatchUpdate(sql, batchArgs, argTypes, this);
/*  864:     */   }
/*  865:     */   
/*  866:     */   public <T> int[][] batchUpdate(String sql, final Collection<T> batchArgs, final int batchSize, final ParameterizedPreparedStatementSetter<T> pss)
/*  867:     */   {
/*  868: 941 */     if (this.logger.isDebugEnabled()) {
/*  869: 942 */       this.logger.debug("Executing SQL batch update [" + sql + "] with a batch size of " + batchSize);
/*  870:     */     }
/*  871: 944 */     (int[][])execute(sql, new PreparedStatementCallback()
/*  872:     */     {
/*  873:     */       public int[][] doInPreparedStatement(PreparedStatement ps)
/*  874:     */         throws SQLException
/*  875:     */       {
/*  876: 946 */         List<int[]> rowsAffected = new ArrayList();
/*  877:     */         try
/*  878:     */         {
/*  879: 948 */           boolean batchSupported = true;
/*  880: 949 */           if (!JdbcUtils.supportsBatchUpdates(ps.getConnection()))
/*  881:     */           {
/*  882: 950 */             batchSupported = false;
/*  883: 951 */             JdbcTemplate.this.logger.warn("JDBC Driver does not support Batch updates; resorting to single statement execution");
/*  884:     */           }
/*  885: 953 */           int n = 0;
/*  886: 954 */           for (T obj : batchArgs)
/*  887:     */           {
/*  888: 955 */             pss.setValues(ps, obj);
/*  889: 956 */             n++;
/*  890: 957 */             if (batchSupported)
/*  891:     */             {
/*  892: 958 */               ps.addBatch();
/*  893: 959 */               if ((n % batchSize == 0) || (n == batchArgs.size()))
/*  894:     */               {
/*  895: 960 */                 if (JdbcTemplate.this.logger.isDebugEnabled())
/*  896:     */                 {
/*  897: 961 */                   int batchIdx = n % batchSize == 0 ? n / batchSize : n / batchSize + 1;
/*  898: 962 */                   int items = n - (n % batchSize == 0 ? n / batchSize - 1 : n / batchSize) * batchSize;
/*  899: 963 */                   JdbcTemplate.this.logger.debug("Sending SQL batch update #" + batchIdx + " with " + items + " items");
/*  900:     */                 }
/*  901: 965 */                 rowsAffected.add(ps.executeBatch());
/*  902:     */               }
/*  903:     */             }
/*  904:     */             else
/*  905:     */             {
/*  906: 969 */               int i = ps.executeUpdate();
/*  907: 970 */               rowsAffected.add(new int[] { i });
/*  908:     */             }
/*  909:     */           }
/*  910: 973 */           int[][] result = new int[rowsAffected.size()][];
/*  911: 974 */           for (int i = 0; i < result.length; i++) {
/*  912: 975 */             result[i] = ((int[])rowsAffected.get(i));
/*  913:     */           }
/*  914: 977 */           return result;
/*  915:     */         }
/*  916:     */         finally
/*  917:     */         {
/*  918: 979 */           if ((pss instanceof ParameterDisposer)) {
/*  919: 980 */             ((ParameterDisposer)pss).cleanupParameters();
/*  920:     */           }
/*  921:     */         }
/*  922:     */       }
/*  923:     */     });
/*  924:     */   }
/*  925:     */   
/*  926:     */   public <T> T execute(CallableStatementCreator csc, CallableStatementCallback<T> action)
/*  927:     */     throws DataAccessException
/*  928:     */   {
/*  929: 994 */     Assert.notNull(csc, "CallableStatementCreator must not be null");
/*  930: 995 */     Assert.notNull(action, "Callback object must not be null");
/*  931: 996 */     if (this.logger.isDebugEnabled())
/*  932:     */     {
/*  933: 997 */       String sql = getSql(csc);
/*  934: 998 */       this.logger.debug("Calling stored procedure" + (sql != null ? " [" + sql + "]" : ""));
/*  935:     */     }
/*  936:1001 */     Connection con = DataSourceUtils.getConnection(getDataSource());
/*  937:1002 */     CallableStatement cs = null;
/*  938:     */     try
/*  939:     */     {
/*  940:1004 */       Connection conToUse = con;
/*  941:1005 */       if (this.nativeJdbcExtractor != null) {
/*  942:1006 */         conToUse = this.nativeJdbcExtractor.getNativeConnection(con);
/*  943:     */       }
/*  944:1008 */       cs = csc.createCallableStatement(conToUse);
/*  945:1009 */       applyStatementSettings(cs);
/*  946:1010 */       CallableStatement csToUse = cs;
/*  947:1011 */       if (this.nativeJdbcExtractor != null) {
/*  948:1012 */         csToUse = this.nativeJdbcExtractor.getNativeCallableStatement(cs);
/*  949:     */       }
/*  950:1014 */       T result = action.doInCallableStatement(csToUse);
/*  951:1015 */       handleWarnings(cs);
/*  952:1016 */       return result;
/*  953:     */     }
/*  954:     */     catch (SQLException ex)
/*  955:     */     {
/*  956:1021 */       if ((csc instanceof ParameterDisposer)) {
/*  957:1022 */         ((ParameterDisposer)csc).cleanupParameters();
/*  958:     */       }
/*  959:1024 */       String sql = getSql(csc);
/*  960:1025 */       csc = null;
/*  961:1026 */       JdbcUtils.closeStatement(cs);
/*  962:1027 */       cs = null;
/*  963:1028 */       DataSourceUtils.releaseConnection(con, getDataSource());
/*  964:1029 */       con = null;
/*  965:1030 */       throw getExceptionTranslator().translate("CallableStatementCallback", sql, ex);
/*  966:     */     }
/*  967:     */     finally
/*  968:     */     {
/*  969:1033 */       if ((csc instanceof ParameterDisposer)) {
/*  970:1034 */         ((ParameterDisposer)csc).cleanupParameters();
/*  971:     */       }
/*  972:1036 */       JdbcUtils.closeStatement(cs);
/*  973:1037 */       DataSourceUtils.releaseConnection(con, getDataSource());
/*  974:     */     }
/*  975:     */   }
/*  976:     */   
/*  977:     */   public <T> T execute(String callString, CallableStatementCallback<T> action)
/*  978:     */     throws DataAccessException
/*  979:     */   {
/*  980:1042 */     return execute(new SimpleCallableStatementCreator(callString), action);
/*  981:     */   }
/*  982:     */   
/*  983:     */   public Map<String, Object> call(CallableStatementCreator csc, List<SqlParameter> declaredParameters)
/*  984:     */     throws DataAccessException
/*  985:     */   {
/*  986:1048 */     final List<SqlParameter> updateCountParameters = new ArrayList();
/*  987:1049 */     final List<SqlParameter> resultSetParameters = new ArrayList();
/*  988:1050 */     final List<SqlParameter> callParameters = new ArrayList();
/*  989:1051 */     for (SqlParameter parameter : declaredParameters) {
/*  990:1052 */       if (parameter.isResultsParameter())
/*  991:     */       {
/*  992:1053 */         if ((parameter instanceof SqlReturnResultSet)) {
/*  993:1054 */           resultSetParameters.add(parameter);
/*  994:     */         } else {
/*  995:1057 */           updateCountParameters.add(parameter);
/*  996:     */         }
/*  997:     */       }
/*  998:     */       else {
/*  999:1061 */         callParameters.add(parameter);
/* 1000:     */       }
/* 1001:     */     }
/* 1002:1064 */     (Map)execute(csc, new CallableStatementCallback()
/* 1003:     */     {
/* 1004:     */       public Map<String, Object> doInCallableStatement(CallableStatement cs)
/* 1005:     */         throws SQLException
/* 1006:     */       {
/* 1007:1066 */         boolean retVal = cs.execute();
/* 1008:1067 */         int updateCount = cs.getUpdateCount();
/* 1009:1068 */         if (JdbcTemplate.this.logger.isDebugEnabled())
/* 1010:     */         {
/* 1011:1069 */           JdbcTemplate.this.logger.debug("CallableStatement.execute() returned '" + retVal + "'");
/* 1012:1070 */           JdbcTemplate.this.logger.debug("CallableStatement.getUpdateCount() returned " + updateCount);
/* 1013:     */         }
/* 1014:1072 */         Map<String, Object> returnedResults = JdbcTemplate.this.createResultsMap();
/* 1015:1073 */         if ((retVal) || (updateCount != -1)) {
/* 1016:1074 */           returnedResults.putAll(JdbcTemplate.this.extractReturnedResults(cs, updateCountParameters, resultSetParameters, updateCount));
/* 1017:     */         }
/* 1018:1076 */         returnedResults.putAll(JdbcTemplate.this.extractOutputParameters(cs, callParameters));
/* 1019:1077 */         return returnedResults;
/* 1020:     */       }
/* 1021:     */     });
/* 1022:     */   }
/* 1023:     */   
/* 1024:     */   protected Map<String, Object> extractReturnedResults(CallableStatement cs, List updateCountParameters, List resultSetParameters, int updateCount)
/* 1025:     */     throws SQLException
/* 1026:     */   {
/* 1027:1094 */     Map<String, Object> returnedResults = new HashMap();
/* 1028:1095 */     int rsIndex = 0;
/* 1029:1096 */     int updateIndex = 0;
/* 1030:1098 */     if (!this.skipResultsProcessing)
/* 1031:     */     {
/* 1032:     */       boolean moreResults;
/* 1033:     */       do
/* 1034:     */       {
/* 1035:1100 */         if (updateCount == -1)
/* 1036:     */         {
/* 1037:1101 */           if ((resultSetParameters != null) && (resultSetParameters.size() > rsIndex))
/* 1038:     */           {
/* 1039:1102 */             SqlReturnResultSet declaredRsParam = (SqlReturnResultSet)resultSetParameters.get(rsIndex);
/* 1040:1103 */             returnedResults.putAll(processResultSet(cs.getResultSet(), declaredRsParam));
/* 1041:1104 */             rsIndex++;
/* 1042:     */           }
/* 1043:1107 */           else if (!this.skipUndeclaredResults)
/* 1044:     */           {
/* 1045:1108 */             String rsName = "#result-set-" + (rsIndex + 1);
/* 1046:1109 */             SqlReturnResultSet undeclaredRsParam = new SqlReturnResultSet(rsName, new ColumnMapRowMapper());
/* 1047:1110 */             this.logger.info("Added default SqlReturnResultSet parameter named " + rsName);
/* 1048:1111 */             returnedResults.putAll(processResultSet(cs.getResultSet(), undeclaredRsParam));
/* 1049:1112 */             rsIndex++;
/* 1050:     */           }
/* 1051:     */         }
/* 1052:1117 */         else if ((updateCountParameters != null) && (updateCountParameters.size() > updateIndex))
/* 1053:     */         {
/* 1054:1118 */           SqlReturnUpdateCount ucParam = (SqlReturnUpdateCount)updateCountParameters.get(updateIndex);
/* 1055:1119 */           String declaredUcName = ucParam.getName();
/* 1056:1120 */           returnedResults.put(declaredUcName, Integer.valueOf(updateCount));
/* 1057:1121 */           updateIndex++;
/* 1058:     */         }
/* 1059:1124 */         else if (!this.skipUndeclaredResults)
/* 1060:     */         {
/* 1061:1125 */           String undeclaredUcName = "#update-count-" + (updateIndex + 1);
/* 1062:1126 */           this.logger.info("Added default SqlReturnUpdateCount parameter named " + undeclaredUcName);
/* 1063:1127 */           returnedResults.put(undeclaredUcName, Integer.valueOf(updateCount));
/* 1064:1128 */           updateIndex++;
/* 1065:     */         }
/* 1066:1132 */         moreResults = cs.getMoreResults();
/* 1067:1133 */         updateCount = cs.getUpdateCount();
/* 1068:1134 */         if (this.logger.isDebugEnabled()) {
/* 1069:1135 */           this.logger.debug("CallableStatement.getUpdateCount() returned " + updateCount);
/* 1070:     */         }
/* 1071:1138 */       } while ((moreResults) || (updateCount != -1));
/* 1072:     */     }
/* 1073:1140 */     return returnedResults;
/* 1074:     */   }
/* 1075:     */   
/* 1076:     */   protected Map<String, Object> extractOutputParameters(CallableStatement cs, List<SqlParameter> parameters)
/* 1077:     */     throws SQLException
/* 1078:     */   {
/* 1079:1152 */     Map<String, Object> returnedResults = new HashMap();
/* 1080:1153 */     int sqlColIndex = 1;
/* 1081:1154 */     for (SqlParameter param : parameters)
/* 1082:     */     {
/* 1083:1155 */       if ((param instanceof SqlOutParameter))
/* 1084:     */       {
/* 1085:1156 */         SqlOutParameter outParam = (SqlOutParameter)param;
/* 1086:1157 */         if (outParam.isReturnTypeSupported())
/* 1087:     */         {
/* 1088:1158 */           Object out = outParam.getSqlReturnType().getTypeValue(cs, sqlColIndex, outParam.getSqlType(), outParam.getTypeName());
/* 1089:     */           
/* 1090:1160 */           returnedResults.put(outParam.getName(), out);
/* 1091:     */         }
/* 1092:     */         else
/* 1093:     */         {
/* 1094:1163 */           Object out = cs.getObject(sqlColIndex);
/* 1095:1164 */           if ((out instanceof ResultSet))
/* 1096:     */           {
/* 1097:1165 */             if (outParam.isResultSetSupported())
/* 1098:     */             {
/* 1099:1166 */               returnedResults.putAll(processResultSet((ResultSet)out, outParam));
/* 1100:     */             }
/* 1101:     */             else
/* 1102:     */             {
/* 1103:1169 */               String rsName = outParam.getName();
/* 1104:1170 */               SqlReturnResultSet rsParam = new SqlReturnResultSet(rsName, new ColumnMapRowMapper());
/* 1105:1171 */               returnedResults.putAll(processResultSet(cs.getResultSet(), rsParam));
/* 1106:1172 */               this.logger.info("Added default SqlReturnResultSet parameter named " + rsName);
/* 1107:     */             }
/* 1108:     */           }
/* 1109:     */           else {
/* 1110:1176 */             returnedResults.put(outParam.getName(), out);
/* 1111:     */           }
/* 1112:     */         }
/* 1113:     */       }
/* 1114:1180 */       if (!param.isResultsParameter()) {
/* 1115:1181 */         sqlColIndex++;
/* 1116:     */       }
/* 1117:     */     }
/* 1118:1184 */     return returnedResults;
/* 1119:     */   }
/* 1120:     */   
/* 1121:     */   protected Map<String, Object> processResultSet(ResultSet rs, ResultSetSupportingSqlParameter param)
/* 1122:     */     throws SQLException
/* 1123:     */   {
/* 1124:1195 */     if (rs == null) {
/* 1125:1196 */       return Collections.emptyMap();
/* 1126:     */     }
/* 1127:1198 */     Map<String, Object> returnedResults = new HashMap();
/* 1128:     */     try
/* 1129:     */     {
/* 1130:1200 */       ResultSet rsToUse = rs;
/* 1131:1201 */       if (this.nativeJdbcExtractor != null) {
/* 1132:1202 */         rsToUse = this.nativeJdbcExtractor.getNativeResultSet(rs);
/* 1133:     */       }
/* 1134:1204 */       if (param.getRowMapper() != null)
/* 1135:     */       {
/* 1136:1205 */         RowMapper rowMapper = param.getRowMapper();
/* 1137:1206 */         Object result = new RowMapperResultSetExtractor(rowMapper).extractData(rsToUse);
/* 1138:1207 */         returnedResults.put(param.getName(), result);
/* 1139:     */       }
/* 1140:1209 */       else if (param.getRowCallbackHandler() != null)
/* 1141:     */       {
/* 1142:1210 */         RowCallbackHandler rch = param.getRowCallbackHandler();
/* 1143:1211 */         new RowCallbackHandlerResultSetExtractor(rch).extractData(rsToUse);
/* 1144:1212 */         returnedResults.put(param.getName(), "ResultSet returned from stored procedure was processed");
/* 1145:     */       }
/* 1146:1214 */       else if (param.getResultSetExtractor() != null)
/* 1147:     */       {
/* 1148:1215 */         Object result = param.getResultSetExtractor().extractData(rsToUse);
/* 1149:1216 */         returnedResults.put(param.getName(), result);
/* 1150:     */       }
/* 1151:     */     }
/* 1152:     */     finally
/* 1153:     */     {
/* 1154:1220 */       JdbcUtils.closeResultSet(rs);
/* 1155:     */     }
/* 1156:1222 */     return returnedResults;
/* 1157:     */   }
/* 1158:     */   
/* 1159:     */   protected RowMapper<Map<String, Object>> getColumnMapRowMapper()
/* 1160:     */   {
/* 1161:1236 */     return new ColumnMapRowMapper();
/* 1162:     */   }
/* 1163:     */   
/* 1164:     */   protected <T> RowMapper<T> getSingleColumnRowMapper(Class<T> requiredType)
/* 1165:     */   {
/* 1166:1246 */     return new SingleColumnRowMapper(requiredType);
/* 1167:     */   }
/* 1168:     */   
/* 1169:     */   protected Map<String, Object> createResultsMap()
/* 1170:     */   {
/* 1171:1257 */     if (isResultsMapCaseInsensitive()) {
/* 1172:1258 */       return new LinkedCaseInsensitiveMap();
/* 1173:     */     }
/* 1174:1261 */     return new LinkedHashMap();
/* 1175:     */   }
/* 1176:     */   
/* 1177:     */   protected void applyStatementSettings(Statement stmt)
/* 1178:     */     throws SQLException
/* 1179:     */   {
/* 1180:1276 */     int fetchSize = getFetchSize();
/* 1181:1277 */     if (fetchSize > 0) {
/* 1182:1278 */       stmt.setFetchSize(fetchSize);
/* 1183:     */     }
/* 1184:1280 */     int maxRows = getMaxRows();
/* 1185:1281 */     if (maxRows > 0) {
/* 1186:1282 */       stmt.setMaxRows(maxRows);
/* 1187:     */     }
/* 1188:1284 */     DataSourceUtils.applyTimeout(stmt, getDataSource(), getQueryTimeout());
/* 1189:     */   }
/* 1190:     */   
/* 1191:     */   protected PreparedStatementSetter newArgPreparedStatementSetter(Object[] args)
/* 1192:     */   {
/* 1193:1294 */     return new ArgPreparedStatementSetter(args);
/* 1194:     */   }
/* 1195:     */   
/* 1196:     */   protected PreparedStatementSetter newArgTypePreparedStatementSetter(Object[] args, int[] argTypes)
/* 1197:     */   {
/* 1198:1305 */     return new ArgTypePreparedStatementSetter(args, argTypes);
/* 1199:     */   }
/* 1200:     */   
/* 1201:     */   protected void handleWarnings(Statement stmt)
/* 1202:     */     throws SQLException
/* 1203:     */   {
/* 1204:1316 */     if (isIgnoreWarnings())
/* 1205:     */     {
/* 1206:1317 */       if (this.logger.isDebugEnabled())
/* 1207:     */       {
/* 1208:1318 */         SQLWarning warningToLog = stmt.getWarnings();
/* 1209:1319 */         while (warningToLog != null)
/* 1210:     */         {
/* 1211:1320 */           this.logger.debug("SQLWarning ignored: SQL state '" + warningToLog.getSQLState() + "', error code '" + warningToLog.getErrorCode() + "', message [" + warningToLog.getMessage() + "]");
/* 1212:     */           
/* 1213:1322 */           warningToLog = warningToLog.getNextWarning();
/* 1214:     */         }
/* 1215:     */       }
/* 1216:     */     }
/* 1217:     */     else {
/* 1218:1327 */       handleWarnings(stmt.getWarnings());
/* 1219:     */     }
/* 1220:     */   }
/* 1221:     */   
/* 1222:     */   protected void handleWarnings(SQLWarning warning)
/* 1223:     */     throws SQLWarningException
/* 1224:     */   {
/* 1225:1338 */     if (warning != null) {
/* 1226:1339 */       throw new SQLWarningException("Warning not ignored", warning);
/* 1227:     */     }
/* 1228:     */   }
/* 1229:     */   
/* 1230:     */   private static String getSql(Object sqlProvider)
/* 1231:     */   {
/* 1232:1350 */     if ((sqlProvider instanceof SqlProvider)) {
/* 1233:1351 */       return ((SqlProvider)sqlProvider).getSql();
/* 1234:     */     }
/* 1235:1354 */     return null;
/* 1236:     */   }
/* 1237:     */   
/* 1238:     */   private class CloseSuppressingInvocationHandler
/* 1239:     */     implements InvocationHandler
/* 1240:     */   {
/* 1241:     */     private final Connection target;
/* 1242:     */     
/* 1243:     */     public CloseSuppressingInvocationHandler(Connection target)
/* 1244:     */     {
/* 1245:1369 */       this.target = target;
/* 1246:     */     }
/* 1247:     */     
/* 1248:     */     public Object invoke(Object proxy, Method method, Object[] args)
/* 1249:     */       throws Throwable
/* 1250:     */     {
/* 1251:1376 */       if (method.getName().equals("equals")) {
/* 1252:1378 */         return Boolean.valueOf(proxy == args[0]);
/* 1253:     */       }
/* 1254:1380 */       if (method.getName().equals("hashCode")) {
/* 1255:1382 */         return Integer.valueOf(System.identityHashCode(proxy));
/* 1256:     */       }
/* 1257:1384 */       if (method.getName().equals("unwrap"))
/* 1258:     */       {
/* 1259:1385 */         if (((Class)args[0]).isInstance(proxy)) {
/* 1260:1386 */           return proxy;
/* 1261:     */         }
/* 1262:     */       }
/* 1263:1389 */       else if (method.getName().equals("isWrapperFor"))
/* 1264:     */       {
/* 1265:1390 */         if (((Class)args[0]).isInstance(proxy)) {
/* 1266:1391 */           return Boolean.valueOf(true);
/* 1267:     */         }
/* 1268:     */       }
/* 1269:     */       else
/* 1270:     */       {
/* 1271:1394 */         if (method.getName().equals("close")) {
/* 1272:1396 */           return null;
/* 1273:     */         }
/* 1274:1398 */         if (method.getName().equals("isClosed")) {
/* 1275:1399 */           return Boolean.valueOf(false);
/* 1276:     */         }
/* 1277:1401 */         if (method.getName().equals("getTargetConnection")) {
/* 1278:1403 */           return this.target;
/* 1279:     */         }
/* 1280:     */       }
/* 1281:     */       try
/* 1282:     */       {
/* 1283:1408 */         Object retVal = method.invoke(this.target, args);
/* 1284:1412 */         if ((retVal instanceof Statement)) {
/* 1285:1413 */           JdbcTemplate.this.applyStatementSettings((Statement)retVal);
/* 1286:     */         }
/* 1287:1416 */         return retVal;
/* 1288:     */       }
/* 1289:     */       catch (InvocationTargetException ex)
/* 1290:     */       {
/* 1291:1419 */         throw ex.getTargetException();
/* 1292:     */       }
/* 1293:     */     }
/* 1294:     */   }
/* 1295:     */   
/* 1296:     */   private static class SimplePreparedStatementCreator
/* 1297:     */     implements PreparedStatementCreator, SqlProvider
/* 1298:     */   {
/* 1299:     */     private final String sql;
/* 1300:     */     
/* 1301:     */     public SimplePreparedStatementCreator(String sql)
/* 1302:     */     {
/* 1303:1433 */       Assert.notNull(sql, "SQL must not be null");
/* 1304:1434 */       this.sql = sql;
/* 1305:     */     }
/* 1306:     */     
/* 1307:     */     public PreparedStatement createPreparedStatement(Connection con)
/* 1308:     */       throws SQLException
/* 1309:     */     {
/* 1310:1438 */       return con.prepareStatement(this.sql);
/* 1311:     */     }
/* 1312:     */     
/* 1313:     */     public String getSql()
/* 1314:     */     {
/* 1315:1442 */       return this.sql;
/* 1316:     */     }
/* 1317:     */   }
/* 1318:     */   
/* 1319:     */   private static class SimpleCallableStatementCreator
/* 1320:     */     implements CallableStatementCreator, SqlProvider
/* 1321:     */   {
/* 1322:     */     private final String callString;
/* 1323:     */     
/* 1324:     */     public SimpleCallableStatementCreator(String callString)
/* 1325:     */     {
/* 1326:1455 */       Assert.notNull(callString, "Call string must not be null");
/* 1327:1456 */       this.callString = callString;
/* 1328:     */     }
/* 1329:     */     
/* 1330:     */     public CallableStatement createCallableStatement(Connection con)
/* 1331:     */       throws SQLException
/* 1332:     */     {
/* 1333:1460 */       return con.prepareCall(this.callString);
/* 1334:     */     }
/* 1335:     */     
/* 1336:     */     public String getSql()
/* 1337:     */     {
/* 1338:1464 */       return this.callString;
/* 1339:     */     }
/* 1340:     */   }
/* 1341:     */   
/* 1342:     */   private static class RowCallbackHandlerResultSetExtractor
/* 1343:     */     implements ResultSetExtractor<Object>
/* 1344:     */   {
/* 1345:     */     private final RowCallbackHandler rch;
/* 1346:     */     
/* 1347:     */     public RowCallbackHandlerResultSetExtractor(RowCallbackHandler rch)
/* 1348:     */     {
/* 1349:1479 */       this.rch = rch;
/* 1350:     */     }
/* 1351:     */     
/* 1352:     */     public Object extractData(ResultSet rs)
/* 1353:     */       throws SQLException
/* 1354:     */     {
/* 1355:1483 */       while (rs.next()) {
/* 1356:1484 */         this.rch.processRow(rs);
/* 1357:     */       }
/* 1358:1486 */       return null;
/* 1359:     */     }
/* 1360:     */   }
/* 1361:     */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.core.JdbcTemplate
 * JD-Core Version:    0.7.0.1
 */