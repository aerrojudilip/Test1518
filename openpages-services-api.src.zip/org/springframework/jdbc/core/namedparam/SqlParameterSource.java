package org.springframework.jdbc.core.namedparam;

public abstract interface SqlParameterSource
{
  public static final int TYPE_UNKNOWN = -2147483648;
  
  public abstract boolean hasValue(String paramString);
  
  public abstract Object getValue(String paramString)
    throws IllegalArgumentException;
  
  public abstract int getSqlType(String paramString);
  
  public abstract String getTypeName(String paramString);
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.core.namedparam.SqlParameterSource
 * JD-Core Version:    0.7.0.1
 */