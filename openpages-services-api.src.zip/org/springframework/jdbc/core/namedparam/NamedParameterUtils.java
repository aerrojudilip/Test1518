/*   1:    */ package org.springframework.jdbc.core.namedparam;
/*   2:    */ 
/*   3:    */ import java.util.ArrayList;
/*   4:    */ import java.util.Collection;
/*   5:    */ import java.util.HashSet;
/*   6:    */ import java.util.Iterator;
/*   7:    */ import java.util.LinkedList;
/*   8:    */ import java.util.List;
/*   9:    */ import java.util.Map;
/*  10:    */ import java.util.Set;
/*  11:    */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*  12:    */ import org.springframework.jdbc.core.SqlParameter;
/*  13:    */ import org.springframework.jdbc.core.SqlParameterValue;
/*  14:    */ import org.springframework.util.Assert;
/*  15:    */ 
/*  16:    */ public abstract class NamedParameterUtils
/*  17:    */ {
/*  18: 47 */   private static final char[] PARAMETER_SEPARATORS = { '"', '\'', ':', '&', ',', ';', '(', ')', '|', '=', '+', '-', '*', '%', '/', '\\', '<', '>', '^' };
/*  19: 53 */   private static final String[] START_SKIP = { "'", "\"", "--", "/*" };
/*  20: 59 */   private static final String[] STOP_SKIP = { "'", "\"", "\n", "*/" };
/*  21:    */   
/*  22:    */   public static ParsedSql parseSqlStatement(String sql)
/*  23:    */   {
/*  24: 74 */     Assert.notNull(sql, "SQL must not be null");
/*  25:    */     
/*  26: 76 */     Set<String> namedParameters = new HashSet();
/*  27: 77 */     String sqlToUse = sql;
/*  28: 78 */     List<ParameterHolder> parameterList = new ArrayList();
/*  29:    */     
/*  30: 80 */     char[] statement = sql.toCharArray();
/*  31: 81 */     int namedParameterCount = 0;
/*  32: 82 */     int unnamedParameterCount = 0;
/*  33: 83 */     int totalParameterCount = 0;
/*  34:    */     
/*  35: 85 */     int escapes = 0;
/*  36: 86 */     int i = 0;
/*  37: 87 */     while (i < statement.length)
/*  38:    */     {
/*  39: 88 */       int skipToPosition = i;
/*  40: 89 */       while (i < statement.length)
/*  41:    */       {
/*  42: 90 */         skipToPosition = skipCommentsAndQuotes(statement, i);
/*  43: 91 */         if (i == skipToPosition) {
/*  44:    */           break;
/*  45:    */         }
/*  46: 95 */         i = skipToPosition;
/*  47:    */       }
/*  48: 98 */       if (i >= statement.length) {
/*  49:    */         break;
/*  50:    */       }
/*  51:101 */       char c = statement[i];
/*  52:102 */       if ((c == ':') || (c == '&'))
/*  53:    */       {
/*  54:103 */         int j = i + 1;
/*  55:104 */         if ((j < statement.length) && (statement[j] == ':') && (c == ':'))
/*  56:    */         {
/*  57:106 */           i += 2;
/*  58:107 */           continue;
/*  59:    */         }
/*  60:109 */         String parameter = null;
/*  61:110 */         if ((j < statement.length) && (c == ':') && (statement[j] == '{'))
/*  62:    */         {
/*  63:112 */           while ((j < statement.length) && ('}' != statement[j]))
/*  64:    */           {
/*  65:113 */             j++;
/*  66:114 */             if ((':' == statement[j]) || ('{' == statement[j])) {
/*  67:115 */               throw new InvalidDataAccessApiUsageException("Parameter name contains invalid character '" + statement[j] + "' at position " + i + " in statement " + sql);
/*  68:    */             }
/*  69:    */           }
/*  70:118 */           if (j >= statement.length) {
/*  71:119 */             throw new InvalidDataAccessApiUsageException("Non-terminated named parameter declaration at position " + i + " in statement " + sql);
/*  72:    */           }
/*  73:121 */           if (j - i > 3)
/*  74:    */           {
/*  75:122 */             parameter = sql.substring(i + 2, j);
/*  76:123 */             namedParameterCount = addNewNamedParameter(namedParameters, namedParameterCount, parameter);
/*  77:124 */             totalParameterCount = addNamedParameter(parameterList, totalParameterCount, escapes, i, j + 1, parameter);
/*  78:    */           }
/*  79:126 */           j++;
/*  80:    */         }
/*  81:    */         else
/*  82:    */         {
/*  83:129 */           while ((j < statement.length) && (!isParameterSeparator(statement[j]))) {
/*  84:130 */             j++;
/*  85:    */           }
/*  86:132 */           if (j - i > 1)
/*  87:    */           {
/*  88:133 */             parameter = sql.substring(i + 1, j);
/*  89:134 */             namedParameterCount = addNewNamedParameter(namedParameters, namedParameterCount, parameter);
/*  90:135 */             totalParameterCount = addNamedParameter(parameterList, totalParameterCount, escapes, i, j, parameter);
/*  91:    */           }
/*  92:    */         }
/*  93:138 */         i = j - 1;
/*  94:    */       }
/*  95:    */       else
/*  96:    */       {
/*  97:141 */         if (c == '\\')
/*  98:    */         {
/*  99:142 */           int j = i + 1;
/* 100:143 */           if ((j < statement.length) && (statement[j] == ':'))
/* 101:    */           {
/* 102:145 */             sqlToUse = sqlToUse.substring(0, i - escapes) + sqlToUse.substring(i - escapes + 1);
/* 103:146 */             escapes++;
/* 104:147 */             i += 2;
/* 105:148 */             continue;
/* 106:    */           }
/* 107:    */         }
/* 108:151 */         if (c == '?')
/* 109:    */         {
/* 110:152 */           unnamedParameterCount++;
/* 111:153 */           totalParameterCount++;
/* 112:    */         }
/* 113:    */       }
/* 114:156 */       i++;
/* 115:    */     }
/* 116:158 */     ParsedSql parsedSql = new ParsedSql(sqlToUse);
/* 117:159 */     for (ParameterHolder ph : parameterList) {
/* 118:160 */       parsedSql.addNamedParameter(ph.getParameterName(), ph.getStartIndex(), ph.getEndIndex());
/* 119:    */     }
/* 120:162 */     parsedSql.setNamedParameterCount(namedParameterCount);
/* 121:163 */     parsedSql.setUnnamedParameterCount(unnamedParameterCount);
/* 122:164 */     parsedSql.setTotalParameterCount(totalParameterCount);
/* 123:165 */     return parsedSql;
/* 124:    */   }
/* 125:    */   
/* 126:    */   private static int addNamedParameter(List<ParameterHolder> parameterList, int totalParameterCount, int escapes, int i, int j, String parameter)
/* 127:    */   {
/* 128:170 */     parameterList.add(new ParameterHolder(parameter, i - escapes, j - escapes));
/* 129:171 */     totalParameterCount++;
/* 130:172 */     return totalParameterCount;
/* 131:    */   }
/* 132:    */   
/* 133:    */   private static int addNewNamedParameter(Set<String> namedParameters, int namedParameterCount, String parameter)
/* 134:    */   {
/* 135:176 */     if (!namedParameters.contains(parameter))
/* 136:    */     {
/* 137:177 */       namedParameters.add(parameter);
/* 138:178 */       namedParameterCount++;
/* 139:    */     }
/* 140:180 */     return namedParameterCount;
/* 141:    */   }
/* 142:    */   
/* 143:    */   private static int skipCommentsAndQuotes(char[] statement, int position)
/* 144:    */   {
/* 145:190 */     for (int i = 0; i < START_SKIP.length; i++) {
/* 146:191 */       if (statement[position] == START_SKIP[i].charAt(0))
/* 147:    */       {
/* 148:192 */         boolean match = true;
/* 149:193 */         for (int j = 1; j < START_SKIP[i].length(); j++) {
/* 150:194 */           if (statement[(position + j)] != START_SKIP[i].charAt(j))
/* 151:    */           {
/* 152:195 */             match = false;
/* 153:196 */             break;
/* 154:    */           }
/* 155:    */         }
/* 156:199 */         if (match)
/* 157:    */         {
/* 158:200 */           int offset = START_SKIP[i].length();
/* 159:201 */           for (int m = position + offset; m < statement.length; m++) {
/* 160:202 */             if (statement[m] == STOP_SKIP[i].charAt(0))
/* 161:    */             {
/* 162:203 */               boolean endMatch = true;
/* 163:204 */               int endPos = m;
/* 164:205 */               for (int n = 1; n < STOP_SKIP[i].length(); n++)
/* 165:    */               {
/* 166:206 */                 if (m + n >= statement.length) {
/* 167:208 */                   return statement.length;
/* 168:    */                 }
/* 169:210 */                 if (statement[(m + n)] != STOP_SKIP[i].charAt(n))
/* 170:    */                 {
/* 171:211 */                   endMatch = false;
/* 172:212 */                   break;
/* 173:    */                 }
/* 174:214 */                 endPos = m + n;
/* 175:    */               }
/* 176:216 */               if (endMatch) {
/* 177:218 */                 return endPos + 1;
/* 178:    */               }
/* 179:    */             }
/* 180:    */           }
/* 181:223 */           return statement.length;
/* 182:    */         }
/* 183:    */       }
/* 184:    */     }
/* 185:228 */     return position;
/* 186:    */   }
/* 187:    */   
/* 188:    */   public static String substituteNamedParameters(ParsedSql parsedSql, SqlParameterSource paramSource)
/* 189:    */   {
/* 190:249 */     String originalSql = parsedSql.getOriginalSql();
/* 191:250 */     StringBuilder actualSql = new StringBuilder();
/* 192:251 */     List paramNames = parsedSql.getParameterNames();
/* 193:252 */     int lastIndex = 0;
/* 194:253 */     for (int i = 0; i < paramNames.size(); i++)
/* 195:    */     {
/* 196:254 */       String paramName = (String)paramNames.get(i);
/* 197:255 */       int[] indexes = parsedSql.getParameterIndexes(i);
/* 198:256 */       int startIndex = indexes[0];
/* 199:257 */       int endIndex = indexes[1];
/* 200:258 */       actualSql.append(originalSql.substring(lastIndex, startIndex));
/* 201:259 */       if ((paramSource != null) && (paramSource.hasValue(paramName)))
/* 202:    */       {
/* 203:260 */         Object value = paramSource.getValue(paramName);
/* 204:261 */         if ((value instanceof SqlParameterValue)) {
/* 205:262 */           value = ((SqlParameterValue)value).getValue();
/* 206:    */         }
/* 207:264 */         if ((value instanceof Collection))
/* 208:    */         {
/* 209:265 */           Iterator entryIter = ((Collection)value).iterator();
/* 210:266 */           int k = 0;
/* 211:267 */           while (entryIter.hasNext())
/* 212:    */           {
/* 213:268 */             if (k > 0) {
/* 214:269 */               actualSql.append(", ");
/* 215:    */             }
/* 216:271 */             k++;
/* 217:272 */             Object entryItem = entryIter.next();
/* 218:273 */             if ((entryItem instanceof Object[]))
/* 219:    */             {
/* 220:274 */               Object[] expressionList = (Object[])entryItem;
/* 221:275 */               actualSql.append("(");
/* 222:276 */               for (int m = 0; m < expressionList.length; m++)
/* 223:    */               {
/* 224:277 */                 if (m > 0) {
/* 225:278 */                   actualSql.append(", ");
/* 226:    */                 }
/* 227:280 */                 actualSql.append("?");
/* 228:    */               }
/* 229:282 */               actualSql.append(")");
/* 230:    */             }
/* 231:    */             else
/* 232:    */             {
/* 233:285 */               actualSql.append("?");
/* 234:    */             }
/* 235:    */           }
/* 236:    */         }
/* 237:    */         else
/* 238:    */         {
/* 239:290 */           actualSql.append("?");
/* 240:    */         }
/* 241:    */       }
/* 242:    */       else
/* 243:    */       {
/* 244:294 */         actualSql.append("?");
/* 245:    */       }
/* 246:296 */       lastIndex = endIndex;
/* 247:    */     }
/* 248:298 */     actualSql.append(originalSql.substring(lastIndex, originalSql.length()));
/* 249:299 */     return actualSql.toString();
/* 250:    */   }
/* 251:    */   
/* 252:    */   public static Object[] buildValueArray(ParsedSql parsedSql, SqlParameterSource paramSource, List<SqlParameter> declaredParams)
/* 253:    */   {
/* 254:314 */     Object[] paramArray = new Object[parsedSql.getTotalParameterCount()];
/* 255:315 */     if ((parsedSql.getNamedParameterCount() > 0) && (parsedSql.getUnnamedParameterCount() > 0)) {
/* 256:316 */       throw new InvalidDataAccessApiUsageException("You can't mix named and traditional ? placeholders. You have " + parsedSql.getNamedParameterCount() + " named parameter(s) and " + parsedSql.getUnnamedParameterCount() + " traditonal placeholder(s) in [" + parsedSql.getOriginalSql() + "]");
/* 257:    */     }
/* 258:322 */     List<String> paramNames = parsedSql.getParameterNames();
/* 259:323 */     for (int i = 0; i < paramNames.size(); i++)
/* 260:    */     {
/* 261:324 */       String paramName = (String)paramNames.get(i);
/* 262:    */       try
/* 263:    */       {
/* 264:326 */         Object value = paramSource.getValue(paramName);
/* 265:327 */         SqlParameter param = findParameter(declaredParams, paramName, i);
/* 266:328 */         paramArray[i] = (param != null ? new SqlParameterValue(param, value) : value);
/* 267:    */       }
/* 268:    */       catch (IllegalArgumentException ex)
/* 269:    */       {
/* 270:331 */         throw new InvalidDataAccessApiUsageException("No value supplied for the SQL parameter '" + paramName + "': " + ex.getMessage());
/* 271:    */       }
/* 272:    */     }
/* 273:335 */     return paramArray;
/* 274:    */   }
/* 275:    */   
/* 276:    */   private static SqlParameter findParameter(List<SqlParameter> declaredParams, String paramName, int paramIndex)
/* 277:    */   {
/* 278:346 */     if (declaredParams != null)
/* 279:    */     {
/* 280:348 */       for (SqlParameter declaredParam : declaredParams) {
/* 281:349 */         if (paramName.equals(declaredParam.getName())) {
/* 282:350 */           return declaredParam;
/* 283:    */         }
/* 284:    */       }
/* 285:354 */       if (paramIndex < declaredParams.size())
/* 286:    */       {
/* 287:355 */         SqlParameter declaredParam = (SqlParameter)declaredParams.get(paramIndex);
/* 288:357 */         if (declaredParam.getName() == null) {
/* 289:358 */           return declaredParam;
/* 290:    */         }
/* 291:    */       }
/* 292:    */     }
/* 293:362 */     return null;
/* 294:    */   }
/* 295:    */   
/* 296:    */   private static boolean isParameterSeparator(char c)
/* 297:    */   {
/* 298:370 */     if (Character.isWhitespace(c)) {
/* 299:371 */       return true;
/* 300:    */     }
/* 301:373 */     for (char separator : PARAMETER_SEPARATORS) {
/* 302:374 */       if (c == separator) {
/* 303:375 */         return true;
/* 304:    */       }
/* 305:    */     }
/* 306:378 */     return false;
/* 307:    */   }
/* 308:    */   
/* 309:    */   public static int[] buildSqlTypeArray(ParsedSql parsedSql, SqlParameterSource paramSource)
/* 310:    */   {
/* 311:390 */     int[] sqlTypes = new int[parsedSql.getTotalParameterCount()];
/* 312:391 */     List<String> paramNames = parsedSql.getParameterNames();
/* 313:392 */     for (int i = 0; i < paramNames.size(); i++)
/* 314:    */     {
/* 315:393 */       String paramName = (String)paramNames.get(i);
/* 316:394 */       sqlTypes[i] = paramSource.getSqlType(paramName);
/* 317:    */     }
/* 318:396 */     return sqlTypes;
/* 319:    */   }
/* 320:    */   
/* 321:    */   public static List<SqlParameter> buildSqlParameterList(ParsedSql parsedSql, SqlParameterSource paramSource)
/* 322:    */   {
/* 323:408 */     List<String> paramNames = parsedSql.getParameterNames();
/* 324:409 */     List<SqlParameter> params = new LinkedList();
/* 325:410 */     for (String paramName : paramNames)
/* 326:    */     {
/* 327:411 */       SqlParameter param = new SqlParameter(paramName, paramSource.getSqlType(paramName), paramSource.getTypeName(paramName));
/* 328:    */       
/* 329:    */ 
/* 330:    */ 
/* 331:415 */       params.add(param);
/* 332:    */     }
/* 333:417 */     return params;
/* 334:    */   }
/* 335:    */   
/* 336:    */   public static String parseSqlStatementIntoString(String sql)
/* 337:    */   {
/* 338:434 */     ParsedSql parsedSql = parseSqlStatement(sql);
/* 339:435 */     return substituteNamedParameters(parsedSql, null);
/* 340:    */   }
/* 341:    */   
/* 342:    */   public static String substituteNamedParameters(String sql, SqlParameterSource paramSource)
/* 343:    */   {
/* 344:449 */     ParsedSql parsedSql = parseSqlStatement(sql);
/* 345:450 */     return substituteNamedParameters(parsedSql, paramSource);
/* 346:    */   }
/* 347:    */   
/* 348:    */   public static Object[] buildValueArray(String sql, Map<String, ?> paramMap)
/* 349:    */   {
/* 350:462 */     ParsedSql parsedSql = parseSqlStatement(sql);
/* 351:463 */     return buildValueArray(parsedSql, new MapSqlParameterSource(paramMap), null);
/* 352:    */   }
/* 353:    */   
/* 354:    */   private static class ParameterHolder
/* 355:    */   {
/* 356:    */     private String parameterName;
/* 357:    */     private int startIndex;
/* 358:    */     private int endIndex;
/* 359:    */     
/* 360:    */     public ParameterHolder(String parameterName, int startIndex, int endIndex)
/* 361:    */     {
/* 362:473 */       this.parameterName = parameterName;
/* 363:474 */       this.startIndex = startIndex;
/* 364:475 */       this.endIndex = endIndex;
/* 365:    */     }
/* 366:    */     
/* 367:    */     public String getParameterName()
/* 368:    */     {
/* 369:479 */       return this.parameterName;
/* 370:    */     }
/* 371:    */     
/* 372:    */     public int getStartIndex()
/* 373:    */     {
/* 374:483 */       return this.startIndex;
/* 375:    */     }
/* 376:    */     
/* 377:    */     public int getEndIndex()
/* 378:    */     {
/* 379:487 */       return this.endIndex;
/* 380:    */     }
/* 381:    */   }
/* 382:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.core.namedparam.NamedParameterUtils
 * JD-Core Version:    0.7.0.1
 */