/*  1:   */ package org.springframework.jdbc.core.namedparam;
/*  2:   */ 
/*  3:   */ import java.sql.PreparedStatement;
/*  4:   */ import java.sql.SQLException;
/*  5:   */ import org.springframework.jdbc.core.BatchPreparedStatementSetter;
/*  6:   */ import org.springframework.jdbc.core.BatchUpdateUtils;
/*  7:   */ import org.springframework.jdbc.core.JdbcOperations;
/*  8:   */ 
/*  9:   */ public class NamedParameterBatchUpdateUtils
/* 10:   */   extends BatchUpdateUtils
/* 11:   */ {
/* 12:   */   public static int[] executeBatchUpdateWithNamedParameters(ParsedSql parsedSql, final SqlParameterSource[] batchArgs, JdbcOperations jdbcOperations)
/* 13:   */   {
/* 14:36 */     if (batchArgs.length <= 0) {
/* 15:37 */       return new int[] { 0 };
/* 16:   */     }
/* 17:39 */     String sqlToUse = NamedParameterUtils.substituteNamedParameters(parsedSql, batchArgs[0]);
/* 18:40 */     jdbcOperations.batchUpdate(sqlToUse, new BatchPreparedStatementSetter()
/* 19:   */     {
/* 20:   */       public void setValues(PreparedStatement ps, int i)
/* 21:   */         throws SQLException
/* 22:   */       {
/* 23:45 */         Object[] values = NamedParameterUtils.buildValueArray(this.val$parsedSql, batchArgs[i], null);
/* 24:46 */         int[] columnTypes = NamedParameterUtils.buildSqlTypeArray(this.val$parsedSql, batchArgs[i]);
/* 25:47 */         NamedParameterBatchUpdateUtils.setStatementParameters(values, ps, columnTypes);
/* 26:   */       }
/* 27:   */       
/* 28:   */       public int getBatchSize()
/* 29:   */       {
/* 30:51 */         return batchArgs.length;
/* 31:   */       }
/* 32:   */     });
/* 33:   */   }
/* 34:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.core.namedparam.NamedParameterBatchUpdateUtils
 * JD-Core Version:    0.7.0.1
 */