package org.springframework.jdbc.core;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

public abstract interface CallableStatementCreator
{
  public abstract CallableStatement createCallableStatement(Connection paramConnection)
    throws SQLException;
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.core.CallableStatementCreator
 * JD-Core Version:    0.7.0.1
 */