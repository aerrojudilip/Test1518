/*  1:   */ package org.springframework.jdbc.core;
/*  2:   */ 
/*  3:   */ public class SqlReturnUpdateCount
/*  4:   */   extends SqlParameter
/*  5:   */ {
/*  6:   */   public SqlReturnUpdateCount(String name)
/*  7:   */   {
/*  8:20 */     super(name, 4);
/*  9:   */   }
/* 10:   */   
/* 11:   */   public boolean isInputValueProvided()
/* 12:   */   {
/* 13:31 */     return false;
/* 14:   */   }
/* 15:   */   
/* 16:   */   public boolean isResultsParameter()
/* 17:   */   {
/* 18:41 */     return true;
/* 19:   */   }
/* 20:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.core.SqlReturnUpdateCount
 * JD-Core Version:    0.7.0.1
 */