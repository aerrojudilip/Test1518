package org.springframework.jdbc.core;

import java.sql.PreparedStatement;
import java.sql.SQLException;

public abstract interface BatchPreparedStatementSetter
{
  public abstract void setValues(PreparedStatement paramPreparedStatement, int paramInt)
    throws SQLException;
  
  public abstract int getBatchSize();
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.core.BatchPreparedStatementSetter
 * JD-Core Version:    0.7.0.1
 */