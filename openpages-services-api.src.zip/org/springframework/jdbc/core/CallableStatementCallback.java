package org.springframework.jdbc.core;

import java.sql.CallableStatement;
import java.sql.SQLException;
import org.springframework.dao.DataAccessException;

public abstract interface CallableStatementCallback<T>
{
  public abstract T doInCallableStatement(CallableStatement paramCallableStatement)
    throws SQLException, DataAccessException;
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.core.CallableStatementCallback
 * JD-Core Version:    0.7.0.1
 */