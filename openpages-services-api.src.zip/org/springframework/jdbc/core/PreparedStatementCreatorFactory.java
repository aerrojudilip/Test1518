/*   1:    */ package org.springframework.jdbc.core;
/*   2:    */ 
/*   3:    */ import java.sql.Connection;
/*   4:    */ import java.sql.PreparedStatement;
/*   5:    */ import java.sql.SQLException;
/*   6:    */ import java.util.Arrays;
/*   7:    */ import java.util.Collection;
/*   8:    */ import java.util.Collections;
/*   9:    */ import java.util.HashSet;
/*  10:    */ import java.util.LinkedList;
/*  11:    */ import java.util.List;
/*  12:    */ import java.util.Set;
/*  13:    */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*  14:    */ import org.springframework.dao.InvalidDataAccessResourceUsageException;
/*  15:    */ import org.springframework.jdbc.support.nativejdbc.NativeJdbcExtractor;
/*  16:    */ import org.springframework.util.Assert;
/*  17:    */ 
/*  18:    */ public class PreparedStatementCreatorFactory
/*  19:    */ {
/*  20:    */   private final String sql;
/*  21:    */   private final List<SqlParameter> declaredParameters;
/*  22: 54 */   private int resultSetType = 1003;
/*  23: 56 */   private boolean updatableResults = false;
/*  24: 58 */   private boolean returnGeneratedKeys = false;
/*  25: 60 */   private String[] generatedKeysColumnNames = null;
/*  26:    */   private NativeJdbcExtractor nativeJdbcExtractor;
/*  27:    */   
/*  28:    */   public PreparedStatementCreatorFactory(String sql)
/*  29:    */   {
/*  30: 70 */     this.sql = sql;
/*  31: 71 */     this.declaredParameters = new LinkedList();
/*  32:    */   }
/*  33:    */   
/*  34:    */   public PreparedStatementCreatorFactory(String sql, int[] types)
/*  35:    */   {
/*  36: 80 */     this.sql = sql;
/*  37: 81 */     this.declaredParameters = SqlParameter.sqlTypesToAnonymousParameterList(types);
/*  38:    */   }
/*  39:    */   
/*  40:    */   public PreparedStatementCreatorFactory(String sql, List<SqlParameter> declaredParameters)
/*  41:    */   {
/*  42: 91 */     this.sql = sql;
/*  43: 92 */     this.declaredParameters = declaredParameters;
/*  44:    */   }
/*  45:    */   
/*  46:    */   public void addParameter(SqlParameter param)
/*  47:    */   {
/*  48:102 */     this.declaredParameters.add(param);
/*  49:    */   }
/*  50:    */   
/*  51:    */   public void setResultSetType(int resultSetType)
/*  52:    */   {
/*  53:113 */     this.resultSetType = resultSetType;
/*  54:    */   }
/*  55:    */   
/*  56:    */   public void setUpdatableResults(boolean updatableResults)
/*  57:    */   {
/*  58:120 */     this.updatableResults = updatableResults;
/*  59:    */   }
/*  60:    */   
/*  61:    */   public void setReturnGeneratedKeys(boolean returnGeneratedKeys)
/*  62:    */   {
/*  63:127 */     this.returnGeneratedKeys = returnGeneratedKeys;
/*  64:    */   }
/*  65:    */   
/*  66:    */   public void setGeneratedKeysColumnNames(String[] names)
/*  67:    */   {
/*  68:134 */     this.generatedKeysColumnNames = names;
/*  69:    */   }
/*  70:    */   
/*  71:    */   public void setNativeJdbcExtractor(NativeJdbcExtractor nativeJdbcExtractor)
/*  72:    */   {
/*  73:141 */     this.nativeJdbcExtractor = nativeJdbcExtractor;
/*  74:    */   }
/*  75:    */   
/*  76:    */   public PreparedStatementSetter newPreparedStatementSetter(List params)
/*  77:    */   {
/*  78:150 */     return new PreparedStatementCreatorImpl(params != null ? params : Collections.emptyList());
/*  79:    */   }
/*  80:    */   
/*  81:    */   public PreparedStatementSetter newPreparedStatementSetter(Object[] params)
/*  82:    */   {
/*  83:158 */     return new PreparedStatementCreatorImpl(params != null ? Arrays.asList(params) : Collections.emptyList());
/*  84:    */   }
/*  85:    */   
/*  86:    */   public PreparedStatementCreator newPreparedStatementCreator(List<?> params)
/*  87:    */   {
/*  88:166 */     return new PreparedStatementCreatorImpl(params != null ? params : Collections.emptyList());
/*  89:    */   }
/*  90:    */   
/*  91:    */   public PreparedStatementCreator newPreparedStatementCreator(Object[] params)
/*  92:    */   {
/*  93:174 */     return new PreparedStatementCreatorImpl(params != null ? Arrays.asList(params) : Collections.emptyList());
/*  94:    */   }
/*  95:    */   
/*  96:    */   public PreparedStatementCreator newPreparedStatementCreator(String sqlToUse, Object[] params)
/*  97:    */   {
/*  98:184 */     return new PreparedStatementCreatorImpl(sqlToUse, params != null ? Arrays.asList(params) : Collections.emptyList());
/*  99:    */   }
/* 100:    */   
/* 101:    */   private class PreparedStatementCreatorImpl
/* 102:    */     implements PreparedStatementCreator, PreparedStatementSetter, SqlProvider, ParameterDisposer
/* 103:    */   {
/* 104:    */     private final String actualSql;
/* 105:    */     private final List parameters;
/* 106:    */     
/* 107:    */     public PreparedStatementCreatorImpl()
/* 108:    */     {
/* 109:200 */       this(PreparedStatementCreatorFactory.this.sql, parameters);
/* 110:    */     }
/* 111:    */     
/* 112:    */     public PreparedStatementCreatorImpl(String actualSql, List parameters)
/* 113:    */     {
/* 114:204 */       this.actualSql = actualSql;
/* 115:205 */       Assert.notNull(parameters, "Parameters List must not be null");
/* 116:206 */       this.parameters = parameters;
/* 117:207 */       if (this.parameters.size() != PreparedStatementCreatorFactory.this.declaredParameters.size())
/* 118:    */       {
/* 119:209 */         Set<String> names = new HashSet();
/* 120:210 */         for (int i = 0; i < parameters.size(); i++)
/* 121:    */         {
/* 122:211 */           Object param = parameters.get(i);
/* 123:212 */           if ((param instanceof SqlParameterValue)) {
/* 124:213 */             names.add(((SqlParameterValue)param).getName());
/* 125:    */           } else {
/* 126:216 */             names.add("Parameter #" + i);
/* 127:    */           }
/* 128:    */         }
/* 129:219 */         if (names.size() != PreparedStatementCreatorFactory.this.declaredParameters.size()) {
/* 130:220 */           throw new InvalidDataAccessApiUsageException("SQL [" + PreparedStatementCreatorFactory.this.sql + "]: given " + names.size() + " parameters but expected " + PreparedStatementCreatorFactory.this.declaredParameters.size());
/* 131:    */         }
/* 132:    */       }
/* 133:    */     }
/* 134:    */     
/* 135:    */     public PreparedStatement createPreparedStatement(Connection con)
/* 136:    */       throws SQLException
/* 137:    */     {
/* 138:228 */       PreparedStatement ps = null;
/* 139:229 */       if ((PreparedStatementCreatorFactory.this.generatedKeysColumnNames != null) || (PreparedStatementCreatorFactory.this.returnGeneratedKeys)) {
/* 140:    */         try
/* 141:    */         {
/* 142:231 */           if (PreparedStatementCreatorFactory.this.generatedKeysColumnNames != null) {
/* 143:232 */             ps = con.prepareStatement(this.actualSql, PreparedStatementCreatorFactory.this.generatedKeysColumnNames);
/* 144:    */           } else {
/* 145:235 */             ps = con.prepareStatement(this.actualSql, 1);
/* 146:    */           }
/* 147:    */         }
/* 148:    */         catch (AbstractMethodError ex)
/* 149:    */         {
/* 150:239 */           throw new InvalidDataAccessResourceUsageException("The JDBC driver is not compliant to JDBC 3.0 and thus does not support retrieval of auto-generated keys", ex);
/* 151:    */         }
/* 152:244 */       } else if ((PreparedStatementCreatorFactory.this.resultSetType == 1003) && (!PreparedStatementCreatorFactory.this.updatableResults)) {
/* 153:245 */         ps = con.prepareStatement(this.actualSql);
/* 154:    */       } else {
/* 155:248 */         ps = con.prepareStatement(this.actualSql, PreparedStatementCreatorFactory.this.resultSetType, PreparedStatementCreatorFactory.this.updatableResults ? 1008 : 1007);
/* 156:    */       }
/* 157:251 */       setValues(ps);
/* 158:252 */       return ps;
/* 159:    */     }
/* 160:    */     
/* 161:    */     public void setValues(PreparedStatement ps)
/* 162:    */       throws SQLException
/* 163:    */     {
/* 164:257 */       PreparedStatement psToUse = ps;
/* 165:258 */       if (PreparedStatementCreatorFactory.this.nativeJdbcExtractor != null) {
/* 166:259 */         psToUse = PreparedStatementCreatorFactory.this.nativeJdbcExtractor.getNativePreparedStatement(ps);
/* 167:    */       }
/* 168:263 */       int sqlColIndx = 1;
/* 169:264 */       for (int i = 0; i < this.parameters.size(); i++)
/* 170:    */       {
/* 171:265 */         Object in = this.parameters.get(i);
/* 172:266 */         SqlParameter declaredParameter = null;
/* 173:269 */         if ((in instanceof SqlParameterValue))
/* 174:    */         {
/* 175:270 */           SqlParameterValue paramValue = (SqlParameterValue)in;
/* 176:271 */           in = paramValue.getValue();
/* 177:272 */           declaredParameter = paramValue;
/* 178:    */         }
/* 179:    */         else
/* 180:    */         {
/* 181:275 */           if (PreparedStatementCreatorFactory.this.declaredParameters.size() <= i) {
/* 182:276 */             throw new InvalidDataAccessApiUsageException("SQL [" + PreparedStatementCreatorFactory.this.sql + "]: unable to access parameter number " + (i + 1) + " given only " + PreparedStatementCreatorFactory.this.declaredParameters.size() + " parameters");
/* 183:    */           }
/* 184:281 */           declaredParameter = (SqlParameter)PreparedStatementCreatorFactory.this.declaredParameters.get(i);
/* 185:    */         }
/* 186:283 */         if (((in instanceof Collection)) && (declaredParameter.getSqlType() != 2003))
/* 187:    */         {
/* 188:284 */           Collection entries = (Collection)in;
/* 189:285 */           for (Object entry : entries) {
/* 190:286 */             if ((entry instanceof Object[]))
/* 191:    */             {
/* 192:287 */               Object[] valueArray = (Object[])entry;
/* 193:288 */               for (Object argValue : valueArray) {
/* 194:289 */                 StatementCreatorUtils.setParameterValue(psToUse, sqlColIndx++, declaredParameter, argValue);
/* 195:    */               }
/* 196:    */             }
/* 197:    */             else
/* 198:    */             {
/* 199:293 */               StatementCreatorUtils.setParameterValue(psToUse, sqlColIndx++, declaredParameter, entry);
/* 200:    */             }
/* 201:    */           }
/* 202:    */         }
/* 203:    */         else
/* 204:    */         {
/* 205:298 */           StatementCreatorUtils.setParameterValue(psToUse, sqlColIndx++, declaredParameter, in);
/* 206:    */         }
/* 207:    */       }
/* 208:    */     }
/* 209:    */     
/* 210:    */     public String getSql()
/* 211:    */     {
/* 212:304 */       return PreparedStatementCreatorFactory.this.sql;
/* 213:    */     }
/* 214:    */     
/* 215:    */     public void cleanupParameters()
/* 216:    */     {
/* 217:308 */       StatementCreatorUtils.cleanupParameters(this.parameters);
/* 218:    */     }
/* 219:    */     
/* 220:    */     public String toString()
/* 221:    */     {
/* 222:313 */       StringBuilder sb = new StringBuilder();
/* 223:314 */       sb.append("PreparedStatementCreatorFactory.PreparedStatementCreatorImpl: sql=[");
/* 224:315 */       sb.append(PreparedStatementCreatorFactory.this.sql).append("]; parameters=").append(this.parameters);
/* 225:316 */       return sb.toString();
/* 226:    */     }
/* 227:    */   }
/* 228:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.core.PreparedStatementCreatorFactory
 * JD-Core Version:    0.7.0.1
 */