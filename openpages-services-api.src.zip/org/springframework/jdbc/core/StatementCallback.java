package org.springframework.jdbc.core;

import java.sql.SQLException;
import java.sql.Statement;
import org.springframework.dao.DataAccessException;

public abstract interface StatementCallback<T>
{
  public abstract T doInStatement(Statement paramStatement)
    throws SQLException, DataAccessException;
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.core.StatementCallback
 * JD-Core Version:    0.7.0.1
 */