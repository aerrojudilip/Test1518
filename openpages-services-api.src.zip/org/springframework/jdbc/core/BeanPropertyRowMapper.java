/*   1:    */ package org.springframework.jdbc.core;
/*   2:    */ 
/*   3:    */ import java.beans.PropertyDescriptor;
/*   4:    */ import java.sql.ResultSet;
/*   5:    */ import java.sql.ResultSetMetaData;
/*   6:    */ import java.sql.SQLException;
/*   7:    */ import java.util.HashMap;
/*   8:    */ import java.util.HashSet;
/*   9:    */ import java.util.Map;
/*  10:    */ import java.util.Set;
/*  11:    */ import org.apache.commons.logging.Log;
/*  12:    */ import org.apache.commons.logging.LogFactory;
/*  13:    */ import org.springframework.beans.BeanUtils;
/*  14:    */ import org.springframework.beans.BeanWrapper;
/*  15:    */ import org.springframework.beans.NotWritablePropertyException;
/*  16:    */ import org.springframework.beans.PropertyAccessorFactory;
/*  17:    */ import org.springframework.beans.TypeMismatchException;
/*  18:    */ import org.springframework.dao.DataRetrievalFailureException;
/*  19:    */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*  20:    */ import org.springframework.jdbc.support.JdbcUtils;
/*  21:    */ import org.springframework.util.Assert;
/*  22:    */ 
/*  23:    */ public class BeanPropertyRowMapper<T>
/*  24:    */   implements RowMapper<T>
/*  25:    */ {
/*  26: 74 */   protected final Log logger = LogFactory.getLog(getClass());
/*  27:    */   private Class<T> mappedClass;
/*  28: 80 */   private boolean checkFullyPopulated = false;
/*  29: 83 */   private boolean primitivesDefaultedForNullValue = false;
/*  30:    */   private Map<String, PropertyDescriptor> mappedFields;
/*  31:    */   private Set<String> mappedProperties;
/*  32:    */   
/*  33:    */   public BeanPropertyRowMapper() {}
/*  34:    */   
/*  35:    */   public BeanPropertyRowMapper(Class<T> mappedClass)
/*  36:    */   {
/*  37:108 */     initialize(mappedClass);
/*  38:    */   }
/*  39:    */   
/*  40:    */   public BeanPropertyRowMapper(Class<T> mappedClass, boolean checkFullyPopulated)
/*  41:    */   {
/*  42:118 */     initialize(mappedClass);
/*  43:119 */     this.checkFullyPopulated = checkFullyPopulated;
/*  44:    */   }
/*  45:    */   
/*  46:    */   public void setMappedClass(Class<T> mappedClass)
/*  47:    */   {
/*  48:127 */     if (this.mappedClass == null) {
/*  49:128 */       initialize(mappedClass);
/*  50:131 */     } else if (!this.mappedClass.equals(mappedClass)) {
/*  51:132 */       throw new InvalidDataAccessApiUsageException("The mapped class can not be reassigned to map to " + mappedClass + " since it is already providing mapping for " + this.mappedClass);
/*  52:    */     }
/*  53:    */   }
/*  54:    */   
/*  55:    */   protected void initialize(Class<T> mappedClass)
/*  56:    */   {
/*  57:143 */     this.mappedClass = mappedClass;
/*  58:144 */     this.mappedFields = new HashMap();
/*  59:145 */     this.mappedProperties = new HashSet();
/*  60:146 */     PropertyDescriptor[] pds = BeanUtils.getPropertyDescriptors(mappedClass);
/*  61:147 */     for (PropertyDescriptor pd : pds) {
/*  62:148 */       if (pd.getWriteMethod() != null)
/*  63:    */       {
/*  64:149 */         this.mappedFields.put(pd.getName().toLowerCase(), pd);
/*  65:150 */         String underscoredName = underscoreName(pd.getName());
/*  66:151 */         if (!pd.getName().toLowerCase().equals(underscoredName)) {
/*  67:152 */           this.mappedFields.put(underscoredName, pd);
/*  68:    */         }
/*  69:154 */         this.mappedProperties.add(pd.getName());
/*  70:    */       }
/*  71:    */     }
/*  72:    */   }
/*  73:    */   
/*  74:    */   private String underscoreName(String name)
/*  75:    */   {
/*  76:166 */     StringBuilder result = new StringBuilder();
/*  77:167 */     if ((name != null) && (name.length() > 0))
/*  78:    */     {
/*  79:168 */       result.append(name.substring(0, 1).toLowerCase());
/*  80:169 */       for (int i = 1; i < name.length(); i++)
/*  81:    */       {
/*  82:170 */         String s = name.substring(i, i + 1);
/*  83:171 */         if (s.equals(s.toUpperCase()))
/*  84:    */         {
/*  85:172 */           result.append("_");
/*  86:173 */           result.append(s.toLowerCase());
/*  87:    */         }
/*  88:    */         else
/*  89:    */         {
/*  90:176 */           result.append(s);
/*  91:    */         }
/*  92:    */       }
/*  93:    */     }
/*  94:180 */     return result.toString();
/*  95:    */   }
/*  96:    */   
/*  97:    */   public final Class<T> getMappedClass()
/*  98:    */   {
/*  99:187 */     return this.mappedClass;
/* 100:    */   }
/* 101:    */   
/* 102:    */   public void setCheckFullyPopulated(boolean checkFullyPopulated)
/* 103:    */   {
/* 104:197 */     this.checkFullyPopulated = checkFullyPopulated;
/* 105:    */   }
/* 106:    */   
/* 107:    */   public boolean isCheckFullyPopulated()
/* 108:    */   {
/* 109:205 */     return this.checkFullyPopulated;
/* 110:    */   }
/* 111:    */   
/* 112:    */   public void setPrimitivesDefaultedForNullValue(boolean primitivesDefaultedForNullValue)
/* 113:    */   {
/* 114:214 */     this.primitivesDefaultedForNullValue = primitivesDefaultedForNullValue;
/* 115:    */   }
/* 116:    */   
/* 117:    */   public boolean isPrimitivesDefaultedForNullValue()
/* 118:    */   {
/* 119:222 */     return this.primitivesDefaultedForNullValue;
/* 120:    */   }
/* 121:    */   
/* 122:    */   public T mapRow(ResultSet rs, int rowNumber)
/* 123:    */     throws SQLException
/* 124:    */   {
/* 125:232 */     Assert.state(this.mappedClass != null, "Mapped class was not specified");
/* 126:233 */     T mappedObject = BeanUtils.instantiate(this.mappedClass);
/* 127:234 */     BeanWrapper bw = PropertyAccessorFactory.forBeanPropertyAccess(mappedObject);
/* 128:235 */     initBeanWrapper(bw);
/* 129:    */     
/* 130:237 */     ResultSetMetaData rsmd = rs.getMetaData();
/* 131:238 */     int columnCount = rsmd.getColumnCount();
/* 132:239 */     Set<String> populatedProperties = isCheckFullyPopulated() ? new HashSet() : null;
/* 133:241 */     for (int index = 1; index <= columnCount; index++)
/* 134:    */     {
/* 135:242 */       String column = JdbcUtils.lookupColumnName(rsmd, index);
/* 136:243 */       PropertyDescriptor pd = (PropertyDescriptor)this.mappedFields.get(column.replaceAll(" ", "").toLowerCase());
/* 137:244 */       if (pd != null) {
/* 138:    */         try
/* 139:    */         {
/* 140:246 */           Object value = getColumnValue(rs, index, pd);
/* 141:247 */           if ((this.logger.isDebugEnabled()) && (rowNumber == 0)) {
/* 142:248 */             this.logger.debug("Mapping column '" + column + "' to property '" + pd.getName() + "' of type " + pd.getPropertyType());
/* 143:    */           }
/* 144:    */           try
/* 145:    */           {
/* 146:252 */             bw.setPropertyValue(pd.getName(), value);
/* 147:    */           }
/* 148:    */           catch (TypeMismatchException e)
/* 149:    */           {
/* 150:255 */             if ((value == null) && (this.primitivesDefaultedForNullValue)) {
/* 151:256 */               this.logger.debug("Intercepted TypeMismatchException for row " + rowNumber + " and column '" + column + "' with value " + value + " when setting property '" + pd.getName() + "' of type " + pd.getPropertyType() + " on object: " + mappedObject);
/* 152:    */             } else {
/* 153:262 */               throw e;
/* 154:    */             }
/* 155:    */           }
/* 156:265 */           if (populatedProperties != null) {
/* 157:266 */             populatedProperties.add(pd.getName());
/* 158:    */           }
/* 159:    */         }
/* 160:    */         catch (NotWritablePropertyException ex)
/* 161:    */         {
/* 162:270 */           throw new DataRetrievalFailureException("Unable to map column " + column + " to property " + pd.getName(), ex);
/* 163:    */         }
/* 164:    */       }
/* 165:    */     }
/* 166:276 */     if ((populatedProperties != null) && (!populatedProperties.equals(this.mappedProperties))) {
/* 167:277 */       throw new InvalidDataAccessApiUsageException("Given ResultSet does not contain all fields necessary to populate object of class [" + this.mappedClass + "]: " + this.mappedProperties);
/* 168:    */     }
/* 169:281 */     return mappedObject;
/* 170:    */   }
/* 171:    */   
/* 172:    */   protected void initBeanWrapper(BeanWrapper bw) {}
/* 173:    */   
/* 174:    */   protected Object getColumnValue(ResultSet rs, int index, PropertyDescriptor pd)
/* 175:    */     throws SQLException
/* 176:    */   {
/* 177:308 */     return JdbcUtils.getResultSetValue(rs, index, pd.getPropertyType());
/* 178:    */   }
/* 179:    */   
/* 180:    */   public static <T> BeanPropertyRowMapper<T> newInstance(Class<T> mappedClass)
/* 181:    */   {
/* 182:318 */     BeanPropertyRowMapper<T> newInstance = new BeanPropertyRowMapper();
/* 183:319 */     newInstance.setMappedClass(mappedClass);
/* 184:320 */     return newInstance;
/* 185:    */   }
/* 186:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.core.BeanPropertyRowMapper
 * JD-Core Version:    0.7.0.1
 */