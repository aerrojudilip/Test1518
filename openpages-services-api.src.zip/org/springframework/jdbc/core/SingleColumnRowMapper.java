/*   1:    */ package org.springframework.jdbc.core;
/*   2:    */ 
/*   3:    */ import java.sql.ResultSet;
/*   4:    */ import java.sql.ResultSetMetaData;
/*   5:    */ import java.sql.SQLException;
/*   6:    */ import org.springframework.dao.TypeMismatchDataAccessException;
/*   7:    */ import org.springframework.jdbc.IncorrectResultSetColumnCountException;
/*   8:    */ import org.springframework.jdbc.support.JdbcUtils;
/*   9:    */ import org.springframework.util.NumberUtils;
/*  10:    */ 
/*  11:    */ public class SingleColumnRowMapper<T>
/*  12:    */   implements RowMapper<T>
/*  13:    */ {
/*  14:    */   private Class<T> requiredType;
/*  15:    */   
/*  16:    */   public SingleColumnRowMapper() {}
/*  17:    */   
/*  18:    */   public SingleColumnRowMapper(Class<T> requiredType)
/*  19:    */   {
/*  20: 59 */     this.requiredType = requiredType;
/*  21:    */   }
/*  22:    */   
/*  23:    */   public void setRequiredType(Class<T> requiredType)
/*  24:    */   {
/*  25: 68 */     this.requiredType = requiredType;
/*  26:    */   }
/*  27:    */   
/*  28:    */   public T mapRow(ResultSet rs, int rowNum)
/*  29:    */     throws SQLException
/*  30:    */   {
/*  31: 84 */     ResultSetMetaData rsmd = rs.getMetaData();
/*  32: 85 */     int nrOfColumns = rsmd.getColumnCount();
/*  33: 86 */     if (nrOfColumns != 1) {
/*  34: 87 */       throw new IncorrectResultSetColumnCountException(1, nrOfColumns);
/*  35:    */     }
/*  36: 91 */     Object result = getColumnValue(rs, 1, this.requiredType);
/*  37: 92 */     if ((result != null) && (this.requiredType != null) && (!this.requiredType.isInstance(result))) {
/*  38:    */       try
/*  39:    */       {
/*  40: 95 */         return convertValueToRequiredType(result, this.requiredType);
/*  41:    */       }
/*  42:    */       catch (IllegalArgumentException ex)
/*  43:    */       {
/*  44: 98 */         throw new TypeMismatchDataAccessException("Type mismatch affecting row number " + rowNum + " and column type '" + rsmd.getColumnTypeName(1) + "': " + ex.getMessage());
/*  45:    */       }
/*  46:    */     }
/*  47:103 */     return result;
/*  48:    */   }
/*  49:    */   
/*  50:    */   protected Object getColumnValue(ResultSet rs, int index, Class requiredType)
/*  51:    */     throws SQLException
/*  52:    */   {
/*  53:124 */     if (requiredType != null) {
/*  54:125 */       return JdbcUtils.getResultSetValue(rs, index, requiredType);
/*  55:    */     }
/*  56:129 */     return getColumnValue(rs, index);
/*  57:    */   }
/*  58:    */   
/*  59:    */   protected Object getColumnValue(ResultSet rs, int index)
/*  60:    */     throws SQLException
/*  61:    */   {
/*  62:148 */     return JdbcUtils.getResultSetValue(rs, index);
/*  63:    */   }
/*  64:    */   
/*  65:    */   protected Object convertValueToRequiredType(Object value, Class requiredType)
/*  66:    */   {
/*  67:167 */     if (String.class.equals(requiredType)) {
/*  68:168 */       return value.toString();
/*  69:    */     }
/*  70:170 */     if (Number.class.isAssignableFrom(requiredType))
/*  71:    */     {
/*  72:171 */       if ((value instanceof Number)) {
/*  73:173 */         return NumberUtils.convertNumberToTargetClass((Number)value, requiredType);
/*  74:    */       }
/*  75:177 */       return NumberUtils.parseNumber(value.toString(), requiredType);
/*  76:    */     }
/*  77:181 */     throw new IllegalArgumentException("Value [" + value + "] is of type [" + value.getClass().getName() + "] and cannot be converted to required type [" + requiredType.getName() + "]");
/*  78:    */   }
/*  79:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.core.SingleColumnRowMapper
 * JD-Core Version:    0.7.0.1
 */