/*  1:   */ package org.springframework.jdbc.config;
/*  2:   */ 
/*  3:   */ import java.io.IOException;
/*  4:   */ import java.net.URL;
/*  5:   */ import java.util.ArrayList;
/*  6:   */ import java.util.Arrays;
/*  7:   */ import java.util.Collections;
/*  8:   */ import java.util.Comparator;
/*  9:   */ import java.util.List;
/* 10:   */ import org.springframework.beans.factory.config.AbstractFactoryBean;
/* 11:   */ import org.springframework.context.ResourceLoaderAware;
/* 12:   */ import org.springframework.core.io.Resource;
/* 13:   */ import org.springframework.core.io.ResourceLoader;
/* 14:   */ import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
/* 15:   */ import org.springframework.core.io.support.ResourcePatternResolver;
/* 16:   */ import org.springframework.core.io.support.ResourcePatternUtils;
/* 17:   */ 
/* 18:   */ public class SortedResourcesFactoryBean
/* 19:   */   extends AbstractFactoryBean<Resource[]>
/* 20:   */   implements ResourceLoaderAware
/* 21:   */ {
/* 22:   */   private final List<String> locations;
/* 23:   */   private ResourcePatternResolver resourcePatternResolver;
/* 24:   */   
/* 25:   */   public SortedResourcesFactoryBean(List<String> locations)
/* 26:   */   {
/* 27:52 */     this.locations = locations;
/* 28:53 */     this.resourcePatternResolver = new PathMatchingResourcePatternResolver();
/* 29:   */   }
/* 30:   */   
/* 31:   */   public SortedResourcesFactoryBean(ResourceLoader resourceLoader, List<String> locations)
/* 32:   */   {
/* 33:57 */     this.locations = locations;
/* 34:58 */     this.resourcePatternResolver = ResourcePatternUtils.getResourcePatternResolver(resourceLoader);
/* 35:   */   }
/* 36:   */   
/* 37:   */   public void setResourceLoader(ResourceLoader resourceLoader)
/* 38:   */   {
/* 39:63 */     this.resourcePatternResolver = ResourcePatternUtils.getResourcePatternResolver(resourceLoader);
/* 40:   */   }
/* 41:   */   
/* 42:   */   public Class<? extends Resource[]> getObjectType()
/* 43:   */   {
/* 44:69 */     return [Lorg.springframework.core.io.Resource.class;
/* 45:   */   }
/* 46:   */   
/* 47:   */   protected Resource[] createInstance()
/* 48:   */     throws Exception
/* 49:   */   {
/* 50:74 */     List<Resource> scripts = new ArrayList();
/* 51:75 */     for (String location : this.locations)
/* 52:   */     {
/* 53:76 */       List<Resource> resources = new ArrayList(Arrays.asList(this.resourcePatternResolver.getResources(location)));
/* 54:   */       
/* 55:78 */       Collections.sort(resources, new Comparator()
/* 56:   */       {
/* 57:   */         public int compare(Resource r1, Resource r2)
/* 58:   */         {
/* 59:   */           try
/* 60:   */           {
/* 61:81 */             return r1.getURL().toString().compareTo(r2.getURL().toString());
/* 62:   */           }
/* 63:   */           catch (IOException ex) {}
/* 64:84 */           return 0;
/* 65:   */         }
/* 66:   */       });
/* 67:88 */       for (Resource resource : resources) {
/* 68:89 */         scripts.add(resource);
/* 69:   */       }
/* 70:   */     }
/* 71:92 */     return (Resource[])scripts.toArray(new Resource[scripts.size()]);
/* 72:   */   }
/* 73:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.config.SortedResourcesFactoryBean
 * JD-Core Version:    0.7.0.1
 */