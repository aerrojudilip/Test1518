/*   1:    */ package org.springframework.jdbc.datasource.init;
/*   2:    */ 
/*   3:    */ import java.io.IOException;
/*   4:    */ import java.io.LineNumberReader;
/*   5:    */ import java.sql.Connection;
/*   6:    */ import java.sql.SQLException;
/*   7:    */ import java.sql.Statement;
/*   8:    */ import java.util.ArrayList;
/*   9:    */ import java.util.Arrays;
/*  10:    */ import java.util.LinkedList;
/*  11:    */ import java.util.List;
/*  12:    */ import org.apache.commons.logging.Log;
/*  13:    */ import org.apache.commons.logging.LogFactory;
/*  14:    */ import org.springframework.core.io.Resource;
/*  15:    */ import org.springframework.core.io.support.EncodedResource;
/*  16:    */ import org.springframework.util.StringUtils;
/*  17:    */ 
/*  18:    */ public class ResourceDatabasePopulator
/*  19:    */   implements DatabasePopulator
/*  20:    */ {
/*  21:    */   private static final String DEFAULT_COMMENT_PREFIX = "--";
/*  22:    */   private static final String DEFAULT_STATEMENT_SEPARATOR = ";";
/*  23: 56 */   private static final Log logger = LogFactory.getLog(ResourceDatabasePopulator.class);
/*  24: 59 */   private List<Resource> scripts = new ArrayList();
/*  25:    */   private String sqlScriptEncoding;
/*  26:    */   private String separator;
/*  27: 65 */   private String commentPrefix = "--";
/*  28: 67 */   private boolean continueOnError = false;
/*  29: 69 */   private boolean ignoreFailedDrops = false;
/*  30:    */   
/*  31:    */   public void addScript(Resource script)
/*  32:    */   {
/*  33: 77 */     this.scripts.add(script);
/*  34:    */   }
/*  35:    */   
/*  36:    */   public void setScripts(Resource[] scripts)
/*  37:    */   {
/*  38: 85 */     this.scripts = Arrays.asList(scripts);
/*  39:    */   }
/*  40:    */   
/*  41:    */   public void setSqlScriptEncoding(String sqlScriptEncoding)
/*  42:    */   {
/*  43: 95 */     this.sqlScriptEncoding = sqlScriptEncoding;
/*  44:    */   }
/*  45:    */   
/*  46:    */   public void setSeparator(String separator)
/*  47:    */   {
/*  48:102 */     this.separator = separator;
/*  49:    */   }
/*  50:    */   
/*  51:    */   public void setCommentPrefix(String commentPrefix)
/*  52:    */   {
/*  53:110 */     this.commentPrefix = commentPrefix;
/*  54:    */   }
/*  55:    */   
/*  56:    */   public void setContinueOnError(boolean continueOnError)
/*  57:    */   {
/*  58:118 */     this.continueOnError = continueOnError;
/*  59:    */   }
/*  60:    */   
/*  61:    */   public void setIgnoreFailedDrops(boolean ignoreFailedDrops)
/*  62:    */   {
/*  63:128 */     this.ignoreFailedDrops = ignoreFailedDrops;
/*  64:    */   }
/*  65:    */   
/*  66:    */   public void populate(Connection connection)
/*  67:    */     throws SQLException
/*  68:    */   {
/*  69:133 */     for (Resource script : this.scripts) {
/*  70:134 */       executeSqlScript(connection, applyEncodingIfNecessary(script), this.continueOnError, this.ignoreFailedDrops);
/*  71:    */     }
/*  72:    */   }
/*  73:    */   
/*  74:    */   private EncodedResource applyEncodingIfNecessary(Resource script)
/*  75:    */   {
/*  76:139 */     if ((script instanceof EncodedResource)) {
/*  77:140 */       return (EncodedResource)script;
/*  78:    */     }
/*  79:143 */     return new EncodedResource(script, this.sqlScriptEncoding);
/*  80:    */   }
/*  81:    */   
/*  82:    */   private void executeSqlScript(Connection connection, EncodedResource resource, boolean continueOnError, boolean ignoreFailedDrops)
/*  83:    */     throws SQLException
/*  84:    */   {
/*  85:160 */     if (logger.isInfoEnabled()) {
/*  86:161 */       logger.info("Executing SQL script from " + resource);
/*  87:    */     }
/*  88:163 */     long startTime = System.currentTimeMillis();
/*  89:164 */     List<String> statements = new LinkedList();
/*  90:    */     String script;
/*  91:    */     try
/*  92:    */     {
/*  93:167 */       script = readScript(resource);
/*  94:    */     }
/*  95:    */     catch (IOException ex)
/*  96:    */     {
/*  97:170 */       throw new CannotReadScriptException(resource, ex);
/*  98:    */     }
/*  99:172 */     String delimiter = this.separator;
/* 100:173 */     if (delimiter == null)
/* 101:    */     {
/* 102:174 */       delimiter = ";";
/* 103:175 */       if (!containsSqlScriptDelimiters(script, delimiter)) {
/* 104:176 */         delimiter = "\n";
/* 105:    */       }
/* 106:    */     }
/* 107:179 */     splitSqlScript(script, delimiter, this.commentPrefix, statements);
/* 108:180 */     int lineNumber = 0;
/* 109:181 */     Statement stmt = connection.createStatement();
/* 110:    */     try
/* 111:    */     {
/* 112:183 */       for (String statement : statements)
/* 113:    */       {
/* 114:184 */         lineNumber++;
/* 115:    */         try
/* 116:    */         {
/* 117:186 */           stmt.execute(statement);
/* 118:187 */           int rowsAffected = stmt.getUpdateCount();
/* 119:188 */           if (logger.isDebugEnabled()) {
/* 120:189 */             logger.debug(rowsAffected + " returned as updateCount for SQL: " + statement);
/* 121:    */           }
/* 122:    */         }
/* 123:    */         catch (SQLException ex)
/* 124:    */         {
/* 125:193 */           boolean dropStatement = StringUtils.startsWithIgnoreCase(statement.trim(), "drop");
/* 126:194 */           if ((continueOnError) || ((dropStatement) && (ignoreFailedDrops)))
/* 127:    */           {
/* 128:195 */             if (logger.isDebugEnabled()) {
/* 129:196 */               logger.debug("Failed to execute SQL script statement at line " + lineNumber + " of resource " + resource + ": " + statement, ex);
/* 130:    */             }
/* 131:    */           }
/* 132:    */           else {
/* 133:201 */             throw new ScriptStatementFailedException(statement, lineNumber, resource, ex);
/* 134:    */           }
/* 135:    */         }
/* 136:    */       }
/* 137:    */       try
/* 138:    */       {
/* 139:208 */         stmt.close();
/* 140:    */       }
/* 141:    */       catch (Throwable ex)
/* 142:    */       {
/* 143:211 */         logger.debug("Could not close JDBC Statement", ex);
/* 144:    */       }
/* 145:214 */       elapsedTime = System.currentTimeMillis() - startTime;
/* 146:    */     }
/* 147:    */     finally
/* 148:    */     {
/* 149:    */       try
/* 150:    */       {
/* 151:208 */         stmt.close();
/* 152:    */       }
/* 153:    */       catch (Throwable ex)
/* 154:    */       {
/* 155:211 */         logger.debug("Could not close JDBC Statement", ex);
/* 156:    */       }
/* 157:    */     }
/* 158:    */     long elapsedTime;
/* 159:215 */     if (logger.isInfoEnabled()) {
/* 160:216 */       logger.info("Done executing SQL script from " + resource + " in " + elapsedTime + " ms.");
/* 161:    */     }
/* 162:    */   }
/* 163:    */   
/* 164:    */   private String readScript(EncodedResource resource)
/* 165:    */     throws IOException
/* 166:    */   {
/* 167:227 */     LineNumberReader lnr = new LineNumberReader(resource.getReader());
/* 168:    */     try
/* 169:    */     {
/* 170:229 */       String currentStatement = lnr.readLine();
/* 171:230 */       StringBuilder scriptBuilder = new StringBuilder();
/* 172:231 */       while (currentStatement != null)
/* 173:    */       {
/* 174:232 */         if ((StringUtils.hasText(currentStatement)) && (this.commentPrefix != null) && (!currentStatement.startsWith(this.commentPrefix)))
/* 175:    */         {
/* 176:234 */           if (scriptBuilder.length() > 0) {
/* 177:235 */             scriptBuilder.append('\n');
/* 178:    */           }
/* 179:237 */           scriptBuilder.append(currentStatement);
/* 180:    */         }
/* 181:239 */         currentStatement = lnr.readLine();
/* 182:    */       }
/* 183:241 */       maybeAddSeparatorToScript(scriptBuilder);
/* 184:242 */       return scriptBuilder.toString();
/* 185:    */     }
/* 186:    */     finally
/* 187:    */     {
/* 188:245 */       lnr.close();
/* 189:    */     }
/* 190:    */   }
/* 191:    */   
/* 192:    */   private void maybeAddSeparatorToScript(StringBuilder scriptBuilder)
/* 193:    */   {
/* 194:250 */     if (this.separator == null) {
/* 195:251 */       return;
/* 196:    */     }
/* 197:253 */     String trimmed = this.separator.trim();
/* 198:254 */     if (trimmed.length() == this.separator.length()) {
/* 199:255 */       return;
/* 200:    */     }
/* 201:259 */     if (scriptBuilder.lastIndexOf(trimmed) == scriptBuilder.length() - trimmed.length()) {
/* 202:260 */       scriptBuilder.append(this.separator.substring(trimmed.length()));
/* 203:    */     }
/* 204:    */   }
/* 205:    */   
/* 206:    */   private boolean containsSqlScriptDelimiters(String script, String delim)
/* 207:    */   {
/* 208:270 */     boolean inLiteral = false;
/* 209:271 */     char[] content = script.toCharArray();
/* 210:272 */     for (int i = 0; i < script.length(); i++)
/* 211:    */     {
/* 212:273 */       if (content[i] == '\'') {
/* 213:274 */         inLiteral = !inLiteral;
/* 214:    */       }
/* 215:276 */       if ((!inLiteral) && (script.startsWith(delim, i))) {
/* 216:277 */         return true;
/* 217:    */       }
/* 218:    */     }
/* 219:280 */     return false;
/* 220:    */   }
/* 221:    */   
/* 222:    */   private void splitSqlScript(String script, String delim, String commentPrefix, List<String> statements)
/* 223:    */   {
/* 224:296 */     StringBuilder sb = new StringBuilder();
/* 225:297 */     boolean inLiteral = false;
/* 226:298 */     boolean inEscape = false;
/* 227:299 */     char[] content = script.toCharArray();
/* 228:300 */     for (int i = 0; i < script.length(); i++)
/* 229:    */     {
/* 230:301 */       char c = content[i];
/* 231:302 */       if (inEscape)
/* 232:    */       {
/* 233:303 */         inEscape = false;
/* 234:304 */         sb.append(c);
/* 235:    */       }
/* 236:308 */       else if (c == '\\')
/* 237:    */       {
/* 238:309 */         inEscape = true;
/* 239:310 */         sb.append(c);
/* 240:    */       }
/* 241:    */       else
/* 242:    */       {
/* 243:313 */         if (c == '\'') {
/* 244:314 */           inLiteral = !inLiteral;
/* 245:    */         }
/* 246:316 */         if (!inLiteral)
/* 247:    */         {
/* 248:317 */           if (script.startsWith(delim, i))
/* 249:    */           {
/* 250:319 */             if (sb.length() > 0)
/* 251:    */             {
/* 252:320 */               statements.add(sb.toString());
/* 253:321 */               sb = new StringBuilder();
/* 254:    */             }
/* 255:323 */             i += delim.length() - 1;
/* 256:324 */             continue;
/* 257:    */           }
/* 258:326 */           if (script.startsWith(commentPrefix, i))
/* 259:    */           {
/* 260:328 */             int indexOfNextNewline = script.indexOf("\n", i);
/* 261:329 */             if (indexOfNextNewline <= i) {
/* 262:    */               break;
/* 263:    */             }
/* 264:330 */             i = indexOfNextNewline;
/* 265:331 */             continue;
/* 266:    */           }
/* 267:339 */           if ((c == ' ') || (c == '\n') || (c == '\t'))
/* 268:    */           {
/* 269:341 */             if ((sb.length() <= 0) || (sb.charAt(sb.length() - 1) == ' ')) {
/* 270:    */               continue;
/* 271:    */             }
/* 272:342 */             c = ' ';
/* 273:    */           }
/* 274:    */         }
/* 275:349 */         sb.append(c);
/* 276:    */       }
/* 277:    */     }
/* 278:351 */     if (StringUtils.hasText(sb)) {
/* 279:352 */       statements.add(sb.toString());
/* 280:    */     }
/* 281:    */   }
/* 282:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.datasource.init.ResourceDatabasePopulator
 * JD-Core Version:    0.7.0.1
 */