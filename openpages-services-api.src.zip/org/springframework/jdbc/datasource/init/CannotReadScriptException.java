/*  1:   */ package org.springframework.jdbc.datasource.init;
/*  2:   */ 
/*  3:   */ import org.springframework.core.io.support.EncodedResource;
/*  4:   */ 
/*  5:   */ public class CannotReadScriptException
/*  6:   */   extends RuntimeException
/*  7:   */ {
/*  8:   */   public CannotReadScriptException(EncodedResource resource, Throwable cause)
/*  9:   */   {
/* 10:37 */     super("Cannot read SQL script from " + resource, cause);
/* 11:   */   }
/* 12:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.datasource.init.CannotReadScriptException
 * JD-Core Version:    0.7.0.1
 */