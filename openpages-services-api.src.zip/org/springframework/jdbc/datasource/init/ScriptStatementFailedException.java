/*  1:   */ package org.springframework.jdbc.datasource.init;
/*  2:   */ 
/*  3:   */ import org.springframework.core.io.support.EncodedResource;
/*  4:   */ 
/*  5:   */ public class ScriptStatementFailedException
/*  6:   */   extends RuntimeException
/*  7:   */ {
/*  8:   */   public ScriptStatementFailedException(String statement, int lineNumber, EncodedResource resource, Throwable cause)
/*  9:   */   {
/* 10:40 */     super("Failed to execute SQL script statement at line " + lineNumber + " of resource " + resource + ": " + statement, cause);
/* 11:   */   }
/* 12:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.datasource.init.ScriptStatementFailedException
 * JD-Core Version:    0.7.0.1
 */