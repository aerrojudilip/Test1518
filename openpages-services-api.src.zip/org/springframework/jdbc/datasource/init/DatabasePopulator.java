package org.springframework.jdbc.datasource.init;

import java.sql.Connection;
import java.sql.SQLException;

public abstract interface DatabasePopulator
{
  public abstract void populate(Connection paramConnection)
    throws SQLException;
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.datasource.init.DatabasePopulator
 * JD-Core Version:    0.7.0.1
 */