/*  1:   */ package org.springframework.jdbc.datasource.init;
/*  2:   */ 
/*  3:   */ import java.sql.Connection;
/*  4:   */ import java.sql.SQLException;
/*  5:   */ import java.util.ArrayList;
/*  6:   */ import java.util.Arrays;
/*  7:   */ import java.util.List;
/*  8:   */ 
/*  9:   */ public class CompositeDatabasePopulator
/* 10:   */   implements DatabasePopulator
/* 11:   */ {
/* 12:34 */   private List<DatabasePopulator> populators = new ArrayList();
/* 13:   */   
/* 14:   */   public void setPopulators(DatabasePopulator... populators)
/* 15:   */   {
/* 16:41 */     this.populators.clear();
/* 17:42 */     this.populators.addAll(Arrays.asList(populators));
/* 18:   */   }
/* 19:   */   
/* 20:   */   public void addPopulators(DatabasePopulator... populators)
/* 21:   */   {
/* 22:49 */     this.populators.addAll(Arrays.asList(populators));
/* 23:   */   }
/* 24:   */   
/* 25:   */   public void populate(Connection connection)
/* 26:   */     throws SQLException
/* 27:   */   {
/* 28:54 */     for (DatabasePopulator populator : this.populators) {
/* 29:55 */       populator.populate(connection);
/* 30:   */     }
/* 31:   */   }
/* 32:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.datasource.init.CompositeDatabasePopulator
 * JD-Core Version:    0.7.0.1
 */