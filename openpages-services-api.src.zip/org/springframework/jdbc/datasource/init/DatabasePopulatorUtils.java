/*  1:   */ package org.springframework.jdbc.datasource.init;
/*  2:   */ 
/*  3:   */ import java.sql.Connection;
/*  4:   */ import javax.sql.DataSource;
/*  5:   */ import org.springframework.dao.DataAccessResourceFailureException;
/*  6:   */ import org.springframework.jdbc.datasource.DataSourceUtils;
/*  7:   */ import org.springframework.util.Assert;
/*  8:   */ 
/*  9:   */ public abstract class DatabasePopulatorUtils
/* 10:   */ {
/* 11:   */   public static void execute(DatabasePopulator populator, DataSource dataSource)
/* 12:   */   {
/* 13:42 */     Assert.notNull(populator, "DatabasePopulator must be provided");
/* 14:43 */     Assert.notNull(dataSource, "DataSource must be provided");
/* 15:   */     try
/* 16:   */     {
/* 17:45 */       Connection connection = DataSourceUtils.getConnection(dataSource);
/* 18:   */       try
/* 19:   */       {
/* 20:47 */         populator.populate(connection);
/* 21:   */       }
/* 22:   */       finally
/* 23:   */       {
/* 24:50 */         if (connection != null) {
/* 25:51 */           DataSourceUtils.releaseConnection(connection, dataSource);
/* 26:   */         }
/* 27:   */       }
/* 28:   */     }
/* 29:   */     catch (Exception ex)
/* 30:   */     {
/* 31:56 */       throw new DataAccessResourceFailureException("Failed to execute database script", ex);
/* 32:   */     }
/* 33:   */   }
/* 34:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.datasource.init.DatabasePopulatorUtils
 * JD-Core Version:    0.7.0.1
 */