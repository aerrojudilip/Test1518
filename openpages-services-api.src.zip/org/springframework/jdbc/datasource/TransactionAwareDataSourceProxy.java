/*   1:    */ package org.springframework.jdbc.datasource;
/*   2:    */ 
/*   3:    */ import java.lang.reflect.InvocationHandler;
/*   4:    */ import java.lang.reflect.InvocationTargetException;
/*   5:    */ import java.lang.reflect.Method;
/*   6:    */ import java.lang.reflect.Proxy;
/*   7:    */ import java.sql.Connection;
/*   8:    */ import java.sql.SQLException;
/*   9:    */ import java.sql.Statement;
/*  10:    */ import javax.sql.DataSource;
/*  11:    */ import org.springframework.transaction.support.TransactionSynchronizationManager;
/*  12:    */ import org.springframework.util.Assert;
/*  13:    */ 
/*  14:    */ public class TransactionAwareDataSourceProxy
/*  15:    */   extends DelegatingDataSource
/*  16:    */ {
/*  17: 82 */   private boolean reobtainTransactionalConnections = false;
/*  18:    */   
/*  19:    */   public TransactionAwareDataSourceProxy() {}
/*  20:    */   
/*  21:    */   public TransactionAwareDataSourceProxy(DataSource targetDataSource)
/*  22:    */   {
/*  23: 97 */     super(targetDataSource);
/*  24:    */   }
/*  25:    */   
/*  26:    */   public void setReobtainTransactionalConnections(boolean reobtainTransactionalConnections)
/*  27:    */   {
/*  28:110 */     this.reobtainTransactionalConnections = reobtainTransactionalConnections;
/*  29:    */   }
/*  30:    */   
/*  31:    */   public Connection getConnection()
/*  32:    */     throws SQLException
/*  33:    */   {
/*  34:125 */     DataSource ds = getTargetDataSource();
/*  35:126 */     Assert.state(ds != null, "'targetDataSource' is required");
/*  36:127 */     return getTransactionAwareConnectionProxy(ds);
/*  37:    */   }
/*  38:    */   
/*  39:    */   protected Connection getTransactionAwareConnectionProxy(DataSource targetDataSource)
/*  40:    */   {
/*  41:139 */     return (Connection)Proxy.newProxyInstance(ConnectionProxy.class.getClassLoader(), new Class[] { ConnectionProxy.class }, new TransactionAwareInvocationHandler(targetDataSource));
/*  42:    */   }
/*  43:    */   
/*  44:    */   protected boolean shouldObtainFixedConnection(DataSource targetDataSource)
/*  45:    */   {
/*  46:156 */     return (!TransactionSynchronizationManager.isSynchronizationActive()) || (!this.reobtainTransactionalConnections);
/*  47:    */   }
/*  48:    */   
/*  49:    */   private class TransactionAwareInvocationHandler
/*  50:    */     implements InvocationHandler
/*  51:    */   {
/*  52:    */     private final DataSource targetDataSource;
/*  53:    */     private Connection target;
/*  54:171 */     private boolean closed = false;
/*  55:    */     
/*  56:    */     public TransactionAwareInvocationHandler(DataSource targetDataSource)
/*  57:    */     {
/*  58:174 */       this.targetDataSource = targetDataSource;
/*  59:    */     }
/*  60:    */     
/*  61:    */     public Object invoke(Object proxy, Method method, Object[] args)
/*  62:    */       throws Throwable
/*  63:    */     {
/*  64:180 */       if (method.getName().equals("equals")) {
/*  65:182 */         return Boolean.valueOf(proxy == args[0]);
/*  66:    */       }
/*  67:184 */       if (method.getName().equals("hashCode")) {
/*  68:186 */         return Integer.valueOf(System.identityHashCode(proxy));
/*  69:    */       }
/*  70:188 */       if (method.getName().equals("toString"))
/*  71:    */       {
/*  72:190 */         StringBuilder sb = new StringBuilder("Transaction-aware proxy for target Connection ");
/*  73:191 */         if (this.target != null) {
/*  74:192 */           sb.append("[").append(this.target.toString()).append("]");
/*  75:    */         } else {
/*  76:195 */           sb.append(" from DataSource [").append(this.targetDataSource).append("]");
/*  77:    */         }
/*  78:197 */         return sb.toString();
/*  79:    */       }
/*  80:199 */       if (method.getName().equals("unwrap"))
/*  81:    */       {
/*  82:200 */         if (((Class)args[0]).isInstance(proxy)) {
/*  83:201 */           return proxy;
/*  84:    */         }
/*  85:    */       }
/*  86:204 */       else if (method.getName().equals("isWrapperFor"))
/*  87:    */       {
/*  88:205 */         if (((Class)args[0]).isInstance(proxy)) {
/*  89:206 */           return Boolean.valueOf(true);
/*  90:    */         }
/*  91:    */       }
/*  92:    */       else
/*  93:    */       {
/*  94:209 */         if (method.getName().equals("close"))
/*  95:    */         {
/*  96:211 */           DataSourceUtils.doReleaseConnection(this.target, this.targetDataSource);
/*  97:212 */           this.closed = true;
/*  98:213 */           return null;
/*  99:    */         }
/* 100:215 */         if (method.getName().equals("isClosed")) {
/* 101:216 */           return Boolean.valueOf(this.closed);
/* 102:    */         }
/* 103:    */       }
/* 104:219 */       if (this.target == null)
/* 105:    */       {
/* 106:220 */         if (this.closed) {
/* 107:221 */           throw new SQLException("Connection handle already closed");
/* 108:    */         }
/* 109:223 */         if (TransactionAwareDataSourceProxy.this.shouldObtainFixedConnection(this.targetDataSource)) {
/* 110:224 */           this.target = DataSourceUtils.doGetConnection(this.targetDataSource);
/* 111:    */         }
/* 112:    */       }
/* 113:227 */       Connection actualTarget = this.target;
/* 114:228 */       if (actualTarget == null) {
/* 115:229 */         actualTarget = DataSourceUtils.doGetConnection(this.targetDataSource);
/* 116:    */       }
/* 117:232 */       if (method.getName().equals("getTargetConnection")) {
/* 118:234 */         return actualTarget;
/* 119:    */       }
/* 120:    */       try
/* 121:    */       {
/* 122:239 */         Object retVal = method.invoke(actualTarget, args);
/* 123:243 */         if ((retVal instanceof Statement)) {
/* 124:244 */           DataSourceUtils.applyTransactionTimeout((Statement)retVal, this.targetDataSource);
/* 125:    */         }
/* 126:247 */         return retVal;
/* 127:    */       }
/* 128:    */       catch (InvocationTargetException ex)
/* 129:    */       {
/* 130:250 */         throw ex.getTargetException();
/* 131:    */       }
/* 132:    */       finally
/* 133:    */       {
/* 134:253 */         if (actualTarget != this.target) {
/* 135:254 */           DataSourceUtils.doReleaseConnection(actualTarget, this.targetDataSource);
/* 136:    */         }
/* 137:    */       }
/* 138:    */     }
/* 139:    */   }
/* 140:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.datasource.TransactionAwareDataSourceProxy
 * JD-Core Version:    0.7.0.1
 */