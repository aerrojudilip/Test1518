/*   1:    */ package org.springframework.jdbc.datasource;
/*   2:    */ 
/*   3:    */ import java.lang.reflect.InvocationHandler;
/*   4:    */ import java.lang.reflect.InvocationTargetException;
/*   5:    */ import java.lang.reflect.Method;
/*   6:    */ import java.lang.reflect.Proxy;
/*   7:    */ import java.sql.Connection;
/*   8:    */ import java.sql.SQLException;
/*   9:    */ import org.apache.commons.logging.Log;
/*  10:    */ import org.springframework.beans.factory.DisposableBean;
/*  11:    */ import org.springframework.util.Assert;
/*  12:    */ import org.springframework.util.ObjectUtils;
/*  13:    */ 
/*  14:    */ public class SingleConnectionDataSource
/*  15:    */   extends DriverManagerDataSource
/*  16:    */   implements SmartDataSource, DisposableBean
/*  17:    */ {
/*  18:    */   private boolean suppressClose;
/*  19:    */   private Boolean autoCommit;
/*  20:    */   private Connection target;
/*  21:    */   private Connection connection;
/*  22: 74 */   private final Object connectionMonitor = new Object();
/*  23:    */   
/*  24:    */   public SingleConnectionDataSource() {}
/*  25:    */   
/*  26:    */   @Deprecated
/*  27:    */   public SingleConnectionDataSource(String driverClassName, String url, String username, String password, boolean suppressClose)
/*  28:    */   {
/*  29:101 */     super(driverClassName, url, username, password);
/*  30:102 */     this.suppressClose = suppressClose;
/*  31:    */   }
/*  32:    */   
/*  33:    */   public SingleConnectionDataSource(String url, String username, String password, boolean suppressClose)
/*  34:    */   {
/*  35:116 */     super(url, username, password);
/*  36:117 */     this.suppressClose = suppressClose;
/*  37:    */   }
/*  38:    */   
/*  39:    */   public SingleConnectionDataSource(String url, boolean suppressClose)
/*  40:    */   {
/*  41:129 */     super(url);
/*  42:130 */     this.suppressClose = suppressClose;
/*  43:    */   }
/*  44:    */   
/*  45:    */   public SingleConnectionDataSource(Connection target, boolean suppressClose)
/*  46:    */   {
/*  47:142 */     Assert.notNull(target, "Connection must not be null");
/*  48:143 */     this.target = target;
/*  49:144 */     this.suppressClose = suppressClose;
/*  50:145 */     this.connection = (suppressClose ? getCloseSuppressingConnectionProxy(target) : target);
/*  51:    */   }
/*  52:    */   
/*  53:    */   public void setSuppressClose(boolean suppressClose)
/*  54:    */   {
/*  55:154 */     this.suppressClose = suppressClose;
/*  56:    */   }
/*  57:    */   
/*  58:    */   protected boolean isSuppressClose()
/*  59:    */   {
/*  60:162 */     return this.suppressClose;
/*  61:    */   }
/*  62:    */   
/*  63:    */   public void setAutoCommit(boolean autoCommit)
/*  64:    */   {
/*  65:169 */     this.autoCommit = Boolean.valueOf(autoCommit);
/*  66:    */   }
/*  67:    */   
/*  68:    */   protected Boolean getAutoCommitValue()
/*  69:    */   {
/*  70:177 */     return this.autoCommit;
/*  71:    */   }
/*  72:    */   
/*  73:    */   public Connection getConnection()
/*  74:    */     throws SQLException
/*  75:    */   {
/*  76:183 */     synchronized (this.connectionMonitor)
/*  77:    */     {
/*  78:184 */       if (this.connection == null) {
/*  79:186 */         initConnection();
/*  80:    */       }
/*  81:188 */       if (this.connection.isClosed()) {
/*  82:189 */         throw new SQLException("Connection was closed in SingleConnectionDataSource. Check that user code checks shouldClose() before closing Connections, or set 'suppressClose' to 'true'");
/*  83:    */       }
/*  84:193 */       return this.connection;
/*  85:    */     }
/*  86:    */   }
/*  87:    */   
/*  88:    */   public Connection getConnection(String username, String password)
/*  89:    */     throws SQLException
/*  90:    */   {
/*  91:204 */     if ((ObjectUtils.nullSafeEquals(username, getUsername())) && (ObjectUtils.nullSafeEquals(password, getPassword()))) {
/*  92:206 */       return getConnection();
/*  93:    */     }
/*  94:209 */     throw new SQLException("SingleConnectionDataSource does not support custom username and password");
/*  95:    */   }
/*  96:    */   
/*  97:    */   public boolean shouldClose(Connection con)
/*  98:    */   {
/*  99:217 */     synchronized (this.connectionMonitor)
/* 100:    */     {
/* 101:218 */       return (con != this.connection) && (con != this.target);
/* 102:    */     }
/* 103:    */   }
/* 104:    */   
/* 105:    */   public void destroy()
/* 106:    */   {
/* 107:229 */     synchronized (this.connectionMonitor)
/* 108:    */     {
/* 109:230 */       closeConnection();
/* 110:    */     }
/* 111:    */   }
/* 112:    */   
/* 113:    */   public void initConnection()
/* 114:    */     throws SQLException
/* 115:    */   {
/* 116:239 */     if (getUrl() == null) {
/* 117:240 */       throw new IllegalStateException("'url' property is required for lazily initializing a Connection");
/* 118:    */     }
/* 119:242 */     synchronized (this.connectionMonitor)
/* 120:    */     {
/* 121:243 */       closeConnection();
/* 122:244 */       this.target = getConnectionFromDriver(getUsername(), getPassword());
/* 123:245 */       prepareConnection(this.target);
/* 124:246 */       if (this.logger.isInfoEnabled()) {
/* 125:247 */         this.logger.info("Established shared JDBC Connection: " + this.target);
/* 126:    */       }
/* 127:249 */       this.connection = (isSuppressClose() ? getCloseSuppressingConnectionProxy(this.target) : this.target);
/* 128:    */     }
/* 129:    */   }
/* 130:    */   
/* 131:    */   public void resetConnection()
/* 132:    */   {
/* 133:257 */     synchronized (this.connectionMonitor)
/* 134:    */     {
/* 135:258 */       closeConnection();
/* 136:259 */       this.target = null;
/* 137:260 */       this.connection = null;
/* 138:    */     }
/* 139:    */   }
/* 140:    */   
/* 141:    */   protected void prepareConnection(Connection con)
/* 142:    */     throws SQLException
/* 143:    */   {
/* 144:272 */     Boolean autoCommit = getAutoCommitValue();
/* 145:273 */     if ((autoCommit != null) && (con.getAutoCommit() != autoCommit.booleanValue())) {
/* 146:274 */       con.setAutoCommit(autoCommit.booleanValue());
/* 147:    */     }
/* 148:    */   }
/* 149:    */   
/* 150:    */   private void closeConnection()
/* 151:    */   {
/* 152:282 */     if (this.target != null) {
/* 153:    */       try
/* 154:    */       {
/* 155:284 */         this.target.close();
/* 156:    */       }
/* 157:    */       catch (Throwable ex)
/* 158:    */       {
/* 159:287 */         this.logger.warn("Could not close shared JDBC Connection", ex);
/* 160:    */       }
/* 161:    */     }
/* 162:    */   }
/* 163:    */   
/* 164:    */   protected Connection getCloseSuppressingConnectionProxy(Connection target)
/* 165:    */   {
/* 166:299 */     return (Connection)Proxy.newProxyInstance(ConnectionProxy.class.getClassLoader(), new Class[] { ConnectionProxy.class }, new CloseSuppressingInvocationHandler(target));
/* 167:    */   }
/* 168:    */   
/* 169:    */   private static class CloseSuppressingInvocationHandler
/* 170:    */     implements InvocationHandler
/* 171:    */   {
/* 172:    */     private final Connection target;
/* 173:    */     
/* 174:    */     public CloseSuppressingInvocationHandler(Connection target)
/* 175:    */     {
/* 176:314 */       this.target = target;
/* 177:    */     }
/* 178:    */     
/* 179:    */     public Object invoke(Object proxy, Method method, Object[] args)
/* 180:    */       throws Throwable
/* 181:    */     {
/* 182:320 */       if (method.getName().equals("equals")) {
/* 183:322 */         return Boolean.valueOf(proxy == args[0]);
/* 184:    */       }
/* 185:324 */       if (method.getName().equals("hashCode")) {
/* 186:326 */         return Integer.valueOf(System.identityHashCode(proxy));
/* 187:    */       }
/* 188:328 */       if (method.getName().equals("unwrap"))
/* 189:    */       {
/* 190:329 */         if (((Class)args[0]).isInstance(proxy)) {
/* 191:330 */           return proxy;
/* 192:    */         }
/* 193:    */       }
/* 194:333 */       else if (method.getName().equals("isWrapperFor"))
/* 195:    */       {
/* 196:334 */         if (((Class)args[0]).isInstance(proxy)) {
/* 197:335 */           return Boolean.valueOf(true);
/* 198:    */         }
/* 199:    */       }
/* 200:    */       else
/* 201:    */       {
/* 202:338 */         if (method.getName().equals("close")) {
/* 203:340 */           return null;
/* 204:    */         }
/* 205:342 */         if (method.getName().equals("isClosed")) {
/* 206:343 */           return Boolean.valueOf(false);
/* 207:    */         }
/* 208:345 */         if (method.getName().equals("getTargetConnection")) {
/* 209:347 */           return this.target;
/* 210:    */         }
/* 211:    */       }
/* 212:    */       try
/* 213:    */       {
/* 214:352 */         return method.invoke(this.target, args);
/* 215:    */       }
/* 216:    */       catch (InvocationTargetException ex)
/* 217:    */       {
/* 218:355 */         throw ex.getTargetException();
/* 219:    */       }
/* 220:    */     }
/* 221:    */   }
/* 222:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.datasource.SingleConnectionDataSource
 * JD-Core Version:    0.7.0.1
 */