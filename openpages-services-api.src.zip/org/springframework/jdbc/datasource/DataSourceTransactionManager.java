/*   1:    */ package org.springframework.jdbc.datasource;
/*   2:    */ 
/*   3:    */ import java.sql.Connection;
/*   4:    */ import java.sql.SQLException;
/*   5:    */ import javax.sql.DataSource;
/*   6:    */ import org.apache.commons.logging.Log;
/*   7:    */ import org.springframework.beans.factory.InitializingBean;
/*   8:    */ import org.springframework.transaction.CannotCreateTransactionException;
/*   9:    */ import org.springframework.transaction.TransactionDefinition;
/*  10:    */ import org.springframework.transaction.TransactionSystemException;
/*  11:    */ import org.springframework.transaction.support.AbstractPlatformTransactionManager;
/*  12:    */ import org.springframework.transaction.support.DefaultTransactionStatus;
/*  13:    */ import org.springframework.transaction.support.ResourceTransactionManager;
/*  14:    */ import org.springframework.transaction.support.TransactionSynchronizationManager;
/*  15:    */ 
/*  16:    */ public class DataSourceTransactionManager
/*  17:    */   extends AbstractPlatformTransactionManager
/*  18:    */   implements ResourceTransactionManager, InitializingBean
/*  19:    */ {
/*  20:    */   private DataSource dataSource;
/*  21:    */   
/*  22:    */   public DataSourceTransactionManager()
/*  23:    */   {
/*  24:114 */     setNestedTransactionAllowed(true);
/*  25:    */   }
/*  26:    */   
/*  27:    */   public DataSourceTransactionManager(DataSource dataSource)
/*  28:    */   {
/*  29:122 */     this();
/*  30:123 */     setDataSource(dataSource);
/*  31:124 */     afterPropertiesSet();
/*  32:    */   }
/*  33:    */   
/*  34:    */   public void setDataSource(DataSource dataSource)
/*  35:    */   {
/*  36:146 */     if ((dataSource instanceof TransactionAwareDataSourceProxy)) {
/*  37:150 */       this.dataSource = ((TransactionAwareDataSourceProxy)dataSource).getTargetDataSource();
/*  38:    */     } else {
/*  39:153 */       this.dataSource = dataSource;
/*  40:    */     }
/*  41:    */   }
/*  42:    */   
/*  43:    */   public DataSource getDataSource()
/*  44:    */   {
/*  45:161 */     return this.dataSource;
/*  46:    */   }
/*  47:    */   
/*  48:    */   public void afterPropertiesSet()
/*  49:    */   {
/*  50:165 */     if (getDataSource() == null) {
/*  51:166 */       throw new IllegalArgumentException("Property 'dataSource' is required");
/*  52:    */     }
/*  53:    */   }
/*  54:    */   
/*  55:    */   public Object getResourceFactory()
/*  56:    */   {
/*  57:172 */     return getDataSource();
/*  58:    */   }
/*  59:    */   
/*  60:    */   protected Object doGetTransaction()
/*  61:    */   {
/*  62:177 */     DataSourceTransactionObject txObject = new DataSourceTransactionObject(null);
/*  63:178 */     txObject.setSavepointAllowed(isNestedTransactionAllowed());
/*  64:179 */     ConnectionHolder conHolder = (ConnectionHolder)TransactionSynchronizationManager.getResource(this.dataSource);
/*  65:    */     
/*  66:181 */     txObject.setConnectionHolder(conHolder, false);
/*  67:182 */     return txObject;
/*  68:    */   }
/*  69:    */   
/*  70:    */   protected boolean isExistingTransaction(Object transaction)
/*  71:    */   {
/*  72:187 */     DataSourceTransactionObject txObject = (DataSourceTransactionObject)transaction;
/*  73:188 */     return (txObject.getConnectionHolder() != null) && (txObject.getConnectionHolder().isTransactionActive());
/*  74:    */   }
/*  75:    */   
/*  76:    */   protected void doBegin(Object transaction, TransactionDefinition definition)
/*  77:    */   {
/*  78:196 */     DataSourceTransactionObject txObject = (DataSourceTransactionObject)transaction;
/*  79:197 */     Connection con = null;
/*  80:    */     try
/*  81:    */     {
/*  82:200 */       if ((txObject.getConnectionHolder() == null) || (txObject.getConnectionHolder().isSynchronizedWithTransaction()))
/*  83:    */       {
/*  84:202 */         Connection newCon = this.dataSource.getConnection();
/*  85:203 */         if (this.logger.isDebugEnabled()) {
/*  86:204 */           this.logger.debug("Acquired Connection [" + newCon + "] for JDBC transaction");
/*  87:    */         }
/*  88:206 */         txObject.setConnectionHolder(new ConnectionHolder(newCon), true);
/*  89:    */       }
/*  90:209 */       txObject.getConnectionHolder().setSynchronizedWithTransaction(true);
/*  91:210 */       con = txObject.getConnectionHolder().getConnection();
/*  92:    */       
/*  93:212 */       Integer previousIsolationLevel = DataSourceUtils.prepareConnectionForTransaction(con, definition);
/*  94:213 */       txObject.setPreviousIsolationLevel(previousIsolationLevel);
/*  95:218 */       if (con.getAutoCommit())
/*  96:    */       {
/*  97:219 */         txObject.setMustRestoreAutoCommit(true);
/*  98:220 */         if (this.logger.isDebugEnabled()) {
/*  99:221 */           this.logger.debug("Switching JDBC Connection [" + con + "] to manual commit");
/* 100:    */         }
/* 101:223 */         con.setAutoCommit(false);
/* 102:    */       }
/* 103:225 */       txObject.getConnectionHolder().setTransactionActive(true);
/* 104:    */       
/* 105:227 */       int timeout = determineTimeout(definition);
/* 106:228 */       if (timeout != -1) {
/* 107:229 */         txObject.getConnectionHolder().setTimeoutInSeconds(timeout);
/* 108:    */       }
/* 109:233 */       if (txObject.isNewConnectionHolder()) {
/* 110:234 */         TransactionSynchronizationManager.bindResource(getDataSource(), txObject.getConnectionHolder());
/* 111:    */       }
/* 112:    */     }
/* 113:    */     catch (Exception ex)
/* 114:    */     {
/* 115:239 */       DataSourceUtils.releaseConnection(con, this.dataSource);
/* 116:240 */       throw new CannotCreateTransactionException("Could not open JDBC Connection for transaction", ex);
/* 117:    */     }
/* 118:    */   }
/* 119:    */   
/* 120:    */   protected Object doSuspend(Object transaction)
/* 121:    */   {
/* 122:246 */     DataSourceTransactionObject txObject = (DataSourceTransactionObject)transaction;
/* 123:247 */     txObject.setConnectionHolder(null);
/* 124:248 */     ConnectionHolder conHolder = (ConnectionHolder)TransactionSynchronizationManager.unbindResource(this.dataSource);
/* 125:    */     
/* 126:250 */     return conHolder;
/* 127:    */   }
/* 128:    */   
/* 129:    */   protected void doResume(Object transaction, Object suspendedResources)
/* 130:    */   {
/* 131:255 */     ConnectionHolder conHolder = (ConnectionHolder)suspendedResources;
/* 132:256 */     TransactionSynchronizationManager.bindResource(this.dataSource, conHolder);
/* 133:    */   }
/* 134:    */   
/* 135:    */   protected void doCommit(DefaultTransactionStatus status)
/* 136:    */   {
/* 137:261 */     DataSourceTransactionObject txObject = (DataSourceTransactionObject)status.getTransaction();
/* 138:262 */     Connection con = txObject.getConnectionHolder().getConnection();
/* 139:263 */     if (status.isDebug()) {
/* 140:264 */       this.logger.debug("Committing JDBC transaction on Connection [" + con + "]");
/* 141:    */     }
/* 142:    */     try
/* 143:    */     {
/* 144:267 */       con.commit();
/* 145:    */     }
/* 146:    */     catch (SQLException ex)
/* 147:    */     {
/* 148:270 */       throw new TransactionSystemException("Could not commit JDBC transaction", ex);
/* 149:    */     }
/* 150:    */   }
/* 151:    */   
/* 152:    */   protected void doRollback(DefaultTransactionStatus status)
/* 153:    */   {
/* 154:276 */     DataSourceTransactionObject txObject = (DataSourceTransactionObject)status.getTransaction();
/* 155:277 */     Connection con = txObject.getConnectionHolder().getConnection();
/* 156:278 */     if (status.isDebug()) {
/* 157:279 */       this.logger.debug("Rolling back JDBC transaction on Connection [" + con + "]");
/* 158:    */     }
/* 159:    */     try
/* 160:    */     {
/* 161:282 */       con.rollback();
/* 162:    */     }
/* 163:    */     catch (SQLException ex)
/* 164:    */     {
/* 165:285 */       throw new TransactionSystemException("Could not roll back JDBC transaction", ex);
/* 166:    */     }
/* 167:    */   }
/* 168:    */   
/* 169:    */   protected void doSetRollbackOnly(DefaultTransactionStatus status)
/* 170:    */   {
/* 171:291 */     DataSourceTransactionObject txObject = (DataSourceTransactionObject)status.getTransaction();
/* 172:292 */     if (status.isDebug()) {
/* 173:293 */       this.logger.debug("Setting JDBC transaction [" + txObject.getConnectionHolder().getConnection() + "] rollback-only");
/* 174:    */     }
/* 175:296 */     txObject.setRollbackOnly();
/* 176:    */   }
/* 177:    */   
/* 178:    */   protected void doCleanupAfterCompletion(Object transaction)
/* 179:    */   {
/* 180:301 */     DataSourceTransactionObject txObject = (DataSourceTransactionObject)transaction;
/* 181:304 */     if (txObject.isNewConnectionHolder()) {
/* 182:305 */       TransactionSynchronizationManager.unbindResource(this.dataSource);
/* 183:    */     }
/* 184:309 */     Connection con = txObject.getConnectionHolder().getConnection();
/* 185:    */     try
/* 186:    */     {
/* 187:311 */       if (txObject.isMustRestoreAutoCommit()) {
/* 188:312 */         con.setAutoCommit(true);
/* 189:    */       }
/* 190:314 */       DataSourceUtils.resetConnectionAfterTransaction(con, txObject.getPreviousIsolationLevel());
/* 191:    */     }
/* 192:    */     catch (Throwable ex)
/* 193:    */     {
/* 194:317 */       this.logger.debug("Could not reset JDBC Connection after transaction", ex);
/* 195:    */     }
/* 196:320 */     if (txObject.isNewConnectionHolder())
/* 197:    */     {
/* 198:321 */       if (this.logger.isDebugEnabled()) {
/* 199:322 */         this.logger.debug("Releasing JDBC Connection [" + con + "] after transaction");
/* 200:    */       }
/* 201:324 */       DataSourceUtils.releaseConnection(con, this.dataSource);
/* 202:    */     }
/* 203:327 */     txObject.getConnectionHolder().clear();
/* 204:    */   }
/* 205:    */   
/* 206:    */   private static class DataSourceTransactionObject
/* 207:    */     extends JdbcTransactionObjectSupport
/* 208:    */   {
/* 209:    */     private boolean newConnectionHolder;
/* 210:    */     private boolean mustRestoreAutoCommit;
/* 211:    */     
/* 212:    */     public void setConnectionHolder(ConnectionHolder connectionHolder, boolean newConnectionHolder)
/* 213:    */     {
/* 214:342 */       super.setConnectionHolder(connectionHolder);
/* 215:343 */       this.newConnectionHolder = newConnectionHolder;
/* 216:    */     }
/* 217:    */     
/* 218:    */     public boolean isNewConnectionHolder()
/* 219:    */     {
/* 220:347 */       return this.newConnectionHolder;
/* 221:    */     }
/* 222:    */     
/* 223:    */     public boolean hasTransaction()
/* 224:    */     {
/* 225:351 */       return (getConnectionHolder() != null) && (getConnectionHolder().isTransactionActive());
/* 226:    */     }
/* 227:    */     
/* 228:    */     public void setMustRestoreAutoCommit(boolean mustRestoreAutoCommit)
/* 229:    */     {
/* 230:355 */       this.mustRestoreAutoCommit = mustRestoreAutoCommit;
/* 231:    */     }
/* 232:    */     
/* 233:    */     public boolean isMustRestoreAutoCommit()
/* 234:    */     {
/* 235:359 */       return this.mustRestoreAutoCommit;
/* 236:    */     }
/* 237:    */     
/* 238:    */     public void setRollbackOnly()
/* 239:    */     {
/* 240:363 */       getConnectionHolder().setRollbackOnly();
/* 241:    */     }
/* 242:    */     
/* 243:    */     public boolean isRollbackOnly()
/* 244:    */     {
/* 245:367 */       return getConnectionHolder().isRollbackOnly();
/* 246:    */     }
/* 247:    */   }
/* 248:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.datasource.DataSourceTransactionManager
 * JD-Core Version:    0.7.0.1
 */