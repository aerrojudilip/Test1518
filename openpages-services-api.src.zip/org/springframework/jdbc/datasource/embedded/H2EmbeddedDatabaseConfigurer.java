/*  1:   */ package org.springframework.jdbc.datasource.embedded;
/*  2:   */ 
/*  3:   */ import java.sql.Driver;
/*  4:   */ import org.springframework.util.ClassUtils;
/*  5:   */ 
/*  6:   */ final class H2EmbeddedDatabaseConfigurer
/*  7:   */   extends AbstractEmbeddedDatabaseConfigurer
/*  8:   */ {
/*  9:   */   private static H2EmbeddedDatabaseConfigurer INSTANCE;
/* 10:   */   private final Class<? extends Driver> driverClass;
/* 11:   */   
/* 12:   */   public static synchronized H2EmbeddedDatabaseConfigurer getInstance()
/* 13:   */     throws ClassNotFoundException
/* 14:   */   {
/* 15:44 */     if (INSTANCE == null) {
/* 16:45 */       INSTANCE = new H2EmbeddedDatabaseConfigurer(ClassUtils.forName("org.h2.Driver", H2EmbeddedDatabaseConfigurer.class.getClassLoader()));
/* 17:   */     }
/* 18:48 */     return INSTANCE;
/* 19:   */   }
/* 20:   */   
/* 21:   */   private H2EmbeddedDatabaseConfigurer(Class<? extends Driver> driverClass)
/* 22:   */   {
/* 23:52 */     this.driverClass = driverClass;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public void configureConnectionProperties(ConnectionProperties properties, String databaseName)
/* 27:   */   {
/* 28:56 */     properties.setDriverClass(this.driverClass);
/* 29:57 */     properties.setUrl(String.format("jdbc:h2:mem:%s;DB_CLOSE_DELAY=-1", new Object[] { databaseName }));
/* 30:58 */     properties.setUsername("sa");
/* 31:59 */     properties.setPassword("");
/* 32:   */   }
/* 33:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.datasource.embedded.H2EmbeddedDatabaseConfigurer
 * JD-Core Version:    0.7.0.1
 */