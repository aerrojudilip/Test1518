package org.springframework.jdbc.datasource.embedded;

import javax.sql.DataSource;

public abstract interface EmbeddedDatabaseConfigurer
{
  public abstract void configureConnectionProperties(ConnectionProperties paramConnectionProperties, String paramString);
  
  public abstract void shutdown(DataSource paramDataSource, String paramString);
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseConfigurer
 * JD-Core Version:    0.7.0.1
 */