package org.springframework.jdbc.datasource.embedded;

import java.sql.Driver;

public abstract interface ConnectionProperties
{
  public abstract void setDriverClass(Class<? extends Driver> paramClass);
  
  public abstract void setUrl(String paramString);
  
  public abstract void setUsername(String paramString);
  
  public abstract void setPassword(String paramString);
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.datasource.embedded.ConnectionProperties
 * JD-Core Version:    0.7.0.1
 */