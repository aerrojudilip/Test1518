package org.springframework.jdbc.datasource.embedded;

import javax.sql.DataSource;

public abstract interface EmbeddedDatabase
  extends DataSource
{
  public abstract void shutdown();
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.datasource.embedded.EmbeddedDatabase
 * JD-Core Version:    0.7.0.1
 */