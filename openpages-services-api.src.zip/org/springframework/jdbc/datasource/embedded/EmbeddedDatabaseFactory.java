/*   1:    */ package org.springframework.jdbc.datasource.embedded;
/*   2:    */ 
/*   3:    */ import java.io.PrintWriter;
/*   4:    */ import java.sql.Connection;
/*   5:    */ import java.sql.SQLException;
/*   6:    */ import java.util.logging.Logger;
/*   7:    */ import javax.sql.DataSource;
/*   8:    */ import org.apache.commons.logging.Log;
/*   9:    */ import org.apache.commons.logging.LogFactory;
/*  10:    */ import org.springframework.jdbc.datasource.init.DatabasePopulator;
/*  11:    */ import org.springframework.jdbc.datasource.init.DatabasePopulatorUtils;
/*  12:    */ import org.springframework.util.Assert;
/*  13:    */ 
/*  14:    */ public class EmbeddedDatabaseFactory
/*  15:    */ {
/*  16: 50 */   private static Log logger = LogFactory.getLog(EmbeddedDatabaseFactory.class);
/*  17:    */   private String databaseName;
/*  18:    */   private DataSourceFactory dataSourceFactory;
/*  19:    */   private EmbeddedDatabaseConfigurer databaseConfigurer;
/*  20:    */   private DatabasePopulator databasePopulator;
/*  21:    */   private DataSource dataSource;
/*  22:    */   
/*  23:    */   public EmbeddedDatabaseFactory()
/*  24:    */   {
/*  25: 52 */     this.databaseName = "testdb";
/*  26:    */     
/*  27: 54 */     this.dataSourceFactory = new SimpleDriverDataSourceFactory();
/*  28:    */   }
/*  29:    */   
/*  30:    */   public void setDatabaseName(String databaseName)
/*  31:    */   {
/*  32: 68 */     Assert.notNull(databaseName, "Database name is required");
/*  33: 69 */     this.databaseName = databaseName;
/*  34:    */   }
/*  35:    */   
/*  36:    */   public void setDataSourceFactory(DataSourceFactory dataSourceFactory)
/*  37:    */   {
/*  38: 77 */     Assert.notNull(dataSourceFactory, "DataSourceFactory is required");
/*  39: 78 */     this.dataSourceFactory = dataSourceFactory;
/*  40:    */   }
/*  41:    */   
/*  42:    */   public void setDatabaseType(EmbeddedDatabaseType type)
/*  43:    */   {
/*  44: 87 */     this.databaseConfigurer = EmbeddedDatabaseConfigurerFactory.getConfigurer(type);
/*  45:    */   }
/*  46:    */   
/*  47:    */   public void setDatabaseConfigurer(EmbeddedDatabaseConfigurer configurer)
/*  48:    */   {
/*  49: 95 */     this.databaseConfigurer = configurer;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public void setDatabasePopulator(DatabasePopulator populator)
/*  53:    */   {
/*  54:103 */     this.databasePopulator = populator;
/*  55:    */   }
/*  56:    */   
/*  57:    */   public EmbeddedDatabase getDatabase()
/*  58:    */   {
/*  59:110 */     if (this.dataSource == null) {
/*  60:111 */       initDatabase();
/*  61:    */     }
/*  62:113 */     return new EmbeddedDataSourceProxy(this.dataSource);
/*  63:    */   }
/*  64:    */   
/*  65:    */   protected void initDatabase()
/*  66:    */   {
/*  67:123 */     if (logger.isInfoEnabled()) {
/*  68:124 */       logger.info("Creating embedded database '" + this.databaseName + "'");
/*  69:    */     }
/*  70:126 */     if (this.databaseConfigurer == null) {
/*  71:127 */       this.databaseConfigurer = EmbeddedDatabaseConfigurerFactory.getConfigurer(EmbeddedDatabaseType.HSQL);
/*  72:    */     }
/*  73:129 */     this.databaseConfigurer.configureConnectionProperties(this.dataSourceFactory.getConnectionProperties(), this.databaseName);
/*  74:    */     
/*  75:131 */     this.dataSource = this.dataSourceFactory.getDataSource();
/*  76:134 */     if (this.databasePopulator != null) {
/*  77:    */       try
/*  78:    */       {
/*  79:136 */         DatabasePopulatorUtils.execute(this.databasePopulator, this.dataSource);
/*  80:    */       }
/*  81:    */       catch (RuntimeException ex)
/*  82:    */       {
/*  83:140 */         shutdownDatabase();
/*  84:141 */         throw ex;
/*  85:    */       }
/*  86:    */     }
/*  87:    */   }
/*  88:    */   
/*  89:    */   protected void shutdownDatabase()
/*  90:    */   {
/*  91:151 */     if (this.dataSource != null)
/*  92:    */     {
/*  93:152 */       this.databaseConfigurer.shutdown(this.dataSource, this.databaseName);
/*  94:153 */       this.dataSource = null;
/*  95:    */     }
/*  96:    */   }
/*  97:    */   
/*  98:    */   protected final DataSource getDataSource()
/*  99:    */   {
/* 100:163 */     return this.dataSource;
/* 101:    */   }
/* 102:    */   
/* 103:    */   private class EmbeddedDataSourceProxy
/* 104:    */     implements EmbeddedDatabase
/* 105:    */   {
/* 106:    */     private final DataSource dataSource;
/* 107:    */     
/* 108:    */     public EmbeddedDataSourceProxy(DataSource dataSource)
/* 109:    */     {
/* 110:172 */       this.dataSource = dataSource;
/* 111:    */     }
/* 112:    */     
/* 113:    */     public Connection getConnection()
/* 114:    */       throws SQLException
/* 115:    */     {
/* 116:176 */       return this.dataSource.getConnection();
/* 117:    */     }
/* 118:    */     
/* 119:    */     public Connection getConnection(String username, String password)
/* 120:    */       throws SQLException
/* 121:    */     {
/* 122:180 */       return this.dataSource.getConnection(username, password);
/* 123:    */     }
/* 124:    */     
/* 125:    */     public PrintWriter getLogWriter()
/* 126:    */       throws SQLException
/* 127:    */     {
/* 128:184 */       return this.dataSource.getLogWriter();
/* 129:    */     }
/* 130:    */     
/* 131:    */     public void setLogWriter(PrintWriter out)
/* 132:    */       throws SQLException
/* 133:    */     {
/* 134:188 */       this.dataSource.setLogWriter(out);
/* 135:    */     }
/* 136:    */     
/* 137:    */     public int getLoginTimeout()
/* 138:    */       throws SQLException
/* 139:    */     {
/* 140:192 */       return this.dataSource.getLoginTimeout();
/* 141:    */     }
/* 142:    */     
/* 143:    */     public void setLoginTimeout(int seconds)
/* 144:    */       throws SQLException
/* 145:    */     {
/* 146:196 */       this.dataSource.setLoginTimeout(seconds);
/* 147:    */     }
/* 148:    */     
/* 149:    */     public <T> T unwrap(Class<T> iface)
/* 150:    */       throws SQLException
/* 151:    */     {
/* 152:200 */       return this.dataSource.unwrap(iface);
/* 153:    */     }
/* 154:    */     
/* 155:    */     public boolean isWrapperFor(Class<?> iface)
/* 156:    */       throws SQLException
/* 157:    */     {
/* 158:204 */       return this.dataSource.isWrapperFor(iface);
/* 159:    */     }
/* 160:    */     
/* 161:    */     public Logger getParentLogger()
/* 162:    */     {
/* 163:210 */       return Logger.getLogger("global");
/* 164:    */     }
/* 165:    */     
/* 166:    */     public void shutdown()
/* 167:    */     {
/* 168:214 */       EmbeddedDatabaseFactory.this.shutdownDatabase();
/* 169:    */     }
/* 170:    */   }
/* 171:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseFactory
 * JD-Core Version:    0.7.0.1
 */