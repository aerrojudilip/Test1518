/*  1:   */ package org.springframework.jdbc.datasource.embedded;
/*  2:   */ 
/*  3:   */ import java.sql.Driver;
/*  4:   */ import org.springframework.util.ClassUtils;
/*  5:   */ 
/*  6:   */ final class HsqlEmbeddedDatabaseConfigurer
/*  7:   */   extends AbstractEmbeddedDatabaseConfigurer
/*  8:   */ {
/*  9:   */   private static HsqlEmbeddedDatabaseConfigurer INSTANCE;
/* 10:   */   private final Class<? extends Driver> driverClass;
/* 11:   */   
/* 12:   */   public static synchronized HsqlEmbeddedDatabaseConfigurer getInstance()
/* 13:   */     throws ClassNotFoundException
/* 14:   */   {
/* 15:44 */     if (INSTANCE == null) {
/* 16:45 */       INSTANCE = new HsqlEmbeddedDatabaseConfigurer(ClassUtils.forName("org.hsqldb.jdbcDriver", HsqlEmbeddedDatabaseConfigurer.class.getClassLoader()));
/* 17:   */     }
/* 18:48 */     return INSTANCE;
/* 19:   */   }
/* 20:   */   
/* 21:   */   private HsqlEmbeddedDatabaseConfigurer(Class<? extends Driver> driverClass)
/* 22:   */   {
/* 23:52 */     this.driverClass = driverClass;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public void configureConnectionProperties(ConnectionProperties properties, String databaseName)
/* 27:   */   {
/* 28:56 */     properties.setDriverClass(this.driverClass);
/* 29:57 */     properties.setUrl("jdbc:hsqldb:mem:" + databaseName);
/* 30:58 */     properties.setUsername("sa");
/* 31:59 */     properties.setPassword("");
/* 32:   */   }
/* 33:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.datasource.embedded.HsqlEmbeddedDatabaseConfigurer
 * JD-Core Version:    0.7.0.1
 */