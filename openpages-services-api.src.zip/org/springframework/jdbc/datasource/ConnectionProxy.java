package org.springframework.jdbc.datasource;

import java.sql.Connection;

public abstract interface ConnectionProxy
  extends Connection
{
  public abstract Connection getTargetConnection();
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.datasource.ConnectionProxy
 * JD-Core Version:    0.7.0.1
 */