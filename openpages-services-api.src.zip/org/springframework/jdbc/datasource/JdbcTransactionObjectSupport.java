/*   1:    */ package org.springframework.jdbc.datasource;
/*   2:    */ 
/*   3:    */ import java.sql.Connection;
/*   4:    */ import java.sql.Savepoint;
/*   5:    */ import org.apache.commons.logging.Log;
/*   6:    */ import org.apache.commons.logging.LogFactory;
/*   7:    */ import org.springframework.transaction.CannotCreateTransactionException;
/*   8:    */ import org.springframework.transaction.NestedTransactionNotSupportedException;
/*   9:    */ import org.springframework.transaction.SavepointManager;
/*  10:    */ import org.springframework.transaction.TransactionException;
/*  11:    */ import org.springframework.transaction.TransactionSystemException;
/*  12:    */ import org.springframework.transaction.TransactionUsageException;
/*  13:    */ import org.springframework.transaction.support.SmartTransactionObject;
/*  14:    */ 
/*  15:    */ public abstract class JdbcTransactionObjectSupport
/*  16:    */   implements SavepointManager, SmartTransactionObject
/*  17:    */ {
/*  18: 52 */   private static final Log logger = LogFactory.getLog(JdbcTransactionObjectSupport.class);
/*  19:    */   private ConnectionHolder connectionHolder;
/*  20:    */   private Integer previousIsolationLevel;
/*  21: 59 */   private boolean savepointAllowed = false;
/*  22:    */   
/*  23:    */   public void setConnectionHolder(ConnectionHolder connectionHolder)
/*  24:    */   {
/*  25: 63 */     this.connectionHolder = connectionHolder;
/*  26:    */   }
/*  27:    */   
/*  28:    */   public ConnectionHolder getConnectionHolder()
/*  29:    */   {
/*  30: 67 */     return this.connectionHolder;
/*  31:    */   }
/*  32:    */   
/*  33:    */   public boolean hasConnectionHolder()
/*  34:    */   {
/*  35: 71 */     return this.connectionHolder != null;
/*  36:    */   }
/*  37:    */   
/*  38:    */   public void setPreviousIsolationLevel(Integer previousIsolationLevel)
/*  39:    */   {
/*  40: 75 */     this.previousIsolationLevel = previousIsolationLevel;
/*  41:    */   }
/*  42:    */   
/*  43:    */   public Integer getPreviousIsolationLevel()
/*  44:    */   {
/*  45: 79 */     return this.previousIsolationLevel;
/*  46:    */   }
/*  47:    */   
/*  48:    */   public void setSavepointAllowed(boolean savepointAllowed)
/*  49:    */   {
/*  50: 83 */     this.savepointAllowed = savepointAllowed;
/*  51:    */   }
/*  52:    */   
/*  53:    */   public boolean isSavepointAllowed()
/*  54:    */   {
/*  55: 87 */     return this.savepointAllowed;
/*  56:    */   }
/*  57:    */   
/*  58:    */   public void flush() {}
/*  59:    */   
/*  60:    */   public Object createSavepoint()
/*  61:    */     throws TransactionException
/*  62:    */   {
/*  63:104 */     ConnectionHolder conHolder = getConnectionHolderForSavepoint();
/*  64:    */     try
/*  65:    */     {
/*  66:106 */       if (!conHolder.supportsSavepoints()) {
/*  67:107 */         throw new NestedTransactionNotSupportedException("Cannot create a nested transaction because savepoints are not supported by your JDBC driver");
/*  68:    */       }
/*  69:    */     }
/*  70:    */     catch (Throwable ex)
/*  71:    */     {
/*  72:112 */       throw new NestedTransactionNotSupportedException("Cannot create a nested transaction because your JDBC driver is not a JDBC 3.0 driver", ex);
/*  73:    */     }
/*  74:    */     try
/*  75:    */     {
/*  76:116 */       return conHolder.createSavepoint();
/*  77:    */     }
/*  78:    */     catch (Throwable ex)
/*  79:    */     {
/*  80:119 */       throw new CannotCreateTransactionException("Could not create JDBC savepoint", ex);
/*  81:    */     }
/*  82:    */   }
/*  83:    */   
/*  84:    */   public void rollbackToSavepoint(Object savepoint)
/*  85:    */     throws TransactionException
/*  86:    */   {
/*  87:    */     try
/*  88:    */     {
/*  89:129 */       getConnectionHolderForSavepoint().getConnection().rollback((Savepoint)savepoint);
/*  90:    */     }
/*  91:    */     catch (Throwable ex)
/*  92:    */     {
/*  93:132 */       throw new TransactionSystemException("Could not roll back to JDBC savepoint", ex);
/*  94:    */     }
/*  95:    */   }
/*  96:    */   
/*  97:    */   public void releaseSavepoint(Object savepoint)
/*  98:    */     throws TransactionException
/*  99:    */   {
/* 100:    */     try
/* 101:    */     {
/* 102:142 */       getConnectionHolderForSavepoint().getConnection().releaseSavepoint((Savepoint)savepoint);
/* 103:    */     }
/* 104:    */     catch (Throwable ex)
/* 105:    */     {
/* 106:145 */       logger.debug("Could not explicitly release JDBC savepoint", ex);
/* 107:    */     }
/* 108:    */   }
/* 109:    */   
/* 110:    */   protected ConnectionHolder getConnectionHolderForSavepoint()
/* 111:    */     throws TransactionException
/* 112:    */   {
/* 113:150 */     if (!isSavepointAllowed()) {
/* 114:151 */       throw new NestedTransactionNotSupportedException("Transaction manager does not allow nested transactions");
/* 115:    */     }
/* 116:154 */     if (!hasConnectionHolder()) {
/* 117:155 */       throw new TransactionUsageException("Cannot create nested transaction if not exposing a JDBC transaction");
/* 118:    */     }
/* 119:158 */     return getConnectionHolder();
/* 120:    */   }
/* 121:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.datasource.JdbcTransactionObjectSupport
 * JD-Core Version:    0.7.0.1
 */