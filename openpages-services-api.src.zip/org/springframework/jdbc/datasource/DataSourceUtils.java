/*   1:    */ package org.springframework.jdbc.datasource;
/*   2:    */ 
/*   3:    */ import java.sql.Connection;
/*   4:    */ import java.sql.SQLException;
/*   5:    */ import java.sql.Statement;
/*   6:    */ import javax.sql.DataSource;
/*   7:    */ import org.apache.commons.logging.Log;
/*   8:    */ import org.apache.commons.logging.LogFactory;
/*   9:    */ import org.springframework.jdbc.CannotGetJdbcConnectionException;
/*  10:    */ import org.springframework.transaction.TransactionDefinition;
/*  11:    */ import org.springframework.transaction.support.TransactionSynchronizationAdapter;
/*  12:    */ import org.springframework.transaction.support.TransactionSynchronizationManager;
/*  13:    */ import org.springframework.util.Assert;
/*  14:    */ 
/*  15:    */ public abstract class DataSourceUtils
/*  16:    */ {
/*  17:    */   public static final int CONNECTION_SYNCHRONIZATION_ORDER = 1000;
/*  18: 58 */   private static final Log logger = LogFactory.getLog(DataSourceUtils.class);
/*  19:    */   
/*  20:    */   public static Connection getConnection(DataSource dataSource)
/*  21:    */     throws CannotGetJdbcConnectionException
/*  22:    */   {
/*  23:    */     try
/*  24:    */     {
/*  25: 77 */       return doGetConnection(dataSource);
/*  26:    */     }
/*  27:    */     catch (SQLException ex)
/*  28:    */     {
/*  29: 80 */       throw new CannotGetJdbcConnectionException("Could not get JDBC Connection", ex);
/*  30:    */     }
/*  31:    */   }
/*  32:    */   
/*  33:    */   public static Connection doGetConnection(DataSource dataSource)
/*  34:    */     throws SQLException
/*  35:    */   {
/*  36: 97 */     Assert.notNull(dataSource, "No DataSource specified");
/*  37:    */     
/*  38: 99 */     ConnectionHolder conHolder = (ConnectionHolder)TransactionSynchronizationManager.getResource(dataSource);
/*  39:100 */     if ((conHolder != null) && ((conHolder.hasConnection()) || (conHolder.isSynchronizedWithTransaction())))
/*  40:    */     {
/*  41:101 */       conHolder.requested();
/*  42:102 */       if (!conHolder.hasConnection())
/*  43:    */       {
/*  44:103 */         logger.debug("Fetching resumed JDBC Connection from DataSource");
/*  45:104 */         conHolder.setConnection(dataSource.getConnection());
/*  46:    */       }
/*  47:106 */       return conHolder.getConnection();
/*  48:    */     }
/*  49:110 */     logger.debug("Fetching JDBC Connection from DataSource");
/*  50:111 */     Connection con = dataSource.getConnection();
/*  51:113 */     if (TransactionSynchronizationManager.isSynchronizationActive())
/*  52:    */     {
/*  53:114 */       logger.debug("Registering transaction synchronization for JDBC Connection");
/*  54:    */       
/*  55:    */ 
/*  56:117 */       ConnectionHolder holderToUse = conHolder;
/*  57:118 */       if (holderToUse == null) {
/*  58:119 */         holderToUse = new ConnectionHolder(con);
/*  59:    */       } else {
/*  60:122 */         holderToUse.setConnection(con);
/*  61:    */       }
/*  62:124 */       holderToUse.requested();
/*  63:125 */       TransactionSynchronizationManager.registerSynchronization(new ConnectionSynchronization(holderToUse, dataSource));
/*  64:    */       
/*  65:127 */       holderToUse.setSynchronizedWithTransaction(true);
/*  66:128 */       if (holderToUse != conHolder) {
/*  67:129 */         TransactionSynchronizationManager.bindResource(dataSource, holderToUse);
/*  68:    */       }
/*  69:    */     }
/*  70:133 */     return con;
/*  71:    */   }
/*  72:    */   
/*  73:    */   public static Integer prepareConnectionForTransaction(Connection con, TransactionDefinition definition)
/*  74:    */     throws SQLException
/*  75:    */   {
/*  76:147 */     Assert.notNull(con, "No Connection specified");
/*  77:150 */     if ((definition != null) && (definition.isReadOnly())) {
/*  78:    */       try
/*  79:    */       {
/*  80:152 */         if (logger.isDebugEnabled()) {
/*  81:153 */           logger.debug("Setting JDBC Connection [" + con + "] read-only");
/*  82:    */         }
/*  83:155 */         con.setReadOnly(true);
/*  84:    */       }
/*  85:    */       catch (SQLException ex)
/*  86:    */       {
/*  87:158 */         Throwable exToCheck = ex;
/*  88:159 */         while (exToCheck != null)
/*  89:    */         {
/*  90:160 */           if (exToCheck.getClass().getSimpleName().contains("Timeout")) {
/*  91:162 */             throw ex;
/*  92:    */           }
/*  93:164 */           exToCheck = exToCheck.getCause();
/*  94:    */         }
/*  95:167 */         logger.debug("Could not set JDBC Connection read-only", ex);
/*  96:    */       }
/*  97:    */       catch (RuntimeException ex)
/*  98:    */       {
/*  99:170 */         Throwable exToCheck = ex;
/* 100:171 */         while (exToCheck != null)
/* 101:    */         {
/* 102:172 */           if (exToCheck.getClass().getSimpleName().contains("Timeout")) {
/* 103:174 */             throw ex;
/* 104:    */           }
/* 105:176 */           exToCheck = exToCheck.getCause();
/* 106:    */         }
/* 107:179 */         logger.debug("Could not set JDBC Connection read-only", ex);
/* 108:    */       }
/* 109:    */     }
/* 110:184 */     Integer previousIsolationLevel = null;
/* 111:185 */     if ((definition != null) && (definition.getIsolationLevel() != -1))
/* 112:    */     {
/* 113:186 */       if (logger.isDebugEnabled()) {
/* 114:187 */         logger.debug("Changing isolation level of JDBC Connection [" + con + "] to " + definition.getIsolationLevel());
/* 115:    */       }
/* 116:190 */       int currentIsolation = con.getTransactionIsolation();
/* 117:191 */       if (currentIsolation != definition.getIsolationLevel())
/* 118:    */       {
/* 119:192 */         previousIsolationLevel = Integer.valueOf(currentIsolation);
/* 120:193 */         con.setTransactionIsolation(definition.getIsolationLevel());
/* 121:    */       }
/* 122:    */     }
/* 123:197 */     return previousIsolationLevel;
/* 124:    */   }
/* 125:    */   
/* 126:    */   public static void resetConnectionAfterTransaction(Connection con, Integer previousIsolationLevel)
/* 127:    */   {
/* 128:208 */     Assert.notNull(con, "No Connection specified");
/* 129:    */     try
/* 130:    */     {
/* 131:211 */       if (previousIsolationLevel != null)
/* 132:    */       {
/* 133:212 */         if (logger.isDebugEnabled()) {
/* 134:213 */           logger.debug("Resetting isolation level of JDBC Connection [" + con + "] to " + previousIsolationLevel);
/* 135:    */         }
/* 136:216 */         con.setTransactionIsolation(previousIsolationLevel.intValue());
/* 137:    */       }
/* 138:220 */       if (con.isReadOnly())
/* 139:    */       {
/* 140:221 */         if (logger.isDebugEnabled()) {
/* 141:222 */           logger.debug("Resetting read-only flag of JDBC Connection [" + con + "]");
/* 142:    */         }
/* 143:224 */         con.setReadOnly(false);
/* 144:    */       }
/* 145:    */     }
/* 146:    */     catch (Throwable ex)
/* 147:    */     {
/* 148:228 */       logger.debug("Could not reset JDBC Connection after transaction", ex);
/* 149:    */     }
/* 150:    */   }
/* 151:    */   
/* 152:    */   public static boolean isConnectionTransactional(Connection con, DataSource dataSource)
/* 153:    */   {
/* 154:241 */     if (dataSource == null) {
/* 155:242 */       return false;
/* 156:    */     }
/* 157:244 */     ConnectionHolder conHolder = (ConnectionHolder)TransactionSynchronizationManager.getResource(dataSource);
/* 158:245 */     return (conHolder != null) && (connectionEquals(conHolder, con));
/* 159:    */   }
/* 160:    */   
/* 161:    */   public static void applyTransactionTimeout(Statement stmt, DataSource dataSource)
/* 162:    */     throws SQLException
/* 163:    */   {
/* 164:257 */     applyTimeout(stmt, dataSource, 0);
/* 165:    */   }
/* 166:    */   
/* 167:    */   public static void applyTimeout(Statement stmt, DataSource dataSource, int timeout)
/* 168:    */     throws SQLException
/* 169:    */   {
/* 170:270 */     Assert.notNull(stmt, "No Statement specified");
/* 171:271 */     Assert.notNull(dataSource, "No DataSource specified");
/* 172:272 */     ConnectionHolder holder = (ConnectionHolder)TransactionSynchronizationManager.getResource(dataSource);
/* 173:273 */     if ((holder != null) && (holder.hasTimeout())) {
/* 174:275 */       stmt.setQueryTimeout(holder.getTimeToLiveInSeconds());
/* 175:277 */     } else if (timeout > 0) {
/* 176:279 */       stmt.setQueryTimeout(timeout);
/* 177:    */     }
/* 178:    */   }
/* 179:    */   
/* 180:    */   public static void releaseConnection(Connection con, DataSource dataSource)
/* 181:    */   {
/* 182:    */     try
/* 183:    */     {
/* 184:294 */       doReleaseConnection(con, dataSource);
/* 185:    */     }
/* 186:    */     catch (SQLException ex)
/* 187:    */     {
/* 188:297 */       logger.debug("Could not close JDBC Connection", ex);
/* 189:    */     }
/* 190:    */     catch (Throwable ex)
/* 191:    */     {
/* 192:300 */       logger.debug("Unexpected exception on closing JDBC Connection", ex);
/* 193:    */     }
/* 194:    */   }
/* 195:    */   
/* 196:    */   public static void doReleaseConnection(Connection con, DataSource dataSource)
/* 197:    */     throws SQLException
/* 198:    */   {
/* 199:316 */     if (con == null) {
/* 200:317 */       return;
/* 201:    */     }
/* 202:319 */     if (dataSource != null)
/* 203:    */     {
/* 204:320 */       ConnectionHolder conHolder = (ConnectionHolder)TransactionSynchronizationManager.getResource(dataSource);
/* 205:321 */       if ((conHolder != null) && (connectionEquals(conHolder, con)))
/* 206:    */       {
/* 207:323 */         conHolder.released();
/* 208:324 */         return;
/* 209:    */       }
/* 210:    */     }
/* 211:327 */     logger.debug("Returning JDBC Connection to DataSource");
/* 212:328 */     doCloseConnection(con, dataSource);
/* 213:    */   }
/* 214:    */   
/* 215:    */   public static void doCloseConnection(Connection con, DataSource dataSource)
/* 216:    */     throws SQLException
/* 217:    */   {
/* 218:340 */     if ((!(dataSource instanceof SmartDataSource)) || (((SmartDataSource)dataSource).shouldClose(con))) {
/* 219:341 */       con.close();
/* 220:    */     }
/* 221:    */   }
/* 222:    */   
/* 223:    */   private static boolean connectionEquals(ConnectionHolder conHolder, Connection passedInCon)
/* 224:    */   {
/* 225:356 */     if (!conHolder.hasConnection()) {
/* 226:357 */       return false;
/* 227:    */     }
/* 228:359 */     Connection heldCon = conHolder.getConnection();
/* 229:    */     
/* 230:    */ 
/* 231:362 */     return (heldCon == passedInCon) || (heldCon.equals(passedInCon)) || (getTargetConnection(heldCon).equals(passedInCon));
/* 232:    */   }
/* 233:    */   
/* 234:    */   public static Connection getTargetConnection(Connection con)
/* 235:    */   {
/* 236:375 */     Connection conToUse = con;
/* 237:376 */     while ((conToUse instanceof ConnectionProxy)) {
/* 238:377 */       conToUse = ((ConnectionProxy)conToUse).getTargetConnection();
/* 239:    */     }
/* 240:379 */     return conToUse;
/* 241:    */   }
/* 242:    */   
/* 243:    */   private static int getConnectionSynchronizationOrder(DataSource dataSource)
/* 244:    */   {
/* 245:391 */     int order = 1000;
/* 246:392 */     DataSource currDs = dataSource;
/* 247:393 */     while ((currDs instanceof DelegatingDataSource))
/* 248:    */     {
/* 249:394 */       order--;
/* 250:395 */       currDs = ((DelegatingDataSource)currDs).getTargetDataSource();
/* 251:    */     }
/* 252:397 */     return order;
/* 253:    */   }
/* 254:    */   
/* 255:    */   private static class ConnectionSynchronization
/* 256:    */     extends TransactionSynchronizationAdapter
/* 257:    */   {
/* 258:    */     private final ConnectionHolder connectionHolder;
/* 259:    */     private final DataSource dataSource;
/* 260:    */     private int order;
/* 261:414 */     private boolean holderActive = true;
/* 262:    */     
/* 263:    */     public ConnectionSynchronization(ConnectionHolder connectionHolder, DataSource dataSource)
/* 264:    */     {
/* 265:417 */       this.connectionHolder = connectionHolder;
/* 266:418 */       this.dataSource = dataSource;
/* 267:419 */       this.order = DataSourceUtils.getConnectionSynchronizationOrder(dataSource);
/* 268:    */     }
/* 269:    */     
/* 270:    */     public int getOrder()
/* 271:    */     {
/* 272:424 */       return this.order;
/* 273:    */     }
/* 274:    */     
/* 275:    */     public void suspend()
/* 276:    */     {
/* 277:429 */       if (this.holderActive)
/* 278:    */       {
/* 279:430 */         TransactionSynchronizationManager.unbindResource(this.dataSource);
/* 280:431 */         if ((this.connectionHolder.hasConnection()) && (!this.connectionHolder.isOpen()))
/* 281:    */         {
/* 282:436 */           DataSourceUtils.releaseConnection(this.connectionHolder.getConnection(), this.dataSource);
/* 283:437 */           this.connectionHolder.setConnection(null);
/* 284:    */         }
/* 285:    */       }
/* 286:    */     }
/* 287:    */     
/* 288:    */     public void resume()
/* 289:    */     {
/* 290:444 */       if (this.holderActive) {
/* 291:445 */         TransactionSynchronizationManager.bindResource(this.dataSource, this.connectionHolder);
/* 292:    */       }
/* 293:    */     }
/* 294:    */     
/* 295:    */     public void beforeCompletion()
/* 296:    */     {
/* 297:456 */       if (!this.connectionHolder.isOpen())
/* 298:    */       {
/* 299:457 */         TransactionSynchronizationManager.unbindResource(this.dataSource);
/* 300:458 */         this.holderActive = false;
/* 301:459 */         if (this.connectionHolder.hasConnection()) {
/* 302:460 */           DataSourceUtils.releaseConnection(this.connectionHolder.getConnection(), this.dataSource);
/* 303:    */         }
/* 304:    */       }
/* 305:    */     }
/* 306:    */     
/* 307:    */     public void afterCompletion(int status)
/* 308:    */     {
/* 309:470 */       if (this.holderActive)
/* 310:    */       {
/* 311:473 */         TransactionSynchronizationManager.unbindResourceIfPossible(this.dataSource);
/* 312:474 */         this.holderActive = false;
/* 313:475 */         if (this.connectionHolder.hasConnection())
/* 314:    */         {
/* 315:476 */           DataSourceUtils.releaseConnection(this.connectionHolder.getConnection(), this.dataSource);
/* 316:    */           
/* 317:478 */           this.connectionHolder.setConnection(null);
/* 318:    */         }
/* 319:    */       }
/* 320:481 */       this.connectionHolder.reset();
/* 321:    */     }
/* 322:    */   }
/* 323:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.datasource.DataSourceUtils
 * JD-Core Version:    0.7.0.1
 */