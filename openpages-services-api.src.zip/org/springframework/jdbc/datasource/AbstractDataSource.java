/*  1:   */ package org.springframework.jdbc.datasource;
/*  2:   */ 
/*  3:   */ import java.io.PrintWriter;
/*  4:   */ import java.sql.SQLException;
/*  5:   */ import java.util.logging.Logger;
/*  6:   */ import javax.sql.DataSource;
/*  7:   */ import org.apache.commons.logging.Log;
/*  8:   */ import org.apache.commons.logging.LogFactory;
/*  9:   */ 
/* 10:   */ public abstract class AbstractDataSource
/* 11:   */   implements DataSource
/* 12:   */ {
/* 13:42 */   protected final Log logger = LogFactory.getLog(getClass());
/* 14:   */   
/* 15:   */   public int getLoginTimeout()
/* 16:   */     throws SQLException
/* 17:   */   {
/* 18:49 */     return 0;
/* 19:   */   }
/* 20:   */   
/* 21:   */   public void setLoginTimeout(int timeout)
/* 22:   */     throws SQLException
/* 23:   */   {
/* 24:56 */     throw new UnsupportedOperationException("setLoginTimeout");
/* 25:   */   }
/* 26:   */   
/* 27:   */   public PrintWriter getLogWriter()
/* 28:   */   {
/* 29:63 */     throw new UnsupportedOperationException("getLogWriter");
/* 30:   */   }
/* 31:   */   
/* 32:   */   public void setLogWriter(PrintWriter pw)
/* 33:   */     throws SQLException
/* 34:   */   {
/* 35:70 */     throw new UnsupportedOperationException("setLogWriter");
/* 36:   */   }
/* 37:   */   
/* 38:   */   public <T> T unwrap(Class<T> iface)
/* 39:   */     throws SQLException
/* 40:   */   {
/* 41:80 */     if (iface.isInstance(this)) {
/* 42:81 */       return this;
/* 43:   */     }
/* 44:83 */     throw new SQLException("DataSource of type [" + getClass().getName() + "] cannot be unwrapped as [" + iface.getName() + "]");
/* 45:   */   }
/* 46:   */   
/* 47:   */   public boolean isWrapperFor(Class<?> iface)
/* 48:   */     throws SQLException
/* 49:   */   {
/* 50:88 */     return iface.isInstance(this);
/* 51:   */   }
/* 52:   */   
/* 53:   */   public Logger getParentLogger()
/* 54:   */   {
/* 55:97 */     return Logger.getLogger("global");
/* 56:   */   }
/* 57:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.datasource.AbstractDataSource
 * JD-Core Version:    0.7.0.1
 */