package org.springframework.jdbc.datasource;

import java.sql.Connection;

public abstract interface ConnectionHandle
{
  public abstract Connection getConnection();
  
  public abstract void releaseConnection(Connection paramConnection);
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.datasource.ConnectionHandle
 * JD-Core Version:    0.7.0.1
 */