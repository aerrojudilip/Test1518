/*   1:    */ package org.springframework.jdbc.datasource;
/*   2:    */ 
/*   3:    */ import java.sql.Connection;
/*   4:    */ import java.sql.SQLException;
/*   5:    */ import javax.sql.DataSource;
/*   6:    */ import org.springframework.core.NamedThreadLocal;
/*   7:    */ import org.springframework.util.Assert;
/*   8:    */ import org.springframework.util.StringUtils;
/*   9:    */ 
/*  10:    */ public class UserCredentialsDataSourceAdapter
/*  11:    */   extends DelegatingDataSource
/*  12:    */ {
/*  13:    */   private String username;
/*  14:    */   private String password;
/*  15:    */   private final ThreadLocal<JdbcUserCredentials> threadBoundCredentials;
/*  16:    */   
/*  17:    */   public UserCredentialsDataSourceAdapter()
/*  18:    */   {
/*  19: 68 */     this.threadBoundCredentials = new NamedThreadLocal("Current JDBC user credentials");
/*  20:    */   }
/*  21:    */   
/*  22:    */   public void setUsername(String username)
/*  23:    */   {
/*  24: 81 */     this.username = username;
/*  25:    */   }
/*  26:    */   
/*  27:    */   public void setPassword(String password)
/*  28:    */   {
/*  29: 93 */     this.password = password;
/*  30:    */   }
/*  31:    */   
/*  32:    */   public void setCredentialsForCurrentThread(String username, String password)
/*  33:    */   {
/*  34:108 */     this.threadBoundCredentials.set(new JdbcUserCredentials(username, password, null));
/*  35:    */   }
/*  36:    */   
/*  37:    */   public void removeCredentialsFromCurrentThread()
/*  38:    */   {
/*  39:117 */     this.threadBoundCredentials.remove();
/*  40:    */   }
/*  41:    */   
/*  42:    */   public Connection getConnection()
/*  43:    */     throws SQLException
/*  44:    */   {
/*  45:130 */     JdbcUserCredentials threadCredentials = (JdbcUserCredentials)this.threadBoundCredentials.get();
/*  46:131 */     if (threadCredentials != null) {
/*  47:132 */       return doGetConnection(threadCredentials.username, threadCredentials.password);
/*  48:    */     }
/*  49:135 */     return doGetConnection(this.username, this.password);
/*  50:    */   }
/*  51:    */   
/*  52:    */   public Connection getConnection(String username, String password)
/*  53:    */     throws SQLException
/*  54:    */   {
/*  55:145 */     return doGetConnection(username, password);
/*  56:    */   }
/*  57:    */   
/*  58:    */   protected Connection doGetConnection(String username, String password)
/*  59:    */     throws SQLException
/*  60:    */   {
/*  61:160 */     Assert.state(getTargetDataSource() != null, "'targetDataSource' is required");
/*  62:161 */     if (StringUtils.hasLength(username)) {
/*  63:162 */       return getTargetDataSource().getConnection(username, password);
/*  64:    */     }
/*  65:165 */     return getTargetDataSource().getConnection();
/*  66:    */   }
/*  67:    */   
/*  68:    */   private static class JdbcUserCredentials
/*  69:    */   {
/*  70:    */     public final String username;
/*  71:    */     public final String password;
/*  72:    */     
/*  73:    */     private JdbcUserCredentials(String username, String password)
/*  74:    */     {
/*  75:180 */       this.username = username;
/*  76:181 */       this.password = password;
/*  77:    */     }
/*  78:    */     
/*  79:    */     public String toString()
/*  80:    */     {
/*  81:186 */       return "JdbcUserCredentials[username='" + this.username + "',password='" + this.password + "']";
/*  82:    */     }
/*  83:    */   }
/*  84:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.datasource.UserCredentialsDataSourceAdapter
 * JD-Core Version:    0.7.0.1
 */