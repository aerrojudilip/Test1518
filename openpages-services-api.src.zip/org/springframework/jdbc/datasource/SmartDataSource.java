package org.springframework.jdbc.datasource;

import java.sql.Connection;
import javax.sql.DataSource;

public abstract interface SmartDataSource
  extends DataSource
{
  public abstract boolean shouldClose(Connection paramConnection);
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.datasource.SmartDataSource
 * JD-Core Version:    0.7.0.1
 */