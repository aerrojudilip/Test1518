/*   1:    */ package org.springframework.jdbc.datasource;
/*   2:    */ 
/*   3:    */ import java.lang.reflect.InvocationHandler;
/*   4:    */ import java.lang.reflect.InvocationTargetException;
/*   5:    */ import java.lang.reflect.Method;
/*   6:    */ import java.lang.reflect.Proxy;
/*   7:    */ import java.sql.Connection;
/*   8:    */ import java.sql.SQLException;
/*   9:    */ import javax.sql.DataSource;
/*  10:    */ import org.apache.commons.logging.Log;
/*  11:    */ import org.apache.commons.logging.LogFactory;
/*  12:    */ import org.springframework.core.Constants;
/*  13:    */ 
/*  14:    */ public class LazyConnectionDataSourceProxy
/*  15:    */   extends DelegatingDataSource
/*  16:    */ {
/*  17: 85 */   private static final Constants constants = new Constants(Connection.class);
/*  18: 87 */   private static final Log logger = LogFactory.getLog(LazyConnectionDataSourceProxy.class);
/*  19:    */   private Boolean defaultAutoCommit;
/*  20:    */   private Integer defaultTransactionIsolation;
/*  21:    */   
/*  22:    */   public LazyConnectionDataSourceProxy() {}
/*  23:    */   
/*  24:    */   public LazyConnectionDataSourceProxy(DataSource targetDataSource)
/*  25:    */   {
/*  26:106 */     setTargetDataSource(targetDataSource);
/*  27:107 */     afterPropertiesSet();
/*  28:    */   }
/*  29:    */   
/*  30:    */   public void setDefaultAutoCommit(boolean defaultAutoCommit)
/*  31:    */   {
/*  32:120 */     this.defaultAutoCommit = Boolean.valueOf(defaultAutoCommit);
/*  33:    */   }
/*  34:    */   
/*  35:    */   public void setDefaultTransactionIsolation(int defaultTransactionIsolation)
/*  36:    */   {
/*  37:137 */     this.defaultTransactionIsolation = Integer.valueOf(defaultTransactionIsolation);
/*  38:    */   }
/*  39:    */   
/*  40:    */   public void setDefaultTransactionIsolationName(String constantName)
/*  41:    */   {
/*  42:151 */     setDefaultTransactionIsolation(constants.asNumber(constantName).intValue());
/*  43:    */   }
/*  44:    */   
/*  45:    */   public void afterPropertiesSet()
/*  46:    */   {
/*  47:157 */     super.afterPropertiesSet();
/*  48:161 */     if ((this.defaultAutoCommit == null) || (this.defaultTransactionIsolation == null)) {
/*  49:    */       try
/*  50:    */       {
/*  51:163 */         Connection con = getTargetDataSource().getConnection();
/*  52:    */         try
/*  53:    */         {
/*  54:165 */           checkDefaultConnectionProperties(con);
/*  55:    */         }
/*  56:    */         finally
/*  57:    */         {
/*  58:168 */           con.close();
/*  59:    */         }
/*  60:    */       }
/*  61:    */       catch (SQLException ex)
/*  62:    */       {
/*  63:172 */         logger.warn("Could not retrieve default auto-commit and transaction isolation settings", ex);
/*  64:    */       }
/*  65:    */     }
/*  66:    */   }
/*  67:    */   
/*  68:    */   protected synchronized void checkDefaultConnectionProperties(Connection con)
/*  69:    */     throws SQLException
/*  70:    */   {
/*  71:188 */     if (this.defaultAutoCommit == null) {
/*  72:189 */       this.defaultAutoCommit = Boolean.valueOf(con.getAutoCommit());
/*  73:    */     }
/*  74:191 */     if (this.defaultTransactionIsolation == null) {
/*  75:192 */       this.defaultTransactionIsolation = Integer.valueOf(con.getTransactionIsolation());
/*  76:    */     }
/*  77:    */   }
/*  78:    */   
/*  79:    */   protected Boolean defaultAutoCommit()
/*  80:    */   {
/*  81:200 */     return this.defaultAutoCommit;
/*  82:    */   }
/*  83:    */   
/*  84:    */   protected Integer defaultTransactionIsolation()
/*  85:    */   {
/*  86:207 */     return this.defaultTransactionIsolation;
/*  87:    */   }
/*  88:    */   
/*  89:    */   public Connection getConnection()
/*  90:    */     throws SQLException
/*  91:    */   {
/*  92:221 */     return (Connection)Proxy.newProxyInstance(ConnectionProxy.class.getClassLoader(), new Class[] { ConnectionProxy.class }, new LazyConnectionInvocationHandler());
/*  93:    */   }
/*  94:    */   
/*  95:    */   public Connection getConnection(String username, String password)
/*  96:    */     throws SQLException
/*  97:    */   {
/*  98:239 */     return (Connection)Proxy.newProxyInstance(ConnectionProxy.class.getClassLoader(), new Class[] { ConnectionProxy.class }, new LazyConnectionInvocationHandler(username, password));
/*  99:    */   }
/* 100:    */   
/* 101:    */   private class LazyConnectionInvocationHandler
/* 102:    */     implements InvocationHandler
/* 103:    */   {
/* 104:    */     private String username;
/* 105:    */     private String password;
/* 106:256 */     private Boolean readOnly = Boolean.FALSE;
/* 107:    */     private Integer transactionIsolation;
/* 108:    */     private Boolean autoCommit;
/* 109:262 */     private boolean closed = false;
/* 110:    */     private Connection target;
/* 111:    */     
/* 112:    */     public LazyConnectionInvocationHandler()
/* 113:    */     {
/* 114:267 */       this.autoCommit = LazyConnectionDataSourceProxy.this.defaultAutoCommit();
/* 115:268 */       this.transactionIsolation = LazyConnectionDataSourceProxy.this.defaultTransactionIsolation();
/* 116:    */     }
/* 117:    */     
/* 118:    */     public LazyConnectionInvocationHandler(String username, String password)
/* 119:    */     {
/* 120:272 */       this();
/* 121:273 */       this.username = username;
/* 122:274 */       this.password = password;
/* 123:    */     }
/* 124:    */     
/* 125:    */     public Object invoke(Object proxy, Method method, Object[] args)
/* 126:    */       throws Throwable
/* 127:    */     {
/* 128:280 */       if (method.getName().equals("equals")) {
/* 129:283 */         return Boolean.valueOf(proxy == args[0]);
/* 130:    */       }
/* 131:285 */       if (method.getName().equals("hashCode")) {
/* 132:289 */         return Integer.valueOf(System.identityHashCode(proxy));
/* 133:    */       }
/* 134:291 */       if (method.getName().equals("unwrap"))
/* 135:    */       {
/* 136:292 */         if (((Class)args[0]).isInstance(proxy)) {
/* 137:293 */           return proxy;
/* 138:    */         }
/* 139:    */       }
/* 140:296 */       else if (method.getName().equals("isWrapperFor"))
/* 141:    */       {
/* 142:297 */         if (((Class)args[0]).isInstance(proxy)) {
/* 143:298 */           return Boolean.valueOf(true);
/* 144:    */         }
/* 145:    */       }
/* 146:301 */       else if (method.getName().equals("getTargetConnection")) {
/* 147:303 */         return getTargetConnection(method);
/* 148:    */       }
/* 149:306 */       if (!hasTargetConnection())
/* 150:    */       {
/* 151:311 */         if (method.getName().equals("toString")) {
/* 152:312 */           return "Lazy Connection proxy for target DataSource [" + LazyConnectionDataSourceProxy.this.getTargetDataSource() + "]";
/* 153:    */         }
/* 154:314 */         if (method.getName().equals("isReadOnly")) {
/* 155:315 */           return this.readOnly;
/* 156:    */         }
/* 157:317 */         if (method.getName().equals("setReadOnly"))
/* 158:    */         {
/* 159:318 */           this.readOnly = ((Boolean)args[0]);
/* 160:319 */           return null;
/* 161:    */         }
/* 162:321 */         if (method.getName().equals("getTransactionIsolation"))
/* 163:    */         {
/* 164:322 */           if (this.transactionIsolation != null) {
/* 165:323 */             return this.transactionIsolation;
/* 166:    */           }
/* 167:    */         }
/* 168:    */         else
/* 169:    */         {
/* 170:328 */           if (method.getName().equals("setTransactionIsolation"))
/* 171:    */           {
/* 172:329 */             this.transactionIsolation = ((Integer)args[0]);
/* 173:330 */             return null;
/* 174:    */           }
/* 175:332 */           if (method.getName().equals("getAutoCommit"))
/* 176:    */           {
/* 177:333 */             if (this.autoCommit != null) {
/* 178:334 */               return this.autoCommit;
/* 179:    */             }
/* 180:    */           }
/* 181:    */           else
/* 182:    */           {
/* 183:339 */             if (method.getName().equals("setAutoCommit"))
/* 184:    */             {
/* 185:340 */               this.autoCommit = ((Boolean)args[0]);
/* 186:341 */               return null;
/* 187:    */             }
/* 188:343 */             if (method.getName().equals("commit")) {
/* 189:345 */               return null;
/* 190:    */             }
/* 191:347 */             if (method.getName().equals("rollback")) {
/* 192:349 */               return null;
/* 193:    */             }
/* 194:351 */             if (method.getName().equals("getWarnings")) {
/* 195:352 */               return null;
/* 196:    */             }
/* 197:354 */             if (method.getName().equals("clearWarnings")) {
/* 198:355 */               return null;
/* 199:    */             }
/* 200:357 */             if (method.getName().equals("close"))
/* 201:    */             {
/* 202:359 */               this.closed = true;
/* 203:360 */               return null;
/* 204:    */             }
/* 205:362 */             if (method.getName().equals("isClosed")) {
/* 206:363 */               return Boolean.valueOf(this.closed);
/* 207:    */             }
/* 208:365 */             if (this.closed) {
/* 209:368 */               throw new SQLException("Illegal operation: connection is closed");
/* 210:    */             }
/* 211:    */           }
/* 212:    */         }
/* 213:    */       }
/* 214:    */       try
/* 215:    */       {
/* 216:376 */         return method.invoke(getTargetConnection(method), args);
/* 217:    */       }
/* 218:    */       catch (InvocationTargetException ex)
/* 219:    */       {
/* 220:379 */         throw ex.getTargetException();
/* 221:    */       }
/* 222:    */     }
/* 223:    */     
/* 224:    */     private boolean hasTargetConnection()
/* 225:    */     {
/* 226:387 */       return this.target != null;
/* 227:    */     }
/* 228:    */     
/* 229:    */     private Connection getTargetConnection(Method operation)
/* 230:    */       throws SQLException
/* 231:    */     {
/* 232:394 */       if (this.target == null)
/* 233:    */       {
/* 234:396 */         if (LazyConnectionDataSourceProxy.logger.isDebugEnabled()) {
/* 235:397 */           LazyConnectionDataSourceProxy.logger.debug("Connecting to database for operation '" + operation.getName() + "'");
/* 236:    */         }
/* 237:401 */         this.target = (this.username != null ? LazyConnectionDataSourceProxy.this.getTargetDataSource().getConnection(this.username, this.password) : LazyConnectionDataSourceProxy.this.getTargetDataSource().getConnection());
/* 238:    */         
/* 239:    */ 
/* 240:    */ 
/* 241:    */ 
/* 242:406 */         LazyConnectionDataSourceProxy.this.checkDefaultConnectionProperties(this.target);
/* 243:409 */         if (this.readOnly.booleanValue()) {
/* 244:410 */           this.target.setReadOnly(this.readOnly.booleanValue());
/* 245:    */         }
/* 246:412 */         if ((this.transactionIsolation != null) && (!this.transactionIsolation.equals(LazyConnectionDataSourceProxy.this.defaultTransactionIsolation()))) {
/* 247:414 */           this.target.setTransactionIsolation(this.transactionIsolation.intValue());
/* 248:    */         }
/* 249:416 */         if ((this.autoCommit != null) && (this.autoCommit.booleanValue() != this.target.getAutoCommit())) {
/* 250:417 */           this.target.setAutoCommit(this.autoCommit.booleanValue());
/* 251:    */         }
/* 252:    */       }
/* 253:423 */       else if (LazyConnectionDataSourceProxy.logger.isDebugEnabled())
/* 254:    */       {
/* 255:424 */         LazyConnectionDataSourceProxy.logger.debug("Using existing database connection for operation '" + operation.getName() + "'");
/* 256:    */       }
/* 257:428 */       return this.target;
/* 258:    */     }
/* 259:    */   }
/* 260:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.datasource.LazyConnectionDataSourceProxy
 * JD-Core Version:    0.7.0.1
 */