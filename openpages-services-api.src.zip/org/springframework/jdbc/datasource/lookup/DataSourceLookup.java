package org.springframework.jdbc.datasource.lookup;

import javax.sql.DataSource;

public abstract interface DataSourceLookup
{
  public abstract DataSource getDataSource(String paramString)
    throws DataSourceLookupFailureException;
}


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.datasource.lookup.DataSourceLookup
 * JD-Core Version:    0.7.0.1
 */