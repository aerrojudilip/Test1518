/*   1:    */ package org.springframework.jdbc.datasource.lookup;
/*   2:    */ 
/*   3:    */ import java.sql.Connection;
/*   4:    */ import java.sql.SQLException;
/*   5:    */ import java.util.HashMap;
/*   6:    */ import java.util.Map;
/*   7:    */ import java.util.Map.Entry;
/*   8:    */ import javax.sql.DataSource;
/*   9:    */ import org.springframework.beans.factory.InitializingBean;
/*  10:    */ import org.springframework.jdbc.datasource.AbstractDataSource;
/*  11:    */ import org.springframework.util.Assert;
/*  12:    */ 
/*  13:    */ public abstract class AbstractRoutingDataSource
/*  14:    */   extends AbstractDataSource
/*  15:    */   implements InitializingBean
/*  16:    */ {
/*  17:    */   private Map<Object, Object> targetDataSources;
/*  18:    */   private Object defaultTargetDataSource;
/*  19: 46 */   private boolean lenientFallback = true;
/*  20: 48 */   private DataSourceLookup dataSourceLookup = new JndiDataSourceLookup();
/*  21:    */   private Map<Object, DataSource> resolvedDataSources;
/*  22:    */   private DataSource resolvedDefaultDataSource;
/*  23:    */   
/*  24:    */   public void setTargetDataSources(Map<Object, Object> targetDataSources)
/*  25:    */   {
/*  26: 66 */     this.targetDataSources = targetDataSources;
/*  27:    */   }
/*  28:    */   
/*  29:    */   public void setDefaultTargetDataSource(Object defaultTargetDataSource)
/*  30:    */   {
/*  31: 79 */     this.defaultTargetDataSource = defaultTargetDataSource;
/*  32:    */   }
/*  33:    */   
/*  34:    */   public void setLenientFallback(boolean lenientFallback)
/*  35:    */   {
/*  36: 96 */     this.lenientFallback = lenientFallback;
/*  37:    */   }
/*  38:    */   
/*  39:    */   public void setDataSourceLookup(DataSourceLookup dataSourceLookup)
/*  40:    */   {
/*  41:106 */     this.dataSourceLookup = (dataSourceLookup != null ? dataSourceLookup : new JndiDataSourceLookup());
/*  42:    */   }
/*  43:    */   
/*  44:    */   public void afterPropertiesSet()
/*  45:    */   {
/*  46:111 */     if (this.targetDataSources == null) {
/*  47:112 */       throw new IllegalArgumentException("Property 'targetDataSources' is required");
/*  48:    */     }
/*  49:114 */     this.resolvedDataSources = new HashMap(this.targetDataSources.size());
/*  50:115 */     for (Map.Entry entry : this.targetDataSources.entrySet())
/*  51:    */     {
/*  52:116 */       Object lookupKey = resolveSpecifiedLookupKey(entry.getKey());
/*  53:117 */       DataSource dataSource = resolveSpecifiedDataSource(entry.getValue());
/*  54:118 */       this.resolvedDataSources.put(lookupKey, dataSource);
/*  55:    */     }
/*  56:120 */     if (this.defaultTargetDataSource != null) {
/*  57:121 */       this.resolvedDefaultDataSource = resolveSpecifiedDataSource(this.defaultTargetDataSource);
/*  58:    */     }
/*  59:    */   }
/*  60:    */   
/*  61:    */   protected Object resolveSpecifiedLookupKey(Object lookupKey)
/*  62:    */   {
/*  63:135 */     return lookupKey;
/*  64:    */   }
/*  65:    */   
/*  66:    */   protected DataSource resolveSpecifiedDataSource(Object dataSource)
/*  67:    */     throws IllegalArgumentException
/*  68:    */   {
/*  69:148 */     if ((dataSource instanceof DataSource)) {
/*  70:149 */       return (DataSource)dataSource;
/*  71:    */     }
/*  72:151 */     if ((dataSource instanceof String)) {
/*  73:152 */       return this.dataSourceLookup.getDataSource((String)dataSource);
/*  74:    */     }
/*  75:155 */     throw new IllegalArgumentException("Illegal data source value - only [javax.sql.DataSource] and String supported: " + dataSource);
/*  76:    */   }
/*  77:    */   
/*  78:    */   public Connection getConnection()
/*  79:    */     throws SQLException
/*  80:    */   {
/*  81:162 */     return determineTargetDataSource().getConnection();
/*  82:    */   }
/*  83:    */   
/*  84:    */   public Connection getConnection(String username, String password)
/*  85:    */     throws SQLException
/*  86:    */   {
/*  87:166 */     return determineTargetDataSource().getConnection(username, password);
/*  88:    */   }
/*  89:    */   
/*  90:    */   public <T> T unwrap(Class<T> iface)
/*  91:    */     throws SQLException
/*  92:    */   {
/*  93:172 */     if (iface.isInstance(this)) {
/*  94:173 */       return this;
/*  95:    */     }
/*  96:175 */     return determineTargetDataSource().unwrap(iface);
/*  97:    */   }
/*  98:    */   
/*  99:    */   public boolean isWrapperFor(Class<?> iface)
/* 100:    */     throws SQLException
/* 101:    */   {
/* 102:180 */     return (iface.isInstance(this)) || (determineTargetDataSource().isWrapperFor(iface));
/* 103:    */   }
/* 104:    */   
/* 105:    */   protected DataSource determineTargetDataSource()
/* 106:    */   {
/* 107:192 */     Assert.notNull(this.resolvedDataSources, "DataSource router not initialized");
/* 108:193 */     Object lookupKey = determineCurrentLookupKey();
/* 109:194 */     DataSource dataSource = (DataSource)this.resolvedDataSources.get(lookupKey);
/* 110:195 */     if ((dataSource == null) && ((this.lenientFallback) || (lookupKey == null))) {
/* 111:196 */       dataSource = this.resolvedDefaultDataSource;
/* 112:    */     }
/* 113:198 */     if (dataSource == null) {
/* 114:199 */       throw new IllegalStateException("Cannot determine target DataSource for lookup key [" + lookupKey + "]");
/* 115:    */     }
/* 116:201 */     return dataSource;
/* 117:    */   }
/* 118:    */   
/* 119:    */   protected abstract Object determineCurrentLookupKey();
/* 120:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource
 * JD-Core Version:    0.7.0.1
 */