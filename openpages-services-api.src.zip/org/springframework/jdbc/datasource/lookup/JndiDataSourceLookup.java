/*  1:   */ package org.springframework.jdbc.datasource.lookup;
/*  2:   */ 
/*  3:   */ import javax.naming.NamingException;
/*  4:   */ import javax.sql.DataSource;
/*  5:   */ import org.springframework.jndi.JndiLocatorSupport;
/*  6:   */ 
/*  7:   */ public class JndiDataSourceLookup
/*  8:   */   extends JndiLocatorSupport
/*  9:   */   implements DataSourceLookup
/* 10:   */ {
/* 11:   */   public JndiDataSourceLookup()
/* 12:   */   {
/* 13:39 */     setResourceRef(true);
/* 14:   */   }
/* 15:   */   
/* 16:   */   public DataSource getDataSource(String dataSourceName)
/* 17:   */     throws DataSourceLookupFailureException
/* 18:   */   {
/* 19:   */     try
/* 20:   */     {
/* 21:44 */       return (DataSource)lookup(dataSourceName, DataSource.class);
/* 22:   */     }
/* 23:   */     catch (NamingException ex)
/* 24:   */     {
/* 25:47 */       throw new DataSourceLookupFailureException("Failed to look up JNDI DataSource with name '" + dataSourceName + "'", ex);
/* 26:   */     }
/* 27:   */   }
/* 28:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup
 * JD-Core Version:    0.7.0.1
 */