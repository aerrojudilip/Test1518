/*   1:    */ package org.springframework.jdbc.datasource;
/*   2:    */ 
/*   3:    */ import java.lang.reflect.Method;
/*   4:    */ import java.sql.Connection;
/*   5:    */ import java.sql.SQLException;
/*   6:    */ import org.apache.commons.logging.Log;
/*   7:    */ import org.apache.commons.logging.LogFactory;
/*   8:    */ import org.springframework.util.ReflectionUtils;
/*   9:    */ import org.springframework.util.StringUtils;
/*  10:    */ 
/*  11:    */ public class WebSphereDataSourceAdapter
/*  12:    */   extends IsolationLevelDataSourceAdapter
/*  13:    */ {
/*  14: 70 */   protected final Log logger = LogFactory.getLog(getClass());
/*  15:    */   private Class wsDataSourceClass;
/*  16:    */   private Method newJdbcConnSpecMethod;
/*  17:    */   private Method wsDataSourceGetConnectionMethod;
/*  18:    */   private Method setTransactionIsolationMethod;
/*  19:    */   private Method setReadOnlyMethod;
/*  20:    */   private Method setUserNameMethod;
/*  21:    */   private Method setPasswordMethod;
/*  22:    */   
/*  23:    */   public WebSphereDataSourceAdapter()
/*  24:    */   {
/*  25:    */     try
/*  26:    */     {
/*  27: 93 */       this.wsDataSourceClass = getClass().getClassLoader().loadClass("com.ibm.websphere.rsadapter.WSDataSource");
/*  28: 94 */       Class jdbcConnSpecClass = getClass().getClassLoader().loadClass("com.ibm.websphere.rsadapter.JDBCConnectionSpec");
/*  29: 95 */       Class wsrraFactoryClass = getClass().getClassLoader().loadClass("com.ibm.websphere.rsadapter.WSRRAFactory");
/*  30: 96 */       this.newJdbcConnSpecMethod = wsrraFactoryClass.getMethod("createJDBCConnectionSpec", (Class[])null);
/*  31: 97 */       this.wsDataSourceGetConnectionMethod = this.wsDataSourceClass.getMethod("getConnection", new Class[] { jdbcConnSpecClass });
/*  32:    */       
/*  33: 99 */       this.setTransactionIsolationMethod = jdbcConnSpecClass.getMethod("setTransactionIsolation", new Class[] { Integer.TYPE });
/*  34:    */       
/*  35:101 */       this.setReadOnlyMethod = jdbcConnSpecClass.getMethod("setReadOnly", new Class[] { Boolean.class });
/*  36:102 */       this.setUserNameMethod = jdbcConnSpecClass.getMethod("setUserName", new Class[] { String.class });
/*  37:103 */       this.setPasswordMethod = jdbcConnSpecClass.getMethod("setPassword", new Class[] { String.class });
/*  38:    */     }
/*  39:    */     catch (Exception ex)
/*  40:    */     {
/*  41:106 */       throw new IllegalStateException("Could not initialize WebSphereDataSourceAdapter because WebSphere API classes are not available: " + ex);
/*  42:    */     }
/*  43:    */   }
/*  44:    */   
/*  45:    */   public void afterPropertiesSet()
/*  46:    */   {
/*  47:117 */     super.afterPropertiesSet();
/*  48:119 */     if (!this.wsDataSourceClass.isInstance(getTargetDataSource())) {
/*  49:120 */       throw new IllegalStateException("Specified 'targetDataSource' is not a WebSphere WSDataSource: " + getTargetDataSource());
/*  50:    */     }
/*  51:    */   }
/*  52:    */   
/*  53:    */   protected Connection doGetConnection(String username, String password)
/*  54:    */     throws SQLException
/*  55:    */   {
/*  56:135 */     Object connSpec = createConnectionSpec(getCurrentIsolationLevel(), getCurrentReadOnlyFlag(), username, password);
/*  57:137 */     if (this.logger.isDebugEnabled()) {
/*  58:138 */       this.logger.debug("Obtaining JDBC Connection from WebSphere DataSource [" + getTargetDataSource() + "], using ConnectionSpec [" + connSpec + "]");
/*  59:    */     }
/*  60:142 */     return (Connection)ReflectionUtils.invokeJdbcMethod(this.wsDataSourceGetConnectionMethod, getTargetDataSource(), new Object[] { connSpec });
/*  61:    */   }
/*  62:    */   
/*  63:    */   protected Object createConnectionSpec(Integer isolationLevel, Boolean readOnlyFlag, String username, String password)
/*  64:    */     throws SQLException
/*  65:    */   {
/*  66:162 */     Object connSpec = ReflectionUtils.invokeJdbcMethod(this.newJdbcConnSpecMethod, null);
/*  67:163 */     if (isolationLevel != null) {
/*  68:164 */       ReflectionUtils.invokeJdbcMethod(this.setTransactionIsolationMethod, connSpec, new Object[] { isolationLevel });
/*  69:    */     }
/*  70:166 */     if (readOnlyFlag != null) {
/*  71:167 */       ReflectionUtils.invokeJdbcMethod(this.setReadOnlyMethod, connSpec, new Object[] { readOnlyFlag });
/*  72:    */     }
/*  73:171 */     if (StringUtils.hasLength(username))
/*  74:    */     {
/*  75:172 */       ReflectionUtils.invokeJdbcMethod(this.setUserNameMethod, connSpec, new Object[] { username });
/*  76:173 */       ReflectionUtils.invokeJdbcMethod(this.setPasswordMethod, connSpec, new Object[] { password });
/*  77:    */     }
/*  78:175 */     return connSpec;
/*  79:    */   }
/*  80:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.datasource.WebSphereDataSourceAdapter
 * JD-Core Version:    0.7.0.1
 */