/*  1:   */ package org.springframework.jdbc;
/*  2:   */ 
/*  3:   */ import java.sql.SQLException;
/*  4:   */ import org.springframework.dao.UncategorizedDataAccessException;
/*  5:   */ 
/*  6:   */ public class UncategorizedSQLException
/*  7:   */   extends UncategorizedDataAccessException
/*  8:   */ {
/*  9:   */   private final String sql;
/* 10:   */   
/* 11:   */   public UncategorizedSQLException(String task, String sql, SQLException ex)
/* 12:   */   {
/* 13:43 */     super(task + "; uncategorized SQLException for SQL [" + sql + "]; SQL state [" + ex.getSQLState() + "]; error code [" + ex.getErrorCode() + "]; " + ex.getMessage(), ex);
/* 14:   */     
/* 15:45 */     this.sql = sql;
/* 16:   */   }
/* 17:   */   
/* 18:   */   public SQLException getSQLException()
/* 19:   */   {
/* 20:53 */     return (SQLException)getCause();
/* 21:   */   }
/* 22:   */   
/* 23:   */   public String getSql()
/* 24:   */   {
/* 25:60 */     return this.sql;
/* 26:   */   }
/* 27:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.UncategorizedSQLException
 * JD-Core Version:    0.7.0.1
 */