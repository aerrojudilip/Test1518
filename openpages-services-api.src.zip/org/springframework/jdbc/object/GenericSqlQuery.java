/*  1:   */ package org.springframework.jdbc.object;
/*  2:   */ 
/*  3:   */ import java.util.Map;
/*  4:   */ import org.springframework.dao.InvalidDataAccessResourceUsageException;
/*  5:   */ import org.springframework.jdbc.core.RowMapper;
/*  6:   */ import org.springframework.util.Assert;
/*  7:   */ 
/*  8:   */ public class GenericSqlQuery
/*  9:   */   extends SqlQuery
/* 10:   */ {
/* 11:   */   Class rowMapperClass;
/* 12:   */   RowMapper rowMapper;
/* 13:   */   
/* 14:   */   public void setRowMapperClass(Class rowMapperClass)
/* 15:   */     throws IllegalAccessException, InstantiationException
/* 16:   */   {
/* 17:33 */     this.rowMapperClass = rowMapperClass;
/* 18:34 */     if (!RowMapper.class.isAssignableFrom(rowMapperClass)) {
/* 19:35 */       throw new IllegalStateException("The specified class '" + rowMapperClass.getName() + " is not a sub class of " + "'org.springframework.jdbc.core.RowMapper'");
/* 20:   */     }
/* 21:   */   }
/* 22:   */   
/* 23:   */   public void afterPropertiesSet()
/* 24:   */   {
/* 25:41 */     super.afterPropertiesSet();
/* 26:42 */     Assert.notNull(this.rowMapperClass, "The 'rowMapperClass' property is required");
/* 27:   */   }
/* 28:   */   
/* 29:   */   protected RowMapper newRowMapper(Object[] parameters, Map context)
/* 30:   */   {
/* 31:   */     try
/* 32:   */     {
/* 33:47 */       return (RowMapper)this.rowMapperClass.newInstance();
/* 34:   */     }
/* 35:   */     catch (InstantiationException e)
/* 36:   */     {
/* 37:50 */       throw new InvalidDataAccessResourceUsageException("Unable to instantiate RowMapper", e);
/* 38:   */     }
/* 39:   */     catch (IllegalAccessException e)
/* 40:   */     {
/* 41:53 */       throw new InvalidDataAccessResourceUsageException("Unable to instantiate RowMapper", e);
/* 42:   */     }
/* 43:   */   }
/* 44:   */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.object.GenericSqlQuery
 * JD-Core Version:    0.7.0.1
 */