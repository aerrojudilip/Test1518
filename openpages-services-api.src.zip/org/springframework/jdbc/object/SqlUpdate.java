/*   1:    */ package org.springframework.jdbc.object;
/*   2:    */ 
/*   3:    */ import java.util.Map;
/*   4:    */ import javax.sql.DataSource;
/*   5:    */ import org.springframework.dao.DataAccessException;
/*   6:    */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*   7:    */ import org.springframework.jdbc.JdbcUpdateAffectedIncorrectNumberOfRowsException;
/*   8:    */ import org.springframework.jdbc.core.JdbcTemplate;
/*   9:    */ import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
/*  10:    */ import org.springframework.jdbc.core.namedparam.NamedParameterUtils;
/*  11:    */ import org.springframework.jdbc.core.namedparam.ParsedSql;
/*  12:    */ import org.springframework.jdbc.support.KeyHolder;
/*  13:    */ 
/*  14:    */ public class SqlUpdate
/*  15:    */   extends SqlOperation
/*  16:    */ {
/*  17: 56 */   private int maxRowsAffected = 0;
/*  18: 62 */   private int requiredRowsAffected = 0;
/*  19:    */   
/*  20:    */   public SqlUpdate() {}
/*  21:    */   
/*  22:    */   public SqlUpdate(DataSource ds, String sql)
/*  23:    */   {
/*  24: 80 */     setDataSource(ds);
/*  25: 81 */     setSql(sql);
/*  26:    */   }
/*  27:    */   
/*  28:    */   public SqlUpdate(DataSource ds, String sql, int[] types)
/*  29:    */   {
/*  30: 94 */     setDataSource(ds);
/*  31: 95 */     setSql(sql);
/*  32: 96 */     setTypes(types);
/*  33:    */   }
/*  34:    */   
/*  35:    */   public SqlUpdate(DataSource ds, String sql, int[] types, int maxRowsAffected)
/*  36:    */   {
/*  37:112 */     setDataSource(ds);
/*  38:113 */     setSql(sql);
/*  39:114 */     setTypes(types);
/*  40:115 */     this.maxRowsAffected = maxRowsAffected;
/*  41:    */   }
/*  42:    */   
/*  43:    */   public void setMaxRowsAffected(int maxRowsAffected)
/*  44:    */   {
/*  45:126 */     this.maxRowsAffected = maxRowsAffected;
/*  46:    */   }
/*  47:    */   
/*  48:    */   public void setRequiredRowsAffected(int requiredRowsAffected)
/*  49:    */   {
/*  50:138 */     this.requiredRowsAffected = requiredRowsAffected;
/*  51:    */   }
/*  52:    */   
/*  53:    */   protected void checkRowsAffected(int rowsAffected)
/*  54:    */     throws JdbcUpdateAffectedIncorrectNumberOfRowsException
/*  55:    */   {
/*  56:151 */     if ((this.maxRowsAffected > 0) && (rowsAffected > this.maxRowsAffected)) {
/*  57:152 */       throw new JdbcUpdateAffectedIncorrectNumberOfRowsException(getSql(), this.maxRowsAffected, rowsAffected);
/*  58:    */     }
/*  59:154 */     if ((this.requiredRowsAffected > 0) && (rowsAffected != this.requiredRowsAffected)) {
/*  60:155 */       throw new JdbcUpdateAffectedIncorrectNumberOfRowsException(getSql(), this.requiredRowsAffected, rowsAffected);
/*  61:    */     }
/*  62:    */   }
/*  63:    */   
/*  64:    */   public int update(Object... params)
/*  65:    */     throws DataAccessException
/*  66:    */   {
/*  67:167 */     validateParameters(params);
/*  68:168 */     int rowsAffected = getJdbcTemplate().update(newPreparedStatementCreator(params));
/*  69:169 */     checkRowsAffected(rowsAffected);
/*  70:170 */     return rowsAffected;
/*  71:    */   }
/*  72:    */   
/*  73:    */   public int update(Object[] params, KeyHolder generatedKeyHolder)
/*  74:    */     throws DataAccessException
/*  75:    */   {
/*  76:181 */     if ((!isReturnGeneratedKeys()) && (getGeneratedKeysColumnNames() == null)) {
/*  77:182 */       throw new InvalidDataAccessApiUsageException("The update method taking a KeyHolder should only be used when generated keys have been configured by calling either 'setReturnGeneratedKeys' or 'setGeneratedKeysColumnNames'.");
/*  78:    */     }
/*  79:187 */     validateParameters(params);
/*  80:188 */     int rowsAffected = getJdbcTemplate().update(newPreparedStatementCreator(params), generatedKeyHolder);
/*  81:189 */     checkRowsAffected(rowsAffected);
/*  82:190 */     return rowsAffected;
/*  83:    */   }
/*  84:    */   
/*  85:    */   public int update()
/*  86:    */     throws DataAccessException
/*  87:    */   {
/*  88:197 */     return update((Object[])null);
/*  89:    */   }
/*  90:    */   
/*  91:    */   public int update(int p1)
/*  92:    */     throws DataAccessException
/*  93:    */   {
/*  94:204 */     return update(new Object[] { Integer.valueOf(p1) });
/*  95:    */   }
/*  96:    */   
/*  97:    */   public int update(int p1, int p2)
/*  98:    */     throws DataAccessException
/*  99:    */   {
/* 100:211 */     return update(new Object[] { Integer.valueOf(p1), Integer.valueOf(p2) });
/* 101:    */   }
/* 102:    */   
/* 103:    */   public int update(long p1)
/* 104:    */     throws DataAccessException
/* 105:    */   {
/* 106:218 */     return update(new Object[] { Long.valueOf(p1) });
/* 107:    */   }
/* 108:    */   
/* 109:    */   public int update(long p1, long p2)
/* 110:    */     throws DataAccessException
/* 111:    */   {
/* 112:225 */     return update(new Object[] { Long.valueOf(p1), Long.valueOf(p2) });
/* 113:    */   }
/* 114:    */   
/* 115:    */   public int update(String p)
/* 116:    */     throws DataAccessException
/* 117:    */   {
/* 118:232 */     return update(new Object[] { p });
/* 119:    */   }
/* 120:    */   
/* 121:    */   public int update(String p1, String p2)
/* 122:    */     throws DataAccessException
/* 123:    */   {
/* 124:239 */     return update(new Object[] { p1, p2 });
/* 125:    */   }
/* 126:    */   
/* 127:    */   public int updateByNamedParam(Map<String, ?> paramMap)
/* 128:    */     throws DataAccessException
/* 129:    */   {
/* 130:250 */     validateNamedParameters(paramMap);
/* 131:251 */     ParsedSql parsedSql = getParsedSql();
/* 132:252 */     MapSqlParameterSource paramSource = new MapSqlParameterSource(paramMap);
/* 133:253 */     String sqlToUse = NamedParameterUtils.substituteNamedParameters(parsedSql, paramSource);
/* 134:254 */     Object[] params = NamedParameterUtils.buildValueArray(parsedSql, paramSource, getDeclaredParameters());
/* 135:255 */     int rowsAffected = getJdbcTemplate().update(newPreparedStatementCreator(sqlToUse, params));
/* 136:256 */     checkRowsAffected(rowsAffected);
/* 137:257 */     return rowsAffected;
/* 138:    */   }
/* 139:    */   
/* 140:    */   public int updateByNamedParam(Map<String, ?> paramMap, KeyHolder generatedKeyHolder)
/* 141:    */     throws DataAccessException
/* 142:    */   {
/* 143:269 */     validateNamedParameters(paramMap);
/* 144:270 */     ParsedSql parsedSql = getParsedSql();
/* 145:271 */     MapSqlParameterSource paramSource = new MapSqlParameterSource(paramMap);
/* 146:272 */     String sqlToUse = NamedParameterUtils.substituteNamedParameters(parsedSql, paramSource);
/* 147:273 */     Object[] params = NamedParameterUtils.buildValueArray(parsedSql, paramSource, getDeclaredParameters());
/* 148:274 */     int rowsAffected = getJdbcTemplate().update(newPreparedStatementCreator(sqlToUse, params), generatedKeyHolder);
/* 149:275 */     checkRowsAffected(rowsAffected);
/* 150:276 */     return rowsAffected;
/* 151:    */   }
/* 152:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.object.SqlUpdate
 * JD-Core Version:    0.7.0.1
 */