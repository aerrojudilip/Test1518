/*   1:    */ package org.springframework.jdbc.object;
/*   2:    */ 
/*   3:    */ import java.util.Arrays;
/*   4:    */ import java.util.Collections;
/*   5:    */ import java.util.LinkedList;
/*   6:    */ import java.util.List;
/*   7:    */ import java.util.Map;
/*   8:    */ import javax.sql.DataSource;
/*   9:    */ import org.apache.commons.logging.Log;
/*  10:    */ import org.apache.commons.logging.LogFactory;
/*  11:    */ import org.springframework.beans.factory.InitializingBean;
/*  12:    */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*  13:    */ import org.springframework.jdbc.core.JdbcTemplate;
/*  14:    */ import org.springframework.jdbc.core.SqlParameter;
/*  15:    */ 
/*  16:    */ public abstract class RdbmsOperation
/*  17:    */   implements InitializingBean
/*  18:    */ {
/*  19: 62 */   protected final Log logger = LogFactory.getLog(getClass());
/*  20: 65 */   private JdbcTemplate jdbcTemplate = new JdbcTemplate();
/*  21: 67 */   private int resultSetType = 1003;
/*  22: 69 */   private boolean updatableResults = false;
/*  23: 71 */   private boolean returnGeneratedKeys = false;
/*  24: 73 */   private String[] generatedKeysColumnNames = null;
/*  25:    */   private String sql;
/*  26: 77 */   private final List<SqlParameter> declaredParameters = new LinkedList();
/*  27:    */   private boolean compiled;
/*  28:    */   
/*  29:    */   public void setJdbcTemplate(JdbcTemplate jdbcTemplate)
/*  30:    */   {
/*  31: 94 */     if (jdbcTemplate == null) {
/*  32: 95 */       throw new IllegalArgumentException("jdbcTemplate must not be null");
/*  33:    */     }
/*  34: 97 */     this.jdbcTemplate = jdbcTemplate;
/*  35:    */   }
/*  36:    */   
/*  37:    */   public JdbcTemplate getJdbcTemplate()
/*  38:    */   {
/*  39:104 */     return this.jdbcTemplate;
/*  40:    */   }
/*  41:    */   
/*  42:    */   public void setDataSource(DataSource dataSource)
/*  43:    */   {
/*  44:112 */     this.jdbcTemplate.setDataSource(dataSource);
/*  45:    */   }
/*  46:    */   
/*  47:    */   public void setFetchSize(int fetchSize)
/*  48:    */   {
/*  49:124 */     this.jdbcTemplate.setFetchSize(fetchSize);
/*  50:    */   }
/*  51:    */   
/*  52:    */   public void setMaxRows(int maxRows)
/*  53:    */   {
/*  54:135 */     this.jdbcTemplate.setMaxRows(maxRows);
/*  55:    */   }
/*  56:    */   
/*  57:    */   public void setQueryTimeout(int queryTimeout)
/*  58:    */   {
/*  59:146 */     this.jdbcTemplate.setQueryTimeout(queryTimeout);
/*  60:    */   }
/*  61:    */   
/*  62:    */   public void setResultSetType(int resultSetType)
/*  63:    */   {
/*  64:158 */     this.resultSetType = resultSetType;
/*  65:    */   }
/*  66:    */   
/*  67:    */   public int getResultSetType()
/*  68:    */   {
/*  69:165 */     return this.resultSetType;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public void setUpdatableResults(boolean updatableResults)
/*  73:    */   {
/*  74:174 */     if (isCompiled()) {
/*  75:175 */       throw new InvalidDataAccessApiUsageException("The updateableResults flag must be set before the operation is compiled");
/*  76:    */     }
/*  77:178 */     this.updatableResults = updatableResults;
/*  78:    */   }
/*  79:    */   
/*  80:    */   public boolean isUpdatableResults()
/*  81:    */   {
/*  82:185 */     return this.updatableResults;
/*  83:    */   }
/*  84:    */   
/*  85:    */   public void setReturnGeneratedKeys(boolean returnGeneratedKeys)
/*  86:    */   {
/*  87:194 */     if (isCompiled()) {
/*  88:195 */       throw new InvalidDataAccessApiUsageException("The returnGeneratedKeys flag must be set before the operation is compiled");
/*  89:    */     }
/*  90:198 */     this.returnGeneratedKeys = returnGeneratedKeys;
/*  91:    */   }
/*  92:    */   
/*  93:    */   public boolean isReturnGeneratedKeys()
/*  94:    */   {
/*  95:206 */     return this.returnGeneratedKeys;
/*  96:    */   }
/*  97:    */   
/*  98:    */   public void setGeneratedKeysColumnNames(String[] names)
/*  99:    */   {
/* 100:214 */     if (isCompiled()) {
/* 101:215 */       throw new InvalidDataAccessApiUsageException("The column names for the generated keys must be set before the operation is compiled");
/* 102:    */     }
/* 103:218 */     this.generatedKeysColumnNames = names;
/* 104:    */   }
/* 105:    */   
/* 106:    */   public String[] getGeneratedKeysColumnNames()
/* 107:    */   {
/* 108:225 */     return this.generatedKeysColumnNames;
/* 109:    */   }
/* 110:    */   
/* 111:    */   public void setSql(String sql)
/* 112:    */   {
/* 113:232 */     this.sql = sql;
/* 114:    */   }
/* 115:    */   
/* 116:    */   public String getSql()
/* 117:    */   {
/* 118:241 */     return this.sql;
/* 119:    */   }
/* 120:    */   
/* 121:    */   public void setTypes(int[] types)
/* 122:    */     throws InvalidDataAccessApiUsageException
/* 123:    */   {
/* 124:254 */     if (isCompiled()) {
/* 125:255 */       throw new InvalidDataAccessApiUsageException("Cannot add parameters once query is compiled");
/* 126:    */     }
/* 127:257 */     if (types != null) {
/* 128:258 */       for (int type : types) {
/* 129:259 */         declareParameter(new SqlParameter(type));
/* 130:    */       }
/* 131:    */     }
/* 132:    */   }
/* 133:    */   
/* 134:    */   public void declareParameter(SqlParameter param)
/* 135:    */     throws InvalidDataAccessApiUsageException
/* 136:    */   {
/* 137:277 */     if (isCompiled()) {
/* 138:278 */       throw new InvalidDataAccessApiUsageException("Cannot add parameters once the query is compiled");
/* 139:    */     }
/* 140:280 */     this.declaredParameters.add(param);
/* 141:    */   }
/* 142:    */   
/* 143:    */   public void setParameters(SqlParameter[] parameters)
/* 144:    */   {
/* 145:291 */     if (isCompiled()) {
/* 146:292 */       throw new InvalidDataAccessApiUsageException("Cannot add parameters once the query is compiled");
/* 147:    */     }
/* 148:294 */     for (int i = 0; i < parameters.length; i++) {
/* 149:295 */       if (parameters[i] != null) {
/* 150:296 */         this.declaredParameters.add(parameters[i]);
/* 151:    */       } else {
/* 152:299 */         throw new InvalidDataAccessApiUsageException("Cannot add parameter at index " + i + " from " + Arrays.asList(parameters) + " since it is 'null'");
/* 153:    */       }
/* 154:    */     }
/* 155:    */   }
/* 156:    */   
/* 157:    */   protected List<SqlParameter> getDeclaredParameters()
/* 158:    */   {
/* 159:309 */     return this.declaredParameters;
/* 160:    */   }
/* 161:    */   
/* 162:    */   public void afterPropertiesSet()
/* 163:    */   {
/* 164:317 */     compile();
/* 165:    */   }
/* 166:    */   
/* 167:    */   public final void compile()
/* 168:    */     throws InvalidDataAccessApiUsageException
/* 169:    */   {
/* 170:327 */     if (!isCompiled())
/* 171:    */     {
/* 172:328 */       if (getSql() == null) {
/* 173:329 */         throw new InvalidDataAccessApiUsageException("Property 'sql' is required");
/* 174:    */       }
/* 175:    */       try
/* 176:    */       {
/* 177:333 */         this.jdbcTemplate.afterPropertiesSet();
/* 178:    */       }
/* 179:    */       catch (IllegalArgumentException ex)
/* 180:    */       {
/* 181:336 */         throw new InvalidDataAccessApiUsageException(ex.getMessage());
/* 182:    */       }
/* 183:339 */       compileInternal();
/* 184:340 */       this.compiled = true;
/* 185:342 */       if (this.logger.isDebugEnabled()) {
/* 186:343 */         this.logger.debug("RdbmsOperation with SQL [" + getSql() + "] compiled");
/* 187:    */       }
/* 188:    */     }
/* 189:    */   }
/* 190:    */   
/* 191:    */   public boolean isCompiled()
/* 192:    */   {
/* 193:355 */     return this.compiled;
/* 194:    */   }
/* 195:    */   
/* 196:    */   protected void checkCompiled()
/* 197:    */   {
/* 198:365 */     if (!isCompiled())
/* 199:    */     {
/* 200:366 */       this.logger.debug("SQL operation not compiled before execution - invoking compile");
/* 201:367 */       compile();
/* 202:    */     }
/* 203:    */   }
/* 204:    */   
/* 205:    */   protected void validateParameters(Object[] parameters)
/* 206:    */     throws InvalidDataAccessApiUsageException
/* 207:    */   {
/* 208:379 */     checkCompiled();
/* 209:380 */     int declaredInParameters = 0;
/* 210:381 */     for (SqlParameter param : this.declaredParameters) {
/* 211:382 */       if (param.isInputValueProvided())
/* 212:    */       {
/* 213:383 */         if ((!supportsLobParameters()) && ((param.getSqlType() == 2004) || (param.getSqlType() == 2005))) {
/* 214:385 */           throw new InvalidDataAccessApiUsageException("BLOB or CLOB parameters are not allowed for this kind of operation");
/* 215:    */         }
/* 216:388 */         declaredInParameters++;
/* 217:    */       }
/* 218:    */     }
/* 219:391 */     validateParameterCount(parameters != null ? parameters.length : 0, declaredInParameters);
/* 220:    */   }
/* 221:    */   
/* 222:    */   protected void validateNamedParameters(Map<String, ?> parameters)
/* 223:    */     throws InvalidDataAccessApiUsageException
/* 224:    */   {
/* 225:402 */     checkCompiled();
/* 226:403 */     Map paramsToUse = parameters != null ? parameters : Collections.emptyMap();
/* 227:404 */     int declaredInParameters = 0;
/* 228:405 */     for (SqlParameter param : this.declaredParameters) {
/* 229:406 */       if (param.isInputValueProvided())
/* 230:    */       {
/* 231:407 */         if ((!supportsLobParameters()) && ((param.getSqlType() == 2004) || (param.getSqlType() == 2005))) {
/* 232:409 */           throw new InvalidDataAccessApiUsageException("BLOB or CLOB parameters are not allowed for this kind of operation");
/* 233:    */         }
/* 234:412 */         if ((param.getName() != null) && (!paramsToUse.containsKey(param.getName()))) {
/* 235:413 */           throw new InvalidDataAccessApiUsageException("The parameter named '" + param.getName() + "' was not among the parameters supplied: " + paramsToUse.keySet());
/* 236:    */         }
/* 237:416 */         declaredInParameters++;
/* 238:    */       }
/* 239:    */     }
/* 240:419 */     validateParameterCount(paramsToUse.size(), declaredInParameters);
/* 241:    */   }
/* 242:    */   
/* 243:    */   private void validateParameterCount(int suppliedParamCount, int declaredInParamCount)
/* 244:    */   {
/* 245:428 */     if (suppliedParamCount < declaredInParamCount) {
/* 246:429 */       throw new InvalidDataAccessApiUsageException(suppliedParamCount + " parameters were supplied, but " + declaredInParamCount + " in parameters were declared in class [" + getClass().getName() + "]");
/* 247:    */     }
/* 248:432 */     if ((suppliedParamCount > this.declaredParameters.size()) && (!allowsUnusedParameters())) {
/* 249:433 */       throw new InvalidDataAccessApiUsageException(suppliedParamCount + " parameters were supplied, but " + declaredInParamCount + " parameters were declared in class [" + getClass().getName() + "]");
/* 250:    */     }
/* 251:    */   }
/* 252:    */   
/* 253:    */   protected abstract void compileInternal()
/* 254:    */     throws InvalidDataAccessApiUsageException;
/* 255:    */   
/* 256:    */   protected boolean supportsLobParameters()
/* 257:    */   {
/* 258:453 */     return true;
/* 259:    */   }
/* 260:    */   
/* 261:    */   protected boolean allowsUnusedParameters()
/* 262:    */   {
/* 263:463 */     return false;
/* 264:    */   }
/* 265:    */ }


/* Location:           C:\Users\aerrojudilip\Desktop\Metlife\deployments\ML_01_00_00_AFCON_v1.18\ML_01_00_00_AFCON_v1.18\lib\openpages-services-api.jar
 * Qualified Name:     org.springframework.jdbc.object.RdbmsOperation
 * JD-Core Version:    0.7.0.1
 */