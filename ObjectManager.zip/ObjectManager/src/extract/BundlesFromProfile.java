package extract;

import java.io.File;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;

import extract.util.ExtractUtils;

public class BundlesFromProfile {
	public static void main(String[] args) throws Exception {

		String inputFileName = "C:\\SureStep\\MC\\Dev\\op-config.xml";
		Document document = ExtractUtils.getDocumentFromFileSting(inputFileName);
		String profileName = "All Profile";
		String xPath = "/openpagesConfiguration/objectProfiles/objectProfile[@name='" + profileName + "']";
		List<Element> elements = ExtractUtils.getElementsFromXpath(document, xPath);
		Set<String> fieldGroups = new LinkedHashSet<String>();
		for (Element element : elements) {
			List<Element> inclObjTypes = ExtractUtils.getSelectNodes(element, "includedObjectType");
			for (Element inclObjType : inclObjTypes) {
				List<Element> inclFieldGroups = ExtractUtils.getSelectNodes(inclObjType, "includedFieldGroup");
				for (Element inclFieldGroup : inclFieldGroups) {
					fieldGroups.add(inclFieldGroup.valueOf("@name"));
				}
			}
		}
		fieldGroups.remove("System Fields");
		Document opdocument = DocumentHelper.createDocument();
		Element opConfigElement = ExtractUtils.getOPConfigRoot(opdocument);
		Element bundleTypesElement =  opConfigElement.addElement("bundleTypes");
		for (String name : fieldGroups) {
			 xPath = "/openpagesConfiguration/bundleTypes/bundleType[@name='" + name + "']";
			 List<Element> bundleTypeElements = ExtractUtils.getElementsFromXpath(document, xPath);
			 for(Element bundleTypeElement : bundleTypeElements)
			 {
				 bundleTypesElement.add((Element)bundleTypeElement.clone());
			 }
		}
		File file = new File(inputFileName);
		ExtractUtils.writetoFile(opdocument, file.getParent()+"\\"+profileName+"_Bundles-op-config.xml");
		System.out.println("Done");
	}
}
