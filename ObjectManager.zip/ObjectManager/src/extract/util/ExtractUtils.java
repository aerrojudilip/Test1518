package extract.util;

import java.io.File;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;

public class ExtractUtils {

	public static Document getDocumentFromFile(File inputFile) throws Exception {
		SAXReader reader = new SAXReader();
		Document document = reader.read(inputFile);
		return document;
	}

	public static Document getDocumentFromFileSting(String inputFile) throws Exception {
		return getDocumentFromFile(new File(inputFile));
	}

	public static Document getDocumentFromString(String xmlString) throws Exception {
		SAXReader reader = new SAXReader();
		Document document = reader.read(xmlString);
		return document;
	}

	public static Element getOPConfigRoot(Document opdocument) throws Exception {
		Element root = opdocument.addElement("openpagesConfiguration");
		return root;
	}

	public static Element getObjectProfilesElemenet(Element root) throws Exception {
		Element objectProfiles = root.addElement("objectProfiles").addAttribute("explicitListing", "false");
		return objectProfiles;
	}

	public static Element getObjectProfileViewsSetElement(Element root) throws Exception {
		Element objectProfileViewsSet = root.addElement("objectProfileViewsSet");
		return objectProfileViewsSet;
	}
	public static Element getBundleTypesElement(Element root) throws Exception {
		Element objectProfileViewsSet = root.addElement("bundleTypes");
		return objectProfileViewsSet;
	}

	public static List<?> getNodesFromXpath(Document document, String xPath) throws Exception {
		List<?> nodes = document.selectNodes(xPath);
		return nodes;
	}

	public static List<Element> getElementsFromXpath(Document document, String xPath) throws Exception {
		List<?> nodes = getNodesFromXpath(document, xPath);
		List<Element> elements = new ArrayList<Element>();
		for (Object obj : nodes) {
			if (obj instanceof Element) {
				Element element = (Element) obj;
				elements.add(element);
			}
		}
		return elements;
	}
	public static List<Element> getSelectNodes(Element element,String node) throws Exception {
		List<?> nodes = element.selectNodes(node);
		List<Element> elements = new ArrayList<Element>();
		for (Object obj : nodes) {
			if (obj instanceof Element) {
				Element childElement = (Element) obj;
				elements.add(childElement);
			}
		}
		return elements;
	}

	public static void writetoFile(Document opdocument, String fileName) throws Exception {
		StringWriter sw = new StringWriter();
		OutputFormat format = OutputFormat.createPrettyPrint();
		format.setNewlines(true);
		format.setOmitEncoding(true);
		XMLWriter writer = new XMLWriter(sw, format);
		writer.write(opdocument);
		FileUtils.writeStringToFile(new File(fileName), sw.toString(), "UTF-8");
	}
	public static Element getBundlesElement(Document document,Element opConfigElement) throws Exception{
		String xPath = "/openpagesConfiguration/bundleTypes";
		Element bundlesElemenet =  ExtractUtils.getObjectProfilesElemenet(opConfigElement);
		List<Element> elements = ExtractUtils.getElementsFromXpath(document, xPath);
		for(Element element : elements){
			bundlesElemenet.add((Element)element.clone());
		}
		return bundlesElemenet;
	}
	public static Element getObjectProfiles(Document document,Element opConfigElement) throws Exception{
		String xPath = "/openpagesConfiguration/objectProfiles";
		List<Element> elements = ExtractUtils.getElementsFromXpath(document, xPath);
		for(Element element : elements){
			opConfigElement.add((Element)element.clone());
		}
		return opConfigElement;
	}
	public static Element getObjectProfileViewsSet(Document document,Element opConfigElement) throws Exception{
		String xPath = "/openpagesConfiguration/objectProfileViewsSet";
		List<Element> elements = ExtractUtils.getElementsFromXpath(document, xPath);
		for(Element element : elements){
			opConfigElement.add((Element)element.clone());
		}
		return opConfigElement;
	}
	
	public static Element getObjectProfilesByNames(Document document,Element opConfigElement,String profileNames[]) throws Exception{
		String xPathPrefix = "/openpagesConfiguration/objectProfiles/objectProfile[@name='$$profileName$$']";
		Element objectProfilesElemenet =  ExtractUtils.getObjectProfilesElemenet(opConfigElement);
		for(String profileName : profileNames)
		{
			String xPath = xPathPrefix.replace("$$profileName$$", profileName);
			List<Element> elements = ExtractUtils.getElementsFromXpath(document, xPath);
			for(Element element : elements){
				objectProfilesElemenet.add((Element)element.clone());
			}
		}
		return objectProfilesElemenet;
	}
	public static Element getobjectProfileViewsSetByNames(Document document,Element opConfigElement,String profileNames[]) throws Exception{
		String xPathPrefix = "/openpagesConfiguration/objectProfileViewsSet/objectProfileViews[@name='$$profileName$$']";
		Element objectProfilesElemenet =  ExtractUtils.getObjectProfileViewsSetElement(opConfigElement);
		for(String profileName : profileNames)
		{
			String xPath = xPathPrefix.replace("$$profileName$$", profileName);
			List<Element> elements = ExtractUtils.getElementsFromXpath(document, xPath);
			for(Element element : elements)
			{
				objectProfilesElemenet.add((Element)element.clone());
			}
		}
		return objectProfilesElemenet;
	}
	public static Element getBundleTypesByNames(Document document,Element opConfigElement,String bundleTypeNames[]) throws Exception{
		String xPathPrefix = "/openpagesConfiguration/bundleTypes/bundleType[@name='$$fieldNames$$']";
		Element bundleTypesElemenet =  ExtractUtils.getBundleTypesElement(opConfigElement);
		for(String bundleTypeName : bundleTypeNames)
		{
			String xPath = xPathPrefix.replace("$$fieldNames$$", bundleTypeName);
			List<Element> elements = ExtractUtils.getElementsFromXpath(document, xPath);
			for(Element element : elements){
				bundleTypesElemenet.add((Element)element.clone());
			}
		}
		return bundleTypesElemenet;
	}
}
