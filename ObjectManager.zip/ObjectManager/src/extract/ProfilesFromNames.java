package extract;

import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;

import extract.util.ExtractUtils;

public class ProfilesFromNames {
	public static void main(String[] args) {
		try {
			//String inputFileName = "C:\\op\\tools\\ObjectManager\\openpages-env-mig-011820061800-op-config.xml";
			String inputFileName = "C:\\SureStep\\MC\\Dev\\op-config.xml";
			String profileNames[] = { "Combined ORM/SOX Module", "All Profile" };
			Document document = ExtractUtils.getDocumentFromFileSting(inputFileName);
			Document opdocument = DocumentHelper.createDocument();
			Element opConfigElement = ExtractUtils.getOPConfigRoot(opdocument);
			ExtractUtils.getObjectProfilesByNames(document, opConfigElement, profileNames);
			ExtractUtils.getobjectProfileViewsSetByNames(document, opConfigElement, profileNames);
			ExtractUtils.writetoFile(opdocument,"C:\\SureStep\\MC\\Dev\\op-config_1.xml");
			System.out.println("Done");
		} catch (Exception e) {
			System.out.println(e);
		}
	}
}
