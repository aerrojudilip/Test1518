package extract;

import java.io.File;

import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;

import extract.util.ExtractUtils;

public class Bundles {

	public static void main(String[] args) {
		try {
			String inputFileName = "C:\\SureStep\\MC\\Dev\\op-config.xml";
			Document document = ExtractUtils.getDocumentFromFileSting(inputFileName);
			Document opdocument = DocumentHelper.createDocument();
			Element opConfigElement = ExtractUtils.getOPConfigRoot(opdocument);
			ExtractUtils.getBundlesElement(document, opConfigElement);
			File file = new File(inputFileName);
			ExtractUtils.writetoFile(opdocument,file.getParent()+"//BundleTypes-op-config.xml");
			System.out.println("Done");
		} catch (Exception e) {
			System.out.println(e);
		}
	}
}
