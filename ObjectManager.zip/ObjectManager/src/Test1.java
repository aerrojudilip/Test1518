import java.io.File;
import java.io.StringWriter;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.Node;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;

public class Test1 {

	public static void main(String[] args) {
		try {

			/*StringWriter sw = new StringWriter();
			File inputFile = new File(
					"C:\\Users\\Dilip Aerroju\\Downloads\\openpages-env-mig-011820102307-op-config.xml");
			SAXReader reader = new SAXReader();
			Document document = reader.read(inputFile);
			List<Node> objectProfilesNodes = document.selectNodes("/openpagesConfiguration/objectProfiles");
			Document opdocument = DocumentHelper.createDocument();
			Element root = opdocument.addElement("openpagesConfiguration");
			for (Node node : objectProfilesNodes) {
				Element element = (Element) node.clone();
				root.add(element);
			}
			List<Node> objectProfileViewsSetNodes = document
					.selectNodes("/openpagesConfiguration/objectProfileViewsSet");
			for (Node node : objectProfileViewsSetNodes) {
				Element element = (Element) node.clone();
				root.add(element);
			}
			OutputFormat format = OutputFormat.createPrettyPrint();
			format.setNewlines(true);
			format.setOmitEncoding(true);
			XMLWriter writer;
			writer = new XMLWriter(sw, format);
			writer.write(opdocument);
			FileUtils.writeStringToFile(
					new File("C:\\Users\\Dilip Aerroju\\Downloads\\openpages-env-mig-011820102307_1-op-config.xml"),
					sw.toString(), "UTF-8"); // System.out.println(sw.toString());
			System.out.println("Done");*/
			String inputFileName = "C:\\SureStep\\MC\\Dev\\op-config.xml";
			
		} catch (Exception e) {
			System.out.println(e);
		}
	}
}
