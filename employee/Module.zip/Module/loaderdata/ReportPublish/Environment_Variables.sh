#!/bin/ksh

#*******************************************************************************
# Licensed Materials - Property of IBM
# 
#
# 5725-D51, 5725-D52, 5725-D53, 5725-D54
#
# © Copyright IBM Corporation 2015. All Rights Reserved. 
#
# US Government Users Restricted Rights- Use, duplication or 
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#*******************************************************************************

# ======================================================
#  Modify the variables below to match your environment.
# ======================================================

openpages_domain_folder="/usr/OpenPages"

login_username=OpenPagesAdministrator
login_password=OpenPagesAdministrator
loader_list_file=OpenPagesModules-objectManagerLoad.txt

# ======================================================

