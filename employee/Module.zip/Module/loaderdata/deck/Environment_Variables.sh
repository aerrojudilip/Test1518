#!/bin/sh
#*******************************************************************************
# Licensed Materials - Property of IBM
# 
#
# 5725-D51, 5725-D52, 5725-D53, 5725-D54
#
# � Copyright IBM Corporation 2016. All Rights Reserved. 
#
# US Government Users Restricted Rights- Use, duplication or 
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#*******************************************************************************

# ======================================================
#  Modify the variables below to match your environment.
# ======================================================

openpages_domain_folder=/home/opuser/OP/OpenPages/bin
login_username=OpenPagesAdministrator
login_password=
loader_data_folder=
OBJ_STATUS_FILE=
OBJ_LOADER_FILE=
export openpages_domain_folder login_username login_password
export loader_data_folder OBJ_STATUS_FILE OBJ_LOADER_FILE

# ======================================================

