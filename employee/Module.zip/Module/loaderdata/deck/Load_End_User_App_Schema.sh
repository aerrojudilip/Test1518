#!/bin/sh
#*******************************************************************************
# Licensed Materials - Property of IBM
# 
#
# 5725-D51, 5725-D52, 5725-D53, 5725-D54
#
# � Copyright IBM Corporation 2016. All Rights Reserved. 
#
# US Government Users Restricted Rights- Use, duplication or 
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
# 
#
#
# Copyright (c) 2016 OpenPages, Inc. All rights reserved.
#
# OpenPages, Inc. Confidential Restricted material. This work
# contains confidential trade secrets of Openpages, Inc.. Use,
# examination, copying, transfer and/or disclosure to others is
# prohibited, except with the express written agreement of Openpages, Inc..
#*******************************************************************************
. "./Environment_Variables.sh"

cd  $openpages_domain_folder


echo "Loading Deck Schema"
./ObjectManager.sh b c $login_username $login_password $loader_data_folder $loader_data_folder/openpages-deck-loader-data.txt
if [ $? != 0 ] 
   then
     echo OBJMGRLOADINGSTATUS=FAIL > $OBJ_STATUS_FILE
     echo OPENPAGES_CORE=Failed to load OpenPages deck data >> $OBJ_LOADER_FILE
fi