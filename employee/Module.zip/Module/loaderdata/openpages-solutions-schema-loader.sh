#*******************************************************************************
# Licensed Materials - Property of IBM
# 
#
# 5725-D51, 5725-D52, 5725-D53, 5725-D54
#
# � Copyright IBM Corporation 2015, 2016. All Rights Reserved. 
#
# US Government Users Restricted Rights- Use, duplication or 
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
#*******************************************************************************

. "./schema_loader_properties.sh"

cd  $OBJMGR_HOME

echo "-----------------------------------------------------------"
echo "Starting Loading Modules"
echo "-----------------------------------------------------------"

if [ "$DEFAULT_SCHEMA_INSTALL" == "1" ]
	then

	echo "Loading Schema"
	./ObjectManager.sh l c $OPXUserName $OPXUserPassword $LOADER_DATA/Objects OpenPagesModules-first-class-schema
	if [ $? != 0 ]  
	   then
	 	echo OBJMGRLOADINGSTATUS=FAIL > $OBJ_STATUS_FILE
		echo Failed to load Objects >> $OBJ_LOADER_FILE
	 	# SET TEMP_VARIABLE="OBJECTS"
	else
		echo ...Loaded Objects successfully >> $OBJ_LOADER_FILE
	fi

	echo "Loading Object Strings"
	./ObjectManager.sh l c $OPXUserName $OPXUserPassword $LOADER_DATA/Objects OpenPagesModules-first-class-object-strings-en_US
	if [ $? != 0 ]  
	   then
	 	echo OBJMGRLOADINGSTATUS=FAIL > $OBJ_STATUS_FILE
		echo Failed to load Objects Strings >> $OBJ_LOADER_FILE
		#TEMP_VARIABLE="OBJECTS"
	else
		echo ...Loaded Object Strings successfully >> $OBJ_LOADER_FILE
	fi

	echo "Loading Registry"
	./ObjectManager.sh l c $OPXUserName $OPXUserPassword $LOADER_DATA/Objects OpenPagesModules-first-class-registry-entries
	if [ $? != 0 ]  
	   then
	 	echo OBJMGRLOADINGSTATUS=FAIL > $OBJ_STATUS_FILE
		echo Failed to load Object Registry Entries >> $OBJ_LOADER_FILE
		#TEMP_VARIABLE="OBJECTS"
	else
		echo ...Loaded Object Registry Entries successfully >> $OBJ_LOADER_FILE
	fi

	echo "Loading Relationships"
	./ObjectManager.sh l c $OPXUserName $OPXUserPassword $LOADER_DATA/Objects OpenPagesModules-object-relationships
	if [ $? != 0 ]  
	   then
	 	echo OBJMGRLOADINGSTATUS=FAIL > $OBJ_STATUS_FILE
		echo Failed to load Relationships >> $OBJ_LOADER_FILE
		#TEMP_VARIABLE="OBJECTS"
	else
		echo ...Loaded Relationships successfully >> $OBJ_LOADER_FILE
	fi

	#if [ "$TEMP_VARIABLE" == "OBJECTS" ]
	#   then
	#      echo OBJECTS=Failed to load OpenPages Solutions Schema >> $OBJ_LOADER_FILE
	#fi

	echo "Loading Registry"
	./ObjectManager.sh b c $OPXUserName $OPXUserPassword $LOADER_DATA/Registry $LOADER_DATA/RegistryFiles.txt
	if [ $? != 0 ]  
	   then
	 	echo OBJMGRLOADINGSTATUS=FAIL > $OBJ_STATUS_FILE
		echo Failed to load Registry >> $OBJ_LOADER_FILE
		#TEMP_VARIABLE="REGISTRY"
	else
		echo ...Loaded Registry successfully >> $OBJ_LOADER_FILE
	fi

	#if [ "$TEMP_VARIABLE" == "REGISTRY" ]
	#   then
	#      echo OBJECTS=Failed to load OpenPages Solutions Registry >> $OBJ_LOADER_FILE
	#fi

	echo "Publishing Reports"
	./ObjectManager.sh b c $OPXUserName $OPXUserPassword $LOADER_DATA/ReportPublish $LOADER_DATA/PublishAllReports.txt
	if [ $? != 0 ]  
	   then
	 	echo OBJMGRLOADINGSTATUS=FAIL > $OBJ_STATUS_FILE
		echo Failed to Publish Reports >> $OBJ_LOADER_FILE
		#TEMP_VARIABLE="REPORTS"
	else
		echo ...Published Reports successfully >> $OBJ_LOADER_FILE
	fi

	#if [ "$TEMP_VARIABLE" == "REPORTS" ]
	#   then
	#      echo OBJECTS=Failed to load OpenPages Solutions Reports >> $OBJ_LOADER_FILE
	#fi

	echo "Loading Reports"
	./ObjectManager.sh b c $OPXUserName $OPXUserPassword $LOADER_DATA/Reports $LOADER_DATA/ReportFiles.txt
	if [ $? != 0 ]  
	   then
	 	echo OBJMGRLOADINGSTATUS=FAIL > $OBJ_STATUS_FILE
		echo Failed to load JSP Reports >> $OBJ_LOADER_FILE
		#TEMP_VARIABLE="REPORTJSP"
	else
		echo ...Loaded JSP Reports successfully >> $OBJ_LOADER_FILE
	fi

	#if [ "$TEMP_VARIABLE" == "REPORTJSP" ]
	#   then
	#      echo OBJECTS=Failed to load OpenPages Solutions JSP Reports >> $OBJ_LOADER_FILE
	#fi

	echo "Loading Helpers"
	./ObjectManager.sh b c $OPXUserName $OPXUserPassword $LOADER_DATA/Helpers $LOADER_DATA/HelperFiles.txt
	if [ $? != 0 ]  
	   then
	 	echo OBJMGRLOADINGSTATUS=FAIL > $OBJ_STATUS_FILE
		echo Failed to load Helpers >> $OBJ_LOADER_FILE
		#TEMP_VARIABLE="HELPERS"
	else
		echo ...Loaded Helpers successfully >> $OBJ_LOADER_FILE
	fi

	#if [ "$TEMP_VARIABLE" == "HELPERS" ]
	#   then
	#      echo OBJECTS=Failed to load OpenPages Solutions Helpers >> $OBJ_LOADER_FILE
	#fi

	#if [ "$DEFAULT_SCHEMA_INSTALL" == "1" ]
	#	then

	echo "Loading Schema"
	./ObjectManager.sh b c $OPXUserName $OPXUserPassword $LOADER_DATA/Schema $LOADER_DATA/SchemaFiles.txt
	if [ $? != 0 ]  
	   then
	 	echo OBJMGRLOADINGSTATUS=FAIL > $OBJ_STATUS_FILE
		echo Failed to load Master Schema and Profile >> $OBJ_LOADER_FILE
		#TEMP_VARIABLE="SCHEMA"
	else
		echo ...Loaded Master Schema and Profile successfully >> $OBJ_LOADER_FILE
	fi
	
	./ObjectManager.sh b c $OPXUserName $OPXUserPassword $LOADER_DATA/Schema $LOADER_DATA/SchemaFiles2.txt
	if [ $? != 0 ]  
	   then
	 	echo OBJMGRLOADINGSTATUS=FAIL > $OBJ_STATUS_FILE
		echo Failed to load Master Object Strings >> $OBJ_LOADER_FILE
		#TEMP_VARIABLE="SCHEMA"
	else
		echo ...Loaded Master Object Strings successfully >> $OBJ_LOADER_FILE
	fi
	
	echo "Loading Profiles"
	./ObjectManager.sh l c $OPXUserName $OPXUserPassword $LOADER_DATA/Schema OPS_FCM_7_3_0_Master_object-profile
	if [ $? != 0 ]  
	   then
	 	echo OBJMGRLOADINGSTATUS=FAIL > $OBJ_STATUS_FILE
		echo Failed to load FCM Profile >> $OBJ_LOADER_FILE
		#TEMP_VARIABLE="SCHEMA"
	else
		echo ...Loaded FCM Profile successfully >> $OBJ_LOADER_FILE
	fi
	
	./ObjectManager.sh l c $OPXUserName $OPXUserPassword $LOADER_DATA/Schema OPS_IAM_7_3_0_Master_object-profile
	if [ $? != 0 ]  
	   then
	 	echo OBJMGRLOADINGSTATUS=FAIL > $OBJ_STATUS_FILE
		echo Failed to load IAM Profile >> $OBJ_LOADER_FILE
		#TEMP_VARIABLE="SCHEMA"
	else
		echo ...Loaded IAM Profile successfully >> $OBJ_LOADER_FILE
	fi
	
	./ObjectManager.sh l c $OPXUserName $OPXUserPassword $LOADER_DATA/Schema OPS_ITG_7_3_0_Master_object-profile
	if [ $? != 0 ]  
	   then
	 	echo OBJMGRLOADINGSTATUS=FAIL > $OBJ_STATUS_FILE
		echo Failed to load ITG Profile >> $OBJ_LOADER_FILE
		#TEMP_VARIABLE="SCHEMA"
	else
		echo ...Loaded ITG Profile successfully >> $OBJ_LOADER_FILE
	fi
	
	./ObjectManager.sh l c $OPXUserName $OPXUserPassword $LOADER_DATA/Schema OPS_ORM_7_3_0_Master_object-profile
	if [ $? != 0 ]  
	   then
	 	echo OBJMGRLOADINGSTATUS=FAIL > $OBJ_STATUS_FILE
		echo Failed to load ORM Profile >> $OBJ_LOADER_FILE
		#TEMP_VARIABLE="SCHEMA"
	else
		echo ...Loaded ORM Profile successfully >> $OBJ_LOADER_FILE
	fi
	
	./ObjectManager.sh l c $OPXUserName $OPXUserPassword $LOADER_DATA/Schema ORM_Business_User_object-profile
	if [ $? != 0 ]  
	   then
	 	echo OBJMGRLOADINGSTATUS=FAIL > $OBJ_STATUS_FILE
		echo Failed to load ORM Business User Profile >> $OBJ_LOADER_FILE
		#TEMP_VARIABLE="SCHEMA"
	else
		echo ...Loaded ORM Business User Profile successfully >> $OBJ_LOADER_FILE
	fi
	
	./ObjectManager.sh l c $OPXUserName $OPXUserPassword $LOADER_DATA/Schema ORM_Operational_Risk_Team_object-profile
	if [ $? != 0 ]  
	   then
	 	echo OBJMGRLOADINGSTATUS=FAIL > $OBJ_STATUS_FILE
		echo Failed to load ORM Operational Risk Team Profile >> $OBJ_LOADER_FILE
		#TEMP_VARIABLE="SCHEMA"
	else
		echo ...Loaded ORM Operational Risk Team Profile successfully >> $OBJ_LOADER_FILE
	fi
	
	./ObjectManager.sh l c $OPXUserName $OPXUserPassword $LOADER_DATA/Schema ORM_Simplified_User_object-profile
	if [ $? != 0 ]  
	   then
	 	echo OBJMGRLOADINGSTATUS=FAIL > $OBJ_STATUS_FILE
		echo Failed to load ORM Simplified User Profile >> $OBJ_LOADER_FILE
		#TEMP_VARIABLE="SCHEMA"
	else
		echo ...Loaded ORM Profile Simplified User successfully >> $OBJ_LOADER_FILE
	fi
	
	./ObjectManager.sh l c $OPXUserName $OPXUserPassword $LOADER_DATA/Schema OPS_PCM_7_3_0_Master_object-profile
	if [ $? != 0 ]  
	   then
	 	echo OBJMGRLOADINGSTATUS=FAIL > $OBJ_STATUS_FILE
		echo Failed to load PCM Profile >> $OBJ_LOADER_FILE
		#TEMP_VARIABLE="SCHEMA"
	else
		echo ...Loaded PCM Profile successfully >> $OBJ_LOADER_FILE
	fi
	
	./ObjectManager.sh l c $OPXUserName $OPXUserPassword $LOADER_DATA/Schema OPS_ORM_FIRST_Loss_7_3_0_object-profile
	if [ $? != 0 ]  
	   then
	 	echo OBJMGRLOADINGSTATUS=FAIL > $OBJ_STATUS_FILE
		echo Failed to load FIRST Profile >> $OBJ_LOADER_FILE
		#TEMP_VARIABLE="SCHEMA"
	else
		echo ...Loaded FIRST Profile successfully >> $OBJ_LOADER_FILE
	fi
	
	./ObjectManager.sh l c $OPXUserName $OPXUserPassword $LOADER_DATA/Schema OPS_MRG_7_3_0_Master_object-profile
	if [ $? != 0 ]  
	   then
	 	echo OBJMGRLOADINGSTATUS=FAIL > $OBJ_STATUS_FILE
		echo Failed to load MRG Profile >> $OBJ_LOADER_FILE
		#TEMP_VARIABLE="SCHEMA"
	else
		echo ...Loaded MRG Profile successfully >> $OBJ_LOADER_FILE
	fi
	
	./ObjectManager.sh l c $OPXUserName $OPXUserPassword $LOADER_DATA/Schema OPS_RCM_7_3_0_Master_object-profile
	if [ $? != 0 ]  
	   then
	 	echo OBJMGRLOADINGSTATUS=FAIL > $OBJ_STATUS_FILE
		echo Failed to load RCM Profile >> $OBJ_LOADER_FILE
		#TEMP_VARIABLE="SCHEMA"
	else
		echo ...Loaded RCM Profile successfully >> $OBJ_LOADER_FILE
	fi
	
	./ObjectManager.sh l c $OPXUserName $OPXUserPassword $LOADER_DATA/Schema OPS_VRM_7_3_0_Master_object-profile
	if [ $? != 0 ]  
	   then
	 	echo OBJMGRLOADINGSTATUS=FAIL > $OBJ_STATUS_FILE
		echo Failed to load VRM Profile >> $OBJ_LOADER_FILE
		#TEMP_VARIABLE="SCHEMA"
	else
		echo ...Loaded VRM Profile successfully >> $OBJ_LOADER_FILE
	fi
	
	./ObjectManager.sh l c $OPXUserName $OPXUserPassword $LOADER_DATA/Schema VRM_Vendor_Manager_object-profile
	if [ $? != 0 ]  
	   then
	 	echo OBJMGRLOADINGSTATUS=FAIL > $OBJ_STATUS_FILE
		echo Failed to load VRM Vendor Manager Profile >> $OBJ_LOADER_FILE
		#TEMP_VARIABLE="SCHEMA"
	else
		echo ...Loaded VRM Vendor Manager Profile successfully >> $OBJ_LOADER_FILE
	fi
	
	./ObjectManager.sh l c $OPXUserName $OPXUserPassword $LOADER_DATA/Schema VRM_Vendor_object-profile
	if [ $? != 0 ]  
	   then
	 	echo OBJMGRLOADINGSTATUS=FAIL > $OBJ_STATUS_FILE
		echo Failed to load VRM Vendor Profile >> $OBJ_LOADER_FILE
		#TEMP_VARIABLE="SCHEMA"
	else
		echo ...Loaded VRM Vendor Profile successfully >> $OBJ_LOADER_FILE
	fi
		
	./ObjectManager.sh l c $OPXUserName $OPXUserPassword $LOADER_DATA/Schema Deck_object-profile
	if [ $? != 0 ]  
	   then
	 	echo OBJMGRLOADINGSTATUS=FAIL > $OBJ_STATUS_FILE
		echo Failed to load Deck Profile >> $OBJ_LOADER_FILE
		#TEMP_VARIABLE="SCHEMA"
	else
		echo ...Loaded Deck Object Profile successfully >> $OBJ_LOADER_FILE
	fi
	
	#if [ "$TEMP_VARIABLE" == "SCHEMA" ]
	#   then
	#      echo OBJECTS=Failed to load OpenPages Solutions Schema >> $OBJ_LOADER_FILE
	#fi

	echo "Loading Profiles and Role Templates"
	./ObjectManager.sh b c $OPXUserName $OPXUserPassword $LOADER_DATA/ProfilesRoleTemplates $LOADER_DATA/ProfilesRoleTemplates.txt
	if [ $? != 0 ]  
	   then
	 	echo OBJMGRLOADINGSTATUS=FAIL > $OBJ_STATUS_FILE
		echo Failed to load Profile Role Templates >> $OBJ_LOADER_FILE
		#TEMP_VARIABLE="PROFILESROLETEMPLATES"
	else
		echo ...Loaded Profile Role Templates successfully >> $OBJ_LOADER_FILE
	fi

	#if [ "$TEMP_VARIABLE" == "PROFILESROLETEMPLATES" ]
	#   then
	#      echo OBJECTS=Failed to load OpenPages Solutions Profiles and Role Templates >> $OBJ_LOADER_FILE
	#fi

	echo "Loading Triggers"
	./ObjectManager.sh b c $OPXUserName $OPXUserPassword $LOADER_DATA/Triggers $LOADER_DATA/TriggerFiles.txt
	if [ $? != 0 ]  
	   then
 		echo OBJMGRLOADINGSTATUS=FAIL > $OBJ_STATUS_FILE
		echo Failed to load Triggers >> $OBJ_LOADER_FILE
		#TEMP_VARIABLE="TRIGGERS"
	else
		echo ...Loaded Triggers successfully >> $OBJ_LOADER_FILE
	fi

	#if [ "$TEMP_VARIABLE" == "TRIGGERS" ]
	#   then
	#      echo OBJECTS=Failed to load OpenPages Solutions Triggers >> $OBJ_LOADER_FILE
	#fi

#fi

	#echo "Loading Namespaces"
	#./ObjectManager.sh l c $OPXUserName $OPXUserPassword $LOADER_DATA/Schema Namespaces
	#if [ $? != 0 ]  
	#   then
	# 	echo OBJMGRLOADINGSTATUS=FAIL> $OBJ_STATUS_FILE
	#	echo Failed to load Namespaces >> $OBJ_LOADER_FILE
	#	#TEMP_VARIABLE="NAMESPACES"
	#else
	#	echo ...Loaded Namespaces successfully >> $OBJ_LOADER_FILE
	#fi

	echo "Loading Namespaces"
	./ObjectManager.sh b c $OPXUserName $OPXUserPassword $LOADER_DATA/Schema $LOADER_DATA/Namespaces.txt
	if [ $? != 0 ]  
	   then
	 	echo OBJMGRLOADINGSTATUS=FAIL > $OBJ_STATUS_FILE
		echo Failed to load Namespaces >> $OBJ_LOADER_FILE
		#TEMP_VARIABLE="NAMESPACES"
	else
		echo ...Loaded Namespaces successfully >> $OBJ_LOADER_FILE
	fi


	echo "Loading Visualizations"
	./ObjectManager.sh b c $OPXUserName $OPXUserPassword $LOADER_DATA/Visualization $LOADER_DATA/VisualizationFiles.txt
	if [ $? != 0 ]  
	   then
	 	echo OBJMGRLOADINGSTATUS=FAIL > $OBJ_STATUS_FILE
		echo Failed to load Visualizations >> $OBJ_LOADER_FILE
		#TEMP_VARIABLE="VISUAL"
	else
		echo ...Loaded Visualizations successfully >> $OBJ_LOADER_FILE
	fi



	echo "Registering Modules"
	./ObjectManager.sh b c $OPXUserName $OPXUserPassword $LOADER_DATA/Modules $LOADER_DATA/ModuleFiles.txt
	if [ $? != 0 ]  
	   then
	 	echo OBJMGRLOADINGSTATUS=FAIL > $OBJ_STATUS_FILE
		echo Failed Registering Modules >> $OBJ_LOADER_FILE
		#TEMP_VARIABLE="MODULES"
	else
		echo ...Registered Modules successfully >> $OBJ_LOADER_FILE
	fi

	#if [ "$TEMP_VARIABLE" == "MODULES" ]
	#   then
	#      echo OBJECTS=Failed to load OpenPages Solutions Module Registration >> $OBJ_LOADER_FILE
	#fi

fi

echo "Finished Loading Modules"
echo "-----------------------------------------------------------"


