#!/bin/sh
#*******************************************************************************
# Licensed Materials - Property of IBM
# 
#
# 5725-D51, 5725-D52, 5725-D53, 5725-D54
#
# � Copyright IBM Corporation 2014, 2016. All Rights Reserved. 
#
# US Government Users Restricted Rights- Use, duplication or 
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
# 
#*******************************************************************************
loaderdata_folder=$1
OP_XMAX=$2
OP_YMAX=$3
assessmentmethod_type=$4
javahome=$5

export loaderdata_folder
export OP_XMAX
export OP_YMAX
export assessmentmethod_type
export javahome

$javahome/bin/java -classpath .:assessmentmethodupdater.jar com.ibm.openpages.assessmentmethodupdate.SetAssessmentMethodType $loaderdata_folder/Schema/OPS_Modules_7_3_0_Master_schema-op-config.xml $assessmentmethod_type

$javahome/bin/java -classpath .:assessmentmethodupdater.jar com.ibm.openpages.assessmentmethodupdate.ShowEnumValsInRangeByProperty $loaderdata_folder/Schema/OPS_Modules_7_3_0_Master_schema-op-config.xml 1 $OP_YMAX "Inherent Impact"

$javahome/bin/java -classpath .:assessmentmethodupdater.jar com.ibm.openpages.assessmentmethodupdate.ShowEnumValsInRangeByProperty $loaderdata_folder/Schema/OPS_Modules_7_3_0_Master_schema-op-config.xml 1 $OP_YMAX "Residual Impact"

$javahome/bin/java -classpath .:assessmentmethodupdater.jar com.ibm.openpages.assessmentmethodupdate.ShowEnumValsInRangeByProperty $loaderdata_folder/Schema/OPS_Modules_7_3_0_Master_schema-op-config.xml 1 $OP_XMAX "Inherent Likelihood"

$javahome/bin/java -classpath .:assessmentmethodupdater.jar com.ibm.openpages.assessmentmethodupdate.ShowEnumValsInRangeByProperty $loaderdata_folder/Schema/OPS_Modules_7_3_0_Master_schema-op-config.xml 1 $OP_XMAX "Residual Likelihood"

$javahome/bin/java -classpath .:assessmentmethodupdater.jar com.ibm.openpages.assessmentmethodupdate.ShowEnumValsInRangeByProperty $loaderdata_folder/Schema/OPS_Modules_7_3_0_Master_schema-op-config.xml 1 $OP_YMAX "Audit Inherent Impact"

$javahome/bin/java -classpath .:assessmentmethodupdater.jar com.ibm.openpages.assessmentmethodupdate.ShowEnumValsInRangeByProperty $loaderdata_folder/Schema/OPS_Modules_7_3_0_Master_schema-op-config.xml 1 $OP_YMAX "Audit Residual Impact"

$javahome/bin/java -classpath .:assessmentmethodupdater.jar com.ibm.openpages.assessmentmethodupdate.ShowEnumValsInRangeByProperty $loaderdata_folder/Schema/OPS_Modules_7_3_0_Master_schema-op-config.xml 1 $OP_XMAX "Audit Inherent Likelihood"

$javahome/bin/java -classpath .:assessmentmethodupdater.jar com.ibm.openpages.assessmentmethodupdate.ShowEnumValsInRangeByProperty $loaderdata_folder/Schema/OPS_Modules_7_3_0_Master_schema-op-config.xml 1 $OP_XMAX "Audit Residual Likelihood"

$javahome/bin/java -classpath .:assessmentmethodupdater.jar com.ibm.openpages.assessmentmethodupdate.SetRiskRatingFilter $loaderdata_folder/Schema/OPS_Modules_7_3_0_Master_schema-op-config.xml $OP_YMAX "Inherent Impact"

$javahome/bin/java -classpath .:assessmentmethodupdater.jar com.ibm.openpages.assessmentmethodupdate.SetRiskRatingFilter $loaderdata_folder/Schema/OPS_Modules_7_3_0_Master_schema-op-config.xml $OP_YMAX "Residual Impact"

$javahome/bin/java -classpath .:assessmentmethodupdater.jar com.ibm.openpages.assessmentmethodupdate.SetRiskRatingFilter $loaderdata_folder/Schema/OPS_Modules_7_3_0_Master_schema-op-config.xml $OP_XMAX "Residual Likelihood"

$javahome/bin/java -classpath .:assessmentmethodupdater.jar com.ibm.openpages.assessmentmethodupdate.SetORMRegistry $loaderdata_folder/Registry/ORM-registry-op-config.xml $OP_XMAX "/OpenPages/Solutions/ORM/Triggers/RCSA/XMAX"

$javahome/bin/java -classpath .:assessmentmethodupdater.jar com.ibm.openpages.assessmentmethodupdate.SetORMRegistry $loaderdata_folder/Registry/ORM-registry-op-config.xml $OP_YMAX "/OpenPages/Solutions/ORM/Triggers/RCSA/YMAX"

