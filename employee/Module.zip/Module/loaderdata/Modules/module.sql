-------------------------------------------------------------------------------
-- Licensed Materials - Property of IBM
-- 
--
-- 5725-D51, 5725-D52, 5725-D53, 5725-D54
--
-- � Copyright IBM Corporation 2013. All Rights Reserved.
-- 
-- US Government Users Restricted Rights- Use, duplication or 
-- disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
------------------------------------------------------------------------------- 
update op_applications set description='OpenPages IAM (7.0.0)' where name='IAM';
update op_applications set description='OpenPages FCM (7.0.0)' where name='FCM';
update op_applications set description='OpenPages PCM (7.0.0)' where name='PCM';
update op_applications set description='OpenPages ITG (7.0.0)' where name='ITG';
update op_applications set description='OpenPages ORM (7.0.0)' where name='ORM';
commit;
quit