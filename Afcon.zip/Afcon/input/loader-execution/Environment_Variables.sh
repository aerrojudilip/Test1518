#!/bin/ksh

#*******************************************************************************
# Licensed Materials - Property of IBM
# 
#
# 5725-D51, 5725-D52, 5725-D53, 5725-D54
#
# � Copyright IBM Corporation 2005, 2016. All Rights Reserved. 
#
# US Government Users Restricted Rights- Use, duplication or 
# disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#*******************************************************************************

# ======================================================
#  Modify the variables below to match your environment.
# ======================================================

openpages_domain_folder="/home/opuser/OP/OpenPages"

login_username=OpenPagesAdministrator
login_password=passw0rd

# ======================================================

