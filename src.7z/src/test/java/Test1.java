import java.io.File;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import com.bbt.egrc.opload.BundleType;
import com.bbt.egrc.opload.OpenpagesConfiguration;
import com.bbt.egrc.opload.PropertyType;

public class Test1 
{
	public static void main(String[] args) throws Exception{
		 
		File file = new File("C:\\Users\\D15051\\Downloads\\openpages-env-mig-042517115350-op-config.xml");
		File file_out = new File("C:\\Users\\D15051\\Downloads\\output.xml");
		JAXBContext jaxbContext = JAXBContext.newInstance(OpenpagesConfiguration.class);

		Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
		OpenpagesConfiguration openpagesConfiguration = (OpenpagesConfiguration) jaxbUnmarshaller.unmarshal(file);
		for(BundleType bundleType :  openpagesConfiguration.getBundleTypes().getBundleType())
		{
			for(PropertyType propertyType :  bundleType.getPropertyType())
			{
				//System.out.println(bundleType.getName()+"::"+ propertyType.getName()+":::"+ propertyType.getDataType()+":::"+propertyType.getEnumType());
			}
		}
		Marshaller jaxbMarshaller = jaxbContext.createMarshaller();

		// output pretty printed
		jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

		jaxbMarshaller.marshal(openpagesConfiguration, file_out);
		System.out.println("Done....");

	}
}
