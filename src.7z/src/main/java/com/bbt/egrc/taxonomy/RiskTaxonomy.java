package com.bbt.egrc.taxonomy;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;

import com.bbt.egrc.opload.BundleType;
import com.bbt.egrc.opload.BundleTypes;
import com.bbt.egrc.opload.ControllingValue;
import com.bbt.egrc.opload.DependentPicklist;
import com.bbt.egrc.opload.DependentPicklistSet;
import com.bbt.egrc.opload.DependentPicklists;
import com.bbt.egrc.opload.DependentValue;
import com.bbt.egrc.opload.EnumType;
import com.bbt.egrc.opload.EnumValue;
import com.bbt.egrc.opload.OpenpagesConfiguration;
import com.bbt.egrc.opload.PropertyType;

public class RiskTaxonomy 
{
	public static void main(String[] args) throws Exception {
		OpenpagesConfiguration configuration = new OpenpagesConfiguration();
		String tax1 = "R01 - Corporate Governance Risk,R02 - Client and Account Handling Risk,R03 - Transaction and Process Management Risk,R04 - Financial Crime Compliance Risk,R05 - Default Risk,R06 - Reporting Risk,R07 - Associate Management and Workplace Safety Risk,R08 - Business Disruption and System Failure Risk,R09 - External Fraud Risk,R10 - Internal Fraud Risk,R11 - Adverse Business Decision Risk,R12 - Failed Execution Risk,R13 - Failed Implementation Risk,R15 - External Environment Risk,R16 - Market Risk,R17 - Liquidity Risk";
		String tax2 = "R01.01 - Misuse of Non-Public Information - Insider Trading Risk,R01.02 - Legal Entity Governance and Registration Risk,R01.03 - Corporate## Client or Counterparty Exposure Risk,R01.04 - Government Relations Risk,R01.05 - Vendor - Third Party Risk,R01.06 - Affiliate - Subsidiary Governance,R01.07 - Community Reinvestment Act Risk,R01.08 - Marketing and Product - Services Delivery Risk,R01.09 - Executive Loan Risk,R01.10 - Improper Business Practices,R02.01 - Client Complaint Handling - Reporting Risk,R02.02 - Client Account Documentation Risk,R02.03 - Fair and Consistent Treatment of Clients Risk,R02.04 - Privacy Risk,R02.05 - Client Assets Risk,R02.06 - Disclosure Violation,R02.07 - Advisory Activity Disputes,R03.01 - Transaction Processing Risk,R03.02 - Counterparty Administration Risk,R03.03 - Collateral Management Risk,R03.04 - Data## Data Transfer and Storage Issues Risk,R03.05 - Tax and Accounting Risk,R03.06 - Model Risk,R03.07 - Inaccurate - Inadequate Documentation,R04.01 - Bank Secrecy Act - Anti-Money Laundering - Know Your Customer (KYC) Risk,R04.02 - OFAC Sanctions Risk,R04.03 - Anti-Bribery - Corruption Risk,R05.01 - Underwriting Risk,R05.02 - Acquired Loan Risk,R05.03 - Obligor Default Risk,R05.04 - Counterparty Default Risk,R05.05 - Collateral Risk,R05.06 - Credit Concentration,R06.01 - Internal Reporting Risk,R06.02 - External Reporting Risk,R07.01 - Workplace Safety Risk,R07.02 - Diversity - Discrimination Risk,R07.03 - Compensation and Benefits Risk,R07.04 - Recruiting and Associate Relations Risk,R07.05 - Associate Perception Risk,R07.06 - Associate Licensing## Registration and - or Certification Risk,R08.01 - System Unavailability Risk,R08.02 - Disruption of Facilities Risk,R08.03 - Loss of Associates Risk,R08.04 - Damage to Physical Assets,R09.01 - External Theft or Fraud Risk,R09.02 - Robbery Risk,R09.03 - Cyber Risk,R10.01 - Internal Theft or Fraud Risk,R10.02 - Unauthorized Activity Risk,R10.03 - Information Security Risk,R11.01 - New or Changed Business Activities Risk,R11.02 - Merger## Acquisition## and Divestiture (M-A-D) Risk,R11.03 - Footprint - Geographic Expansion Risk,R11.04 - Distribution Channel Risk,R11.05 - Adequate Human Capital Resources Risk,R11.06 - Incentive-Driven - Compensation Risk,R11.07 - Technology Obsolescence Risk,R11.08 - Business Intelligence Integration Risk,R12.01 - Program Execution Risk,R12.02 - Capital and Budget Allocation Risk,R12.03 - Financial Objectives Risk,R13.01 - Systems - Process Change Implementation Risk,R13.02 - Merger## Acquisition and Divestiture Implementation Risk,R13.03 - Product or Service Implementation Risk,R15.01 - External Perception Risk,R15.02 - Competitive Environment Risk,R15.03 - Geopolitical - Macroeconomic Country Risk,R15.04 - Sociopolitical Risk,R15.05 - Cultural Risk,R15.06 - Regulatory Environment Risk,R15.07 - Economic Conditions Risk,R16.01 - Interest Rate Risk,R16.02 - Commodity Risk,R16.03 - FX Risk,R16.04 - Equity Price Risk,R16.05 - Credit Spread Risk,R16.06 - Market Liquidity Risk,R16.07 - Gap Risk,R16.08 - Concentration Risk,R16.09 - Basis Risk,R16.10 - Correlation Risk,R16.11 - Wrong Way Risk,R16.12 - Issuer Default,R17.01 - Intraday Liquidity Risk,R17.02 - Funding Concentration Risk ,R17.03 - Legal Entity Liquidity Risk ,R17.04 - Off-Balance Sheet Liquidity Risk ,R17.05 - Contingent Liquidity Risk,R17.06 - Asset Concentration,R17.07 - Rate Sensitive Funding,R17.08 - Non-Core Funding,R17.09 - Short-term Funding,R17.10 - Mismatch Risk";
		String dep1= "R01 - Corporate Governance Risk:R01.01 - Misuse of Non-Public Information - Insider Trading Risk,R01.02 - Legal Entity Governance and Registration Risk,R01.03 - Corporate## Client or Counterparty Exposure Risk,R01.04 - Government Relations Risk,R01.05 - Vendor - Third Party Risk,R01.06 - Affiliate - Subsidiary Governance,R01.07 - Community Reinvestment Act Risk,R01.08 - Marketing and Product - Services Delivery Risk,R01.09 - Executive Loan Risk,R01.10 - Improper Business Practices|R02 - Client and Account Handling Risk:R02.01 - Client Complaint Handling - Reporting Risk,R02.02 - Client Account Documentation Risk,R02.03 - Fair and Consistent Treatment of Clients Risk,R02.04 - Privacy Risk,R02.05 - Client Assets Risk,R02.06 - Disclosure Violation,R02.07 - Advisory Activity Disputes|R03 - Transaction and Process Management Risk:R03.01 - Transaction Processing Risk,R03.02 - Counterparty Administration Risk,R03.03 - Collateral Management Risk,R03.04 - Data## Data Transfer and Storage Issues Risk,R03.05 - Tax and Accounting Risk,R03.06 - Model Risk,R03.07 - Inaccurate - Inadequate Documentation|R04 - Financial Crime Compliance Risk:R04.01 - Bank Secrecy Act - Anti-Money Laundering - Know Your Customer (KYC) Risk,R04.02 - OFAC Sanctions Risk,R04.03 - Anti-Bribery - Corruption Risk|R05 - Default Risk:R05.01 - Underwriting Risk,R05.02 - Acquired Loan Risk,R05.03 - Obligor Default Risk,R05.04 - Counterparty Default Risk,R05.05 - Collateral Risk,R05.06 - Credit Concentration|R06 - Reporting Risk:R06.01 - Internal Reporting Risk,R06.02 - External Reporting Risk|R07 - Associate Management and Workplace Safety Risk:R07.01 - Workplace Safety Risk,R07.02 - Diversity - Discrimination Risk,R07.03 - Compensation and Benefits Risk,R07.04 - Recruiting and Associate Relations Risk,R07.05 - Associate Perception Risk,R07.06 - Associate Licensing## Registration and - or Certification Risk|R08 - Business Disruption and System Failure Risk:R08.01 - System Unavailability Risk,R08.02 - Disruption of Facilities Risk,R08.03 - Loss of Associates Risk,R08.04 - Damage to Physical Assets|R09 - External Fraud Risk:R09.01 - External Theft or Fraud Risk,R09.02 - Robbery Risk,R09.03 - Cyber Risk|R10 - Internal Fraud Risk:R10.01 -Internal Theft or Fraud Risk,R10.02 - Unauthorized Activity Risk,R10.03 - Information Security Risk|R11 - Adverse Business Decision Risk:R11.01 - New or Changed Business Activities Risk,R11.02 - Merger## Acquisition## and Divestiture (M-A-D) Risk,R11.03 - Footprint - Geographic Expansion Risk,R11.04 - Distribution Channel Risk,R11.05 - Adequate Human Capital Resources Risk,R11.06 - Incentive-Driven - Compensation Risk,R11.07 - Technology Obsolescence Risk,R11.08 - Business Intelligence Integration Risk|R12 - Failed Execution Risk:R12.01 - Program Execution Risk,R12.02 - Capital and Budget Allocation Risk,R12.03 - Financial Objectives Risk|R13 - Failed Implementation Risk:R13.01 - Systems - Process Change Implementation Risk,R13.02 - Merger## Acquisition and Divestiture Implementation Risk,R13.03 - Product or Service Implementation Risk|R15 - External Environment Risk:R15.01 - External Perception Risk,R15.02 - Competitive Environment Risk,R15.03 - Geopolitical - Macroeconomic Country Risk,R15.04 - Sociopolitical Risk,R15.05 - Cultural Risk,R15.06 - Regulatory Environment Risk,R15.07 - Economic Conditions Risk|R16 - Market Risk:R16.01 - Interest Rate Risk,R16.02 - Commodity Risk,R16.03 - FX Risk,R16.04 - Equity Price Risk,R16.05 - Credit Spread Risk,R16.06 - Market Liquidity Risk,R16.07 - Gap Risk,R16.08 - Concentration Risk,R16.09 - Basis Risk,R16.10 - Correlation Risk,R16.11 - Wrong Way Risk,R16.12 - Issuer Default|R17 - Liquidity Risk:R17.01 - Intraday Liquidity Risk,R17.02 - Funding Concentration Risk ,R17.03 - Legal Entity Liquidity Risk ,R17.04 - Off-Balance Sheet Liquidity Risk ,R17.05 - Contingent Liquidity Risk,R17.06 - Asset Concentration,R17.07 - Rate Sensitive Funding,R17.08 - Non-Core Funding,R17.09 - Short-term Funding,R17.10 - Mismatch Risk";
		BundleTypes bundleTypes = new BundleTypes();
		List<BundleType> bundleTypeList = new ArrayList<BundleType>();
		BundleType bundleType = new BundleType();
		bundleType.setName("BBT-Shr-Rsk");
		bundleType.setDescription("Processed by AFCON");
		List<PropertyType> propertyTypeList = new ArrayList<PropertyType>();
		propertyTypeList.add(fillTaxonomy("RskL1","Select the appropriate Level 1 Risk.",tax1,16));
		propertyTypeList.add(fillTaxonomy("RskL2","Select the appropriate Level 2 Risk.",tax2,93));
		bundleType.setPropertyType(propertyTypeList);
		bundleTypeList.add(bundleType);
		bundleTypes.setBundleType(bundleTypeList);
		configuration.setBundleTypes(bundleTypes);
		JAXBContext jaxbContext = JAXBContext.newInstance(OpenpagesConfiguration.class);
		DependentPicklists dependentPicklists = new DependentPicklists();
		DependentPicklistSet dependentPicklistSet = new DependentPicklistSet();
		dependentPicklistSet.setObjectType("SOXRisk");
		List<DependentPicklistSet> dependentPicklistSetList = new ArrayList<DependentPicklistSet>();
		dependentPicklistSetList.add(dependentPicklistSet);
		List<DependentPicklist> picklist = new ArrayList<DependentPicklist>();
		picklist.add(fillDependencies("BBT-Shr-Rsk", "RskL1", "BBT-Shr-Rsk", "RskL2",dep1));
		dependentPicklistSet.setDependentPicklist(picklist);
		dependentPicklists.setDependentPicklistSet(dependentPicklistSetList);
		configuration.setDependentPicklists(dependentPicklists);
		Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
		jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		jaxbMarshaller.marshal(configuration, System.out);
	}
	
	public static PropertyType fillTaxonomy(String name,String description,String tax,int count)
	{
		PropertyType propertyType = new PropertyType();
		propertyType.setName(name);
		propertyType.setDescription(description);
		propertyType.setDataType("Enumerated String");
		EnumType enumType = new EnumType();
		List<EnumValue> enumValues = new ArrayList<EnumValue>();
		EnumValue enumValue;
		int order =0;
		for(String tax1Str :  tax.split(","))
		{
			count++;
			order++;
			tax1Str = tax1Str.replace("##", ",");
			enumValue = new EnumValue();
			enumValue.setName(tax1Str);
			enumValue.setValue(count);
			enumValue.setDisplayOrder(order);
			enumValues.add(enumValue);
		}
		enumType.setEnumValue(enumValues);
		enumType.setName(name);
		propertyType.setEnumType(enumType);
		return propertyType;
	}
	
	public static DependentPicklist fillDependencies(String controllingFieldGroup,String controllingField,String dependentFieldGroup,String dependentField,String dep)
	{
		DependentPicklist dependentPicklist = new DependentPicklist();
		List<ControllingValue> controllingValueList = new ArrayList<ControllingValue>();
		dependentPicklist.setDimension(true);
		dependentPicklist.setControllingField(controllingField);
		dependentPicklist.setControllingFieldGroup(controllingFieldGroup);
		dependentPicklist.setDependentFieldGroup(dependentFieldGroup);
		dependentPicklist.setDependentField(dependentField);
		dependentPicklist.setEnabled(true);
		dependentPicklist.setSuppliedByVendor(false);
		for(String controlandDependency : dep.split("\\|"))
		{
			String controlValue = controlandDependency.split(":")[0];
			ControllingValue controllingValue = new ControllingValue();
			controlValue = controlValue.replace("##", ",");
			controllingValue.setName(controlValue);
			List<DependentValue> dependentValueList = new ArrayList<DependentValue>();
			for(String value :   controlandDependency.split(":")[1].split(","))
			{
				DependentValue dependentValue = new DependentValue();
				value = value.replace("##", ",");
				dependentValue.setName(value);
				dependentValueList.add(dependentValue);
			}
			controllingValue.setDependentValue(dependentValueList);
			controllingValueList.add(controllingValue);
			dependentPicklist.setControllingValue(controllingValueList);
		}
		return dependentPicklist;
	}
	
}
