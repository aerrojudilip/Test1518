package com.bbt.egrc.taxonomy;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

public class RemoveLine {

	public static void main(String[] args) throws Exception {
		File inputFile =  new File("C:\\OpenPages\\AFCON\\Iteration-2\\BBT_01_02_02\\loader-data\\Schema\\BBT_Master_7_3_0_object-strings-op-config.xml");
		File tempFile = new File("myTempFile.txt");

		BufferedReader reader = new BufferedReader(new FileReader(inputFile));
		BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile));

		String linesToRemoveStartsWith = "P ";
		String currentLine;

		while((currentLine = reader.readLine()) != null) {
		    // trim newline when comparing with lineToRemove
		    String trimmedLine = currentLine.trim();
		    if(!trimmedLine.contains(linesToRemoveStartsWith )) continue;
		    writer.write(currentLine + System.getProperty("line.separator"));
		}
		writer.close(); 
		reader.close(); 
		boolean successful = tempFile.renameTo(inputFile);
	}
}
