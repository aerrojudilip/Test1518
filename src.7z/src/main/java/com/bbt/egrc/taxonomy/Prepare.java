package com.bbt.egrc.taxonomy;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.StringUtils;

public class Prepare {

	public static void main(String[] args) throws Exception {
		int level = 3;
		String fileName = "RiskTax.txt";
		File file = new File(fileName);
		List<String> taxs = new ArrayList<String>();
		BufferedReader b = new BufferedReader(new FileReader(file));
		String readLine = "";
		 while ((readLine = b.readLine()) != null) {
			 taxs.add(readLine);
         }
		 //System.out.println(StringUtils.join(getTaxName(taxs, 0), ","));
		 //System.out.println(StringUtils.join(getTaxName(taxs, 1), ","));
		 //System.out.println(StringUtils.join(getTaxName(taxs, 2), ","));
		 System.out.println(getDepdencieString(getDependency(taxs,0,1)));
	}
	
	public static Set<String> getTaxName(List<String> taxs,int level)
	{
		Set<String> taxNames = new LinkedHashSet<String>();
		for(String line :  taxs)
		{
			taxNames.add(line.split(":")[level]);
		}
		return taxNames;
	}
	public static Map<String , Set<String>> getDependency(List<String> taxs,int controlLevel,int dependencyLevel)
	{
		Set<String> conTaxNames = getTaxName(taxs,controlLevel);
		
		Map<String , Set<String>> dependices = new LinkedHashMap<String, Set<String>>();
		for(String controlTax : conTaxNames)
		{
			Set<String> dependVals = new LinkedHashSet<String>();
			String check = "";
			if(controlLevel==0)
				check = controlTax+":";
			else
				check = ":"+controlTax+":";
			for(String line: taxs)
			{
				if(line.contains(check))
				{
					dependVals.add(line.split(":")[dependencyLevel]);
				}
			}
			dependices.put(controlTax, dependVals);
		}
		return dependices;
	}
	public static String getDepdencieString(Map<String , Set<String>> dependices)
	{
		StringBuffer buffer = null;
		for(String s : dependices.keySet())
		{
			if(buffer==null)
			{
				buffer = new StringBuffer();
				buffer.append(s+":"+StringUtils.join(dependices.get(s),","));
			}
			else
				buffer.append("|"+s+":"+StringUtils.join(dependices.get(s),","));
		}
		return removeLastLetter(buffer.toString());
	}
	
	public static String removeLastLetter(String str) {
	    if (str != null && str.length() > 0 && str.charAt(str.length() - 1) == 'x') {
	        str = str.substring(0, str.length() - 1);
	    }
	    return str;
	}
}
