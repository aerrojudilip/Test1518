package com.bbt.egrc.taxonomy;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import org.apache.commons.validator.GenericTypeValidator;

import com.bbt.egrc.opload.EnumType;
import com.bbt.egrc.opload.EnumValue;
import com.bbt.egrc.opload.OpenpagesConfiguration;

public class Test
{
	public static void main(String[] args) throws Exception {
		
		File file = new File("displayOrder.txt");
		JAXBContext jaxbContext = JAXBContext.newInstance(OpenpagesConfiguration.class);
		Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
		EnumType enumType = (EnumType) jaxbUnmarshaller.unmarshal(file);
		List<EnumValue> enumValues = new ArrayList<EnumValue>();
		for(EnumValue enumValue : enumType.getEnumValue())
		{
			if(!enumValue.getName().startsWith("R "))
			{
				//enumValue.setValue(enumValue.getDisplayOrder()-119);
				//enumValue.setDisplayOrder(enumValue.getDisplayOrder()-119);
				enumValue.setValue(enumValue.getDisplayOrder());
				enumValues.add(enumValue);
			}
		}
		Collections.sort(enumValues, new Comparator<EnumValue>() {
			public int compare(EnumValue o1, EnumValue o2) {
				// TODO Auto-generated method stub
				return o1.getValue()-o2.getValue();
			}
		});
		enumType.setEnumValue(enumValues);
		Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
		jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		jaxbMarshaller.marshal(enumType, System.out);
	}
}
