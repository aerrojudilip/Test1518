package com.bbt.egrc.opload;

import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

public class Controller {

	private String name;
	private String fieldGroup;
	private List<ControllerValue> controllerValue;
	
	@XmlAttribute(name="name")
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	@XmlAttribute(name="fieldGroup")
	public String getFieldGroup() {
		return fieldGroup;
	}
	public void setFieldGroup(String fieldGroup) {
		this.fieldGroup = fieldGroup;
	}
	
	@XmlElement(name="controllerValue")
	public List<ControllerValue> getControllerValue() {
		return controllerValue;
	}

	public void setControllerValue(List<ControllerValue> controllerValue) {
		this.controllerValue = controllerValue;
	}
}
