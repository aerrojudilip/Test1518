package com.bbt.egrc.opload;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;

public class SectionNameTranslations {

	private List<SectionNameTranslation> sectionNameTranslation;

	@XmlElement(name="sectionNameTranslation")
	public List<SectionNameTranslation> getSectionNameTranslation() {
		return sectionNameTranslation;
	}

	public void setSectionNameTranslation(List<SectionNameTranslation> sectionNameTranslation) {
		this.sectionNameTranslation = sectionNameTranslation;
	}
	
	
}
