package com.bbt.egrc.opload;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="objectStrings")
public class ObjectStrings {

	private List<LocaleStrings> localeStrings;

	@XmlElement(name="localeStrings")
	public List<LocaleStrings> getLocaleStrings() {
		return localeStrings;
	}

	public void setLocaleStrings(List<LocaleStrings> localeStrings) {
		this.localeStrings = localeStrings;
	}
	
	
	
	
}
