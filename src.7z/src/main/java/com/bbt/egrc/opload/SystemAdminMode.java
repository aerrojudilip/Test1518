package com.bbt.egrc.opload;

import javax.xml.bind.annotation.XmlAttribute;

public class SystemAdminMode {

	private boolean enabled=false;

	public boolean isEnabled() {
		return enabled;
	}

	@XmlAttribute
	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}
			
	
}
