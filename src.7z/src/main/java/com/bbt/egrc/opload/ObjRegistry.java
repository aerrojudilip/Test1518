package com.bbt.egrc.opload;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement(name="registry")
public class ObjRegistry {

	private List<RegistryEntry> entries;

	@XmlElement(name="registryEntry")
	public List<RegistryEntry> getEntries() {
		return entries;
	}

	public void setEntries(List<RegistryEntry> entries) {
		this.entries = entries;
	}

	
	
}
