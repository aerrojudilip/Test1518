package com.bbt.egrc.opload;

import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

public class DependentPicklistSet implements Cloneable{

	private String objectType;
	private List<DependentPicklist> dependentPicklist;
	
	@XmlAttribute(name="objectType",required=true)
	public String getObjectType() {
		return objectType;
	}
	public void setObjectType(String objectType) {
		this.objectType = objectType;
	}


	@XmlElement(name="dependentPicklist")
	public List<DependentPicklist> getDependentPicklist() {
		return dependentPicklist;
	}
	public void setDependentPicklist(List<DependentPicklist> dependentPicklist) {
		this.dependentPicklist = dependentPicklist;
	}
	
	
	@Override
	public Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return super.clone();
	}
	
}
