package com.bbt.egrc.opload;

import javax.xml.bind.annotation.XmlAttribute;

public class SearchValue {
	private String searchConditionValue;

	@XmlAttribute(name="searchConditionValue",required=true)
	public String getSearchConditionValue() {
		return searchConditionValue;
	}

	public void setSearchConditionValue(String searchConditionValue) {
		this.searchConditionValue = searchConditionValue;
	}
	
}
