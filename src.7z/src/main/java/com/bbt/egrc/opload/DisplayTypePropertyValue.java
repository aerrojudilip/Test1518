package com.bbt.egrc.opload;

import javax.xml.bind.annotation.XmlAttribute;

public class DisplayTypePropertyValue {

	private String name;
	@XmlAttribute(name="name")
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
