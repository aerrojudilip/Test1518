package com.bbt.egrc.opload;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;

public class InnerObjectProfileViews {
	private List<InnerObjectProfileView> innerObjectProfileView;

	@XmlElement(name="innerObjectProfileView")
	public List<InnerObjectProfileView> getInnerObjectProfileView() {
		return innerObjectProfileView;
	}

	public void setInnerObjectProfileView(List<InnerObjectProfileView> innerObjectProfileView) {
		this.innerObjectProfileView = innerObjectProfileView;
	}
	
}
