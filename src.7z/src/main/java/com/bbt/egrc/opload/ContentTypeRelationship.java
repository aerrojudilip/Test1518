package com.bbt.egrc.opload;

import javax.xml.bind.annotation.XmlAttribute;

public class ContentTypeRelationship 
{
	private String parent;
	private String child;
	private boolean enabled;
	private String minParents;
	private String maxParents;
	private String minChildren;
	private String maxChildren;
	
	@XmlAttribute(name="parent",required=true)
	public String getParent() {
		return parent;
	}
	public void setParent(String parent) {
		this.parent = parent;
	}
	
	@XmlAttribute(name="child",required=true)
	public String getChild() {
		return child;
	}
	public void setChild(String child) {
		this.child = child;
	}
	
	@XmlAttribute(name="enabled",required=true)
	public boolean isEnabled() {
		return enabled;
	}
	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}
	
	@XmlAttribute(name="minParents",required=true)
	public String getMinParents() {
		return minParents;
	}
	public void setMinParents(String minParents) {
		this.minParents = minParents;
	}
	
	@XmlAttribute(name="maxParents",required=true)
	public String getMaxParents() {
		return maxParents;
	}
	public void setMaxParents(String maxParents) {
		this.maxParents = maxParents;
	}
	
	@XmlAttribute(name="minChildren",required=true)
	public String getMinChildren() {
		return minChildren;
	}
	public void setMinChildren(String minChildren) {
		this.minChildren = minChildren;
	}
	
	@XmlAttribute(name="maxChildren",required=true)
	public String getMaxChildren() {
		return maxChildren;
	}
	public void setMaxChildren(String maxChildren) {
		this.maxChildren = maxChildren;
	}
	
	
}
