package com.bbt.egrc.opload;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;

public class ObjectProfileViewsSet {
	private List<ObjectProfileViews> objectProfileViews;

	@XmlElement(name="objectProfileViews")
	public List<ObjectProfileViews> getObjectProfileViews() {
		return objectProfileViews;
	}

	public void setObjectProfileViews(List<ObjectProfileViews> objectProfileViews) {
		this.objectProfileViews = objectProfileViews;
	}
	
}
