package com.bbt.egrc.opload;

import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

public class ObjectProfileViewsForObjectType {
	private String name;
	private boolean explicitListing =false;
	private List<ObjectProfileView> objectProfileView;
	
	@XmlAttribute(name="name",required=true)
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	@XmlAttribute(name="explicitListing",required=true)
	public boolean isExplicitListing() {
		return explicitListing;
	}
	public void setExplicitListing(boolean explicitListing) {
		this.explicitListing = explicitListing;
	}
	
	@XmlElement(name="objectProfileView")
	public List<ObjectProfileView> getObjectProfileView() {
		return objectProfileView;
	}
	public void setObjectProfileView(List<ObjectProfileView> objectProfileView) {
		this.objectProfileView = objectProfileView;
	}
	
	
}
