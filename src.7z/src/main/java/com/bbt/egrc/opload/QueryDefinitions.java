package com.bbt.egrc.opload;

import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

public class QueryDefinitions 
{
	private boolean explicitListing = false;
	private List<QueryDefinition> queryDefinition;
	
	@XmlAttribute(name="explicitListing",required=true)
	public boolean isExplicitListing() {
		return explicitListing;
	}
	public void setExplicitListing(boolean explicitListing) {
		this.explicitListing = explicitListing;
	}
	
	@XmlElement(name="queryDefinition")
	public List<QueryDefinition> getQueryDefinition() {
		return queryDefinition;
	}
	public void setQueryDefinition(List<QueryDefinition> queryDefinition) {
		this.queryDefinition = queryDefinition;
	}
	
	
	
}
