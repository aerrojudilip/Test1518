package com.bbt.egrc.opload;

import javax.xml.bind.annotation.XmlAttribute;

public class RegistryEntry {

	private String name;
	private String description;
	private String hidden;
	private String encrypted;
	private String protected_s;
	
	@XmlAttribute(name="name")
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	@XmlAttribute(name="description")
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	@XmlAttribute(name="hidden")
	public String getHidden() {
		return hidden;
	}
	public void setHidden(String hidden) {
		this.hidden = hidden;
	}
	
	@XmlAttribute(name="encrypted")
	public String getEncrypted() {
		return encrypted;
	}
	public void setEncrypted(String encrypted) {
		this.encrypted = encrypted;
	}
	
	@XmlAttribute(name="protected")
	public String getProtected_s() {
		return protected_s;
	}
	public void setProtected_s(String protected_s) {
		this.protected_s = protected_s;
	}

	
	
}
