package com.bbt.egrc.opload;

import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

public class DependentPicklist {

	private boolean isDimension;
	private String controllingField;
	private String controllingFieldGroup;
	private String dependentField;
	private String dependentFieldGroup;
	private boolean enabled = true;
	private boolean suppliedByVendor = false;
	private List<ControllingValue> controllingValue;
	
	@XmlAttribute(name="isDimension")
	public boolean isDimension() {
		return isDimension;
	}
	public void setDimension(boolean isDimension) {
		this.isDimension = isDimension;
	}
	
	@XmlAttribute(name="controllingField")
	public String getControllingField() {
		return controllingField;
	}
	public void setControllingField(String controllingField) {
		this.controllingField = controllingField;
	}
	
	@XmlAttribute(name="controllingFieldGroup")
	public String getControllingFieldGroup() {
		return controllingFieldGroup;
	}
	public void setControllingFieldGroup(String controllingFieldGroup) {
		this.controllingFieldGroup = controllingFieldGroup;
	}
	
	@XmlAttribute(name="dependentField")
	public String getDependentField() {
		return dependentField;
	}
	public void setDependentField(String dependentField) {
		this.dependentField = dependentField;
	}
	
	@XmlAttribute(name="dependentFieldGroup")
	public String getDependentFieldGroup() {
		return dependentFieldGroup;
	}
	public void setDependentFieldGroup(String dependentFieldGroup) {
		this.dependentFieldGroup = dependentFieldGroup;
	}
	
	@XmlAttribute(name="enabled")
	public boolean isEnabled() {
		return enabled;
	}
	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}
	
	@XmlAttribute(name="suppliedByVendor")
	public boolean isSuppliedByVendor() {
		return suppliedByVendor;
	}
	public void setSuppliedByVendor(boolean suppliedByVendor) {
		this.suppliedByVendor = suppliedByVendor;
	}
	
	@XmlElement(name="controllingValue")
	public List<ControllingValue> getControllingValue() {
		return controllingValue;
	}
	public void setControllingValue(List<ControllingValue> controllingValue) {
		this.controllingValue = controllingValue;
	}
	
	
}
