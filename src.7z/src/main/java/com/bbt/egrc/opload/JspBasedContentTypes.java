package com.bbt.egrc.opload;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;

public class JspBasedContentTypes {

	
	private List<ContentType> contentType;

	@XmlElement(name="contentType",required=true)
	public List<ContentType> getContentType() {
		return contentType;
	}

	public void setContentType(List<ContentType> contentType) {
		this.contentType = contentType;
	}
	
	
}
