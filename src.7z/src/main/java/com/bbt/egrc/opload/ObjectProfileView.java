package com.bbt.egrc.opload;

import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(propOrder={"viewNameTranslations","objectProfileViewField",
					"objectProfileViewSection","innerObjectProfileViews",
					"objectProfileViewReferenceObjectType","objectProfileViewAssociatedQueryDefs"})
public class ObjectProfileView {

	private String type;
	private String description;
	private boolean showDescription = true;
	private boolean isDefault = false;
	private boolean isDisabled = false;
	private List<ViewNameTranslations> viewNameTranslations;
	private List<ObjectProfileViewField> objectProfileViewField;
	private List<ObjectProfileViewSection> objectProfileViewSection;
	private List<InnerObjectProfileViews> innerObjectProfileViews;
	private List<ObjectProfileViewReferenceObjectType> objectProfileViewReferenceObjectType;
	private ObjectProfileViewAssociatedQueryDefs objectProfileViewAssociatedQueryDefs;
	@XmlAttribute(name="type")
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	@XmlAttribute(name="description")
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	@XmlAttribute(name="showDescription")
	public boolean isShowDescription() {
		return showDescription;
	}
	public void setShowDescription(boolean showDescription) {
		this.showDescription = showDescription;
	}
	
	@XmlAttribute(name="isDefault")
	public boolean isDefault() {
		return isDefault;
	}
	public void setDefault(boolean isDefault) {
		this.isDefault = isDefault;
	}
	
	@XmlAttribute(name="isDisabled")
	public boolean isDisabled() {
		return isDisabled;
	}
	public void setDisabled(boolean isDisabled) {
		this.isDisabled = isDisabled;
	}
	
	@XmlElement(name="viewNameTranslations")
	public List<ViewNameTranslations> getViewNameTranslations() {
		return viewNameTranslations;
	}
	public void setViewNameTranslations(List<ViewNameTranslations> viewNameTranslations) {
		this.viewNameTranslations = viewNameTranslations;
	}
	
	@XmlElement(name="objectProfileViewField")
	public List<ObjectProfileViewField> getObjectProfileViewField() {
		return objectProfileViewField;
	}
	public void setObjectProfileViewField(List<ObjectProfileViewField> objectProfileViewField) {
		this.objectProfileViewField = objectProfileViewField;
	}
	@XmlElement(name="objectProfileViewReferenceObjectType")
	public List<ObjectProfileViewReferenceObjectType> getObjectProfileViewReferenceObjectType() {
		return objectProfileViewReferenceObjectType;
	}
	public void setObjectProfileViewReferenceObjectType(
			List<ObjectProfileViewReferenceObjectType> objectProfileViewReferenceObjectType) {
		this.objectProfileViewReferenceObjectType = objectProfileViewReferenceObjectType;
	}
	
	@XmlElement(name="objectProfileViewSection")
	public List<ObjectProfileViewSection> getObjectProfileViewSection() {
		return objectProfileViewSection;
	}
	public void setObjectProfileViewSection(List<ObjectProfileViewSection> objectProfileViewSection) {
		this.objectProfileViewSection = objectProfileViewSection;
	}
	
	@XmlElement(name="innerObjectProfileViews")
	public List<InnerObjectProfileViews> getInnerObjectProfileViews() {
		return innerObjectProfileViews;
	}
	public void setInnerObjectProfileViews(List<InnerObjectProfileViews> innerObjectProfileViews) {
		this.innerObjectProfileViews = innerObjectProfileViews;
	}
	
	@XmlElement(name="objectProfileViewAssociatedQueryDefs")
	public ObjectProfileViewAssociatedQueryDefs getObjectProfileViewAssociatedQueryDefs() {
		return objectProfileViewAssociatedQueryDefs;
	}
	public void setObjectProfileViewAssociatedQueryDefs(
			ObjectProfileViewAssociatedQueryDefs objectProfileViewAssociatedQueryDefs) {
		this.objectProfileViewAssociatedQueryDefs = objectProfileViewAssociatedQueryDefs;
	}
	
}
