package com.bbt.egrc.opload;

import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

public class QueryDefinition {

	private String name;
	private String description;
	private String type;
	private String visibility;
	private String contentType;
	private String checkAcl;
	private boolean suppliedByVendor = false;
	private String expression;
	private String lastModifiedBy;
	private String creator;
	private String lastModifiedOn;
	private String creationDate;
	private List<CriteriaList> criteriaList;
	
	@XmlAttribute(name="name",required=true)
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	@XmlAttribute(name="description")
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	@XmlAttribute(name="type")
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	@XmlAttribute(name="visibility")
	public String getVisibility() {
		return visibility;
	}
	public void setVisibility(String visibility) {
		this.visibility = visibility;
	}
	
	@XmlAttribute(name="contentType")
	public String getContentType() {
		return contentType;
	}
	public void setContentType(String contentType) {
		this.contentType = contentType;
	}
	
	@XmlAttribute(name="checkAcl")
	public String getCheckAcl() {
		return checkAcl;
	}
	public void setCheckAcl(String checkAcl) {
		this.checkAcl = checkAcl;
	}
	
	@XmlAttribute(name="suppliedByVendor")
	public boolean isSuppliedByVendor() {
		return suppliedByVendor;
	}
	public void setSuppliedByVendor(boolean suppliedByVendor) {
		this.suppliedByVendor = suppliedByVendor;
	}
	
	@XmlAttribute(name="expression")
	public String getExpression() {
		return expression;
	}
	public void setExpression(String expression) {
		this.expression = expression;
	}
	
	@XmlAttribute(name="lastModifiedBy")
	public String getLastModifiedBy() {
		return lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	
	@XmlAttribute(name="creator")
	public String getCreator() {
		return creator;
	}
	public void setCreator(String creator) {
		this.creator = creator;
	}
	
	@XmlAttribute(name="lastModifiedOn")
	public String getLastModifiedOn() {
		return lastModifiedOn;
	}
	public void setLastModifiedOn(String lastModifiedOn) {
		this.lastModifiedOn = lastModifiedOn;
	}
	
	@XmlAttribute(name="creationDate")
	public String getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}
	
	@XmlElement(name="criteriaList")
	public List<CriteriaList> getCriteriaList() {
		return criteriaList;
	}
	public void setCriteriaList(List<CriteriaList> criteriaList) {
		this.criteriaList = criteriaList;
	}
	
	
}
