package com.bbt.egrc.opload;

import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

public class ObjectProfileViewSection {
	private String name;
	private List<SectionNameTranslations> sectionNameTranslations;
	@XmlAttribute(name="name",required=true)
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@XmlElement(name="sectionNameTranslations")
	public List<SectionNameTranslations> getSectionNameTranslations() {
		return sectionNameTranslations;
	}

	public void setSectionNameTranslations(List<SectionNameTranslations> sectionNameTranslations) {
		this.sectionNameTranslations = sectionNameTranslations;
	}
	
}
