package com.bbt.egrc.opload;

import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(propOrder={"overview","filteredListView","includedFieldGroup"})
public class IncludedObjectType 
{
	private String name;
	private String displayOrder;
	private Overview overview;
	private FilteredListView filteredListView;
	private List<IncludedFieldGroup> includedFieldGroup;
	
	@XmlAttribute(name="name",required=true)
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	@XmlAttribute(name="displayOrder",required=true)
	public String getDisplayOrder() {
		return displayOrder;
	}
	public void setDisplayOrder(String displayOrder) {
		this.displayOrder = displayOrder;
	}
	
	@XmlElement(name="overview")
	public Overview getOverview() {
		return overview;
	}
	public void setOverview(Overview overview) {
		this.overview = overview;
	}
	
	@XmlElement(name="filteredListView")
	public FilteredListView getFilteredListView() {
		return filteredListView;
	}
	public void setFilteredListView(FilteredListView filteredListView) {
		this.filteredListView = filteredListView;
	}
	
	@XmlElement(name="includedFieldGroup")
	public List<IncludedFieldGroup> getIncludedFieldGroup() {
		return includedFieldGroup;
	}
	public void setIncludedFieldGroup(List<IncludedFieldGroup> includedFieldGroup) {
		this.includedFieldGroup = includedFieldGroup;
	}
	
	
	
}
