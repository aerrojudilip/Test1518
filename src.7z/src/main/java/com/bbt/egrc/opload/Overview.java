package com.bbt.egrc.opload;

import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

public class Overview
{
	private boolean showDescription=true;
	private List<ObjectTypeReference> objectTypeReference;
	
	@XmlAttribute(name="showDescription")
	public boolean isShowDescription() {
		return showDescription;
	}

	public void setShowDescription(boolean showDescription) {
		this.showDescription = showDescription;
	}
	
	@XmlElement(name="objectTypeReference")
	public List<ObjectTypeReference> getObjectTypeReference() {
		return objectTypeReference;
	}
	public void setObjectTypeReference(List<ObjectTypeReference> objectTypeReference) {
		this.objectTypeReference = objectTypeReference;
	}
	
	
}
