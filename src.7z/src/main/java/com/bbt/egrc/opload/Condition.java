package com.bbt.egrc.opload;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

public class Condition {
	private String searchOperator;
	private String searchType;
	private String bundleType;
	private String propertyType;
	private String label;
	private String not;
	private SearchValues searchValues;
	
	@XmlAttribute(name="searchOperator")
	public String getSearchOperator() {
		return searchOperator;
	}
	public void setSearchOperator(String searchOperator) {
		this.searchOperator = searchOperator;
	}
	
	@XmlAttribute(name="searchType")
	public String getSearchType() {
		return searchType;
	}
	public void setSearchType(String searchType) {
		this.searchType = searchType;
	}
	
	@XmlAttribute(name="bundleType")
	public String getBundleType() {
		return bundleType;
	}
	public void setBundleType(String bundleType) {
		this.bundleType = bundleType;
	}
	
	@XmlAttribute(name="propertyType")
	public String getPropertyType() {
		return propertyType;
	}
	public void setPropertyType(String propertyType) {
		this.propertyType = propertyType;
	}
	
	@XmlAttribute(name="label")
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	
	@XmlAttribute(name="not")
	public String getNot() {
		return not;
	}
	public void setNot(String not) {
		this.not = not;
	}
	
	@XmlElement(name="searchValues")
	public SearchValues getSearchValues() {
		return searchValues;
	}
	public void setSearchValues(SearchValues searchValues) {
		this.searchValues = searchValues;
	}
	
	
	
	
}
