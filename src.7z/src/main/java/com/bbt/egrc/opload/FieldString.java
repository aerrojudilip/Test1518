package com.bbt.egrc.opload;

import javax.xml.bind.annotation.XmlAttribute;

public class FieldString {

	private String fieldGroup;
	private String guidance;
	private String name;
	private boolean overriddenByUser=true;
	private String pluralValue;
	private String singularValue;
	private boolean suppliedByVendor=false;
	
	@XmlAttribute(name="")
	public String getFieldGroup() {
		return fieldGroup;
	}
	public void setFieldGroup(String fieldGroup) {
		this.fieldGroup = fieldGroup;
	}
	
	@XmlAttribute(name="")
	public String getGuidance() {
		return guidance;
	}
	public void setGuidance(String guidance) {
		this.guidance = guidance;
	}
	
	@XmlAttribute(name="")
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	@XmlAttribute(name="")
	public boolean isOverriddenByUser() {
		return overriddenByUser;
	}
	public void setOverriddenByUser(boolean overriddenByUser) {
		this.overriddenByUser = overriddenByUser;
	}
	
	@XmlAttribute(name="pluralValue")
	public String getPluralValue() {
		return pluralValue;
	}
	public void setPluralValue(String pluralValue) {
		this.pluralValue = pluralValue;
	}
	
	@XmlAttribute(name="singularValue")
	public String getSingularValue() {
		return singularValue;
	}
	public void setSingularValue(String singularValue) {
		this.singularValue = singularValue;
	}
	
	@XmlAttribute(name="suppliedByVendor")
	public boolean isSuppliedByVendor() {
		return suppliedByVendor;
	}
	public void setSuppliedByVendor(boolean suppliedByVendor) {
		this.suppliedByVendor = suppliedByVendor;
	}
	
	
	
}
