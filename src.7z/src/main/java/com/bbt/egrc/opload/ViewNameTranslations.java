package com.bbt.egrc.opload;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;

public class ViewNameTranslations {

	private List<ViewNameTranslation> viewNameTranslation;

	@XmlElement(name="viewNameTranslation")
	public List<ViewNameTranslation> getViewNameTranslation() {
		return viewNameTranslation;
	}

	public void setViewNameTranslation(List<ViewNameTranslation> viewNameTranslation) {
		this.viewNameTranslation = viewNameTranslation;
	}
	
	
}
