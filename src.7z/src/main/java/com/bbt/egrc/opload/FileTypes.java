package com.bbt.egrc.opload;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;

public class FileTypes {
	private List<FileType> fileType;

	@XmlElement(name="fileType")
	public List<FileType> getFileType() {
		return fileType;
	}

	public void setFileType(List<FileType> fileType) {
		this.fileType = fileType;
	}
	
	
}
