package com.bbt.egrc.opload;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;

public class BundleTypes {

	private List<BundleType> bundleType = null;

	@XmlElement(name="bundleType")
	public List<BundleType> getBundleType() {
		return bundleType;
	}

	public void setBundleType(List<BundleType> bundleType) {
		this.bundleType = bundleType;
	}
	
	
}
