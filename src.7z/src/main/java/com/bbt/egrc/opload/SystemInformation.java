package com.bbt.egrc.opload;

import javax.xml.bind.annotation.XmlAttribute;

public class SystemInformation {
	private String name;
	private String retrievalDate;
	private String openpages;
	private String operatingSystem;
	private String javaRuntimeEnvironment;
	private String database;
	private String databaseDriver;
	private boolean systemAdminMode;
	
	@XmlAttribute(name="name",required=true)
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	@XmlAttribute(name="retrievalDate",required=true)
	public String getRetrievalDate() {
		return retrievalDate;
	}
	public void setRetrievalDate(String retrievalDate) {
		this.retrievalDate = retrievalDate;
	}
	
	@XmlAttribute(name="openpages",required=true)
	public String getOpenpages() {
		return openpages;
	}
	public void setOpenpages(String openpages) {
		this.openpages = openpages;
	}
	
	@XmlAttribute(name="operatingSystem",required=true)
	public String getOperatingSystem() {
		return operatingSystem;
	}
	public void setOperatingSystem(String operatingSystem) {
		this.operatingSystem = operatingSystem;
	}
	
	@XmlAttribute(name="javaRuntimeEnvironment",required=true)
	public String getJavaRuntimeEnvironment() {
		return javaRuntimeEnvironment;
	}
	public void setJavaRuntimeEnvironment(String javaRuntimeEnvironment) {
		this.javaRuntimeEnvironment = javaRuntimeEnvironment;
	}
	
	@XmlAttribute(name="database",required=true)
	public String getDatabase() {
		return database;
	}
	public void setDatabase(String database) {
		this.database = database;
	}
	
	@XmlAttribute(name="databaseDriver",required=true)
	public String getDatabaseDriver() {
		return databaseDriver;
	}
	public void setDatabaseDriver(String databaseDriver) {
		this.databaseDriver = databaseDriver;
	}
	
	@XmlAttribute(name="systemAdminMode",required=true)
	public boolean isSystemAdminMode() {
		return systemAdminMode;
	}
	public void setSystemAdminMode(boolean systemAdminMode) {
		this.systemAdminMode = systemAdminMode;
	}
	
	
}
