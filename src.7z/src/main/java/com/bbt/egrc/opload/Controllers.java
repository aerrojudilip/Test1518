package com.bbt.egrc.opload;

import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

public class Controllers {

	private String operator;
	private List<Controller> controller;
	
	@XmlAttribute(name="operator")
	public String getOperator() {
		return operator;
	}

	public void setOperator(String operator) {
		this.operator = operator;
	}

	@XmlElement(name="controller")
	public List<Controller> getController() {
		return controller;
	}

	public void setController(List<Controller> controller) {
		this.controller = controller;
	}

	
	
	
	
	
}
