package com.bbt.egrc.opload;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;

public class CriteriaList {

	private List<Conditions> conditions;

	@XmlElement(name="conditions",required=true)
	public List<Conditions> getConditions() {
		return conditions;
	}

	public void setConditions(List<Conditions> conditions) {
		this.conditions = conditions;
	}
	
	
}
