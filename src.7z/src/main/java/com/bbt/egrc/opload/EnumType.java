package com.bbt.egrc.opload;

import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="enumType")
public class EnumType {
	
	private String name;
	private String description;
	private List<EnumValue> enumValue;
	
	@XmlAttribute(name="name")
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	@XmlAttribute(name="description")
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	@XmlElement(name="enumValue")
	public List<EnumValue> getEnumValue() {
		return enumValue;
	}
	public void setEnumValue(List<EnumValue> enumValue) {
		this.enumValue = enumValue;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return name+":"+description;
	}
}
