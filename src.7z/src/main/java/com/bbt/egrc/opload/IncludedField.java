package com.bbt.egrc.opload;

import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

public class IncludedField {
	
	private String name;
	private boolean readOnly;
	private boolean required;
	private List<DisplayType> displayType;
	private List<View> view;
	
	@XmlAttribute(name="name")
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	@XmlAttribute(name="readOnly")
	public boolean isReadOnly() {
		return readOnly;
	}
	public void setReadOnly(boolean readOnly) {
		this.readOnly = readOnly;
	}
	
	@XmlAttribute(name="required")
	public boolean isRequired() {
		return required;
	}
	public void setRequired(boolean required) {
		this.required = required;
	}
	
	@XmlElement(name="displayType")
	public List<DisplayType> getDisplayType() {
		return displayType;
	}
	public void setDisplayType(List<DisplayType> displayType) {
		this.displayType = displayType;
	}
	
	@XmlElement(name="view")
	public List<View> getView() {
		return view;
	}
	public void setView(List<View> view) {
		this.view = view;
	}
	
	
}
