package com.bbt.egrc.opload;

import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

public class IncludedFieldGroup {

	private String name;
	private List<IncludedField> includedField;

	@XmlAttribute(name="name")
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	@XmlElement(name="includedField")
	public List<IncludedField> getIncludedField() {
		return includedField;
	}

	public void setIncludedField(List<IncludedField> includedField) {
		this.includedField = includedField;
	}
	
	
}
