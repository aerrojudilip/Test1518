package com.bbt.egrc.opload;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;

public class SearchValues {

	private List<SearchValue> searchValue;

	@XmlElement(name="searchValue",required=true)
	public List<SearchValue> getSearchValue() {
		return searchValue;
	}

	public void setSearchValue(List<SearchValue> searchValue) {
		this.searchValue = searchValue;
	}
	
	
}
