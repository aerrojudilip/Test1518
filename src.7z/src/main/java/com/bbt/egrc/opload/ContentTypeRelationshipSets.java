package com.bbt.egrc.opload;

import javax.xml.bind.annotation.XmlElement;

public class ContentTypeRelationshipSets {

	private ContentTypeRelationshipSet contentTypeRelationshipSet;

	@XmlElement(name="contentTypeRelationshipSet",required=true)
	public ContentTypeRelationshipSet getContentTypeRelationshipSet() {
		return contentTypeRelationshipSet;
	}

	public void setContentTypeRelationshipSet(ContentTypeRelationshipSet contentTypeRelationshipSet) {
		this.contentTypeRelationshipSet = contentTypeRelationshipSet;
	}
	
	
}
