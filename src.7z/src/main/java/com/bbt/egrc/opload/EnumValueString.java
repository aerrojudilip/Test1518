package com.bbt.egrc.opload;

import javax.xml.bind.annotation.XmlAttribute;

public class EnumValueString {

	private String field;
	private String fieldGroup;
	private String name;
	private String value;
	private boolean overriddenByUser=true;
	private boolean suppliedByVendor=false;
	
	@XmlAttribute(name="field")
	public String getField() {
		return field;
	}
	public void setField(String field) {
		this.field = field;
	}
	
	@XmlAttribute(name="fieldGroup")
	public String getFieldGroup() {
		return fieldGroup;
	}
	public void setFieldGroup(String fieldGroup) {
		this.fieldGroup = fieldGroup;
	}
	
	@XmlAttribute(name="name")
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	@XmlAttribute(name="value")
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	
	@XmlAttribute(name="overriddenByUser")
	public boolean isOverriddenByUser() {
		return overriddenByUser;
	}
	public void setOverriddenByUser(boolean overriddenByUser) {
		this.overriddenByUser = overriddenByUser;
	}
	
	@XmlAttribute(name="suppliedByVendor")
	public boolean isSuppliedByVendor() {
		return suppliedByVendor;
	}
	public void setSuppliedByVendor(boolean suppliedByVendor) {
		this.suppliedByVendor = suppliedByVendor;
	}
	
	
}
