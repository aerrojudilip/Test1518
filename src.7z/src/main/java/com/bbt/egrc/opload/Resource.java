package com.bbt.egrc.opload;

import javax.xml.bind.annotation.XmlAttribute;

public class Resource {
	
	private String name;
	private String shortName;
	private String parentFolder;
	private String description;
	private String resourceType;
	private String subResourceType;
	private String storageServer;
	private String contentLength;
	private String contentLocation;
	private boolean multiVersionable = false;
	private String contentLanguage;
	private String fileType;
	private String contentType;
	private String sourceResource;
	private String creator;
	private String creationDate;
	private boolean checkedOut = false;
	private String checkedOutBy;
	private String checkedOutDate;
	private String modifiedBy;
	private String modificationDate;
	private String visibilityType ="Normal";
	private boolean inheritAcls=true;
	
	@XmlAttribute(name="name",required=true)
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	@XmlAttribute(name="shortName")
	public String getShortName() {
		return shortName;
	}
	public void setShortName(String shortName) {
		this.shortName = shortName;
	}
	
	@XmlAttribute(name="parentFolder")
	public String getParentFolder() {
		return parentFolder;
	}
	public void setParentFolder(String parentFolder) {
		this.parentFolder = parentFolder;
	}
	
	@XmlAttribute(name="description")
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	@XmlAttribute(name="resourceType")
	public String getResourceType() {
		return resourceType;
	}
	public void setResourceType(String resourceType) {
		this.resourceType = resourceType;
	}
	
	@XmlAttribute(name="subResourceType")
	public String getSubResourceType() {
		return subResourceType;
	}
	public void setSubResourceType(String subResourceType) {
		this.subResourceType = subResourceType;
	}
	
	@XmlAttribute(name="storageServer")
	public String getStorageServer() {
		return storageServer;
	}
	public void setStorageServer(String storageServer) {
		this.storageServer = storageServer;
	}
	
	@XmlAttribute(name="contentLength")
	public String getContentLength() {
		return contentLength;
	}
	public void setContentLength(String contentLength) {
		this.contentLength = contentLength;
	}
	
	@XmlAttribute(name="contentLocation")
	public String getContentLocation() {
		return contentLocation;
	}
	public void setContentLocation(String contentLocation) {
		this.contentLocation = contentLocation;
	}
	
	@XmlAttribute(name="multiVersionable")
	public boolean isMultiVersionable() {
		return multiVersionable;
	}
	public void setMultiVersionable(boolean multiVersionable) {
		this.multiVersionable = multiVersionable;
	}
	
	@XmlAttribute(name="contentLanguage")
	public String getContentLanguage() {
		return contentLanguage;
	}
	public void setContentLanguage(String contentLanguage) {
		this.contentLanguage = contentLanguage;
	}
	
	@XmlAttribute(name="fileType")
	public String getFileType() {
		return fileType;
	}
	public void setFileType(String fileType) {
		this.fileType = fileType;
	}
	
	@XmlAttribute(name="contentType")
	public String getContentType() {
		return contentType;
	}
	public void setContentType(String contentType) {
		this.contentType = contentType;
	}
	
	@XmlAttribute(name="sourceResource")
	public String getSourceResource() {
		return sourceResource;
	}
	public void setSourceResource(String sourceResource) {
		this.sourceResource = sourceResource;
	}
	
	@XmlAttribute(name="creator")
	public String getCreator() {
		return creator;
	}
	public void setCreator(String creator) {
		this.creator = creator;
	}
	
	@XmlAttribute(name="creationDate")
	public String getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}
	
	@XmlAttribute(name="checkedOut")
	public boolean isCheckedOut() {
		return checkedOut;
	}
	public void setCheckedOut(boolean checkedOut) {
		this.checkedOut = checkedOut;
	}
	
	@XmlAttribute(name="checkedOutBy")
	public String getCheckedOutBy() {
		return checkedOutBy;
	}
	public void setCheckedOutBy(String checkedOutBy) {
		this.checkedOutBy = checkedOutBy;
	}
	
	@XmlAttribute(name="checkedOutDate")
	public String getCheckedOutDate() {
		return checkedOutDate;
	}
	public void setCheckedOutDate(String checkedOutDate) {
		this.checkedOutDate = checkedOutDate;
	}
	
	@XmlAttribute(name="modifiedBy")
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	
	@XmlAttribute(name="modificationDate")
	public String getModificationDate() {
		return modificationDate;
	}
	public void setModificationDate(String modificationDate) {
		this.modificationDate = modificationDate;
	}
	
	@XmlAttribute(name="visibilityType")
	public String getVisibilityType() {
		return visibilityType;
	}
	public void setVisibilityType(String visibilityType) {
		this.visibilityType = visibilityType;
	}
	
	@XmlAttribute(name="inheritAcls")
	public boolean isInheritAcls() {
		return inheritAcls;
	}
	public void setInheritAcls(boolean inheritAcls) {
		this.inheritAcls = inheritAcls;
	}

	
	
}
