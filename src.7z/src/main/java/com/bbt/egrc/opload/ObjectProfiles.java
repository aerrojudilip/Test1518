package com.bbt.egrc.opload;

import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

public class ObjectProfiles {

	private boolean explicitListing=false;
	private List<ObjectProfile> objectProfile;
	
	@XmlAttribute(name="explicitListing",required=true)
	public boolean isExplicitListing() {
		return explicitListing;
	}
	public void setExplicitListing(boolean explicitListing) {
		this.explicitListing = explicitListing;
	}
	
	@XmlElement(name="objectProfile")
	public List<ObjectProfile> getObjectProfile() {
		return objectProfile;
	}
	public void setObjectProfile(List<ObjectProfile> objectProfile) {
		this.objectProfile = objectProfile;
	}
	
	
}
