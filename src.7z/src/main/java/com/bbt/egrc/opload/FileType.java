package com.bbt.egrc.opload;

import javax.xml.bind.annotation.XmlAttribute;

public class FileType {
	private String name;
	private String mimeType;
	private String fileExtension;
	private String searchEnabled;
	
	@XmlAttribute(name="name",required=true)
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	@XmlAttribute(name="mimeType",required=true)
	public String getMimeType() {
		return mimeType;
	}
	public void setMimeType(String mimeType) {
		this.mimeType = mimeType;
	}
	
	@XmlAttribute(name="fileExtension",required=true)
	public String getFileExtension() {
		return fileExtension;
	}
	public void setFileExtension(String fileExtension) {
		this.fileExtension = fileExtension;
	}
	
	@XmlAttribute(name="searchEnabled",required=true)
	public String getSearchEnabled() {
		return searchEnabled;
	}
	public void setSearchEnabled(String searchEnabled) {
		this.searchEnabled = searchEnabled;
	}
}
