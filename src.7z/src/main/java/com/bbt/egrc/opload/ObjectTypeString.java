package com.bbt.egrc.opload;

import javax.xml.bind.annotation.XmlAttribute;

public class ObjectTypeString 
{
	private String name;
	private boolean overriddenByUser=true;
	private String pluralValue;
	private String singularValue;
	private boolean suppliedByVendor=true;
	
	@XmlAttribute(name="name")
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	@XmlAttribute(name="overriddenByUser")
	public boolean isOverriddenByUser() {
		return overriddenByUser;
	}
	public void setOverriddenByUser(boolean overriddenByUser) {
		this.overriddenByUser = overriddenByUser;
	}
	
	@XmlAttribute(name="pluralValue")
	public String getPluralValue() {
		return pluralValue;
	}
	public void setPluralValue(String pluralValue) {
		this.pluralValue = pluralValue;
	}
	
	@XmlAttribute(name="singularValue")
	public String getSingularValue() {
		return singularValue;
	}
	public void setSingularValue(String singularValue) {
		this.singularValue = singularValue;
	}
	
	@XmlAttribute(name="suppliedByVendor")
	public boolean isSuppliedByVendor() {
		return suppliedByVendor;
	}
	public void setSuppliedByVendor(boolean suppliedByVendor) {
		this.suppliedByVendor = suppliedByVendor;
	}
	
	
}
