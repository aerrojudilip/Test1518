package com.bbt.egrc.opload;

import javax.xml.bind.annotation.XmlAccessOrder;
import javax.xml.bind.annotation.XmlAccessorOrder;
import javax.xml.bind.annotation.XmlAttribute;

@XmlAccessorOrder(XmlAccessOrder.ALPHABETICAL)
public class EnumValue implements Comparable<EnumValue>
{
	private String name;
	private boolean isCommentRequired = false;
	private boolean isAttachmentRequired = false;
	private boolean hidden =false;
	private int value;
	private int displayOrder;
	
	@XmlAttribute(name="name")
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	
	@XmlAttribute(name="isCommentRequired")
	public boolean isCommentRequired() {
		return isCommentRequired;
	}
	public void setIsCommentRequired(boolean isCommentRequired) {
		this.isCommentRequired = isCommentRequired;
	}
	
	@XmlAttribute(name="isAttachmentRequired")
	public boolean isAttachmentRequired() {
		return isAttachmentRequired;
	}
	public void setAttachmentRequired(boolean isAttachmentRequired) {
		this.isAttachmentRequired = isAttachmentRequired;
	}
	
	@XmlAttribute(name="hidden")
	public boolean isHidden() {
		return hidden;
	}
	public void setHidden(boolean hidden) {
		this.hidden = hidden;
	}
	
	@XmlAttribute(name="value")
	public int getValue() {
		return value;
	}
	public void setValue(int value) {
		this.value = value;
	}
	
	@XmlAttribute(name="displayOrder")
	public int getDisplayOrder() {
		return displayOrder;
	}
	public void setDisplayOrder(int displayOrder) {
		this.displayOrder = displayOrder;
	}
	public int compareTo(EnumValue o) {
		int valtest = o.getValue();
		return this.value-valtest;
	}
}
