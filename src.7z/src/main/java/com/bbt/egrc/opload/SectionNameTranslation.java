package com.bbt.egrc.opload;

import javax.xml.bind.annotation.XmlAttribute;

public class SectionNameTranslation {
	private String locale;
	private String value;
	
	@XmlAttribute(name="locale",required=true)
	public String getLocale() {
		return locale;
	}
	public void setLocale(String locale) {
		this.locale = locale;
	}
	
	@XmlAttribute(name="value",required=true)
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	
	
}
