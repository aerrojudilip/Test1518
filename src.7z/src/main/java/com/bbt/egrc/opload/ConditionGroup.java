package com.bbt.egrc.opload;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

public class ConditionGroup {
	
	private String logicalOperator;
	private String not;
	private Condition condition;
	
	@XmlAttribute(name="logicalOperator")
	public String getLogicalOperator() {
		return logicalOperator;
	}
	public void setLogicalOperator(String logicalOperator) {
		this.logicalOperator = logicalOperator;
	}
	
	@XmlAttribute(name="not")
	public String getNot() {
		return not;
	}
	public void setNot(String not) {
		this.not = not;
	}
	
	@XmlElement(name="condition")
	public Condition getCondition() {
		return condition;
	}
	public void setCondition(Condition condition) {
		this.condition = condition;
	}
}
