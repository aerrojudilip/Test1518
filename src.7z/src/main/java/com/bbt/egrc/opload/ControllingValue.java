package com.bbt.egrc.opload;

import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

public class ControllingValue {

	private String name;
	private List<DependentValue> dependentValue;

	@XmlAttribute(name="name",required=true)
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@XmlElement(name="dependentValue")
	public List<DependentValue> getDependentValue() {
		return dependentValue;
	}

	public void setDependentValue(List<DependentValue> dependentValue) {
		this.dependentValue = dependentValue;
	}
	
	
}
