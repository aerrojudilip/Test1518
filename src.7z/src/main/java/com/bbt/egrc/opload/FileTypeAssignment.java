package com.bbt.egrc.opload;

import javax.xml.bind.annotation.XmlAttribute;

public class FileTypeAssignment 
{
	private String name = "txt (text/plain)";

	@XmlAttribute(name="name",required=true)
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
}
