package com.bbt.egrc.opload;

import java.util.List;

public class ObjectProfileViewAssociatedQueryDefs {

	private List<ObjectProfileViewAssociatedQueryDefinition> objectProfileViewAssociatedQueryDefinition;

	public List<ObjectProfileViewAssociatedQueryDefinition> getObjectProfileViewAssociatedQueryDefinition() {
		return objectProfileViewAssociatedQueryDefinition;
	}

	public void setObjectProfileViewAssociatedQueryDefinition(
			List<ObjectProfileViewAssociatedQueryDefinition> objectProfileViewAssociatedQueryDefinition) {
		this.objectProfileViewAssociatedQueryDefinition = objectProfileViewAssociatedQueryDefinition;
	}
	
}
