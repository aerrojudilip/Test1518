package com.bbt.egrc.opload;

import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

public class DependentPicklists {

	private List<DependentPicklistSet> dependentPicklistSet;
	private boolean explicitListing = false;
	
	@XmlElement(name="dependentPicklistSet")
	public List<DependentPicklistSet> getDependentPicklistSet() {
		return dependentPicklistSet;
	}

	public void setDependentPicklistSet(List<DependentPicklistSet> dependentPicklistSet) {
		this.dependentPicklistSet = dependentPicklistSet;
	}
	
	@XmlAttribute(name="explicitListing")
	public boolean isExplicitListing() {
		return explicitListing;
	}
	public void setExplicitListing(boolean explicitListing) {
		this.explicitListing = explicitListing;
	}
	
}
