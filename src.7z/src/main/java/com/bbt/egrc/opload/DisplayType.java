package com.bbt.egrc.opload;

import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

public class DisplayType {

	private String name;
	private boolean spanColumns;
	private List<DisplayTypeProperty> displayTypeProperty;
	
	@XmlAttribute(name="name")
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	@XmlAttribute(name="spanColumns")
	public boolean isSpanColumns() {
		return spanColumns;
	}
	public void setSpanColumns(boolean spanColumns) {
		this.spanColumns = spanColumns;
	}
	
	@XmlElement(name="displayTypeProperty")
	public List<DisplayTypeProperty> getDisplayTypeProperty() {
		return displayTypeProperty;
	}
	public void setDisplayTypeProperty(List<DisplayTypeProperty> displayTypeProperty) {
		this.displayTypeProperty = displayTypeProperty;
	}
	
	
}
