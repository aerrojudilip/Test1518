package com.bbt.egrc.opload;

import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

public class LocaleStrings {
	
	private String name;
	private List<ObjectTypeString> objectTypeStrings;
	private List<FieldString> fieldString;
	private List<EnumValueString> enumValueString;
	
	@XmlAttribute(name="name")
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@XmlElement(name="objectTypeString")
	public List<ObjectTypeString> getObjectTypeStrings() {
		return objectTypeStrings;
	}

	public void setObjectTypeStrings(List<ObjectTypeString> objectTypeStrings) {
		this.objectTypeStrings = objectTypeStrings;
	}

	@XmlElement(name="fieldString")
	public List<FieldString> getFieldString() {
		return fieldString;
	}

	public void setFieldString(List<FieldString> fieldString) {
		this.fieldString = fieldString;
	}

	@XmlElement(name="enumValueString")
	public List<EnumValueString> getEnumValueString() {
		return enumValueString;
	}

	public void setEnumValueString(List<EnumValueString> enumValueString) {
		this.enumValueString = enumValueString;
	}
	
	
}
