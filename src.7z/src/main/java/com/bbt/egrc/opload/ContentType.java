package com.bbt.egrc.opload;

import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

public class ContentType 
{
	private String name;
	private String description;
	private String rootFolder;
	private String category = "Compliance";
	private boolean multiVersionable = true;
	private boolean suppliedByVendor = false;
	private boolean searchEnabled = true;
	private String jspPath = "/propertyForm/renderProperties.jsp";
	private List<BundleTypeAssignment> bundleTypeAssignment;
	private FileTypeAssignment fileTypeAssignment;
	
	@XmlAttribute(name="name",required=true)
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	@XmlAttribute(name="description",required=true)
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	@XmlAttribute(name="rootFolder",required=true)
	public String getRootFolder() {
		return rootFolder;
	}
	public void setRootFolder(String rootFolder) {
		this.rootFolder = rootFolder;
	}
	
	@XmlAttribute(name="category",required=true)
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	
	@XmlAttribute(name="multiVersionable",required=true)
	public boolean isMultiVersionable() {
		return multiVersionable;
	}
	public void setMultiVersionable(boolean multiVersionable) {
		this.multiVersionable = multiVersionable;
	}
	
	@XmlAttribute(name="suppliedByVendor",required=true)
	public boolean isSuppliedByVendor() {
		return suppliedByVendor;
	}
	public void setSuppliedByVendor(boolean suppliedByVendor) {
		this.suppliedByVendor = suppliedByVendor;
	}
	
	@XmlAttribute(name="searchEnabled",required=true)
	public boolean isSearchEnabled() {
		return searchEnabled;
	}
	public void setSearchEnabled(boolean searchEnabled) {
		this.searchEnabled = searchEnabled;
	}
	
	@XmlAttribute(name="jspPath",required=true)
	public String getJspPath() {
		return jspPath;
	}
	public void setJspPath(String jspPath) {
		this.jspPath = jspPath;
	}
	
	@XmlElement(name="bundleTypeAssignment")
	public List<BundleTypeAssignment> getBundleTypeAssignment() {
		return bundleTypeAssignment;
	}
	public void setBundleTypeAssignment(List<BundleTypeAssignment> bundleTypeAssignment) {
		this.bundleTypeAssignment = bundleTypeAssignment;
	}
	
	@XmlElement(name="fileTypeAssignment")
	public FileTypeAssignment getFileTypeAssignment() {
		return fileTypeAssignment;
	}
	public void setFileTypeAssignment(FileTypeAssignment fileTypeAssignment) {
		this.fileTypeAssignment = fileTypeAssignment;
	}
	
	
}
