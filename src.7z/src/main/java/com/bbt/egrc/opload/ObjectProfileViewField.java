package com.bbt.egrc.opload;

import javax.xml.bind.annotation.XmlAttribute;

public class ObjectProfileViewField {
	private String name;
	private String fieldGroup;
	private int displayOrder;
	private boolean isReadOnly;
	private boolean isVisible;
	private boolean isCompactMode;
	private int columnWidth;
	private String sectionName;
	
	@XmlAttribute(name="name",required=true)
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	@XmlAttribute(name="fieldGroup",required=true)
	public String getFieldGroup() {
		return fieldGroup;
	}
	public void setFieldGroup(String fieldGroup) {
		this.fieldGroup = fieldGroup;
	}
	
	@XmlAttribute(name="displayOrder",required=true)
	public int getDisplayOrder() {
		return displayOrder;
	}
	public void setDisplayOrder(int displayOrder) {
		this.displayOrder = displayOrder;
	}
	
	@XmlAttribute(name="isReadOnly",required=true)
	public boolean isReadOnly() {
		return isReadOnly;
	}
	public void setReadOnly(boolean isReadOnly) {
		this.isReadOnly = isReadOnly;
	}
	
	@XmlAttribute(name="isVisible",required=true)
	public boolean isVisible() {
		return isVisible;
	}
	public void setVisible(boolean isVisible) {
		this.isVisible = isVisible;
	}
	
	@XmlAttribute(name="isCompactMode",required=true)
	public boolean isCompactMode() {
		return isCompactMode;
	}
	public void setCompactMode(boolean isCompactMode) {
		this.isCompactMode = isCompactMode;
	}
	
	@XmlAttribute(name="columnWidth",required=true)
	public int getColumnWidth() {
		return columnWidth;
	}
	public void setColumnWidth(int columnWidth) {
		this.columnWidth = columnWidth;
	}
	
	@XmlAttribute(name="sectionName",required=true)
	public String getSectionName() {
		return sectionName;
	}
	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}
	
}
