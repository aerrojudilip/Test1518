package com.bbt.egrc.opload;

import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "bundleType")
public class BundleType {

	private String name;
	private String description;
	private String type="Content Type";
	private boolean suppliedByVendor=false;
	private List<PropertyType> propertyType = null;
	
	@XmlAttribute(name="name",required=true)
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	@XmlAttribute(name="description")
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	@XmlAttribute(name="type")
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	@XmlAttribute(name="suppliedByVendor")
	public boolean isSuppliedByVendor() {
		return suppliedByVendor;
	}
	public void setSuppliedByVendor(boolean suppliedByVendor) {
		this.suppliedByVendor = suppliedByVendor;
	}
	
	@XmlElement(name="propertyType")
	public List<PropertyType> getPropertyType() {
		return propertyType;
	}
	public void setPropertyType(List<PropertyType> propertyType) {
		this.propertyType = propertyType;
	}
	
	
	
}
