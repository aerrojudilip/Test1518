package com.bbt.egrc.opload;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;

public class InnerObjectProfileView {
	private ObjectProfileViewFilter objectProfileViewFilter;
	private List<ObjectProfileViewHierarchyPathList> objectProfileViewHierarchyPathList;
	private List<ObjectProfileViewField> objectProfileViewField;
	private List<ObjectProfileViewSection> objectProfileViewSection;
	private List<InnerObjectProfileViews> innerObjectProfileViews;
	
	@XmlElement(name="objectProfileViewFilter")
	public ObjectProfileViewFilter getObjectProfileViewFilter() {
		return objectProfileViewFilter;
	}
	public void setObjectProfileViewFilter(ObjectProfileViewFilter objectProfileViewFilter) {
		this.objectProfileViewFilter = objectProfileViewFilter;
	}
	
	@XmlElement(name="objectProfileViewHierarchyPathList")
	public List<ObjectProfileViewHierarchyPathList> getObjectProfileViewHierarchyPathList() {
		return objectProfileViewHierarchyPathList;
	}
	public void setObjectProfileViewHierarchyPathList(
			List<ObjectProfileViewHierarchyPathList> objectProfileViewHierarchyPathList) {
		this.objectProfileViewHierarchyPathList = objectProfileViewHierarchyPathList;
	}
	
	@XmlElement(name="objectProfileViewField")
	public List<ObjectProfileViewField> getObjectProfileViewField() {
		return objectProfileViewField;
	}
	public void setObjectProfileViewField(List<ObjectProfileViewField> objectProfileViewField) {
		this.objectProfileViewField = objectProfileViewField;
	}
	
	@XmlElement(name="objectProfileViewSection")
	public List<ObjectProfileViewSection> getObjectProfileViewSection() {
		return objectProfileViewSection;
	}
	public void setObjectProfileViewSection(List<ObjectProfileViewSection> objectProfileViewSection) {
		this.objectProfileViewSection = objectProfileViewSection;
	}
	
	@XmlElement(name="innerObjectProfileViews")
	public List<InnerObjectProfileViews> getInnerObjectProfileViews() {
		return innerObjectProfileViews;
	}
	public void setInnerObjectProfileViews(List<InnerObjectProfileViews> innerObjectProfileViews) {
		this.innerObjectProfileViews = innerObjectProfileViews;
	}
	
	
}
