package com.bbt.egrc.opload;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;


public class PropertyType {

	private String name;
	private String description;
	private String dataType;
	private String minValue;
	private String maxValue;
	private String defaultValue;
	private boolean required = false;
	private boolean encrypted = false;
	private String currencyCode;
	private boolean isDimension = false;
	private boolean isFact = false;
	private boolean multiValued = false;
	private boolean searchEnabled= true;
	private boolean includeConversion=true;
	private boolean suppliedByVendor =false;
	private String dataLength;
	private EnumType enumType;
	
	
	@XmlAttribute(name="name")
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	@XmlAttribute(name="description")
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	@XmlAttribute(name="dataType")
	public String getDataType() {
		return dataType;
	}
	public void setDataType(String dataType) {
		this.dataType = dataType;
	}
	
	@XmlAttribute(name="minValue")
	public String getMinValue() {
		return minValue;
	}
	public void setMinValue(String minValue) {
		this.minValue = minValue;
	}
	
	@XmlAttribute(name="maxValue")
	public String getMaxValue() {
		return maxValue;
	}
	public void setMaxValue(String maxValue) {
		this.maxValue = maxValue;
	}
	
	@XmlAttribute(name="defaultValue")
	public String getDefaultValue() {
		return defaultValue;
	}
	public void setDefaultValue(String defaultValue) {
		this.defaultValue = defaultValue;
	}
	
	@XmlAttribute(name="required")
	public boolean isRequired() {
		return required;
	}
	public void setRequired(boolean required) {
		this.required = required;
	}
	
	@XmlAttribute(name="encrypted")
	public boolean isEncrypted() {
		return encrypted;
	}
	public void setEncrypted(boolean encrypted) {
		this.encrypted = encrypted;
	}
	
	@XmlAttribute(name="currencyCode")
	public String getCurrencyCode() {
		return currencyCode;
	}
	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}
	
	@XmlAttribute(name="isDimension")
	public boolean isDimension() {
		return isDimension;
	}
	public void setDimension(boolean isDimension) {
		this.isDimension = isDimension;
	}
	
	@XmlAttribute(name="isFact")
	public boolean isFact() {
		return isFact;
	}
	public void setFact(boolean isFact) {
		this.isFact = isFact;
	}
	
	@XmlAttribute(name="multiValued")
	public boolean isMultiValued() {
		return multiValued;
	}
	public void setMultiValued(boolean multiValued) {
		this.multiValued = multiValued;
	}
	
	@XmlAttribute(name="searchEnabled")
	public boolean isSearchEnabled() {
		return searchEnabled;
	}
	public void setSearchEnabled(boolean searchEnabled) {
		this.searchEnabled = searchEnabled;
	}
	
	@XmlAttribute(name="includeConversion")
	public boolean isIncludeConversion() {
		return includeConversion;
	}
	public void setIncludeConversion(boolean includeConversion) {
		this.includeConversion = includeConversion;
	}
	
	@XmlAttribute(name="suppliedByVendor")
	public boolean isSuppliedByVendor() {
		return suppliedByVendor;
	}
	public void setSuppliedByVendor(boolean suppliedByVendor) {
		this.suppliedByVendor = suppliedByVendor;
	}
	
	@XmlAttribute(name="dataLength")
	public String getDataLength() {
		return dataLength;
	}
	public void setDataLength(String dataLength) {
		this.dataLength = dataLength;
	}
	
	@XmlElement(name="enumType")
	public EnumType getEnumType() {
		return enumType;
	}
	public void setEnumType(EnumType enumType) {
		this.enumType = enumType;
	}
	
	
	
}
