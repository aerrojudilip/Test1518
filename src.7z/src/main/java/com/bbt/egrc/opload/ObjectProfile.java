package com.bbt.egrc.opload;

import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

public class ObjectProfile {
	
	private String name;
	private String description;
	private boolean defaultSelection = false;
	private boolean fallback = false;
	private boolean enabled = true;
	private List<IncludedObjectType> includedObjectType;
	
	@XmlAttribute(name="name",required=true)
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	@XmlAttribute(name="description",required=true)
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	@XmlAttribute(name="defaultSelection",required=true)
	public boolean isDefaultSelection() {
		return defaultSelection;
	}
	public void setDefaultSelection(boolean defaultSelection) {
		this.defaultSelection = defaultSelection;
	}
	
	@XmlAttribute(name="fallback",required=true)
	public boolean isFallback() {
		return fallback;
	}
	public void setFallback(boolean fallback) {
		this.fallback = fallback;
	}
	
	@XmlAttribute(name="enabled",required=true)
	public boolean isEnabled() {
		return enabled;
	}
	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}
	
	@XmlElement(name="includedObjectType")
	public List<IncludedObjectType> getIncludedObjectType() {
		return includedObjectType;
	}
	public void setIncludedObjectType(List<IncludedObjectType> includedObjectType) {
		this.includedObjectType = includedObjectType;
	}
	
	
}
