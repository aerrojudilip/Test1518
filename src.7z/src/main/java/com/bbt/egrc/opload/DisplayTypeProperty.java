package com.bbt.egrc.opload;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

public class DisplayTypeProperty {

	private String name;
	private DisplayTypePropertyValue displayTypePropertyValue;
	
	@XmlAttribute(name="name")
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	@XmlElement(name="displayTypePropertyValue")
	public DisplayTypePropertyValue getDisplayTypePropertyValue() {
		return displayTypePropertyValue;
	}
	public void setDisplayTypePropertyValue(DisplayTypePropertyValue displayTypePropertyValue) {
		this.displayTypePropertyValue = displayTypePropertyValue;
	}
	
	
}
