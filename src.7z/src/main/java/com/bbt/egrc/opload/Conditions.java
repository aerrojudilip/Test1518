package com.bbt.egrc.opload;

import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

public class Conditions 
{
	private String logicalOperator;
	private String contentType;
	private List<ConditionGroup> conditionGroup;
	
	@XmlAttribute(name="logicalOperator",required=true)
	public String getLogicalOperator() {
		return logicalOperator;
	}
	public void setLogicalOperator(String logicalOperator) {
		this.logicalOperator = logicalOperator;
	}
	
	@XmlAttribute(name="contentType",required=true)
	public String getContentType() {
		return contentType;
	}
	public void setContentType(String contentType) {
		this.contentType = contentType;
	}
	
	@XmlElement(name="conditionGroup")
	public List<ConditionGroup> getConditionGroup() {
		return conditionGroup;
	}
	public void setConditionGroup(List<ConditionGroup> conditionGroup) {
		this.conditionGroup = conditionGroup;
	}
	
	
}
