package com.bbt.egrc.opload;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;

public class Dependencies {

	private List<DependencySet> dependencySet;

	@XmlElement(name="dependencySet")
	public List<DependencySet> getDependencySet() {
		return dependencySet;
	}

	public void setDependencySet(List<DependencySet> dependencySet) {
		this.dependencySet = dependencySet;
	}
	
	
}
