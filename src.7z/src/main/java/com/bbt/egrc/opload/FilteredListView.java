package com.bbt.egrc.opload;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;

public class FilteredListView {

	private List<AssociatedQueryDefinition> associatedQueryDefinition;

	@XmlElement(name="associatedQueryDefinition")
	public List<AssociatedQueryDefinition> getAssociatedQueryDefinition() {
		return associatedQueryDefinition;
	}

	public void setAssociatedQueryDefinition(List<AssociatedQueryDefinition> associatedQueryDefinition) {
		this.associatedQueryDefinition = associatedQueryDefinition;
	}
	
	
}
