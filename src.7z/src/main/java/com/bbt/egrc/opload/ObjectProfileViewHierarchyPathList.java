package com.bbt.egrc.opload;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;

public class ObjectProfileViewHierarchyPathList {
	private List<ObjectProfileViewHierarchyPath> objectProfileViewHierarchyPath;

	@XmlElement(name="objectProfileViewHierarchyPath")
	public List<ObjectProfileViewHierarchyPath> getObjectProfileViewHierarchyPath() {
		return objectProfileViewHierarchyPath;
	}

	public void setObjectProfileViewHierarchyPath(List<ObjectProfileViewHierarchyPath> objectProfileViewHierarchyPath) {
		this.objectProfileViewHierarchyPath = objectProfileViewHierarchyPath;
	}
	
}
