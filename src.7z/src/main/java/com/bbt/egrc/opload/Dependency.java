package com.bbt.egrc.opload;

import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

public class Dependency {
	
	private boolean enabled = true;
	private boolean suppliedByVendor = false;
	private List<Controllers> controllers;
	private List<Dependents> dependents;
	
	
	@XmlAttribute(name="enabled")
	public boolean isEnabled() {
		return enabled;
	}
	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}
	
	@XmlAttribute(name="suppliedByVendor")
	public boolean isSuppliedByVendor() {
		return suppliedByVendor;
	}
	public void setSuppliedByVendor(boolean suppliedByVendor) {
		this.suppliedByVendor = suppliedByVendor;
	}
	
	@XmlElement(name="controllers")
	public List<Controllers> getControllers() {
		return controllers;
	}
	public void setControllers(List<Controllers> controllers) {
		this.controllers = controllers;
	}
	
	@XmlElement(name="dependents")
	public List<Dependents> getDependents() {
		return dependents;
	}
	public void setDependents(List<Dependents> dependents) {
		this.dependents = dependents;
	}
	
	

}
