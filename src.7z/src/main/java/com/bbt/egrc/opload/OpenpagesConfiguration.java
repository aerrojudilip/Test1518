package com.bbt.egrc.opload;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlRootElement(name="openpagesConfiguration")
@XmlType(propOrder={"systemAdminMode","systemInformation","fileTypes",
					"bundleTypes","nonFormBasedResources",
					"jspBasedContentTypes","contentTypeRelationshipSets",
					"queryDefinitions","objectProfiles","dependencies",
					"dependentPicklists","objectProfileViewsSet","registry","objectStrings"})
public class OpenpagesConfiguration {

		private SystemAdminMode systemAdminMode;
		private SystemInformation systemInformation;
		private FileTypes fileTypes;
		private BundleTypes bundleTypes;
		private NonFormBasedResources nonFormBasedResources;
		private JspBasedContentTypes jspBasedContentTypes;
		private ContentTypeRelationshipSets contentTypeRelationshipSets;
		private QueryDefinitions queryDefinitions;
		private ObjectProfiles objectProfiles;
		private Dependencies dependencies;
		private DependentPicklists dependentPicklists;
		private ObjectProfileViewsSet objectProfileViewsSet;
		private ObjRegistry registry;
		private ObjectStrings objectStrings;
		@XmlElement(name="systemAdminMode")
		public SystemAdminMode getSystemAdminMode() {
			return systemAdminMode;
		}
		public void setSystemAdminMode(SystemAdminMode systemAdminMode) {
			this.systemAdminMode = systemAdminMode;
		}
		
		@XmlElement(name="systemInformation")
		public SystemInformation getSystemInformation() {
			return systemInformation;
		}
		public void setSystemInformation(SystemInformation systemInformation) {
			this.systemInformation = systemInformation;
		}
		@XmlElement(name="bundleTypes")
		public BundleTypes getBundleTypes() {
			return bundleTypes;
		}
		public void setBundleTypes(BundleTypes bundleTypes) {
			this.bundleTypes = bundleTypes;
		}

		@XmlElement(name="nonFormBasedResources")
		public NonFormBasedResources getNonFormBasedResources() {
			return nonFormBasedResources;
		}
		public void setNonFormBasedResources(NonFormBasedResources nonFormBasedResources) {
			this.nonFormBasedResources = nonFormBasedResources;
		}
		
		@XmlElement(name="jspBasedContentTypes")
		public JspBasedContentTypes getJspBasedContentTypes() {
			return jspBasedContentTypes;
		}
		public void setJspBasedContentTypes(JspBasedContentTypes jspBasedContentTypes) {
			this.jspBasedContentTypes = jspBasedContentTypes;
		}
		
		@XmlElement(name="contentTypeRelationshipSets")
		public ContentTypeRelationshipSets getContentTypeRelationshipSets() {
			return contentTypeRelationshipSets;
		}
		public void setContentTypeRelationshipSets(ContentTypeRelationshipSets contentTypeRelationshipSets) {
			this.contentTypeRelationshipSets = contentTypeRelationshipSets;
		}
		
		@XmlElement(name="queryDefinitions")
		public QueryDefinitions getQueryDefinitions() {
			return queryDefinitions;
		}
		public void setQueryDefinitions(QueryDefinitions queryDefinitions) {
			this.queryDefinitions = queryDefinitions;
		}
		
		@XmlElement(name="objectProfiles")
		public ObjectProfiles getObjectProfiles() {
			return objectProfiles;
		}
		public void setObjectProfiles(ObjectProfiles objectProfiles) {
			this.objectProfiles = objectProfiles;
		}
		
		@XmlElement(name="dependencies")
		public Dependencies getDependencies() {
			return dependencies;
		}
		public void setDependencies(Dependencies dependencies) {
			this.dependencies = dependencies;
		}
		
		@XmlElement(name="dependentPicklists")
		public DependentPicklists getDependentPicklists() {
			return dependentPicklists;
		}
		public void setDependentPicklists(DependentPicklists dependentPicklists) {
			this.dependentPicklists = dependentPicklists;
		}
		
		@XmlElement(name="objectProfileViewsSet")
		public ObjectProfileViewsSet getObjectProfileViewsSet() {
			return objectProfileViewsSet;
		}
		public void setObjectProfileViewsSet(ObjectProfileViewsSet objectProfileViewsSet) {
			this.objectProfileViewsSet = objectProfileViewsSet;
		}
		
		@XmlElement(name="fileTypes")
		public FileTypes getFileTypes() {
			return fileTypes;
		}
		public void setFileTypes(FileTypes fileTypes) {
			this.fileTypes = fileTypes;
		}
		
		@XmlElement(name="registry")
		public ObjRegistry getRegistry() {
			return registry;
		}
		public void setRegistry(ObjRegistry registry) {
			this.registry = registry;
		}
		
		@XmlElement(name="objectStrings")
		public ObjectStrings getObjectStrings() {
			return objectStrings;
		}
		public void setObjectStrings(ObjectStrings objectStrings) {
			this.objectStrings = objectStrings;
		}
		
		
		
}
