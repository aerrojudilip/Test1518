package com.bbt.egrc.opload;

import java.util.List;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;

public class ContentTypeRelationshipSet {

		private String name;
		private String inheritsFrom;
		private List<ContentTypeRelationship> contentTypeRelationship;
		
		@XmlAttribute(name="name",required=true)
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		
		@XmlAttribute(name="inheritsFrom")
		public String getInheritsFrom() {
			return inheritsFrom;
		}
		public void setInheritsFrom(String inheritsFrom) {
			this.inheritsFrom = inheritsFrom;
		}
		
		@XmlElement(name="contentTypeRelationship")
		public List<ContentTypeRelationship> getContentTypeRelationship() {
			return contentTypeRelationship;
		}
		public void setContentTypeRelationship(List<ContentTypeRelationship> contentTypeRelationship) {
			this.contentTypeRelationship = contentTypeRelationship;
		}
		
		
}
