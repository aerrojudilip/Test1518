import java.io.FileInputStream;
import java.util.Enumeration;
import java.util.Properties;

import com.openpages.aurora.common.objectid.EncryptionKeyId;
import com.openpages.aurora.common.valueobject.EncryptionModuleVO;
import com.openpages.aurora.service.security.KeyStoreUtil;
import com.openpages.aurora.service.security.helper.PasswordEncryptor;
import com.openpages.aurora.service.util.ConfigurationUtil;

public class BBTCustomRegistry {

	
	private static String CONFIG_FILE_PATH = null;
	private Properties users = new Properties();
	
	public static void main(String[] args) throws Exception {
		BBTCustomRegistry bbtCustomRegistry = new BBTCustomRegistry();
		if(args.length!=1)
		{
			System.out.println(PasswordEncryptor.encrypt("OpenPagesAdministrator",bbtCustomRegistry.getEncryptionModuleVO()));
			System.err.println("File Path need to be specified");
		}
		else
		{
			CONFIG_FILE_PATH = args[0];
			bbtCustomRegistry.doEncrypt();
			System.out.println(ConfigurationUtil.encrypt("OpenPagesAdministrator", KeyStoreUtil.getKeyStoreProperties()));
		}
	}
	public void doEncrypt() throws Exception
	{
		this.users.load(new FileInputStream(CONFIG_FILE_PATH));
		Enumeration propNames = this.users.propertyNames();
		boolean isChanged = false;
	    while (propNames.hasMoreElements())
	    {
	    	String name = (String)propNames.nextElement();
	        String value = this.users.getProperty(name);
	    }
	}
	
	public EncryptionModuleVO getEncryptionModuleVO()
	{
		EncryptionModuleVO vo = new EncryptionModuleVO();
		vo.setAlgorithmName("AES");
		vo.setAlgorithmParams("BBBreUlIWUE2OW42dlBRelR3");
		EncryptionKeyId encryptionKeyId = new EncryptionKeyId(1l);
		vo.setEncryptionKeyId(encryptionKeyId);
		vo.setModuleName("PASSWORD_ENCRYPTION_MODULE");
		vo.setProviderClass("org.bouncycastle145.jce.provider.BouncyCastleProvider");
		vo.setProviderName("CAMCryptoBC");
		return vo;
	}
	  
}
