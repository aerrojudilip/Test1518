import java.io.File;
import java.io.FileInputStream;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class RoleTemplate {

	private static final String FILE_NAME = "\\\\WIL-HOMEDRIVE03\\D15051$\\Desktop\\Role_Templates.xlsx";
	private static final String INDEX = "Index";


	public static void main(String[] args) throws Exception {

		FileInputStream fileInputStream = new FileInputStream(new File(FILE_NAME));
		Workbook workbook = new XSSFWorkbook(fileInputStream);
		Sheet indexSheet = workbook.getSheet(INDEX);
		Iterator<Row> rows  = indexSheet.iterator();
		int count=0;
		
		while(rows.hasNext())
		{
			Row currentRow = rows.next();
			if(count>0)
			{
				Iterator<Cell> cells = currentRow.iterator();
				int columnCount=0;
				while(cells.hasNext())
				{
					Cell currentCell = cells.next();
					if(columnCount==0)
					{
						System.out.println("Name : "+currentCell.getStringCellValue().trim());
					}
					else if(columnCount==1)
					{
						System.out.println("Description : "+currentCell.getStringCellValue().trim());
					}
					columnCount++;
				}
			}
			count++;
		}
	}
	

}
