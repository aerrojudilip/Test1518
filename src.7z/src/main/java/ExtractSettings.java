import java.io.File;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import com.bbt.egrc.opload.ObjRegistry;
import com.bbt.egrc.opload.OpenpagesConfiguration;

public class ExtractSettings {

	public static void main(String[] args) throws Exception {
		File file = new File("C:\\OpenPages\\AFCON\\Config_Jun14-op-config.xml");
		JAXBContext jaxbContext = JAXBContext.newInstance(OpenpagesConfiguration.class);
		Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
		OpenpagesConfiguration configuration = (OpenpagesConfiguration) jaxbUnmarshaller.unmarshal(file);
		ObjRegistry registry = configuration.getRegistry();
		//System.out.println(registry.getEntries());
		Marshaller marshaller = jaxbContext.createMarshaller();
		marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		marshaller.marshal(registry, System.out);
	}
}
