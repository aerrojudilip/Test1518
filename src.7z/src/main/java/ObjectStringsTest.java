import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import com.bbt.egrc.opload.EnumValueString;
import com.bbt.egrc.opload.LocaleStrings;
import com.bbt.egrc.opload.ObjectStrings;
import com.bbt.egrc.opload.ObjectTypeString;
import com.bbt.egrc.opload.OpenpagesConfiguration;

public class ObjectStringsTest 
{
	public static void main(String[] args) throws Exception
	{
		File file = new File("C:\\OpenPages\\AFCON\\Iteration-2\\BBT_01_02_02\\loader-data\\Schema\\BBT_Master_7_3_0_object-strings-op-config.xml");
		File output = new File("localeStrings-op-config.xml");
		JAXBContext jaxbContext = JAXBContext.newInstance(OpenpagesConfiguration.class);
		Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
		OpenpagesConfiguration configuration = (OpenpagesConfiguration) jaxbUnmarshaller.unmarshal(file);
		ObjectStrings objectStrings = configuration.getObjectStrings();
		List<EnumValueString> enumValueStrings = new ArrayList<EnumValueString>();
		for(LocaleStrings localeStrings : objectStrings.getLocaleStrings() )
		{
			for(EnumValueString enumValueString :  localeStrings.getEnumValueString())
			{
				if(!(enumValueString.getFieldGroup().equalsIgnoreCase("BBT-Shr-Ctrl") 
						||enumValueString.getFieldGroup().equalsIgnoreCase("BBT-Shr-Prcs")
							|| enumValueString.getFieldGroup().equalsIgnoreCase("BBT-Shr-Rsk")))
				{
					enumValueStrings.add(enumValueString);
				}
			}
			localeStrings.setEnumValueString(enumValueStrings);
		}
		Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
		jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		jaxbMarshaller.marshal(objectStrings, System.out);
		jaxbMarshaller.marshal(objectStrings, output);
	}
}
