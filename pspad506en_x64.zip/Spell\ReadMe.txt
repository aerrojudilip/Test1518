Folder for dictionary files (*.DIC)
Download dictionary from PSPad download page and extract it from CAB archive.
--------------------------------------------------------------------------------
Slo�ka pro soubory slovn�k� pro kontrolu pravopisu (*.DIC)
St�hn�te si slovn�k ze str�nek PSPadu a rozbalte z CAB archivu
