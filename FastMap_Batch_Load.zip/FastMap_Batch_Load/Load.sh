#!/bin/ksh

#=====================================================================
#Licensed Materials - Property of IBM

#5725-D51, 5725-D52, 5725-D53, 5725-D54

#� Copyright IBM Corporation 2012. All Rights Reserved.

#US Government Users Restricted Rights- Use, duplication or 
#disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#======================================================================


env_variables_file="./Environment_Variables.sh"
object_manager_file="./ObjectManager.sh"

. $env_variables_file

load_type=Fastmap_Batch_Load
log_file="./"$load_type"_Load.log"
loader_data_folder=$(pwd)

# check for openpages/bin directory
ls -l $openpages_domain_folder > /dev/null 2>&1

if [[ $? -ne 0 ]]; then
	print "The openpages_domain_folder is incorrect. Please open the $env_variables_file file in a text editor, and edit the openpages_domain_folder variable to match the location of the OpenPages bin folder on your application server."
else
	cd $openpages_domain_folder
	
	#check for objectmanager.sh file
	ls -l $object_manager_file > /dev/null 2>&1
	if [[ $? -ne 0 ]]; then
		print "ObjectManager could not be found in $openpages_domain_folder. Please open the $env_variables_file file in a text editor, and make sure the openpages_domain_folder variable correctly points to the location of the OpenPages bin folder on your application server."
	else
	
		#load the files
		print "Loading "$load_type"..."
		./ObjectManager.sh b c $login_username $login_password $loader_data_folder "${loader_data_folder}/${loader_list_file}" > "${loader_data_folder}/${log_file}" 2>&1
	
		#check log file for errors
		grep -q "ERROR" "${loader_data_folder}/${log_file}"
		if [[ $? -eq 0 ]]; then
			print "Errors occurred!  Please see $log_file for more information."
		else
			grep -q "EXCEPTION" "${loader_data_folder}/${log_file}"
			
			if [[ $? -eq 0 ]]; then
				print "Errors occurred!  Please see $log_file for more information."
			else
				print "Done!  No errors were detected."
			fi
		fi
	fi
fi

cd $loader_data_folder
