#!/bin/ksh

#=====================================================================
#Licensed Materials - Property of IBM

#5725-D51, 5725-D52, 5725-D53, 5725-D54

#� Copyright IBM Corporation 2018. All Rights Reserved.

#US Government Users Restricted Rights- Use, duplication or
#disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#======================================================================

notification_manager_folder="/home/opuser/OP/OpenPages/bin"
username="OpenPagesAdministrator"
password="passw0rd"

# ==================================================================
# ===================== EDIT VALUES ABOVE HERE =====================
# ==================================================================

report_folder="Reporting/Hidden Reports/Fastmap Batch Job/Fastmap Batch Job"

log_file="Fastmap Batch Scheduler.log"

loader_data_folder="$(pwd)"

cd $notification_manager_folder


# -------------
# Run Notifications
# -------------
print "Executing Fastmap Batch job..."
./NotificationManager.sh -Username ${username} -Password ${password} -NotificationProgram "${report_folder}" -SaveOutput true -LogSession true >"${loader_data_folder}/${log_file}"
# 2>&1


cd $loader_data_folder
print "Done Batch job..."
